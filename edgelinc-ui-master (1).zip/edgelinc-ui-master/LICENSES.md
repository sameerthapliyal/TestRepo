
### new-webui (Responsive UI) ###

| Library                       | Version | License      | Modified by Proximetry | Modified Files                                                       | Dependencies          |
|-------------------------------|---------|--------------|------------------------|----------------------------------------------------------------------|-----------------------|
| compression                   | ^1.6.2  | MIT          | NO                     | N/A                                                                  | dependencies          |
| express                       | 4.13.4  | MIT          | NO                     | N/A                                                                  | dependencies          |
| file-saver                    | ^1.2.2  | MIT          | NO                     | N/A                                                                  | dependencies          |
| http-proxy-middleware         | ^0.14.0 | MIT          | NO                     | N/A                                                                  | dependencies          |
| lodash                        | ^4.14.0 | MIT          | NO                     | N/A                                                                  | dependencies          |
| underscore                    | ^1.8.3  | MIT          | NO                     | N/A                                                                  | dependencies          |
| when                          | ^3.7.7  | MIT          | NO                     | N/A                                                                  | dependencies          |
| yargs                         | ^3.31.0 | MIT/X11      | NO                     | N/A                                                                  | dependencies          |
| bootstrap-sass                | ^3.3.7  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| bower                         | ^1.7.9  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| browser-sync                  | ^2.7.7  | Apache 2.0   | NO                     | N/A                                                                  | dev-dependencies      |
| browserslist                  | ^1.4.0  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| del                           | ^2.0.2  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| fs-extra                      | ^0.30.0 | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp                          | ^3.9.0  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-angular-templatecache    | ^2.0.0  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-autoprefixer             | ^3.1.1  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-clean-css                | ^2.2.0  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-copy                     | 0.0.2   | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-debug                    | ^2.1.2  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-dedupe                   | 0.0.2   | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-flatmap                  | ^1.0.0  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-git                      | ^1.6.0  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-html-src                 | ^1.0.0  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-if                       | ^2.0.0  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-ignore                   | ^2.0.1  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-jspm-build               | 0.0.15  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-less                     | ^3.0.5  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-replace                  | ^0.5.4  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-sass                     | ^2.3.2  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-sourcemaps               | ^1.6.0  | ISC          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-tslint                   | 3.6.0   | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-typescript               | 2.12.2  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-uglify                   | ^1.5.3  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| gulp-watch                    | ^4.3.5  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| jasmine-core                  | ^2.3.4  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| jspm                          | 0.16.39 | Apache 2.0   | YES                    | cli.js, lib/config.js                                                | dev-dependencies      |
| karma                         | ~0.12   | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| karma-chrome-launcher         | ^0.1.12 | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| karma-firefox-launcher        | ^0.1.6  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| karma-jasmine                 | ^0.3.5  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| karma-junit-reporter          | ^0.2.2  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| lazypipe                      | ^1.0.1  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| merge2                        | ^0.3.6  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| node-sass                     | ^3.13.0 | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| protractor                    | ^2.1.0  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| run-sequence                  | ^1.1.4  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| through2                      | ^2.0.1  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| typings                       | ^0.7.12 | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| vinyl-fs                      | ^2.4.3  | MIT          | NO                     | N/A                                                                  | dev-dependencies      |
| angular                       | 1.5.10  | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-animate               | 1.5.3   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-bootstrap             | 1.3.2   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-drag-and-drop-lists   | 1.4.0   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-http-auth             | 1.3.0   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-leaflet-directive     | ^0.10.0 | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-messages              | 1.5.3   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-mocks                 | 1.5.3   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-route                 | 1.5.3   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-sanitize              | 1.5.3   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-smart-table           | 2.1.7   | MIT          | YES                    | dist/smart-table.js, src/smart-table.module.js,  src/stPagination.js | jspm dependencies     |
| angular-translate             | ^2.11.1 | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-translate-handler-log | ^2.11.1 | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-translate-loader-url  | ^2.11.1 | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-ui-switch             | 0.1.1   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| bootstrap-sass                | ^3.3.7  | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| angular-ui/ui-mask            | ^1.8.7  | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| d3                            | 3.5.16  | BSD-3-Clause | NO                     | N/A                                                                  | jspm dependencies     |
| filesaver                     | 1.3.0   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| handlebars                    | 4.0.5   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| leaflet                       | 0.7.7   |              | NO                     | N/A                                                                  | jspm dependencies     |
| leaflet.markercluster         | 0.5.0   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| lodash                        | ^4.15.0 | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| ng-tags-input-custom          | 3.1.1.  | MIT          | YES                    | ngTagsInput/build/ng-tags-input.js                                   | jspm dependencies     |
| ngSticky                      | 1.8.10  | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| oclazyload                    | 1.0.9   | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| underscore                    | ^1.8.3  | MIT          | NO                     | N/A                                                                  | jspm dependencies     |
| zip                           | N/A     | BSD          | NO                     | N/A                                                                  | jspm dependencies     |
| typescript                    | ^1.6.2  | Apache 2.0   | NO                     | N/A                                                                  | jspm dev-dependencies |
| jssha                         | 0.6.0   | MIT          | NO                     | N/A                                                                  | dependencies          |

### rcs ###

| Library  | Version | License | Modified by Proximetry | Modified Files | Dependencies     |
|----------|---------|---------|------------------------|----------------|------------------|
| ssh2     | 0.5.0   | MIT     | NO                     | N/A            | dependencies     |
| ws       | 1.0.1   | MIT     | NO                     | N/A            | dependencies     |
| fs-extra | ^0.30.0 | MIT     | NO                     | N/A            | dev-dependencies |

## gcs ###

| Library               | Version | License       | Modified by Proximetry | Modified Files | Dependencies     |
|-----------------------|---------|---------------|------------------------|----------------|------------------|
| body-parser           | ^1.15.0 | MIT           | NO                     | N/A            | dependencies     |
| cors                  | ^2.8.1  | MIT           | NO                     | N/A            | dependencies     |
| express               | ^4.13.4 | MIT           | NO                     | N/A            | dependencies     |
| express-promise       | ^0.4.0  | MIT           | NO                     | N/A            | dependencies     |
| js-yaml               | ^3.7.0  | MIT           | NO                     | N/A            | dependencies     |
| lodash                | ^4.17.2 | MIT           | NO                     | N/A            | dependencies     |
| ngeohash              | ^0.6.0  | MIT           | NO                     | N/A            | dependencies     |
| request               | ^2.79.0 | Apache 2.0    | NO                     | N/A            | dependencies     |
| request-debug         | ^0.2.0  | MIT           | NO                     | N/A            | dependencies     |
| request-promise       | ^4.1.1  | ISC           | NO                     | N/A            | dependencies     |
| swagger-tools         | ^0.10.1 | MIT           | NO                     | N/A            | dependencies     |
| tv4                   | ^1.2.7  | Public Domain | NO                     | N/A            | dependencies     |
| when                  | ^3.7.7  | MIT           | NO                     | N/A            | dependencies     |
| chai                  | ^3.5.0  | MIT           | NO                     | N/A            | dev-dependencies |
| copy                  | ^0.3.0  | MIT           | NO                     | N/A            | dev-dependencies |
| mocha                 | ^3.2.0  | MIT           | NO                     | N/A            | dev-dependencies |
| mocha-junit-reporter  | ^1.13.0 | MIT           | NO                     | N/A            | dev-dependencies |
| mocha-multi-reporters | ^1.1.3  | MIT           | NO                     | N/A            | dev-dependencies |
| nyc                   | ^10.1.2 | ISC           | NO                     | N/A            | dev-dependencies |

### dds-ui ###

| Library     | Version | License | Modified by Proximetry | Modified Files | Dependencies    |
|-------------|---------|---------|------------------------|----------------|-----------------|
| bower       | ^1.3.1  |         | NO                     | N/A            | devDependencies |
| http-server | ^0.6.1  |         | NO                     | N/A            | devDependencies |
| underscore  | *       |         | NO                     | N/A            | devDependencies |

### dds ###

| Library          | Version | License | Modified by Proximetry | Modified Files | Dependencies     |
|------------------|---------|---------|------------------------|----------------|------------------|
| async            | 1.5.2   | MIT     | NO                     | N/A            | dependencies     |
| body-parser      | 1.15.2  | MIT     | NO                     | N/A            | dependencies     |
| cookie-parser    | 1.4.3   | MIT     | NO                     | N/A            | dependencies     |
| express          | 4.14.0  | MIT     | NO                     | N/A            | dependencies     |
| is-my-json-valid | 2.15.0  | MIT     | NO                     | N/A            | dependencies     |
| lodash           | 4.17.2  | MIT     | NO                     | N/A            | dependencies     |
| underscore       | 1.8.3   | MIT     | NO                     | N/A            | dependencies     |
| unirest          | 0.4.2   | MIT     | NO                     | N/A            | dependencies     |
| fs-extra         | ^0.30.0 | MIT     | NO                     | N/A            | dev-dependencies |

### agent_sdk-http-javascript ###

| Library       | Version  | License       | Modified by Proximetry | Modified Files | Dependencies |
|---------------|----------|---------------|------------------------|----------------|--------------|
| body-parser   | ^1.15.1  | MIT           | NO                     | N/A            | dependencies |
| cors          | ^2.8.1   | MIT           | NO                     | N/A            | dependencies |
| express       | ^4.13.4  | MIT           | NO                     | N/A            | dependencies |
| ini           | ~1.3.0   | ISC           | NO                     | N/A            | dependencies |
| js-yaml       | ^3.7.0   | MIT           | NO                     | N/A            | dependencies |
| log4js-config | >= 0.1.0 | Apache 2.0    | NO                     | N/A            | dependencies |
| request       | 2.40.0   | Apache 2.0    | NO                     | N/A            | dependencies |
| sync          | ~0.2.5   | MIT           | NO                     | N/A            | dependencies |
| tv4           | ~1.1.0   | Public Domain | NO                     | N/A            | dependencies |
| underscore    | ~1.8.3   | MIT           | NO                     | N/A            | dependencies |
| xml2js        | ~0.4.10  | MIT           | NO                     | N/A            | dependencies |

### node-configurator ###

| Library | Version | License | Modified by Proximetry | Modified Files | Dependencies |
|---------|---------|---------|------------------------|----------------|--------------|
| js-yaml | 3.6.1   | MIT     | NO                     | N/A            | dependencies |
| lodash  | 4.15.0  | MIT     | NO                     | N/A            | dependencies |
| yargs   | 4.8.1   | MIT/X11 | NO                     | N/A            | dependencies |

### node-security ###

| Library      | Version | License | Modified by Proximetry | Modified Files | Dependencies |
|--------------|---------|---------|------------------------|----------------|--------------|
| lodash       | 4.15.0  | MIT     | NO                     | N/A            | dependencies |
| jsonwebtoken | 7.1.9   | MIT     | NO                     | N/A            | dependencies |

### node-logging ###

| Library | Version | License    | Modified by Proximetry | Modified Files | Dependencies |
|---------|---------|------------|------------------------|----------------|--------------|
| log4js  | 0.6.36  | Apache 2.0 | NO                     | N/A            | dependencies |

### node-messaging ###

| Library | Version | License    | Modified by Proximetry | Modified Files | Dependencies |
|---------|---------|------------|------------------------|----------------|--------------|
| amqplib | 0.4.2   | MIT        | NO                     | N/A            | dependencies |
| thrift  | 0.9.2   | Apache 2.0 | NO                     | N/A            | dependencies |
| lodash  | 4.15.0  | MIT        | NO                     | N/A            | dependencies |

### gvs ###

| Library | Version | License | Modified by Proximetry | Modified Files | Dependencies |
|-------------|---------|------------|------------------------|----------------|------------------|
| amqplib | 0.4.2 | MIT | NO | N/A | dependencies |
| async | ^1.5.2 | MIT | NO | N/A | dependencies |
| body-parser | ^1.15.2 | MIT | NO | N/A | dependencies |
| express | ^4.14.0 | MIT | NO | N/A | dependencies |
| thrift | 0.9.2 | Apache 2.0 | NO | N/A | dependencies |
| underscore | 1.8.3 | MIT | NO | N/A | dependencies |
| fs-extra | ^0.30.0 | MIT | NO | N/A | dev-dependencies |
