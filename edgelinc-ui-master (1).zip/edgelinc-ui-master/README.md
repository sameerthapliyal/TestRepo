# Responsible UI

## [Description](#description)
Front-end for the AirSync system.

## [Dependencies](#dependencies)
  - EAPI - main entry to the system; always required
  - RCS - required for SSH access view (GEL)
  - A2PP - required for Predix integration views (GER)

## [Status](#status)
  - *Deployed*: In production
  - *Stability*: Stable
  - *Scalability*: Scalable

## [Customers](#customers)
  - GER