/**
 * Created by rwitczak on 2016-03-29.
 */
declare module App.Models {
    export interface SearchResult<T> {
        items: T[],
        totalCount: number;
    }
}