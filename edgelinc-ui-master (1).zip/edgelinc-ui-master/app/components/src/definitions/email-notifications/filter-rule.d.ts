﻿declare module models.emailNotifications {
    export interface FilterRule {
        name: string;
        description?: string;
        systemNames?: string[];
        deviceIds?: string[];
        deviceNames?: string[];
        deviceTypes?: string[];
        maxAlertSeverity?: string;
        emailLists: string[];
        isEnabled: boolean;
    }
}