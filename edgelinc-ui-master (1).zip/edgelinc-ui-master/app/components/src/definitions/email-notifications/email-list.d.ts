﻿declare module models.emailNotifications {
    export interface EmailList {
        name: string;
        description?: string;
        to: string[];
        cc?: string[];
        from?: string;
        subject?: string;
        interval?: number;
    }
}