export interface ITokenInfo {
    jti: string;
    sub: string;
    scope: string[];
    client_id: string;
    cid: string;
    azp: string;
    grant_type: string;
    user_id: string;
    user_name: string;
    email: string;
    rev_sig: string;
    iat: number;
    exp: number;
    iss: string;
    zid: string;
    aud: string[];
}