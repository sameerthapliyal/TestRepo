export interface ITokenResponse {
    access_token: string;
    expires_in: number;
    expires_at: number; // generated in code
    jti: string;
    refresh_token: string;
    scope: string;
    token_type: string;
}