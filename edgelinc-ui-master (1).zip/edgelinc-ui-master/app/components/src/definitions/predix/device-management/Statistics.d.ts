export interface Statistics {
    name: string;
    statID: string;
    value: string;
}