export interface BatchDeleteOperationStatus {
    success: boolean;
    message: string;
}

export type BatchDeleteResponse = {[did: string]: BatchDeleteOperationStatus};