import {Status} from "./Status";
import {Attributes} from "./Attributes";
import {AlertSummary} from "./AlertSummary";
import {Statistics} from "./Statistics";


export interface Device {
    alert: AlertSummary;
    asdid: string;
    attributes: Attributes;
    device_model_id: string;
    device_model_name: string;
    device_model_version: string;
    did: string;
    firmware:string;
    installationDate:string;
    manufacturer:string;
    name: string;
    osVersion:string;
    statisticsList: Statistics[];
    status: Status;
}