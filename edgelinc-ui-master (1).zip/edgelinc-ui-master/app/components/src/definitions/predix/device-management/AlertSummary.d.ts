export interface AlertSummary {
    lastTime: string;
    numberOfAlert: number;
}