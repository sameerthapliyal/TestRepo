export interface DeviceToAdd {
    did: string;
    groupId: string;
    modelID: string;
    modelIDVersion: string;
    name: string;
}

export type DevicesToAdd = DeviceToAdd[];