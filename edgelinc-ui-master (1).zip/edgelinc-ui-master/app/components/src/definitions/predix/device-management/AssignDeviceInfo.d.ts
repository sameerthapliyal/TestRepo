export interface AssignDeviceInfo {
    deviceList: string[];
    location: string;
}