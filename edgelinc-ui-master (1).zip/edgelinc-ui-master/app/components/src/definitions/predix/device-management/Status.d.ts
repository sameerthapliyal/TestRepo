export interface Status {
    "device_status": DeviceStatusEnum,
    "last_change": number,
}

export type DeviceStatusEnum = "Unreachable - Inventory" | "Unreachable - Enrolled" | "Reachable"