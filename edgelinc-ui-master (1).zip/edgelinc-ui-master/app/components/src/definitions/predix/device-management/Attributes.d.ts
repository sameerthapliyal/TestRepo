export interface Attributes {
    groupId: string;
    location: string;
    technicianId: string;
}