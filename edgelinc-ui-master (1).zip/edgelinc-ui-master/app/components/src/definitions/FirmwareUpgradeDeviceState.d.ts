/// <reference path="Device.d.ts" />

declare module App.Models {
    interface IFirmwareUpgradeDeviceState {
        device: IDevice;
        state: string;
        stateDisplayName: string;
    }
}