declare module App.Models {
    interface ISystem {
        asdid: string;
        name: string;
        did: string;
        numericDID: number;
        numericLocoId: number;
        deviceModel: IDeviceModelDefinition;
        status: IStatusDescription;
        attributes?: {[attrName:string]:string};
        parameters?: App.Models.EAPI.IParameterWithStatus[];
        statistics?:IDeviceStatisticsLastValue[];
        alarms?: App.Models.EAPI.IAlarm[];
        alarmCounters: {[severity: string]: number}
        location: {
            latitude: number;
            longitude: number
        };
        //totalAlerts: number;
        //activeDevices: number;
        //inactiveDevices: number;
        registrationDate: number;
        lastCommunication: number;
        additionalData: {[key: string]: any};
        aggregates: any;
        parameters_object: any;
        mcsParameters?: IMCSParameter
    }

    type IDeviceModelDefinition = eapi19.DeviceModelDefinition;

    export type IStatusDescription = app.branding.IDeviceStatus;

    export interface IMCSParameter {
        asset_type?: eapi19.Parameter,
        fleet?: eapi19.Parameter,
        manufacturer?: eapi19.Parameter,
        model?: eapi19.Parameter,
        controller_config?: eapi19.Parameter
    }

    interface IDeviceStatisticsLastValue{
        name: string;
        stat_id: string;
        value: number;
    }
}
