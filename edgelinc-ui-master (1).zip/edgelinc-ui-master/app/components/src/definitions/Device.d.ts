/// <reference path="DeviceModel.d.ts" />

declare module App.Models {
    interface IDevice {
        uuid: string;
        name: string;
        model: IDeviceModel;
        hasFirmwaresList: boolean;
    }
}