declare module App.Models.FirmwareUpgrade {
    interface IConnectedDeviceStatus {
        did: string;
        uuid: string;
        deviceModel: string;
        deviceModelName: string;
        runningFirmware: string;
        availableFirmware: string;
        state: string;
        active: string;
    }
}