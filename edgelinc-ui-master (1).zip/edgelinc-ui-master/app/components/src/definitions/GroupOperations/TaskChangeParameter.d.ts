/// <reference path="../../../../../typings/browser.d.ts" />
declare module models.GroupOperations {
    export interface TaskChangeParameter extends eapi17.IParameter{
        parameterName?:ng.IPromise<string>;
    }
}