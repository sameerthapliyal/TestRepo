﻿declare module models.GroupOperations {
    export interface ITaskItem {
        id: string,
        operation_id: string;
        asdid: string,
        //name: ng.IPromise<string>,
        //device: ng.IPromise<App.Models.EAPI.IDevice>,
        status: string,
        result?: string,
        configurationStatus: string,
        commandStatus: string,
        commandDetailedStatus?: string,
        installationStatus?:string,
        installation_result?:string,
        calculated_status?:string,
        cancel_status?:string,
        registration_status?:string;
        registration_result?:string;
        type?: string,
        data?:{[key:string]:any},
        end_ts?:number,
        start_ts?:number,
        create_ts?:number,
        change_ts?:number,
        details:any,
        groupOperation?: IGroupOperation,

        systemAsdid?: ng.IPromise<string>,
        //system?: ng.IPromise<eapi18.DeviceFromDSC>,
        systemName?: ng.IPromise<string>,
        description?:ng.IPromise<string>,
        device?: ng.IPromise<eapi18.DeviceFromDSC>
        task_details?:any
    }
}
