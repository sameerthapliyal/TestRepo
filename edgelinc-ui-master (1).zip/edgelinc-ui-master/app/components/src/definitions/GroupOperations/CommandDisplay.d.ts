/**
 * Created by rosadnik on 16-Jun-16.
 */
declare module models.GroupOperations {
    export interface ICommandDisplay extends eapi18.Command{
        commandParmas?:{
            paramName?:string;
            parmaCaption?:string;
            paramValue?: string;
            paramDisplayValue?: string;
            paramType?:string;
            paramSpecialFormat?:string;
        }[];
        commandDispalyName?:string
    }
}