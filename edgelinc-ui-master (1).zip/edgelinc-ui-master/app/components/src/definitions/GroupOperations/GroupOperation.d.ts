﻿/// <reference path="TaskItem.d.ts" />
/// <reference path="TaskChangeParameter.d.ts" />
/// <reference path="../../../../../typings/browser.d.ts" />
declare module models.GroupOperations {
    export interface IGroupOperation {
        id: string,
        type?: string,
        status: string,
        result?:string,
        createTs: number,
        startTs: number,
        endTs: number,
        changeTs: number,

        systemName?: ng.IPromise<string>,
        description?: ng.IPromise<string>,
        details?: any,
        items?: ITaskItem[],
        systemAsdid?: ng.IPromise<string>,
        system?: ng.IPromise<eapi18.Device>,
        parameters?: eapi17.IParameter[],
        command?: models.GroupOperations.ICommandDisplay,
        package?: any,
        devNamesMapping?: IGroupOperation_devNamesMapping
        ui_details?: any,
        detailsPromise?: ng.IPromise<eapi18.ParametersGroupOperationDetails | eapi18.CommandGroupOperationDetails | eapi18.PackageGroupOperationDetails>,
    }
    
    export interface IGroupOperation_devNamesMapping { [asdid: string]: {
        name: string,
        did: string,
        device_model_id: string,
        device_model_name: string,
        device_model_version: string,
        customer_id?:string;
        loco_id?:string;
        reporter_id?:string;
        missingDeviceData?:boolean;
        asdid?:string
    }}
}
