﻿declare module models.Commands {
    export interface ICommandParameter {
        /* old Command Parameter interface
        name: string;
        caption: string;
        placeholder?: string;
        defaultValue?: string;
        value?: string;
        type?: string;
        display_type?: string;
        options?: {};
        */
        //====== new Command Parameter interface
        name?: string;
        api_name: string;
        description?: string;
        value?:any;
        type?: string;
        special_format?: string;
        default_value?: any;
        required?: boolean;
        options?: {
            value:any,
            name:string
        }[];
        min?: number;
        max?: number;
        min_length?: number;
        max_length?: number;
        regex?:string;
        asterisk_mask?:boolean;
    }
}
