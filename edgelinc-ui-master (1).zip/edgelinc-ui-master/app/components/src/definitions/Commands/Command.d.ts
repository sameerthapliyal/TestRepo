﻿/// <reference path="CommandParameter.d.ts" />

declare module models.Commands {
    export interface ICommand {
        name: string;
        caption?: string;
        parameters?: ICommandParameter[];
        api_name: string;
    }
}
