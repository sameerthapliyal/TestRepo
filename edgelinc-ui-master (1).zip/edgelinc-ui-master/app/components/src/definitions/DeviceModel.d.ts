declare module App.Models {
    interface IDeviceModel {
        model: string;
        modelName: string;
        modelVersion?: string;
    }
}