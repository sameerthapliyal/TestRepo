declare module App.Models {
    interface IFirmware {
        id: string;
        deviceModel: string;
        firmwareVersion: string;
        firmwareSize: string;
        description: string;
        armed: string;
    }
}