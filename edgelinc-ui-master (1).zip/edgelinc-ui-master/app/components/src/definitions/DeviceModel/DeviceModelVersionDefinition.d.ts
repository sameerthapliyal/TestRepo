declare module Models.DeviceModel {
    export type IDeviceModelVersionDefinition = any;
}