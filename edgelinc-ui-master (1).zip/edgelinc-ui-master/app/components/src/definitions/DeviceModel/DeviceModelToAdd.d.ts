declare module Models.DeviceModel {
    export interface IDeviceModelToAdd {
        name: string;
    }
}