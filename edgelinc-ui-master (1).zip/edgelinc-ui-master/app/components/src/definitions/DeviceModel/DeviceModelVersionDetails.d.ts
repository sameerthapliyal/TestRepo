declare module Models.DeviceModel {

    export interface IDeviceModelVersionDetails {
        modelId: string;
        modelName: string;
        version: string;
        attributes: {
            [name: string]: string
        };
    }
}