declare module Models.DeviceModel {
    export interface IDeviceModel {
        id: string;
        name: string;
        deleted?: boolean;
    }
}