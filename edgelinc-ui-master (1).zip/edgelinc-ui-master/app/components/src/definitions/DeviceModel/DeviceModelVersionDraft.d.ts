declare module Models.DeviceModel {

    export interface IDeviceModelVersionDraft {
        Id: string;
    }
}