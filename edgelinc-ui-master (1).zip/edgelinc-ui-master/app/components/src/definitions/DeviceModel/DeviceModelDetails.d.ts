declare module Models.DeviceModel {

    export interface IDeviceModelDetails {
        id: string;
        name: string;
        deleted?: boolean;
        versions: string[];
    }
}