﻿/// <reference path="types.d.ts" />

declare module eapi19 {
    export interface Parameter {
        api_name: ParamApiName;
        value: ParamValue;
        actual_value?: ParamValue,
        desired_value?: ParamValue,
        status?: string,
        shouldBeDisable?: boolean
    }

    export type Parameters = Parameter[];
}