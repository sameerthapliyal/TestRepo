///<reference path="../types.d.ts"/>

declare module eapi19.requests {

    export interface SearchAlarmsParameters {
        sort_by?: string;
        sort_order?: SortOrder;
        limit?: number;
        offset?: number;
        filter?: string;
        prefix?: string;
        contains?:string;
        global_search_fields?: string;
    }
}