declare module eapi19 {
    export interface IDeviceModel {
        id: string;
        name: string;
        deleted?: boolean;
    }
}
