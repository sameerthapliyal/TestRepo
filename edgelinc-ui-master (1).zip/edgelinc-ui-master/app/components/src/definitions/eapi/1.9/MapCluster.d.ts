declare module eapi19 {
    export interface MapBounds {
        min_lat: number;
        min_lng: number;
        max_lat: number;
        max_lng: number;
    }

    export interface MapCluster {
        bounds: MapBounds;
        nodes_count: number;
        operational_status: {[operational_status: string]: number};
        has_children: boolean;
    }
}
