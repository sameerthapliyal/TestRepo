export interface ICustomParameterStruct {
    parameters: {[apiName: string]: ICustomParameterDefinition};
    data: ICustomParameterValue[];
}

export interface ICustomParameterDefinition {
  caption:string;
  hint:string;
}


export interface ICustomParameterValue {
  api_name:string;
  value:string;
}
