/**
 * Created by rosadnik on 14-Dec-16.
 */

declare module eapi18 {
    export interface Task {
        task_id:string;
        operation_id:string;
        asdid?:string;
        type:string;
        create_ts:number;
        start_ts:number;
        end_ts:number;
        change_ts?:number;
        task_status?:string;
        task_result?:string;
        cancel_status?:string;   // REQUESTED, REQUEST_CONFIRMED, ERROR.
        cancel_details?:string;
        data:any;
        task_data?:{
            status:string;
            detailed_status?:string;
            schedule_ts?:number;
            command?:{
                data:string;
                name:string;
            },
            output_available?:boolean;
            parameters?:any;
            package?:{
                type:string;
                name:string;
                signature_url:string;
                file_url:string;
                file_size?:number;
            }
        }
        task_detailed_status:{
            calculated_status:string;
            command_status?:string;
            command_result?:string;
            installation_status?:string;
            installation_result?:string;
            configuration_status?:string;
            registration_status?:string;
            registration_result?:string;
            status_code?:number;
            message?:string;
        }
        task_details?:any;
    }
}