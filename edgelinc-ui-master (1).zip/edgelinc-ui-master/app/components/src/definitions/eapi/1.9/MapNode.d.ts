///<reference path="MapCluster.d.ts"/>

declare module eapi19 {
    export interface MapLocation {
        lat: number;
        lng: number;
    }

    export interface MapNode {
        node_type: "CLUSTER"|"DEVICE";
        geo_hash: string;
        location: MapLocation;
        cluster?: MapCluster;
        device: System;
    }

    export type MapNodes = MapNode[];
}
