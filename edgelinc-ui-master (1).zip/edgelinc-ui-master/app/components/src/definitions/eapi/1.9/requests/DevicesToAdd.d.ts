/**
 * Created by rosadnik on 19-Sep-16.
 */
declare module eapi19.requests {
    export interface IDeviceToAddGO {
        did: string;
        name?: string;
        device_model_id: string;
        device_model_version: string;
        assertions?: {
            predicate: string,
            object:string
        }[];
        parameters?:{
            api_name:string;
            value:any;
        }[];
        details?:any;
    }
    export type IDevicesToAddGO = {
        devices:IDeviceToAddGO[];
        details:any;
    }
}
