///<reference path="types.d.ts"/>

declare module eapi19 {
    export interface System {
        asdid: ASDID;
        did: string;
        loco_id: number;
        operational_status: number;
        operational_status_text: string;
        class: string;
        device_model: string;
        model_version: string;
        statistics: any;
        assertions?: any;
        enrollment_status?:"Inventory"|"Assigned"|"Enrolled"|"Unknown";
        system_id: string;
        name?: string;
        device_name: string;
        first_seen_ts: number;
        registered_ts: number;
        location?: {
            lat: number;
            lon: number;
        }
        aggregates: {[key: string]: any};
        parameters_object: {[api_name: string]: eapi19.Parameter};
    }

    export interface mcsParameter {
        api_name: string,
        value?: any,
        actual_value?: any,
        desired_value?: any,
        status?: string
    }
}