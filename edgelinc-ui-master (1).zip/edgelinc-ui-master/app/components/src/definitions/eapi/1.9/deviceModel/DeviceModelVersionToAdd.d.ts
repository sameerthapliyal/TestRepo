declare module eapi19 {
    export interface DeviceModelVersionToAdd {
        definition: {
            json: any;
        }
    }
}
