declare module eapi19.requests {

    export interface GetUsersQuery {
        //sort_by?: string;
        //sort_order?: SortOrder;
        limit?: number;
        offset?: number;
        //filter?: string;
        contains?: string;
    }
}