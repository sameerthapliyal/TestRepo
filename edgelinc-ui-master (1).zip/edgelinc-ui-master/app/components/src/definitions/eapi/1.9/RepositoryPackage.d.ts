///<reference path="RepositoryPackageVersion.d.ts"/>

declare module eapi19 {
    export interface RepositoryPackage {
        id: string,
        template_type: string;
        versions: RepositoryPackageVersion[];
    }
}
