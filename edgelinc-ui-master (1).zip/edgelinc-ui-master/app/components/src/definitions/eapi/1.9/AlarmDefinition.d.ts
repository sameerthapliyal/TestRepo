declare module eapi19 {

    export interface AlarmDefinition {
        id: AlarmId;
        display_name: string;
        severity: string;
    }

    export type AlarmDefinitions = AlarmDefinition[];
}
