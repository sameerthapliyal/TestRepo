declare module eapi19 {
    export interface IParameterToSet {
        api_name: string;
        value: string;
    }

    export type IParametersToSet = IParameterToSet[]
}
