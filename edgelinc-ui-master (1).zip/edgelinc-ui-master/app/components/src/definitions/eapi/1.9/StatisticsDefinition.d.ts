declare module eapi19 {

    export interface StatisticsDefinition {
        id: string;
        display_name: string
        unit: string;
        type: string;
    }

    export type StatisticsDefinitions = StatisticsDefinition[];
}
