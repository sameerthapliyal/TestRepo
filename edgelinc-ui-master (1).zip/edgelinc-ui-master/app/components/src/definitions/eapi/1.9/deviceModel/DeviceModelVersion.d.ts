declare module eapi19 {
    export interface IDeviceModelVersion {
        version: string;
    }

    export type IDeviceModelVersions = IDeviceModelVersion[];
}
