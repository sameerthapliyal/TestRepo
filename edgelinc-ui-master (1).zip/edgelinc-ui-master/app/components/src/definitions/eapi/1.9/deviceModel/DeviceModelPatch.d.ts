declare module eapi19 {
    export interface IDeviceModelPatch {
        operation: string;
    }
}
