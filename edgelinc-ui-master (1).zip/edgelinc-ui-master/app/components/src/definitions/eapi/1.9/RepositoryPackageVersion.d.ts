declare module eapi19 {
    export type RepositoryPackageStatus = "Pending"|"Approved"|"Obsolete";
    export interface RepositoryPackageVersionAttributes {
        package_type: string;
        template_type: string;
        device_enum: string;
        description: string;
        restrict_to: string[];
        file_name: string;
        file_url: string;
        signature_name: string;
        signature_url: string;
        last_updated_by: string;
        last_updated_ts: number;
        software_version_date: string;
        file_size: number;
        template_definition: any;
        config: any;
        is_draft: boolean;
        address: string;
        software_name: string;
    }
    export interface RepositoryPackageVersion {
        id: string,
        version: string,
        template_type: string;
        attributes: RepositoryPackageVersionAttributes;
        status: RepositoryPackageStatus;
    }
}
