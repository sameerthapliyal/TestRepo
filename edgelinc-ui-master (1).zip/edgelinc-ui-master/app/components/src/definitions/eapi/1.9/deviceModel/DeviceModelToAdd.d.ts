declare module eapi19 {
    export interface IDeviceModelToAdd {
        name: string;
    }
}
