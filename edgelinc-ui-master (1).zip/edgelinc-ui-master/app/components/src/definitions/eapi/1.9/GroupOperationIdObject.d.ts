﻿/// <reference path="types.d.ts" />

declare module eapi19 {
    export interface GroupOperationIdObject {
        operation_id: GroupOperationId
    }
}
