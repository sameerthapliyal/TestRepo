﻿declare module eapi19 {
    export interface Package {
        type: string;
        name: string;
        signature_url: string;
        file_url: string;
    }

    export interface PackageGroupOperation {
        asdids: string[],
        schedule_ts?: number,
        package: Package,
        details?: any,
    }
}
