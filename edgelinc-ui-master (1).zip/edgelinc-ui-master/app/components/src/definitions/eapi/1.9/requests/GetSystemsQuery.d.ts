///<reference path="../types.d.ts"/>

declare module eapi19.requests {

    export interface GetSystemsQuery {
        sort_by?: string;
        sort_order?: SortOrder;
        limit?: number;
        offset?: number;
        filter?: string;
        prefix?: string;
        regexp?: string;
        global_search_fields?: string;
    }
}