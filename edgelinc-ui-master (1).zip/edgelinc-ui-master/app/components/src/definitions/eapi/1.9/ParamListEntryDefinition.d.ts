///<reference path="types.d.ts"/>

declare module eapi19 {

    export interface ParamListEntryDefinition {
        api_name: ParamApiName;
        display_name: string;
        type: string;
    }

    export type ParamListEntryDefinitions = ParamListEntryDefinition[];
}
