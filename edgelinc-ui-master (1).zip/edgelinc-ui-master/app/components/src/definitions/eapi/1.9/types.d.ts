declare module eapi19 {
    export type AlarmId = string;
    export type ASDID = string;
    export type ASDIDs = ASDID[];
    export type Timestamp = number;
    export type SortOrder = "asc" | "desc";
    export type UserRole = string;
    export type AttributeValues = { [p: string]: string };
    export type GroupOperationId = string;
    export type GroupOperationStatus = "PENDING" | "IN_PROGRESS" | "FINISHED" | "UNKNOWN";
    export type GroupOperationResult = "SUCCESS" | "FAILURE" | "ABORTED";
    export type TaskStatus = "PENDING" | "IN_PROGRESS" | "FINISHED" | "UNKNOWN";
    export type TaskResult = "SUCCESS" | "FAILURE" | "ABORTED";
    export type ParamId = string;
    export type ParamApiName = string;
    export type ParamValue = string | number | boolean | Object;
    export type AppendersList = string[];
    export type AsdidsList = string[];
    export type DidsList = string[];
    export type SitesList = string[];
    export type DeviceNamesList = string[];
}