﻿///<reference path="types.d.ts"/>

declare module eapi19 {
    export interface User {
        name: string,
        given_name?: string,
        family_name?: string,
        email: string,
        roles: UserRole[],
        password?: string,
        attributes?: AttributeValues
    }

    export type Users = User[];
}