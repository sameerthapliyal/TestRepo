/**
 * Created by rosadnik on 2015-12-23.
 */
declare module App.Models.EAPI {
    interface IDeviceParameter {
        api_name:string;
        display_name?: string;
        status: string;
        value: any;
        read_only?:boolean
    }
}
