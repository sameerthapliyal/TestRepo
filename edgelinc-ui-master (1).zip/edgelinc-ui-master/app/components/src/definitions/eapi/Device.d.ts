/**
 * Created by rwitczak on 2015-08-12.
 */
/// <reference path="Alarm.d.ts" />
declare module App.Models.EAPI {
    interface IDevice {
        asdid: string;
        name: string;
        did: string;
        device_model_id: string;
        device_model_version: string;
        device_model_name: string;
        registration_status: string;
        status: IDeviceStatus;
        attributes: {[attrName:string]:string};
        systemROAttributes: {[attrName:string]:string};
        systemRWAttributes: {[attrName:string]:string};
        parameters?: App.Models.EAPI.IParameterWithStatus[];
        statistics?:IDeviceStatisticsLastValue[];
        alarms?: App.Models.EAPI.IAlarm[];
        $modelDefinition?: eapi19.DeviceModelDefinition;
    }
    interface IDeviceStatus{
        device_status:string;
        last_change:number;
    }
    interface IDeviceStatisticsLastValue{
        name: string;
        stat_id: string;
        value: number;
    }
}