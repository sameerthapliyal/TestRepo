﻿/// <reference path="SimpleAlarm.d.ts"/>

declare module App.Models.EAPI {
    interface IAlarmNotification {
        asdid: string;
        device_model_id: string;
        device_model_version: string;
        alarms: ISimpleAlarm[];
    }
}