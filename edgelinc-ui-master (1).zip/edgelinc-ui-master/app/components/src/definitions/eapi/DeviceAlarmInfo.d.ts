/**
 * Created by rosadnik on 2015-10-02.
 */
declare module App.Models.EAPI {
    export interface IDeviceAlarm {
        alarm_id:number;
        clear_ts: number;
        severity: string;
        state: string;
    }
}