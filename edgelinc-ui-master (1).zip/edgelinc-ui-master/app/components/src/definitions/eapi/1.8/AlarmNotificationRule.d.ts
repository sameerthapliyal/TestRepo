﻿/// <reference path="Appender.d.ts" />
/// <reference path="Rule.d.ts" />

declare module eapi18 {
    export interface AlarmNotificationRule {
        name: string;
        dataType: "alarm";
        appenders: Appenders;
        rules: Rules;
    }

    export type AlarmsNotificationsRules = AlarmNotificationRule[];
}