///<reference path="ParameterToSet.d.ts"/>

declare module eapi18 {

    export type ActivationCode = string;
    export interface DeviceToAdd {
        did: string;
        name?: string;
        device_model_id: string;
        device_model_version: string;
        activation_code?: ActivationCode;
        parameters?: ParametersToSet
    }

    export type DevicesToAdd = DeviceToAdd[];
}