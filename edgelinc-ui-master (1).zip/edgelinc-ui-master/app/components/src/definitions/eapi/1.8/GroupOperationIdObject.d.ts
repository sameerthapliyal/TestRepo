﻿/// <reference path="types.d.ts" />

declare module eapi18 {
    export interface GroupOperationIdObject {
        operation_id: GroupOperationId
    }
}