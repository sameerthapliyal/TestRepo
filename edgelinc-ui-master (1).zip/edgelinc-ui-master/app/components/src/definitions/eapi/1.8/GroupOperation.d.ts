﻿/// <reference path="types.d.ts" />

declare module eapi18 {
    export interface GroupOperation {
        operation_id: GroupOperationId;
        type: string;
        create_ts: Timestamp;
        start_ts: Timestamp;
        end_ts: Timestamp;
        change_ts: Timestamp;
        status: GroupOperationStatus;
        result?: GroupOperationResult;
        details?: any;
        parameters?:any;
        tasks?:any[];
        command?: Command;
    }
    
    export type GroupOperations = GroupOperation[];
}