﻿///<reference path="../types.d.ts"/>

declare module eapi18.requests {
    export interface UserPatch {
        given_name?: string,
        family_name?: string,
        email?: string,
        role?: UserRole,
        password?: string,
        attributes?: AttributeValues
    }
}