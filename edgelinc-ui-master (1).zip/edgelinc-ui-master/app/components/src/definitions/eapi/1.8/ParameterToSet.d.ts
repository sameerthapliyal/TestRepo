declare module eapi18 {
    export interface ParameterToSet {
        api_name: string;
        value: string;
    }

    export type ParametersToSet = ParameterToSet[]
}