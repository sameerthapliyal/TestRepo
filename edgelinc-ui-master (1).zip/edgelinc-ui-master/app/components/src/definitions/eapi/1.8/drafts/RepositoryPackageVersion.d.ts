declare module eapi18 {
    export type RepositoryPackageStatus = "Pending"|"Approved"|"Obsolete";

    export interface RepositoryPackageVersionAttributes {
        package_type: string;
        template_type: string;
        device_enum: string;
        status: RepositoryPackageStatus;
        description: string;
        restrict_to: string[];
        file_name: string;
        file_url: string;
        signature_name: string;
        signature_url: string;
        last_updated_by: string;
        last_updated_ts: number;
        software_version_date: string;
        file_size: number;
    }

    export interface RepositoryPackageVersion {
        id: string,
        version: string,
        template_type: string;
        attributes: RepositoryPackageVersionAttributes;
    }
}
