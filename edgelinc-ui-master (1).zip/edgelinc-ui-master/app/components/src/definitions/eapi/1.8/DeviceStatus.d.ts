declare module eapi18 {
    export interface DeviceStatus {
        device_status: string;
        last_change: number;
    }
}