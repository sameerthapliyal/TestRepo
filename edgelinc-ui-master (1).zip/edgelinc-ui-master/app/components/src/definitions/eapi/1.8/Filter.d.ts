﻿/// <reference path="FilterModel.d.ts" />
/// <reference path="types.d.ts" />

declare module eapi18 {
    export interface Filter {
        isActive?: boolean;
        severity?: string; //"EMERGENCY" | "FATAL" | "CRITICAL" | "MAJOR" | "ERROR" | "MINOR" | "WARNING" | "INFORMATIONAL";
        isSet?: boolean;
        asdids?: AsdidsList;
        dids?: DidsList;
        sites?: SitesList;
        model?: FilterModel;
        deviceNames?: DeviceNamesList;
    }
}