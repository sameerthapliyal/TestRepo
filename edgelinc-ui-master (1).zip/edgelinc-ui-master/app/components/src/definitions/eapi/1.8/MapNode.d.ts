///<reference path="Device.d.ts"/>

declare module eapi18 {
    export interface MapNode {
        asdid: string;
        latitude: number;
        longitude: number;
        type: string; // "DEVICE"|"CLUSTER"
        source: string; //"USER"|"DEVICE"
        device?: Device
    }

    export type MapNodes = MapNode[];
}