﻿/// <reference path="StatisticsForASDID.d.ts" />

declare module eapi18 {
    export type StatisticsNotification = StatisticsForASDID;
}