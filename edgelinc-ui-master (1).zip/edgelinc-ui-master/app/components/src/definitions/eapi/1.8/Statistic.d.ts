﻿/// <reference path="StatisticPoint.d.ts" />

declare module eapi18 {
    export interface Statistic {
        stat_id: string,
        points: StatisticPoints
    }

    export type Statistics = Statistic[];
}