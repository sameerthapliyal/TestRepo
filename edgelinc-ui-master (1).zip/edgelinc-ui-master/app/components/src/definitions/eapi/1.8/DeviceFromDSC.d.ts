/**
 * Created by rosadnik on 15-Jun-16.
 */
declare module eapi18 {
    export interface DeviceFromDSC {
        asdid: string;
        device_name?:string;
        name?:string;
        did:string;
        device_model: string;
        device_model_id?:string;
        model_version?: string;
        device_model_version?: string;
        device_model_name?: string;
        class?: string;
        system_id?: string;
        operational_status?: number,
        operational_status_text?: string,
        customer_id?: string;
        location?: {
          lat?: number;
          lon?: number;
        }
        statistics?:{
            last_seen?: string|number;
            memory_usage?: string|number;
            cpu_usage?: string|number;
            uptime?: string|number;
            active_alarms?: string|number;
            active_emergency_alarms?: string|number;
            active_fatal_alarms?: string|number;
            active_critical_alarms?: string|number;
            active_error_alarms?: string|number;
            active_warning_alarms?: string|number;
            active_informational_alarms?: string|number;
            service_active?: string|number;
            gateway_active?: string|number;
            gateway_stale?: string|number;
            gateway_removed?: string|number;
            node_active?: string|number;
            node_stale?: string|number;
            node_removed?: string|number;
            node_disconnected?: string|number;
        }
        assertions?:{[attrName:string]:string};
        enrollment_status?:"Inventory"|"Assigned"|"Enrolled"|"Unknown";
        first_seen_ts?: number;
        registered_ts?: number;
        customization?: {
            did_device_type?: string;
            did_name?: string;
            did_serial_number?: number;
        };
        parameters_object?: any;
        $modelDefinition?: eapi19.DeviceModelDefinition;
        aggregates?: {
            _activeAlarms?: number;
            _activeCriticalAlarms?: number;
            _activeEmergencyAlarms?: number;
            _activeErrorAlarms?: number;
            _activeFatalAlarms?: number;
            _activeInformationalAlarms?: number;
            _activeMajorAlarms?: number;
            _activeMinorAlarms?: number;
            _activeWarningAlarms?: number;
            _devicesActive?: number;
            _devicesInactive?: number;
            _systemOperationalStatus?: number;
        }
    }
}
