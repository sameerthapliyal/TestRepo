
declare module eapi18 {
    export interface LogType {
        type: string;
        name: string;
        category: string;
    }

    export type LogTypes = LogType[];
}