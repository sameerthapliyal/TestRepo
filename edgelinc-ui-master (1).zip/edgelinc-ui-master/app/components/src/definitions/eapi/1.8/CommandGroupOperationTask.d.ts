﻿/// <reference path="types.d.ts" />

declare module eapi18 {
    export interface CommandGroupOperationTask {
        task_id: string;
        asdid: ASDID;
        task_status: TaskStatus;
        task_result?: TaskResult;
        command_status: string;
        detailed_status?: string;
    }

    export type CommandGroupOperationTasks = CommandGroupOperationTask[];
}