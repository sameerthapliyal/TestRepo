///<reference path="../types.d.ts"/>

declare module eapi18.requests {

    export interface GetDevicesQuery {
        sort_by?: string;
        sort_order?: SortOrder;
        limit?: number;
        offset?: number;
        filter?: string;
        filter_cs?: boolean;
        prefix?: string;
        contains?: string;
        regexp?: string;
        client_id?: number;
    }
}