﻿/// <reference path="types.d.ts" />
/// <reference path="Statistic.d.ts" />

declare module eapi18 {
    export interface StatisticsForASDID {
        asdid: ASDID,
        statistics: Statistics
    }
}