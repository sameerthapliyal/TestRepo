﻿declare module eapi18 {
    export interface Command {
        name?: string;
        data: string;
    }
}