﻿declare module eapi18 {
    export interface Package {
        type: string;
        name: string;
        signature_url: string;
        file_url: string;
    }
}