﻿declare module eapi18 {
    export interface AssertionKey {
        subject: string,
        predicate: string
    }

    export type AssertionKeys = AssertionKey[];
}