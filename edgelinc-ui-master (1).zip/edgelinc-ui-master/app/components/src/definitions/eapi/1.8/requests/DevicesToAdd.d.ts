/**
 * Created by rosadnik on 19-Sep-16.
 */
declare module eapi18.requests {
    export interface IDeviceToAddGO {
        did: string;
        name?: string;
        device_model_id: string;
        device_model_version: string;
        assertions?: {
            predicate: string,
            object:string
        }[];
    }
    export type IDevicesToAddGO = IDeviceToAddGO[];
}
