///<reference path="ParameterToSet.d.ts"/>

declare module eapi18 {

    export interface AddedDevice {
        did: string;
        asdid: string;
    }

    export interface NotAddedDevice {
        did:string;
        reason:string;
    }

    export interface AddDevicesResult {
        success: AddedDevice[];
        failure: NotAddedDevice[];
    }
}