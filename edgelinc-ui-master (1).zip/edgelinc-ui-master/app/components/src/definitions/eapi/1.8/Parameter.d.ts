﻿/// <reference path="types.d.ts" />

declare module eapi18 {
    export interface Parameter {
        api_name: ParamApiName;
        value: ParamValue;
    }

    export type Parameters = Parameter[];
}