///<reference path="DeviceStatus.d.ts"/>

declare module eapi18 {
    export interface Device {
        asdid: string;
        did: string;
        name: string;
        device_model_id: string;
        device_model_version: string;
        device_model_name: string;
        registration_status: string; // "PREPROVISIONED"|"REGISTERED"
        status: DeviceStatus;
        attributes: {[name: string]: string};
        systemROAttributes: {[name:string]:string};
        systemRWAttributes: {[name:string]:string};
    }
}