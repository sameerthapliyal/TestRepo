﻿declare module eapi18 {
    export interface FilterModel {
        name: string;
        version: string;
    }
}