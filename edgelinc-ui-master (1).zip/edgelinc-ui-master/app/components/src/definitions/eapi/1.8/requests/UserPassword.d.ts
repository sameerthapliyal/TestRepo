﻿declare module eapi18.requests {
    export interface UserPassword {
        password?: string
    }
}