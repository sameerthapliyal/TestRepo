﻿/// <reference path="Filter.d.ts" />
/// <reference path="types.d.ts" />

declare module eapi18 {
    export interface Rule {
        name: string;
        description?: string;
        filter: Filter;
        appenders: AppendersList;
    }

    export type Rules = Rule[];
}