﻿declare module eapi18.requests {
    export interface UserPasswordPatch {
        operation: "reset";
    }
}