﻿/// <reference path="types.d.ts" />

declare module eapi18 {
    export interface ParametersGroupOperationTask {
        task_id: string,
        asdid: ASDID,
        task_status: TaskStatus,
        task_result?: TaskResult,
        configuration_status: string
    }

    export type ParametersGroupOperationTasks = ParametersGroupOperationTask[];
}