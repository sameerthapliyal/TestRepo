﻿/// <reference path="types.d.ts" />

declare module eapi18 {
    export interface PackageGroupOperationTask {
        task_id: string;
        asdid: ASDID;
        task_status: TaskStatus;
        task_result: TaskResult;
        installation_status: "PENDING" | "STARTING" | "IN_PROGRESS" | "DELIVERED" | "INSTALLED" | "ERROR";
    }

    export type PackageGroupOperationTasks = PackageGroupOperationTask[];
}