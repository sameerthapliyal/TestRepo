﻿/// <reference path="types.d.ts" />
/// <reference path="Parameter.d.ts" />
/// <reference path="ParametersGroupOperationTask.d.ts" />

declare module eapi18 {
    export interface ParametersGroupOperationDetails {
        operation_id: GroupOperationId;
        parameters: Parameters;
        create_ts: Timestamp;
        start_ts: Timestamp;
        end_ts: Timestamp;
        change_ts: Timestamp;
        status: GroupOperationStatus;
        result?: GroupOperationResult;
        tasks?: ParametersGroupOperationTasks;
        type:string;
        details?:any;
    }
}