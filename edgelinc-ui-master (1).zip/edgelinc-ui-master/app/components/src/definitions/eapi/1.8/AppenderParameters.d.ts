﻿declare module eapi18 {
    export interface AppenderParameters {
        subject?: string;
        interval?: number;
        to: string;
        from?: string;
        cc?: string;
    }
}