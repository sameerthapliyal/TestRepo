﻿/// <reference path="types.d.ts" />
/// <reference path="Command.d.ts" />
/// <reference path="CommandGroupOperationTask.d.ts" />

declare module eapi18 {
    export interface CommandGroupOperationDetails {
        operation_id: GroupOperationId;
        command: Command;
        output_url_required?: boolean;
        schedule_ts: Timestamp;
        create_ts: Timestamp;
        start_ts: Timestamp;
        end_ts: Timestamp;
        change_ts: Timestamp;
        status: GroupOperationStatus;
        result?: GroupOperationResult;
        tasks?: CommandGroupOperationTasks;
        type:string;
        details?:any;
    }
}