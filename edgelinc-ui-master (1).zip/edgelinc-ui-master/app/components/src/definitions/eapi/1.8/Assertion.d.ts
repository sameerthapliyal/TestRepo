declare module eapi18 {
    export interface Assertion {
        subject: string;
        predicate: string;
        object: string;
    }

    export type Assertions = Assertion[];
}