﻿/// <reference path="AppenderParameters.d.ts" />

declare module eapi18 {
    export interface Appender {
        type: "mail";
        name: string;
        description?: string;
        params: AppenderParameters;
    }

    export type Appenders = Appender[];
}