/**
 * Created by rosadnik on 09-Dec-16.
 */
/// <reference path="../Package.d.ts" />
/// <reference path="../../IGroupOperation.d.ts" />

declare module eapi18.requests {
    export interface PackageGroupOperation extends  App.Models.EAPI.IGroupOperation {
        asdids?: string[],
        schedule_ts?: number,
        package: Package,
        details?: any,
    }
}