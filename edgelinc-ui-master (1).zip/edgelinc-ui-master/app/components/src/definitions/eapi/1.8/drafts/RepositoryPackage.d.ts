///<reference path="RepositoryPackageVersion.d.ts"/>


declare module eapi18 {

    export interface RepositoryPackage {
        id: string,
        template_type: string;
        versions: RepositoryPackageVersion[];
    }
}
