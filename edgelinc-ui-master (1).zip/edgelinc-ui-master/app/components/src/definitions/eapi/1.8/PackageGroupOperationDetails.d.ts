﻿/// <reference path="types.d.ts" />
/// <reference path="Package.d.ts" />
/// <reference path="PackageGroupOperationTask.d.ts" />

declare module eapi18 {
    export interface PackageGroupOperationDetails {
        operation_id: GroupOperationId;
        package: Package;
        schedule_ts: Timestamp;
        create_ts: Timestamp;
        start_ts: Timestamp;
        end_ts: Timestamp;
        change_ts: Timestamp;
        status: GroupOperationStatus;
        result?: GroupOperationResult;
        tasks?: PackageGroupOperationTasks;
        type:string;
        details?:any;
    }
}