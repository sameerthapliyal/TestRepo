﻿/// <reference path="../types.d.ts" />
/// <reference path="../Command.d.ts" />
/// <reference path="../../IGroupOperation.d.ts" />

declare module eapi18.requests {
    export interface CommandGroupOperation extends  App.Models.EAPI.IGroupOperation{
        asdids?: ASDIDs;
        schedule_ts?: Timestamp;
        command: Command;
        output_url_required?: boolean;
        details?: any;
    }
}