﻿/// <reference path="../types.d.ts" />
/// <reference path="../AssertionKey.d.ts" />
/// <reference path="../../IGroupOperation.d.ts" />

declare module eapi18.requests {
    export interface UnregistrationOperation extends  App.Models.EAPI.IGroupOperation {
        asdids?: ASDIDs,
        assertions?: AssertionKeys,
        details?:any
    }
}