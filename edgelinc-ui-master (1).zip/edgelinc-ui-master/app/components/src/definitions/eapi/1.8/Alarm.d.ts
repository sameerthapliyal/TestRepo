﻿
declare module eapi18 {
    interface Alarm {
        alarm_id: string;
        alarm_state: string;
        set_ts: number;
        clear_ts: number;
        severity: string;
        description: string;
    }
}