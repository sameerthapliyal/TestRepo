///<reference path="../types.d.ts"/>

declare module eapi18.requests {

    export interface SearchAlarmsParameters {
        sort_by?: string;
        sort_order?: SortOrder;
        limit?: number;
        offset?: number;
        filter?: string;
        contains?: string;
        prefix?: string;
    }
}