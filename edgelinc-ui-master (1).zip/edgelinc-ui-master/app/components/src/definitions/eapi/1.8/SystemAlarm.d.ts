///<reference path="types.d.ts"/>

declare module eapi18 {

    export interface SystemAlarm {
        alarm_id: AlarmId;
        asdid: ASDID;
        device_name: string;
        system_id: string;
        system_name: string;
        device_model_id: string;
        device_model_name: string;
        device_model_version: string;
        alarm_state: "SET" | "CLEARED";
        set_ts: Timestamp;
        clear_ts: Timestamp;
        severity: string;
        description: string
    }

    export type SystemAlarms = SystemAlarm[];
    
    export type SystemAlarmField = "alarm_id" | "asdid" | "device_name" | "system_id" | "system_name" | "device_model_id" |
            "device_model_name" | "device_model_version" | "alarm_state" | "set_ts" | "clear_ts" | "severity" | "description"
}