/**
 * Created by rwitczak on 2015-08-14.
 */
declare module App.Models.EAPI {
    export interface IParameter {
        api_name: string;
        value: string;
    }
}