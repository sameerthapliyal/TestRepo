/**
 * Created by rwitczak on 2015-08-13.
 */
declare module App.Models.EAPI {
    interface IFUMTask {
        id?: number;
        name: string;
        signature_url: string;
        file_url: string;
        devices: string[];
        start_ts: number;
    }
}