declare module App.Models.EAPI {
    export interface IStatistic {
        stat_id: string;
        points: IStatisticPoints;
        stat_name: string;
    }

    export type IStatistics = IStatistic[];
}
