/**
 * Created by rwitczak on 2015-08-13.
 */
declare module App.Models.EAPI {
    interface IFUMStateOfDevice {
        uuid: string;
        state: string;
    }
}