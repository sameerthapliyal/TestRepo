﻿
declare module App.Models.EAPI {
    interface IAlarm {
        alarm_id: string;
        alarm_state: string;
        set_ts: number;
        clear_ts: number;
        severity: string;
        description: string;
    }
}