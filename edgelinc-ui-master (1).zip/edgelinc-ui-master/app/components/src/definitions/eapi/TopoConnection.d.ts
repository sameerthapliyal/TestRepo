/**
 * Created by rosadnik on 2015-10-02.
 */
declare module App.Models.EAPI {
    export interface ITopoConnection{
        child_id:string;
        parent_id:string;
        attributes:any[];
        status:string;
    }
}
