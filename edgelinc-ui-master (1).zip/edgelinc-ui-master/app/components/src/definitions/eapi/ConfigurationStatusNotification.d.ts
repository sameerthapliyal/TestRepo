/// <reference path="SimpleAlarm.d.ts"/>

declare module App.Models.EAPI {
    interface IConfigurationStatusNotification {
        asdid: string;
        configuration_status: string;
    }
}