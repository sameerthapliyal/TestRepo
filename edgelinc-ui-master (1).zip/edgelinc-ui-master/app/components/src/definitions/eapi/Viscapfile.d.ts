/**
 * Created by rosadnik on 2015-12-03.
 */
declare module App.Models.EAPI {
    interface IViscapfile{
        General?: IViscapfileGeneral;
        DeviceView?: IViscapfileDeviceView;
        StatisticsView?: IViscapfileStatisticsView;
        Parameters?: IViscapfileParameters;
        Statistics?: IViscapfileStatistics;
        Commands?:models.Commands.ICommand[];
    }

    interface IViscapfileDeviceIcon {
        Symbol: string;
        Class: string;
    }

    interface IViscapfileGeneral{
        Icon?: IViscapfileDeviceIcon;
    }

    interface IViscapfileDeviceView{
        Provisioning:IViscapfileDeviceViewProvisioning;
        DeviceSummary:IViscapfileDeviceViewDeviceSummary;
    }

    interface IViscapfileDeviceViewProvisioning{
        Groups:IViscapfileProvisioningGroups[];
    }

    interface IViscapfileDeviceViewDeviceSummary{
        Layout:string[][];
        Sections:{[sectionId: string]: IViscapfileDeviceViewDeviceSummarySection};
    }

    interface  IViscapfileProvisioningGroups{
        Caption:string;
        Parameters?:string[];
        Subgroups?:IViscapfileProvisioningSubgroups[];
        Visible?:boolean;
    }

    interface  IViscapfileProvisioningSubgroups{
        Caption:string;
        Parameters?:string[];
        Visible?:boolean;
    }

    interface IViscapfileDeviceViewDeviceSummarySection{
        Caption?: string;
        Type: string;   // "Custom", "Picture"
        Entries?: {[EntryId:string]:IViscapfileDeviceViewDeviceSummarySectionEntrie};
        ImageUrl?:string;

    }
    interface IViscapfileDeviceViewDeviceSummarySectionEntrie{
        Type: string;   // "Property", "Alarm", "Parameter"
        Order: number;
        Caption: string;
        Visible?:boolean;

        // if Tupe  == "Property"
        Property?: string;

        // if Tupe  == "Parameter"
        Name?: string;

        // if Tupe  == "Alarm"
        AlarmInfoType?:string;  //"LastAlarm" or "TotalCount"
        Severities?:string[];   // "Critical", "Major", "Minor", "Warning"
    }

    type ViscapfileParameterEnumeration = {[value: string]: string};

    interface IViscapfileParameter{
        IsListParameter?: boolean;
        ListParameter?: IViscapfileListParameter;
        Caption: string;
        Hint?: string;
        Visible?:boolean;
        Type?: string; //"enum", "boolean", "integer", "float", "string", "password", "list"; default: "string"
        Readonly?: boolean; // default: true
        Constraints?: IViscapfileParameterConstraints;
        Enumeration?: ViscapfileParameterEnumeration;
        ValueType?: string;
    }
    type IViscapfileParameters = {[api_name:string]: IViscapfileParameter;}

    interface IViscapfileParameterConstraints {
        Min?: number; //[Float/Integer] Minimal value of the numeric parameter. Default: not set
        Max?: number; //[Float/Integer] Maximum value of the numeric parameter. Default: not set
        Step?: number; //[Float/Integer] Granularity of the spin-box in UI. Default: 1
        MinLength?: number; //[String] Minimal length of the parameter. Default: 0
        MaxLength?: number; //[String] Maximum length of the parameter. Default: not set.",
        Regexp?: string; //[String] Regular expression for testing parameter value (string). It should be valid JavaScript RegExp pattern (http://www.regular-expressions.info/javascript.html). Default: not set.",
        IsCaseSensitive?: boolean; //[String] States if string value is case sensitive or not. Default: false.";
    }

    interface IViscapfileListParameter {
        MinEntries?: number; //Specifies minimum number of entries a list must contain. Value of this parameter must be non-negative integer lesser or equal to max_entries (if specified). If this attribute is not specified then 0 is assumed
        MaxEntries?: number; //Specifies maximum number of entries which constitutes the list. If this attribute is not specified then “no limit” is assumed
        Entry: IViscapfileListParameterEntry;
    }

    interface IViscapfileListParameterEntry {
        Items: IViscapfileListParameterItem[];
    }

    interface IViscapfileListParameterItem {
        Name: string;
        Type?: string; //"enum", "boolean", "integer", "float", "string", "password"; default: "string"
        Readonly?: boolean; // default: true
        Description: string;
        Hint?: string;
        Constraints?: IViscapfileParameterConstraints;
        Enumeration?: ViscapfileParameterEnumeration;
    }



    interface IImage {
        imageData: Blob;
        imageType: string;
        imageBase64Data: string
    }

    interface IViscapfileStatistic {
        Caption?: string;
        ValueType?: string;
        Enumeration?:{[val:string]:string;}
    }

    type IViscapfileStatistics = {[statId:string]: IViscapfileStatistic;}

    interface IViscapfileStatisticsView {
        Series: IViscapfileStatisticSeries;
    }

    interface IViscapfileStatisticSerie {
        StatisticName: string;
    }

    type IViscapfileStatisticSeries = {[serieId:string]: IViscapfileStatisticSerie;}
}
