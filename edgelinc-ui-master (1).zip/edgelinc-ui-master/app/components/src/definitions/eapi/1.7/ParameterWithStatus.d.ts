declare module eapi17 {
    interface IParameterWithStatus {
        api_name: string;
        value: string;
        status: string;
    }
}