declare module eapi17 {
    export interface DeviceModelVersionToAdd {
        definition: {
            json: any;
        }
    }
}