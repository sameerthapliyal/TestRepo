declare module eapi17 {
    export interface VisualizationCapabilityFile {
        DeviceModel: string
        ModelVersion: string
        General: any;
        Parameters: any;
        Statistics: any;
        ManualRegistration: any;
        DeviceView: any;
        StatisticsView: any;
        TopologyView: any;
    }

    export type VisualizationCapabilityFiles = VisualizationCapabilityFile[];
}