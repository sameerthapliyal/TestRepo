declare module eapi17 {
    export interface IDeviceModel {
        id: string;
        name: string;
        deleted?: boolean;
    }
}