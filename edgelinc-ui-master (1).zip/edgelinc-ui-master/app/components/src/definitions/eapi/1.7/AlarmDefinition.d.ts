declare module eapi17 {

    export interface AlarmDefinition {
        id: AlarmId;
        display_name: string;
        severity: string;
    }

    export type AlarmDefinitions = AlarmDefinition[];
}