﻿declare module eapi17 {
    export interface IParametersGroupOperationTask {
        task_id: string,
        asdid: string,
        task_status: string,
        task_result?: string,
        configuration_status: string
    }
}