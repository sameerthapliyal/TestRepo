﻿/// <reference path="Package.d.ts" />

declare module eapi17 {
    export interface IPackageGroupOperation {
        asdids: string[],
        schedule_ts?: number,
        package: IPackage,
        details?: any,
    }
}