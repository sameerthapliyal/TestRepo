declare module eapi17 {
    export interface IGroupOperationIdObject {
        operation_id: string;
    }
}