declare module eapi17 {
    export interface DeviceStatus {
        device_status: string;
        last_change: number;
    }
}