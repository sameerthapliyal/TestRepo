declare module eapi17 {
    export interface IDeviceModelToAdd {
        name: string;
    }
}