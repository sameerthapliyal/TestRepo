declare module eapi17 {
    export interface IDeviceModelPatch {
        operation: string;
    }
}