declare module eapi17 {
    export interface IAssertion {
        subject: string;
        predicate: string;
        object: string;
    }

    export type IAssertions = IAssertion[];
}