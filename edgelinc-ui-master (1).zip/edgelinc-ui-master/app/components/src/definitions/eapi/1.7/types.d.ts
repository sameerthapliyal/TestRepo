declare module eapi17 {
    export type ParamId = string;
    export type ParamApiName = string;
    export type AlarmId = string;
}