///<reference path="types.d.ts"/>
///<reference path="ParamListEntryDefinition.d.ts"/>

declare module eapi17 {

    export interface ParamDefinition {
        id: ParamId;
        api_name: ParamApiName;
        display_name: string;
        type: string;
        read_only: boolean;
        list_entries: ParamListEntryDefinitions;
    }

    export type ParamDefinitions = ParamDefinition[];
}