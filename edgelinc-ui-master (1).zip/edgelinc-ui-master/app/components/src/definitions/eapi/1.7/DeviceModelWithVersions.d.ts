///<reference path="DeviceModelVersion.d.ts"/>

declare module eapi17 {

    export interface IDeviceModelWithVersions {
        id: string;
        name: string;
        deleted?: boolean;
        versions: IDeviceModelVersions;
    }
}