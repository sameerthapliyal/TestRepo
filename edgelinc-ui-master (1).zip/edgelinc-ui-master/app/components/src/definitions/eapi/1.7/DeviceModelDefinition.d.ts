///<reference path="ParamDefinition.d.ts"/>
///<reference path="AlarmDefinition.d.ts"/>
///<reference path="StatisticsDefinition.d.ts"/>

declare module eapi17 {

    export interface DeviceModelDefinition {
        id: string;
        version: string;
        name: string;
        parameters: ParamDefinitions;
        alarms: AlarmDefinitions;
        statistics: StatisticsDefinitions;
        attributes: {
            [name: string]: string
        };
    }
}