declare module eapi17 {
    export interface IParameter {
        api_name: string;
        value: string;
    }
}