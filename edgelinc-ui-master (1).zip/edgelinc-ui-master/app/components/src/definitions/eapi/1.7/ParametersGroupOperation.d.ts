﻿/// <reference path="Parameter.d.ts" />

declare module eapi17 {
    export interface IParametersGroupOperation {
        asdids: string[],
        parameters: IParameter[],
        details?: any
    }
}