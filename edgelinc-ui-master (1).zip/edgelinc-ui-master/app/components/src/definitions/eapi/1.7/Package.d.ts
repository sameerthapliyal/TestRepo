﻿declare module eapi17 {
    export interface IPackage {
        type: string,
        name: string,
        signature_url: string,
        file_url: string
    }
}