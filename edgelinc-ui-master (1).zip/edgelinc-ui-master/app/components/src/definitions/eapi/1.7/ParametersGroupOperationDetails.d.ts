﻿/// <reference path="Parameter.d.ts" />
/// <reference path="ParametersGroupOperationTask.d.ts" />

declare module eapi17 {
    export interface IParametersGroupOperationDetails {
        operation_id: string,
        parameters: IParameter[],
        create_ts: number,
        start_ts: number,
        end_ts: number,
        status: string,
        result?:string,
        tasks?: IParametersGroupOperationTask[],
    }
}
