declare module App.Models.EAPI {
    export interface IGroupOperation {
        asdids?: string[],
        devices?: {
            asdid:string;
            details?:any;
        }[],
        details?: any
    }
}