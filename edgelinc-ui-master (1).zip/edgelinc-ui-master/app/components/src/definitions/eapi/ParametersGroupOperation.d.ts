
/// <reference path="Parameter.d.ts" />
/// <reference path="IGroupOperation.d.ts" />

declare module App.Models.EAPI {
    export interface IParametersGroupOperation extends IGroupOperation{
        asdids?: string[],
        parameters: IParameter[],
        details?: any
    }
}
