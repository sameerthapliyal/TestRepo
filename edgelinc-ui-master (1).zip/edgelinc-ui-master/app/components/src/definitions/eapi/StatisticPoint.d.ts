declare module App.Models.EAPI {
    export interface IStatisticPoint {
        value: any;
        timestamp: number;
    }

    export type IStatisticPoints = IStatisticPoint[];
}