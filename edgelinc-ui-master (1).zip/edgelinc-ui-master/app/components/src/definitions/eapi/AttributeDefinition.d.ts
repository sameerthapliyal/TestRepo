declare module App.Models.EAPI {
    interface IAttributeDefinition {
        name: string;
        toString: () => string;
    }
}