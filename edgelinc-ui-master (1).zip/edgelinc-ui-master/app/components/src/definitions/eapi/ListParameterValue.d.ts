/**
 * Created by rwitczak on 2015-08-14.
 */
declare module App.Models.EAPI {
    interface IListParameterValueEntry {
        [key: string]: any[];
    }

    interface IListParameterValue {
        [key: string]: IListParameterValueEntry[];
    }
}