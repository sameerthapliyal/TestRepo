﻿
declare module App.Models.EAPI {
    interface ISimpleAlarm {
        id: string;
        state: "SET"|"CLEAR";
        severity: string;
        timestamp: number;
    }
}