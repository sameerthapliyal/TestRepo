///<reference path="../../../../../typings/browser.d.ts"/>



export interface ClusteredDeviceNode extends ng.leaflet.MapMarker {
    id: string;
    type: "CLUSTER"|"DEVICE";
    geoHash: string;
    cluster?: {
        bounds: ng.leaflet.Bounds;
        hasChildren: boolean;
    },
    spiderfy?: {
        getNodes(limit: number, offset: number): ng.IPromise<ClusteredDeviceNode[]>;
    }
    properties?: {
        asdid?: string;
        rawNode?: eapi19.MapNode;
        rawDevice?: eapi19.System;
        rawCluster?: eapi19.MapCluster;
    }
    icon: MarkerIcon; // override
}

export interface MarkerIcon extends ng.leaflet.DivIcon {
    setSelected(selected: boolean): void;
}

export interface MarkerNodeIcon extends MarkerIcon {
    setStatus(statusCss: string): void;
    setIcon(iconCss: string): void;
}

export interface MarkerClusterIcon extends MarkerIcon {
    setStatus(statusCss: string): void;
    setCount(count: number): void;
}