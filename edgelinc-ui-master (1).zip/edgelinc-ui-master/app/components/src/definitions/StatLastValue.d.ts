declare module App.Models {
    interface IStatLastValue {
        statId: string;
        timestamp: number;
        value: any;
    }
}