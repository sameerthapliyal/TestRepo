declare module Models {
    interface IAlertSeverity {
        key: string;
        caption: string;
        /**
         * obsolete, use cssClass
         */
        labelCss: string;
        order_by:number;
        cssClass: string;
    }
}