declare module App.Models {

}