
declare module ldarsGWProxy {
    export interface RuleDeployOutputOperation {
        customerId: string;
        requestId: string;
        message: string;
        created: string;
        status: string;
        locoId: string;
    }

    export type RuleDeployOutputOperations = RuleDeployOutputOperation[];
}
