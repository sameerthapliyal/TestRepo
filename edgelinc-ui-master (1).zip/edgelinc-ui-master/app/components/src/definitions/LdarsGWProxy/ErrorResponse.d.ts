
declare module ldarsGWProxy {
    export interface ErrorResponse {
        errorMessage: string;
        errorCode: string;

    }

}
