/**
 * Created by Jothi Nadhamuni
 */

declare module ldarsGWProxy.requests {
    export interface RuleDeployInputOperation {
        locos?: string[],
        schedule_ts?: number,
        bundleId: string,
        ruleBundleName: string,
        ruleBundleVersion: string
    }
}
