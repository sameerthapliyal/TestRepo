﻿///<reference path="ParsedDescription.d.ts"/>


declare module App.Models {
    interface IAlert {
        uniqueId: string; // contains asdid and alarm id
        id: string;
        state: string;
        severity: string;
        timestamp: number;
        clearTs: number;
        description: string;
        asdid: string;
        deviceName: string;
        model: string;
        device_model_id: string;
        device_model_version: string;
        systemId: string;
        systemName: string;
        severityCss?:string;
        severityLabel?:string;
        hasDescription: boolean;
        getDescription(): ng.IPromise<IParsedDescription>;
        //system: App.Models.ISystem;
        system:{
            asdid?:string
            name?:string
        },
        device: {
            asdid: string;
            name: string;
            model: {
                id: string;
                version: string;
                name: string;
            };
            //type: string;
        },
        raw: any
    }
}