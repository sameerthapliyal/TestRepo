/// <reference path="FirmwareUpgradeDeviceState.d.ts" />

declare module App.Models {
    interface IFirmwareUpgradeTask {
        id: number;
        name: string;
        signatureUrl: string;
        fileUrl: string;
        devices: string[];
        startDate: Date;
        deviceStates?: IFirmwareUpgradeDeviceState[];
    }
}