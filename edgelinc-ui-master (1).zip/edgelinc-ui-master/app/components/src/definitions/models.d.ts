/// <reference path="eapi/Device.d.ts" />
/// <reference path="eapi/FUMTask.d.ts" />
/// <reference path="eapi/FUMStateofDevice.d.ts" />
/// <reference path="eapi/Parameter.d.ts" />
/// <reference path="eapi/ParameterWithStatus.d.ts" />
/// <reference path="eapi/ListParameterValue.d.ts" />
/// <reference path="eapi/TopoConnection.d.ts" />
/// <reference path="eapi/DeviceAlarmInfo.d.ts" />

/// <reference path="Device.d.ts" />
/// <reference path="DeviceModel.d.ts" />
/// <reference path="FirmwareUpgradeTask.d.ts" />
/// <reference path="FirmwareUpgradeDeviceState.d.ts" />
/// <reference path="Firmware.d.ts" />
/// <reference path="FirmwareUpgrade/ConnectedDeviceStatus.d.ts" />