declare module App.Models {
    interface IParsedDescription {
        raw:string;
        message:string;
        payload?:any;
    }
}