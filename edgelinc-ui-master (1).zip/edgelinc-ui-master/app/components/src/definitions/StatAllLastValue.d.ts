declare module App.Models {
    interface IStatAllLastValue {
        stat_id: string;
        name: string;
        value: any;
    }
}
