/**
 * Created by rosadnik on 2015-12-10.
 */
declare module App.Models.Common {
    export interface CachedDate<T>{
        cached:boolean;
        ts:number;
        data:T;
    }
}