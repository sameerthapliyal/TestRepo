///<reference path="../../../typings/browser.d.ts"/>

import AlertsListModule from "./directives/alerts-list/alerts-list";

export default angular.module('components.alerts', [AlertsListModule.name]);