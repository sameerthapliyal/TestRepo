
const POOLING_INTERVAL = 60000;

interface IVersionInfo {
    version: string;
}

interface IRuiUpgradeCheckerDirectiveScope extends ng.IScope {
    initialVersion: string;
    currentVersion: string;
    mismatch: boolean;
    visible: boolean;
    refreshNow();
    suspend();
    suspension: {
        time: number;
        options: {value: number, text: string}[];
    };
}

function RuiUpgradeCheckerDirective($config: app.config.IConfigService, $timeout: ng.ITimeoutService, $interval: ng.IIntervalService, $window: ng.IWindowService, $http: ng.IHttpService) {
    return {
        restrict: "E",
        templateUrl: "/components/src/directives/rui-upgrade-checker/rui-upgrade-checker.html",
        link: (scope: IRuiUpgradeCheckerDirectiveScope) => {
            scope.initialVersion = scope.currentVersion = $config.$config.VERSION;
            scope.mismatch = false;
            scope.visible = false;
            scope.refreshNow = refreshNow;
            scope.suspend = suspend;
            scope.suspension = {
                time: 5 * 60 * 1000,
                options: [
                    //{ value: 5*1000, text: "5 seconds"},
                    //{ value: 30*1000, text: "30 seconds"},
                    //{ value: 60*1000, text: "1 minute"},
                    { value: 5*60*1000, text: "5 minutes"},
                    { value: 30*60*1000, text: "30 minutes"},
                    { value: 60*60*1000, text: "1 hour"}
                ]
            };

            let interval = $interval(checkVersion, POOLING_INTERVAL);

            function checkVersion() {
                $http.get<IVersionInfo>('/version')
                    .then(versionInfo => {
                        scope.currentVersion = versionInfo.data.version;
                        if(scope.initialVersion != scope.currentVersion) {
                            handleMismatch();
                        }
                    })
                    .catch(err => {
                        console.warn("Cannot retrieve RUI version.", err);
                    });
            }

            function handleMismatch() {
                $interval.cancel(interval);
                scope.mismatch = true;
                displayNotification();
            }

            function displayNotification() {
                scope.visible = true;
            }

            function refreshNow() {
                $window.location.reload();
            }

            function suspend() {
                $timeout(displayNotification, scope.suspension.time);
                scope.visible = false;
            }
        }
    }
}

RuiUpgradeCheckerDirective.$inject = ['$config', '$timeout', '$interval', '$window', '$http'];


export default angular.module('directives.upgradeChecker', [])
    .directive('ruiUpgradeChecker', RuiUpgradeCheckerDirective);