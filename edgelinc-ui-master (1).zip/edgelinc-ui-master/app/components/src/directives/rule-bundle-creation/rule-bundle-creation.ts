import RuleBundleCreationControllerModule, {
    RuleBundleCreationController,
    IRuleBundleCreationControllerScope
} from "./RuleBundleCreationController";
import {IRepositoryPackage} from "../../services/PackageRepositoryService";

interface IRuleBundleCreationDirectiveScope extends IRuleBundleCreationControllerScope {
}

function RuleBundleCreationDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('RuleBundleCreationDirective'),
        controller: 'RuleBundleCreationController',
        link: (scope: IRuleBundleCreationDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: RuleBundleCreationController) => {
            ctrl.initialize("CREATE");
        }
    }
}

export default angular.module('directives.ruleBundleCreation.ruleBundleCreation', [RuleBundleCreationControllerModule.name])
    .directive("ruleBundleCreation", ['$branding', RuleBundleCreationDirective]);
