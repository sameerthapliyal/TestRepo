///<reference path="../../../../../typings/browser.d.ts"/>
///<reference path="../../definitions/eapi/1.9/deviceModel/DeviceModel.d.ts"/>

import RuleBundleCreationServiceModule, {
    IRuleBundleToUploadXML, RuleBundleCreationService, IRepositoryPackage
} from "../../services/RuleBundleCreationService";
import UserManagementServiceModule, {UserManagementService} from "../../services/UserManagementService";
import AuthServiceModule, {AuthService} from "../../services/AuthService";
import {NotifyData} from "../../utilities/NotifyHelper";
import AclServiceModule, {ACLService} from "../../services/ACLService";
import DeviceModelsServiceModule, {DeviceModelsService} from "../services/DeviceModelsService";
import IDeviceModel = Models.DeviceModel.IDeviceModel;

export type RuleBundleCreationControllerMode = "CREATE";

export interface IRuleBundleCreationControllerScope extends ng.IScope {
    xmlUpload: IRuleBundleToUploadXML;
    originalPackage: IRepositoryPackage;
    savedPackage: IRepositoryPackage;
    fileSize: number;
    initialized: boolean;
    inProgress: boolean;
    inConfigView: boolean;
    inSave: boolean;
    inProgressMessage:string;
    uploadXML(form: ng.IFormController): void;
    reset(form: ng.IFormController): void;
    createBundle(form: ng.IFormController): void;
    addEventsGroup(): void;
    removeEventsGroup(): void;
    allowTravel(step: boolean): void;

    step1:boolean;
    step2:boolean;
    step3:boolean;

    isEventsSelected(): boolean;
    isSnapParamsSelected(): boolean;
    addUploadFile(): void;
    removeUploadFile(): void;


    getEvents(tag: any, removed: boolean); void;

    getDownloadURIs(): string[];

    showUploadButton: boolean;
    error?: Error;
    lastChoosenXmlFile: File,
    inProgressFileProgres:number;
    inProgressFileDetailedProgres: NotifyData;
    result: string;
    parameters: string[];
    saveSuccess: boolean;
    eventsToDisplay: string[];
    validationMsg: string;
    deviceModels: eapi19.IDeviceModel[];

    getParameters(any):string[];
    getEventsList(any):string[];
}

export class RuleBundleCreationController {

    public static $inject = ["$window","$config","$scope", "$q", "RuleBundleCreationService", "UserManagementService", "AuthorizationService", "DeviceModelsService"];

    private mode: RuleBundleCreationControllerMode;

    public emptyPackageFactory: (originalPackage: IRepositoryPackage) => IRuleBundleToUploadXML;

    constructor(
        private $window: ng.IWindowService,
        private $config: app.config.IConfigService,
        private $scope: IRuleBundleCreationControllerScope,
        private $q: ng.IQService,
        private RuleBundleCreationService: RuleBundleCreationService,
        private UserManagementService: UserManagementService,
        private AuthorizationService: AuthService,
        private DeviceModelsService: DeviceModelsService){

        this.emptyPackageFactory = () => {
            return <any>{}
        };


        this.$scope.inConfigView = false;
        this.$scope.inSave = false;
        this.$scope.showUploadButton = false;

        this.$scope.uploadXML = (form: ng.IFormController) => this.uploadXML(form);

        this.$scope.createBundle = (form: ng.IFormController) => this.createBundle(form);

        this.$scope.addEventsGroup = () => this.addEventsGroup();

        this.$scope.removeEventsGroup = () => this.removeEventsGroup();

        this.$scope.allowTravel = (step1: boolean) => this.allowTravel(step1);

        this.$scope.isEventsSelected = () => this.isEventsSelected();

        this.$scope.isSnapParamsSelected = () => this.isSnapParamsSelected();

        this.$scope.addUploadFile = () => this.addUploadFile();

        this.$scope.removeUploadFile = () => this.removeUploadFile();

        this.$scope.getEvents = (tag: any, removed: boolean) => this.getEvents(tag, removed);

        this.$scope.getDownloadURIs = () => this.getDownloadURIs();

        this.$scope.reset = (form: ng.IFormController) => this.reset(form);

        this.resetData();

        $scope.$on("$routeChangeStart",(event: ng.IAngularEvent, next:any, current:any)=>{
            if(this.$scope.inProgress) {
                var message = null;
                if (this.mode == "CREATE") {
                    message = "Rule Bundle creation is in progress. You might cause this process to fail when you left the page";
                }
                if(confirm(message) == false){
                    event.preventDefault()
                }
            }
        });

        $scope.$on("$destroy", ()=>{
            window.onbeforeunload = null;
        });

        window.onbeforeunload = (event: BeforeUnloadEvent)=>{
            if(this.$scope.inProgress) {
                if (this.mode == "CREATE") {
                    return "Rule Bundle creation is in progress. You will cause the process to fail when you left the page";
                }
            }else{
                window.onbeforeunload = null;
            }
        };
    }

    public initialize(mode: RuleBundleCreationControllerMode) {
        this.mode = mode;

        this.RuleBundleCreationService.getParameters().then(data => {

          this.$scope.parameters = data;
        })
        .catch(err => {
            console.error(err);
            this.$scope.inProgress = false;
            this.$scope.error = err;
            this.$scope.step1 = true;
            this.$scope.step2 = false;
            this.$scope.step3 = false;
            this.$window.scrollTo(0,0);
        });

        this.$scope.getParameters = (query: string) => {
            if (query != null && query.trim().length > 0) {
                var pattern = new RegExp(query, "i");
                return this.$scope.parameters.filter((m) => {
                    return pattern.test(m.parameterName);
                })
            } else {
                return this.$scope.parameters;
            }
        }

        this.$scope.getEventsList = (query: string) => {
            if (query != null && query.trim().length > 0) {
                var pattern = new RegExp(query, "i");
                return this.$scope.eventsToDisplay.filter((m) => {
                    return pattern.test(m);
                })
            } else {
                return this.$scope.eventsToDisplay;
            }
        }

        this.DeviceModelsService.getDeviceModelsFromEAPI(false).then(data => {
          this.$scope.deviceModels = data;
        })
        .catch(err => {
            console.error(err);
            this.$scope.inProgress = false;
            this.$scope.error = err;
            this.$scope.step1 = true;
            this.$scope.step2 = false;
            this.$scope.step3 = false;
            this.$window.scrollTo(0,0);
        })
    }


    private uploadXML(form: ng.IFormController) {

      if (this.$scope.inProgress) {
          return;
      }

      this.$scope.xmlUpload.numbers = [];

      this.$scope.saveSuccess = false;

      this.$scope.inProgress = true;

      this.$scope.error = null;

      this.RuleBundleCreationService.uploadXML(this.$scope.xmlUpload)
            .then(data => {

                let jsonData = JSON.parse(angular.toJson(data));

                jsonData.eventList.unshift("sas/event/#");

                this.$scope.xmlUpload.events = jsonData.eventList;

                this.$scope.eventsToDisplay = jsonData.eventList.slice();
                this.$scope.xmlUpload.parameters = this.$scope.parameters;
                this.$scope.xmlUpload.eventCount = 1;
                this.$scope.xmlUpload.numbers.unshift(angular.copy(this.$scope.xmlUpload.eventCount));
                this.$scope.inProgress = true;
                this.$scope.inConfigView = true;
                this.$scope.inSave = false;

                this.$scope.step1 = false;
                this.$scope.step2 = true;
                this.$scope.step3 = false;

            },null,(notifyData:NotifyData)=> this.RuleBundleCreationProgresNotifyHandle(notifyData))
            .catch(err => {
                console.error(err);
                this.$scope.inProgress = false;
                this.$scope.error = err;
                this.$scope.step1 = true;
                this.$scope.step2 = false;
                this.$scope.step3 = false;
                this.$window.scrollTo(0,0);
            })
    }

    private addEventsGroup() {
      this.$scope.xmlUpload.eventCount = this.$scope.xmlUpload.eventCount + 1;
      this.$scope.xmlUpload.numbers.push(this.$scope.xmlUpload.eventCount);
    }

    private removeEventsGroup() {
      var index = this.$scope.xmlUpload.numbers.indexOf(this.$scope.xmlUpload.eventCount);
      this.$scope.xmlUpload.numbers.splice(index, 1);
      this.$scope.xmlUpload.eventCount = this.$scope.xmlUpload.eventCount - 1;
      for(index=0; index<this.$scope.xmlUpload.event[this.$scope.xmlUpload.eventCount].length; index++){
        this.getEvents(this.$scope.xmlUpload.event[this.$scope.xmlUpload.eventCount][index], true);
      }

      delete this.$scope.xmlUpload.event[this.$scope.xmlUpload.eventCount];
    }

    private allowTravel(step: boolean): void{
      if(step){
        if(!this.$scope.saveSuccess){
          this.$scope.step1 = true;
          this.$scope.step2 = false;
          this.$scope.step3 = false;
        }
      } else {
        if(!this.$scope.saveSuccess && this.$scope.inConfigView){
          this.$scope.step1 = false;
          this.$scope.step2 = true;
          this.$scope.step3 = false;
        }
      }
    }

    private isEventsSelected(): boolean{
      if(this.$scope.eventsToDisplay != null){
        var count: number;
        var index: number;
        count = 0;
        for(index=0; index<this.$scope.eventsToDisplay.length; index++){
          if(this.$scope.eventsToDisplay[index] != null){
            count++;
          }
        }
        return (count > 0);
      } else {
        return true;
      }
    }

    private isSnapParamsSelected(): boolean{

      if(this.$scope.xmlUpload.parameter != null){
        var index: number;
        for(index=0; index<this.$scope.xmlUpload.eventCount; index++){
          if(this.$scope.xmlUpload.parameter[index] != null && this.$scope.xmlUpload.parameter[index].length > 0){
            return true;
          }
        }
      }

      return false;
    }

    private addUploadFile() {
      if(this.$scope.inConfigView){
        return;
      }
      this.$scope.xmlUpload.fileCount = this.$scope.xmlUpload.fileCount + 1;
      this.$scope.xmlUpload.files.push(this.$scope.xmlUpload.fileCount);
    }

    private removeUploadFile() {
      if(this.$scope.inConfigView){
        return;
      }
      var index = this.$scope.xmlUpload.files.indexOf(this.$scope.xmlUpload.fileCount);
      this.$scope.xmlUpload.files.splice(index, 1);
      this.$scope.xmlUpload.fileCount = this.$scope.xmlUpload.fileCount - 1;
      delete this.$scope.xmlUpload.xmlFile[this.$scope.xmlUpload.fileCount];
    }

    private getDownloadURIs(): string[] {
      var uris = [];
      uris = this.$config.ServerURI.split(",");
      return uris;
    }

    private getEvents(tag: any, removed: boolean){

      if(removed){
        let jsonData = JSON.parse(angular.toJson(tag));
        var index = this.$scope.eventsToDisplay.indexOf(jsonData.event);
        if(index < 0){
          index = this.$scope.xmlUpload.events.indexOf(jsonData.event);
          this.$scope.eventsToDisplay.splice(index, 0, jsonData.event);
        }
      } else {
        let jsonData = JSON.parse(angular.toJson(tag));
        var index = this.$scope.eventsToDisplay.indexOf(jsonData.event);
        if(index >= 0)
          delete this.$scope.eventsToDisplay[index];
      }
    }

    private createBundle(form: ng.IFormController) {

      if (this.$scope.inSave) {
          return;
      }
      this.$scope.inSave = true;
      this.$scope.error = null;

      this.RuleBundleCreationService.createBundle(this.$scope.xmlUpload)
      .then(data => {
            this.$scope.inProgress = false;
            this.$scope.inConfigView = false;
            this.$scope.saveSuccess = true;
            this.$scope.step1 = false;
            this.$scope.step2 = false;
            this.$scope.step3 = true;
            this.$scope.inSave = true;
        },null,(notifyData:NotifyData)=> this.RuleBundleCreationProgresNotifyHandle(notifyData))
          .catch(err => {

          this.$scope.saveSuccess = false;
          console.error(err);
          this.$scope.inProgress = false;
          this.$scope.error = err;
          this.$scope.step1 = false;
          this.$scope.step2 = true;
          this.$scope.step3 = false;
          this.$scope.inSave = false;
          this.$window.scrollTo(0,0);
        });
    }

    private RuleBundleCreationProgresNotifyHandle(notifyData:NotifyData){
        if(notifyData && notifyData.message) {
            this.$scope.inProgressMessage = notifyData.message;
        }
    }

    private reset(form: ng.IFormController) {
        this.resetData();
    }

    public resetData() {

        if (this.$scope.savedPackage) {
            this.$scope.originalPackage = this.$scope.savedPackage;
        }
        this.$scope.step1 = true;
        this.$scope.step2 = false;
        this.$scope.step3 = false;
        this.$scope.xmlUpload = this.emptyPackageFactory(this.$scope.originalPackage);
        this.$scope.savedPackage = null;
        this.$scope.error = null;
        this.$scope.inProgress = false;
        this.$scope.inConfigView = false;
        this.$scope.inSave = false;
        this.$scope.initialized = true;
        this.$scope.saveSuccess = false;
        this.$scope.xmlUpload.xmlFile = [];
        this.$scope.xmlUpload.files = [];
        this.$scope.xmlUpload.fileCount = 1;
        this.$scope.xmlUpload.files.unshift(angular.copy(this.$scope.xmlUpload.fileCount));

    }
}

var angularModule = angular.module('directives.ruleBundleCreation.ruleBundleCreationController', [RuleBundleCreationServiceModule.name, UserManagementServiceModule.name,
    AuthServiceModule.name, AclServiceModule.name])
    .controller("RuleBundleCreationController", RuleBundleCreationController);

angularModule.directive('xmlValidate', function($branding: app.branding.IBrandingService) {
    return {
        require: 'ngModel',
        link: function(scope: IRuleBundleCreationControllerScope, el, attrs: any, ctrl: any) {

            var validate = function(ctrl, type) {

                scope.validationMsg = "";
                var branding = (<any>$branding).getBrandingConstants();
                var test_ext: boolean = true, test_name: boolean = true, test_size: boolean = true, size: number, re_name: RegExp, re_ext: RegExp = /\.([a-z.]+)/, val: any, file: string, svd: string, extensions: any, ext: string;
                var test_ext_exist: boolean = true;
                var max_file_size: number;

                val = ctrl.$modelValue ? ctrl.$modelValue.name : null;

                max_file_size = 1 * 1024 * 1024 * 1024; // 1GB

                size = ctrl.$modelValue ? ctrl.$modelValue.size : 0;

                let fileExtChecking = val.split('.');

                if(fileExtChecking.length <= 1) {
                  test_ext_exist = false;
                }

                if(test_ext_exist) {
                  ext = ctrl.$modelValue.name ? ctrl.$modelValue.name.match(re_ext)[1] : null;
                }

                if(ctrl.$modelValue) {
                  scope.lastChoosenXmlFile = ctrl.$modelValue;
                }

                if (extensions != null) {
                    test_ext = extensions.some((el, i, arr) => {
                        return el == ext;
                    })
                }

                if (!val) {
                  scope.validationMsg = 'Rule XML file is required.';
                }
                else if(!test_ext_exist) {
                  scope.validationMsg = 'File without extension are unacceptable!';
                }
                else if(ext != "xml") {
                  scope.validationMsg = 'File extension are unacceptable!';
                }
                else if (val && size > max_file_size) {
                    test_size = false;
                    let $filter = angular.element(document.body).injector().get("$filter");
                    let fileSize = $filter('sizeInBytes')(max_file_size);
                    scope.validationMsg = `Wrong, file is too large. Max size is ${fileSize}`;
                } else {
                  scope.validationMsg = "";
                }

                return test_ext && test_name && test_size && test_ext_exist;
            }

            el.bind('change', function() {
                ctrl.$setValidity('xmlValidate', validate(ctrl, attrs.xmlValidate));
                ctrl.$setDirty();
                scope.$apply(function() {
                    ctrl.$render();
                });
            })
        }
    };
});

angularModule.directive('jsonValidate', function($branding: app.branding.IBrandingService) {
    return {
        require: 'ngModel',
        link: function(scope: IRuleBundleCreationControllerScope, el, attrs: any, ctrl: any) {

            var validate = function(ctrl, type) {

                ctrl.validationMsg = "";
                var branding = (<any>$branding).getBrandingConstants();
                var test_ext: boolean = true, test_name: boolean = true, test_size: boolean = true, size: number, re_name: RegExp, re_ext: RegExp = /\.([a-z.]+)/, val: any, file: string, svd: string, extensions: any, ext: string;
                var test_ext_exist: boolean = true;
                var max_file_size: number;

                val = ctrl.$modelValue ? ctrl.$modelValue.name : null;

                max_file_size = 1 * 1024 * 1024 * 1024; // 1GB

                size = ctrl.$modelValue ? ctrl.$modelValue.size : 0;

                let fileExtChecking = val.split('.');

                if(fileExtChecking.length <= 1) {
                  test_ext_exist = false;
                }

                if(test_ext_exist) {
                  ext = ctrl.$modelValue.name ? ctrl.$modelValue.name.match(re_ext)[1] : null;
                }

                if(ctrl.$modelValue) {
                  scope.lastChoosenXmlFile = ctrl.$modelValue;
                }

                if (extensions != null) {
                    test_ext = extensions.some((el, i, arr) => {
                        return el == ext;
                    })
                }

                if (!val) {
                  ctrl.validationMsg = 'Rule XML file is required.';
                }
                else if(!test_ext_exist) {
                  ctrl.validationMsg = 'File without extension are unacceptable!';
                }
                else if(ext != "json") {
                  ctrl.validationMsg = 'File extension are unacceptable!';
                }
                else if (val && size > max_file_size) {
                    test_size = false;
                    let $filter = angular.element(document.body).injector().get("$filter");
                    let fileSize = $filter('sizeInBytes')(max_file_size);
                    ctrl.validationMsg = `Wrong, file is too large. Max size is ${fileSize}`;
                } else {
                  ctrl.validationMsg = "";
                }

                return test_ext && test_name && test_size && test_ext_exist;
            }

            el.bind('change', function() {
                ctrl.$setValidity('jsonValidate', validate(ctrl, attrs.jsonValidate));
                ctrl.$setDirty();
                scope.$apply(function() {
                    ctrl.$render();
                });
            })
        }
    };
});
export default angularModule;
