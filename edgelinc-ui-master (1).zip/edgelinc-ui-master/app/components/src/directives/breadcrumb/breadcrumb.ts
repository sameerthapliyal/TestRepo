/// <reference path="../../../../app.d.ts" />


import NavigationServiceModule, {INavigationService, IBreadcrumbItem} from "../../services/navigation/NavigationService";

var angularModule = angular.module('directives.breadcrumb',[NavigationServiceModule.name, 'utilities.routeHelpers']);
export default angularModule;

interface IBreadcrumbItemScope extends ng.IScope {
    breadcrumbItem: IBreadcrumbItem;
    active: boolean;
    data: any;
}

angularModule.directive('breadcrumbItem', ['$compile','$parse', function($compile: ng.ICompileService, $parse:ng.IParseService){
    return {
        restrict: "A",
        replace: true,
        scope: {
            breadcrumbItem: '=',
            active: '=',
            data: '=',
        },
        link: (scope: IBreadcrumbItemScope, element: ng.IAugmentedJQuery, attrs: ng.IAttributes) => {
            function update() {
                element.empty();
                
                if(scope.breadcrumbItem != null) {
                    var childElement;
                    if (scope.breadcrumbItem.url) {
                        childElement = angular.element('<a/>')
                            .text(scope.breadcrumbItem.text)
                            .attr('title', scope.breadcrumbItem.text)
                            .attr('ng-href', scope.breadcrumbItem.url);
                    } else if (scope.breadcrumbItem.route) {
                        childElement = angular.element('<a/>')
                            .text(scope.breadcrumbItem.text)
                            .attr('title', scope.breadcrumbItem.text)
                            .attr('route-href', scope.breadcrumbItem.route);
                        if(scope.breadcrumbItem.routeParams) {
                            childElement.attr('route-args', scope.breadcrumbItem.routeParams)
                        }
                        if(scope.breadcrumbItem.routeHash)
                            childElement.attr('route-hash', scope.breadcrumbItem.routeHash);
                    } else {
                        childElement = angular.element('<span/>')
                            .text(scope.breadcrumbItem.text);
                    }
                    element.append(childElement);
                }
                $compile(element.contents())(scope);
            }
            scope.$watch('data', update, false);
            update();
        }
    }
}]);

interface IBreadcrumbScope extends ng.IScope {
    data: any;
    breadcrumbItems: IBreadcrumbItem[];
    isVisible:(breadcrumbItem :IBreadcrumbItem)=>boolean;
}

angularModule.directive('breadcrumb',['$branding', 'NavigationService', '$parse', function($branding: app.branding.IBrandingService, NavigationService: INavigationService, $parse){
    return {
        templateUrl: $branding.getTemplateUrl("directives.breadcrumb"),
        restrict: "E",
        scope:{
            data: '=',
            visible: '='
        },
        link: (scope: IBreadcrumbScope) => {
            scope.breadcrumbItems = NavigationService.getBreadcrumb();
            scope.isVisible = (breadcrumbItem :IBreadcrumbItem)=>{
                if(breadcrumbItem.hide ){
                    var getter = $parse(breadcrumbItem.hide);
                    var show = !getter(scope);
                    return show;
                }
                return true;
            }
        }
    };
}]);
