/**
 * Created by rosadnik on 10-Jun-17.
 */
///<reference path="../../../../typings/browser.d.ts"/>

var angularModule = angular.module('directives.proxBox', []);
export default angularModule;


class proxBoxController{
    private static $inject = ['$scope'];
    constructor($scope){
    }
}

angularModule.directive('proxBox', function () {
    return {
        template:
        '<fieldset class="prox-box">' +
        '  <legend class="prox-box-header">{{header}} <small>{{subheader}}</small></legend>' +
        '  <span  class="prox-box-content" ng-transclude=""></span>' +
        '</fieldset>',
        restrict: "E",
        replace:true,
        transclude: true,
        controller: proxBoxController,
        scope: {
            header: "@",
            subheader: "@"
        },
        link: (scope, element, attributes) => { }
    }
});