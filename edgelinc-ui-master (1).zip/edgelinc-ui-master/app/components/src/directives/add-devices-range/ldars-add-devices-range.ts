/**
 * Created by rosadnik on 24-May-17.
 */
///<reference path="../../../../../typings/browser.d.ts"/>
///<reference path="../../../../components/src/services/parameters-validator/definitions/ParametersVisibility.d.ts"/>

import PredixDevicesServiceModule, {
    PredixDevicesService,
    IPredixDeviceToAdd, IPredixDevice
} from "../../services/predix/PredixDevicesService";
import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";
import GroupOperationsServiceModule, {GroupOperationsService} from "../../services/GroupOperationsService";
import DeviceServiceModule, {DeviceService, IDevicesToAdd, IDeviceToAdd,IAddDevicesResult} from "../../services/DeviceService";
import AuthServiceModule, {AuthService} from "../../services/AuthService";
import ProxMapperServiceModule, {FieldsMapping, ProxMapperService} from "../../utilities/proxMapper";
import {ProxListController} from "../list-header/prox-list";
import addDevicesGroupOperationSummaryModule from "../add-devices-range/add-devices-group-operation-summary";
//import {IListComponent, PredixListController, makeListComponent,makeListComponentButton} from "../../directives/predix/devices/predix-device-list/predix-list";
import ConfigServiceModule, {ConfigService} from "../../services/ConfigService";
import ParametersValidatorServiceModule, {ParametersValidatorService, ParametersValidatorWrapper} from "../../services/ParametersValidatorService";
import {ParametersVisibility} from "../../services/parameters-validator/definitions/ParametersVisibility";
import {ParameterRestriction} from "../../services/parameters-validator/definitions/ParameterRestriction";
import {HttpError} from "../../utilities/RestHelper";

var directiveName = "ldarsAddDevicesRange";

interface IAddDeviceViaMcs {
    interfaces: {
        options: Array<string>;
        selectedInterface: string;
    }
    uplincgateway: {
        addDevice: {
            devices: Array<string>;
            selectedDevice: string;
            range:{
                from:number;
                to:number;
            }
            singleLocoId:number;
        },
        addSerialNumber: {
            number: number;
        }
    }
    qnxGateway: {
        addQNXCustomerId: {
            selectedId: string;
        }
        addQNXDevice: {
            devices: Array<string>;
            selectedDevice: string;
        }
        addQNXAntennaMfg: {
            antennas: {[key: string]: string};
            selectedAntennaMfg: string;
        }
        addQNXAntennaModel: {
            antennaModels: {[key: string]: string};
            selectedModel: string;
        }
    }
}

interface IDeviceData {
    iterator: string; //number;
    deviceToAdd?: IDeviceToAdd;
    result?: {
        success?: boolean;
        asdid?: string;
        reason?: string;
        assertions_set?: boolean;
        reregistered?:boolean;
    }
    sort_status?:number;
}

interface IPredixAddDeviceScope extends ng.IScope {
    state: {
        active: boolean;
        completed: boolean;
        success: boolean;
        initError: HttpError;
        errorMessage: boolean;
        inProgress: boolean;
    }
    device: any;
    predix_mapping: FieldsMapping;
    ldars_mapping: FieldsMapping;
    predixDevice: IPredixDeviceToAdd[] | IDevicesToAdd;
    addedDevice: IPredixDeviceToAdd[] | IDevicesToAdd;
    addDevice(form: ng.IFormController): void;
    close(): void;
    onAdded(): void;
    formChange(): void;
    showWarning: boolean;
    mcsProperties: IAddDeviceViaMcs;
    
    upperLocoIdLimit():number;
    lowerLocoIdLimit():number;
    iterator:string;
    user_login:string;
    
    // group operation summary
    added:boolean;
    successDevices:number;
    failedDevices:number;
    inProgressDevices:number;
    reregisteredDevices:number;
    operation_id:string;
    totalDevices:number;
    devicesData:IDeviceData[];
    startAddDevice:()=>void;
    
    duplicateDev:App.Models.SearchResult<eapi18.DeviceFromDSC>;
    missingLocmotive:string[];
    allDevicesFromRangeExist:boolean;
    maxNumberOfDeviceToBeSkipInRange:number;
    
    showLocoIdColumn:boolean;
    showCustomerIdColumn:boolean;
    showDeviceNameColumn:boolean;
    expectAssertionTaskInRegistration:boolean;
}

class PredixAddDeviceController /*implements IListComponent*/ {
    public static $inject = ["$scope", "$q", "$timeout","ProxMapper", "PredixDevicesService", "DeviceModelsService", "GroupOperationsService", "AuthorizationService", "$config",
        "ParametersValidatorService", "DeviceService"];
    
    public addDeviceForm: ng.IFormController;

    private parameterValidators: {[modelVersion: string]: ParametersValidatorWrapper} = {};
    //private _predixListController: PredixListController;
    
    constructor(
        private $scope: IPredixAddDeviceScope,
        private $q: ng.IQService,
        private $timeout: ng.ITimeoutService,
        private ProxMapper: ProxMapperService,
        private PredixDevicesService: PredixDevicesService,
        private DeviceModelsService: DeviceModelsService,
        private GroupOperationsService: GroupOperationsService,
        private authorizationService: AuthService,
        private _config:ConfigService,
        private ParametersValidatorService:ParametersValidatorService,
        private DeviceService: DeviceService
    ) {
        this.$scope.maxNumberOfDeviceToBeSkipInRange = 500;
        this.$scope.showLocoIdColumn = true;
        this.$scope.showCustomerIdColumn = true;
        this.$scope.showDeviceNameColumn = false;
        this.$scope.expectAssertionTaskInRegistration = true;
        
        this.$scope.state = {
            active: false,
            completed: false,
            success: null,
            initError: null,
            errorMessage: null,
            inProgress: false
        };
        this.$scope.showWarning = false;
        this.$scope.addDevice = (form: ng.IFormController) => this.addDevice(form);
        this.$scope.close = () => this.close();
        this.$scope.formChange = () => this.formChanged();
        this.$scope.mcsProperties = {
            interfaces: {
                options: ['UpLINCGateway', 'QNX Gateway'],
                selectedInterface: ''
            },
            uplincgateway: {
                addDevice: {
                    devices: ['HPEAP'],
                    selectedDevice: '',
                    range:{
                        from:null,
                        to:null
                    },
                    singleLocoId:null
                },
                addSerialNumber: {
                    number: 0
                }
            },
            qnxGateway: {
                addQNXCustomerId: {
                    selectedId: ''
                },
                addQNXDevice: {
                    devices: ['LCV','HPEAP'],
                    selectedDevice: ''
                },
                addQNXAntennaMfg: {
                    antennas: null,
                    selectedAntennaMfg: ''
                },
                addQNXAntennaModel: {
                    antennaModels: null,
                    selectedModel: ''
                }
            },
        };
        this.reset();
    
        this.$scope.startAddDevice = ()=>{
            this.$scope.state.active = !this.$scope.state.active;
            if(!this.$scope.state.active){
                this.reset();
            }
        };
        var checkDeviceExistence_debounce = _.debounce(()=>this.checkDeviceExistence(),1000);
        var checkLocomotiveExistence_debounce = _.debounce(()=>this.checkLocomotiveExistence(),1000);
        
        $scope.upperLocoIdLimit = ()=>{
            return Math.max(Math.min(this.$scope.mcsProperties.uplincgateway.addDevice.range.to || 9999999, 9999999),0);
        };
        $scope.lowerLocoIdLimit = ()=>{
            return Math.max(Math.min(this.$scope.mcsProperties.uplincgateway.addDevice.range.from || 0, 9999999),0);
        };
        
        $scope.user_login = this.authorizationService.getLoginUserName();
        
        $scope.$watch("mcsProperties.qnxGateway.addQNXDevice.selectedDevice",()=>{
            this.updateRestrictions();
            checkDeviceExistence_debounce();
        });
        $scope.$watch("mcsProperties.qnxGateway.addQNXAntennaMfg.selectedAntennaMfg",()=>{
            this.updateRestrictions();
        });
        $scope.$watch("mcsProperties.qnxGateway.addQNXAntennaModel.selectedModel",()=>{
            this.updateRestrictions();
            checkDeviceExistence_debounce();
        });
        
        $scope.$watch("mcsProperties.qnxGateway.addQNXCustomerId.selectedId",()=>{
            checkDeviceExistence_debounce();
            checkLocomotiveExistence_debounce();
        });
        
        $scope.$watch("mcsProperties.uplincgateway.addDevice.singleLocoId",()=>{
            checkDeviceExistence_debounce();
            checkLocomotiveExistence_debounce();
        });
    
        $scope.$watch("mcsProperties.uplincgateway.addDevice.range.from",()=>{
            checkDeviceExistence_debounce();
            checkLocomotiveExistence_debounce();
        });
    
        $scope.$watch("mcsProperties.uplincgateway.addDevice.range.to",()=>{
            checkDeviceExistence_debounce()
            checkLocomotiveExistence_debounce();
        });
    }
    
    getComponentKey():string {
        return directiveName;
    }
    
    //attach(predixListController:PredixListController):void {
    //    this._predixListController = predixListController;
    //}
    
    start(): boolean {
        this.reset();
        this.$scope.state.active = true;
        return true;
    }
    
    close(): boolean {
        this.reset();
        if(this.$scope.state.inProgress) {
            return false;
        }
        this.$scope.state.active = false;
        return true;
    }
    
    isActive(): boolean {
        return this.$scope.state.active;
    }
    
    isEnabled(): boolean {
        return !this.$scope.state.inProgress;
    }
    
    private getRestriction(deviceModel: string, modelVersion: string, apiName: string):ng.IPromise<ParameterRestriction> {
        let key = `${deviceModel}/${modelVersion}`;
        var parameters: eapi19.Parameters = new Array();
        if(this.$scope.mcsProperties.qnxGateway.addQNXAntennaMfg.selectedAntennaMfg) {
            parameters.push({
                api_name: "antenna_mfg",
                value: this.$scope.mcsProperties.qnxGateway.addQNXAntennaMfg.selectedAntennaMfg
            });
        }
        if(this.$scope.mcsProperties.qnxGateway.addQNXAntennaModel.selectedModel) {
            parameters.push({
                api_name: "antenna_model",
                value: this.$scope.mcsProperties.qnxGateway.addQNXAntennaModel.selectedModel
            });
        }
        
        if(!_.has(this.parameterValidators, key)) {
            this.parameterValidators[key] = this.ParametersValidatorService.getInstance(this.$scope, deviceModel, modelVersion);
        }
        var restriction = this.parameterValidators[key].getRestriction(apiName, parameters); // TODO: pass current parameters
        return restriction;
    }
    
    private addDevice(form: ng.IFormController) {
        if(this.$scope.mcsProperties.interfaces.selectedInterface == "QNX Gateway"){
            this.addDevice_Go(form);
        }else{
            this.addDevice_Predix(form);
        }
    }
    
    private addDevice_Predix(form: ng.IFormController) {
        if(this.$scope.state.inProgress) {
            return;
        }
        
        if(!this.$scope.device.serialNumber && !this.$scope.mcsProperties.uplincgateway.addSerialNumber.number){
            this.$scope.showWarning = true;
            return;
        }
        this.$scope.state.inProgress = true;
        var device: IPredixDeviceToAdd = this.ProxMapper.map(this.$scope, this.$scope.predix_mapping);
        this.$scope.predixDevice = [device];
        var dt_send = Date.now();
        this.PredixDevicesService.addDeviceToInventory(device)
        .then(addedDevice => {
            //this.$scope.addedDevice = addedDevice;
            this.$scope.state.success = true;
            this.$scope.onAdded();
            var dt_end = Date.now();
            //if(this._predixListController) {
            //    this._predixListController.refresh();
            //}
            //this.tryGetNewCreatedDeviceActivationCode(device.did);
            this.$timeout(()=>{
                this.addDevice_Predix_getGroupOperationId(device, dt_send, dt_end).then((goId)=>{
                    this.$scope.operation_id = goId;
                    this.$scope.showLocoIdColumn = false;
                    this.$scope.showCustomerIdColumn = false;
                    this.$scope.showDeviceNameColumn = true;
                    this.$scope.expectAssertionTaskInRegistration = false;
                });
            },this._config.DeviceEventFromWebsocketDelay);
        })
        .catch(err => {
            this.$scope.state.errorMessage = err.message;
            this.$scope.state.success = false;
        })
        .finally(() => {
            this.$scope.state.inProgress = false;
            this.$scope.state.completed = true;
            this.$scope.$emit('smartTable:refreshRequired');
        });
    }
    
    private addDevice_Predix_getGroupOperationId(device:IPredixDeviceToAdd, dt_send:number, dt_end:number):ng.IPromise<string>{
        return this.GroupOperationsService.getTasks({taskType:"registration", filter:`data.deviceName eq "${device.name}"`, createDate:{from: dt_send, to: dt_end}},"operation_id", "desc",500,0)
        .then((tasks:App.Models.SearchResult<models.GroupOperations.ITaskItem>)=>{
            var goId = null;
            if(tasks.items && tasks.items.length > 0){
                goId = tasks.items[0].operation_id;
                return goId;
            }else{
                return  this.$q.reject("Group Operation not found");
            }
        });
    }
    
    private addDevice_Go(form: ng.IFormController) {
        if(this.$scope.state.inProgress) {
            return;
        }
        // add device using gooup operation
        this.$scope.state.inProgress = true;
        var devicesToAdd:IDevicesToAdd = [];
    
        let getDuplicateDevicePromise:ng.IPromise<App.Models.SearchResult<eapi18.DeviceFromDSC>>
        if (this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId!= null) {
            getDuplicateDevicePromise = this.DeviceService.getSystemDevices(
                {
                    attributes: {
                        "customer_id": this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId,
                        "device_type": this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice
                    },
                    deviceModels: [(<any>this.$scope.$root).brandConstants.mcsEnrolledDeviceTypes[this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice].deviceModel],
                    cmsNumericLocoId: {
                        from: this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId,
                        to: this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId
                    }
                }, "loco_id", "asc", 20)
            
        } else if (this.$scope.mcsProperties.uplincgateway.addDevice.range.from != null && this.$scope.mcsProperties.uplincgateway.addDevice.range.to != null) {
            getDuplicateDevicePromise = this.DeviceService.getSystemDevices(
                {
                    attributes: {
                        "customer_id": this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId,
                        "device_type": this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice
                    },
                    deviceModels: [(<any>this.$scope.$root).brandConstants.mcsEnrolledDeviceTypes[this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice].deviceModel],
                    cmsNumericLocoId: {
                        from: this.$scope.mcsProperties.uplincgateway.addDevice.range.from,
                        to: this.$scope.mcsProperties.uplincgateway.addDevice.range.to
                    }
                }, "loco_id", "asc", 20)
        } else{
            getDuplicateDevicePromise = this.$q.resolve({ items:[], totalCount:0 });
        }
        
        getDuplicateDevicePromise.then((devDuplicate:App.Models.SearchResult<eapi18.DeviceFromDSC>)=>{
            this.devicesData = [];
            for( var iterator_number = parseInt(<any>this.$scope.mcsProperties.uplincgateway.addDevice.range.from || this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId || 0);
                 iterator_number <= parseInt(<any>this.$scope.mcsProperties.uplincgateway.addDevice.range.to || this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId || 0);
                iterator_number++)
            {
                if(devDuplicate.totalCount > this.$scope.maxNumberOfDeviceToBeSkipInRange){
                    this.$scope.state.inProgress = false;
                    return ;
                }
                
                this.$scope.iterator = iterator_number.toString();
                
                var device: IDeviceToAdd = this.ProxMapper.map(this.$scope, this.$scope.ldars_mapping);
    
                //check if this device already exist
                let existingDuplicate = _.find(devDuplicate.items, (exDev:eapi18.DeviceFromDSC)=>{
                    if(exDev && exDev.assertions && device && device.attributes && exDev.assertions['$attributes/loco_id'] && exDev.assertions['$attributes/customer_id']) {
                        return exDev.assertions['$attributes/loco_id'] == device.attributes['$attributes/loco_id'] &&
                            exDev.assertions['$attributes/customer_id'] == device.attributes['$attributes/customer_id'] &&
                            exDev.assertions['$attributes/device_type'] == device.attributes['$attributes/device_type'];
                    }else {
                        return false;
                    }
                });
    
                if(!existingDuplicate) {
                    devicesToAdd.push(device);
                    this.devicesData.push({
                        iterator: this.$scope.iterator,
                        deviceToAdd: device,
                        result: {success: null, assertions_set: null}
                    });
                }
            }
            this.$scope.operation_id == null;
            this.$scope.predixDevice = devicesToAdd;
            if(devicesToAdd.length > 0) {
                this.GroupOperationsService.addDevicesGO(devicesToAdd).then((result: eapi18.GroupOperationIdObject) => {
                    //this.getAndDisplayTaskDetails(result.operation_id, 0);
                    this.$scope.state.inProgress = false;
                    this.$scope.state.success = true;
                    this.$scope.operation_id = result.operation_id;
                    this.$scope.showLocoIdColumn = true;
                    this.$scope.showCustomerIdColumn = true;
                    this.$scope.showDeviceNameColumn = false;
                    this.$scope.expectAssertionTaskInRegistration = true;
                }).catch((err) => {
                    this.$scope.state.errorMessage = err.message;
                    this.$scope.state.success = false;
                }).finally(() => {
                    this.$scope.state.inProgress = false;
                    this.$scope.state.completed = true;
                    this.$scope.$emit('smartTable:refreshRequired');
                });
            }else{
                this.$scope.state.inProgress = false;
                this.$scope.predixDevice =[];
            }
        });
    }
    
    private reset() {
        this.$scope.showLocoIdColumn = true;
        this.$scope.showCustomerIdColumn = true;
        this.$scope.showDeviceNameColumn = false;
        this.$scope.expectAssertionTaskInRegistration = true;
        
        this.$scope.device = {};
        this.$scope.predixDevice = null;
        this.$scope.addedDevice = null;
        this.$scope.operation_id = null;
        this.$scope.state.active = false;
        this.$scope.state.completed = false;
        this.$scope.state.success = null;
        this.$scope.state.initError = null;
        this.$scope.state.errorMessage = null;
        this.$scope.state.inProgress = false;
    
        this.$scope.mcsProperties.interfaces.selectedInterface = '';
        this.$scope.mcsProperties.uplincgateway.addDevice.selectedDevice ="";
        this.$scope.mcsProperties.uplincgateway.addDevice.range.from = null;
        this.$scope.mcsProperties.uplincgateway.addDevice.range.to = null;
        this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId = null;
        this.$scope.mcsProperties.uplincgateway.addSerialNumber.number = null;
        this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId ="";
        this.$scope.mcsProperties.qnxGateway.addQNXAntennaMfg.selectedAntennaMfg ="";
        this.$scope.mcsProperties.qnxGateway.addQNXAntennaMfg.antennas = null;
        this.$scope.mcsProperties.qnxGateway.addQNXAntennaModel.selectedModel ="";
        this.$scope.mcsProperties.qnxGateway.addQNXAntennaModel.antennaModels = null;
        this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice ="";
        
        if(this.addDeviceForm) {
            this.addDeviceForm.$setPristine();
        }
    }
    
    private formChanged() {
        this.$scope.showWarning = false;
    }
    
    private devicesData: IDeviceData[];
    
    public updateRestrictions(){
        var selectedDevModel = this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice;
        if(selectedDevModel && window.BRANDING.ui.constants.mcsEnrolledDeviceTypes[selectedDevModel]){
            var deviceModel = window.BRANDING.ui.constants.mcsEnrolledDeviceTypes[selectedDevModel].deviceModel;
            var modelVersion = window.BRANDING.ui.constants.mcsEnrolledDeviceTypes[selectedDevModel].modelVersion;
        
            if(deviceModel && modelVersion) {
                let antennaMfgPromise = this.getRestriction(deviceModel, modelVersion, "antenna_mfg").then((data: ParameterRestriction)=>{
                    console.log("antenna_mfg restriction", data);
                    this.$scope.mcsProperties.qnxGateway.addQNXAntennaMfg.antennas = !_.isEmpty(data.options) ? data.options : null;
                });
                let antennaModelPromise = this.getRestriction(deviceModel, modelVersion, "antenna_model").then((data: ParameterRestriction)=>{
                    console.log("antenna_model restriction", data);
                    this.$scope.mcsProperties.qnxGateway.addQNXAntennaModel.antennaModels = !_.isEmpty(data.options) ? data.options : null;
                });
                this.$q.all([antennaMfgPromise, antennaModelPromise])
                    .then(response => {
                        this.$scope.state.initError = null;
                    })
                    .catch(err => {
                        this.$scope.state.initError = err;
                    });
            }
        }
    }
    
    private checkDeviceExistence_lastId:number = 0;
    private checkDeviceExistence() {
        if ( this.$scope.mcsProperties.interfaces.selectedInterface == "QNX Gateway" &&
             this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId &&
             this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice &&
            (this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId || (this.$scope.mcsProperties.uplincgateway.addDevice.range.from && this.$scope.mcsProperties.uplincgateway.addDevice.range.to)))
        {
            this.checkDeviceExistence_lastId++;
            var checkLocomotiveExistence_id = this.checkDeviceExistence_lastId;

            if (this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId!= null) {
                this.DeviceService.getSystemDevices(
                    {
                        attributes: {
                            "customer_id": this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId,
                            "device_type": this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice
                        },
                        deviceModels: [(<any>this.$scope.$root).brandConstants.mcsEnrolledDeviceTypes[this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice].deviceModel],
                        cmsNumericLocoId: {
                            from: this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId,
                            to: this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId
                        }
                    }, "loco_id", "asc", 20).then((duplicateDev: App.Models.SearchResult<eapi18.DeviceFromDSC>) => {
                        if (checkLocomotiveExistence_id == this.checkDeviceExistence_lastId) {
                            this.$scope.duplicateDev = duplicateDev;
                            this.$scope.allDevicesFromRangeExist = duplicateDev.totalCount == 1;
                        }
                    });
            } else if (this.$scope.mcsProperties.uplincgateway.addDevice.range.from != null && this.$scope.mcsProperties.uplincgateway.addDevice.range.to != null) {
                this.DeviceService.getSystemDevices(
                    {
                        attributes: {
                            "customer_id": this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId,
                            "device_type": this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice
                        },
                        deviceModels: [(<any>this.$scope.$root).brandConstants.mcsEnrolledDeviceTypes[this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice].deviceModel],
                        cmsNumericLocoId: {
                            from: this.$scope.mcsProperties.uplincgateway.addDevice.range.from,
                            to: this.$scope.mcsProperties.uplincgateway.addDevice.range.to
                        }
                    }, "loco_id", "asc", 20).then((duplicateDev: App.Models.SearchResult<eapi18.DeviceFromDSC>) => {
                        if (checkLocomotiveExistence_id == this.checkDeviceExistence_lastId) {
                            this.$scope.duplicateDev = duplicateDev;
                            this.$scope.allDevicesFromRangeExist = duplicateDev.totalCount ==  this.$scope.mcsProperties.uplincgateway.addDevice.range.to - this.$scope.mcsProperties.uplincgateway.addDevice.range.from + 1;
                        }
                    });
            } else {
                this.$scope.duplicateDev = null;
            }
        } else {
            this.$scope.duplicateDev = null;
        }
    }
    
    private checkLocomotiveExistence_lastId:number = 0;
    private checkLocomotiveExistence(){
        this.checkLocomotiveExistence_lastId++;
        var checkLocomotiveExistence_id = this.checkLocomotiveExistence_lastId;
        if(this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId != null)
        {
            if(this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId != null){
                this.DeviceService.getSystems(
                    {
                        attributes:{customer_id:this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId},
                        numericLocoId:{
                            from:this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId,
                            to: this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId
                        }
                    }, "loco_id", "asc", 20).then((locmotive:App.Models.SearchResult<App.Models.ISystem>)=>{
                        this.displayMissingLocomotive(locmotive);
                    });
            }else if(this.$scope.mcsProperties.uplincgateway.addDevice.range.from != null && this.$scope.mcsProperties.uplincgateway.addDevice.range.to != null){
                this.DeviceService.getSystems(
                    {
                        attributes:{customer_id:this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId},
                        numericLocoId:{
                            from:this.$scope.mcsProperties.uplincgateway.addDevice.range.from,
                            to: this.$scope.mcsProperties.uplincgateway.addDevice.range.to
                        }
                    }, "loco_id", "asc", 20).then((locmotive:App.Models.SearchResult<App.Models.ISystem>)=>{
                        if(this.checkLocomotiveExistence_lastId == checkLocomotiveExistence_id){
                            this.displayMissingLocomotive(locmotive);
                        }
                    });
            }else{
                this.$scope.missingLocmotive = [];
            }
        }else {
            this.$scope.missingLocmotive = [];
        }
    }
    
    private displayMissingLocomotive(locmotive:App.Models.SearchResult<App.Models.ISystem>):void{
        this.$scope.missingLocmotive = [];
        var from,to:number;
        if(this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId != null){
            from =this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId;
            to =this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId;
        }else if(this.$scope.mcsProperties.uplincgateway.addDevice.range.from != null && this.$scope.mcsProperties.uplincgateway.addDevice.range.to != null){
            from = this.$scope.mcsProperties.uplincgateway.addDevice.range.from;
            to = this.$scope.mcsProperties.uplincgateway.addDevice.range.to;
        }else{
            return;
        }
        let locoId:number;
        for(locoId = from; locoId<= to; locoId++){
            let missingLoco = _.find(locmotive.items, (loco:App.Models.ISystem)=>{ return loco.numericLocoId == locoId; }) == null;
            if(missingLoco){
                if(this.$scope.missingLocmotive.length < 20){
                    this.$scope.missingLocmotive.push(`${this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId} ${locoId}`);
                    
                }else{
                    this.$scope.missingLocmotive.push("...");
                    return;
                }
            }
        }
        console.log("missingLocmotive",this.$scope.missingLocmotive);
    }
}

export default angular.module('directives.ldarsAddDevicesRange', [ProxMapperServiceModule.name, PredixDevicesServiceModule.name, DeviceModelsServiceModule.name, GroupOperationsServiceModule.name,
    DeviceServiceModule.name, AuthServiceModule.name, addDevicesGroupOperationSummaryModule.name])
.directive("ldarsAddDevicesRange", ['$branding', function($branding){
    return {
        templateUrl: $branding.getTemplateUrl('LdarsAddDevicesRangeDirective'),
        controller: PredixAddDeviceController,
        controllerAs: 'ctrl',
        scope: {
            onAdded: "&",
            startAddDevice:"="
        }
    };
}]);
