
import {ParameterRestriction} from "../../../services/parameters-validator/definitions/ParameterRestriction";
import ParametersValidatorServiceModule, {ParametersValidatorService, ParametersValidatorWrapper} from "../../../services/ParametersValidatorService";
import {HttpError} from "../../../utilities/RestHelper";

interface IDeviceParametersFormOptions {
    deviceModel?: string;
    modelVersion?: string;
}

interface IDeviceParametersFormAttributes extends ng.IAttributes {
    deviceParametersForm: string;
    deviceParametersFormOptions: string;
}


function getParametersList(parameters: {[apiName: string]: any}): {api_name: string, value: string}[] {
    return _.map(parameters, (value, apiName) => {
        return {
            api_name: apiName,
            value: value
        };
    });
}

const REFRESH_EVENT = `DeviceParametersFormController:refresh`;

class DeviceParametersFormController {
    public error: HttpError;
    public errorVisible: boolean;

    private parametersValidator: ParametersValidatorWrapper;
    private options: IDeviceParametersFormOptions = {};
    private parametersList: {api_name: string, value: string}[];
    private parameters: {[apiName: string]: any} = {};

    public static $inject = ['$scope', '$attrs', '$q', '$parse', 'ParametersValidatorService'];

    constructor(private $scope: ng.IScope,
                private $attrs: IDeviceParametersFormAttributes,
                private $q: ng.IQService,
                private $parse: ng.IParseService,
                private ParametersValidatorService: ParametersValidatorService
    ) {
        let parametersGetter = $parse($attrs.deviceParametersForm);
        let optionsGetter = $parse($attrs.deviceParametersFormOptions);

        this.options = optionsGetter($scope);
        this.parametersList = getParametersList(parametersGetter($scope));

        $scope.$watch(optionsGetter.bind(null, $scope), (options: IDeviceParametersFormOptions) => {
            this.options = options;
            this.refreshOptions();
            this.$scope.$broadcast(REFRESH_EVENT);
        }, true);


        $scope.$watch(parametersGetter.bind(null, $scope), (parameters: {[apiName: string]: any}) => {
            this.parameters = parameters;
            this.refreshParameters();
            this.$scope.$broadcast(REFRESH_EVENT);
        }, true);
    }

    private refreshOptions() {
        if (this.parametersValidator) {
            this.parametersValidator.destroy();
        }
        if(this.options.deviceModel && this.options.modelVersion) {
            this.parametersValidator = this.ParametersValidatorService.getInstance(this.$scope, this.options.deviceModel, this.options.modelVersion);
        }
    }

    private refreshParameters() {
        this.parametersList = getParametersList(this.parameters);
    }

    public refresh() {
        this.refreshOptions();
        this.refreshParameters();
        this.$scope.$broadcast(REFRESH_EVENT);
    }

    getRestriction(apiName: string): ng.IPromise<ParameterRestriction> {
        if(this.parametersValidator) {
            return this.parametersValidator.getRestriction(apiName, this.parametersList)
                .then(result => {
                    if(this.error) {
                        this.error = null;
                        this.refresh();
                    }
                    return result;
                })
                .catch(err => {
                    this.error = err;
                    this.errorVisible = true;
                    return this.$q.reject(err);
                })
        } else {
            return this.$q.resolve({});
        }
    }
}

function DeviceParametersFormDirective() {
    return {
        restrict: "A",
        require: ["deviceParametersForm", "?form"],
        controller: DeviceParametersFormController,
        link: (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrls: [DeviceParametersFormController, ng.IFormController]) => {
            if(ctrls[1]) {
                ctrls[1]['deviceParametersForm'] = ctrls[0];
            }
        }
    }
}

function DeviceParametersFormOptions() {
    return {
        restrict: "A",
        require: "deviceParametersForm",
        link: () => {}
    }
}

interface IDeviceParameterDropDownDirectiveScope extends ng.IScope {
    apiName: string;
    model: any;
    required: boolean;
    restriction: ParameterRestriction;
    isEmpty: boolean;
    inProgress: boolean;
}

function DeviceParameterDropDownDirective() {
    return {
        restrict: "E",
        require: ["^deviceParametersForm", "ngModel"],
        templateUrl: "/components/src/directives/add-devices-range/device-parameters/device-parameter-dropdown.html",
        scope: {
            apiName: "@apiName",
            model: "=ngModel",
            required: "=required"
        },
        link: (scope: IDeviceParameterDropDownDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrls: [DeviceParametersFormController, ng.INgModelController]) => {
            let deviceParametersFormCtrl: DeviceParametersFormController = ctrls[0];

            function refreshRestriction() {
                scope.inProgress = true;
                deviceParametersFormCtrl.getRestriction(scope.apiName)
                    .then(restriction => {
                        scope.inProgress = false;
                        scope.restriction = restriction;
                        scope.isEmpty = _.isEmpty(restriction.options);
                    })
                    .catch(() => {
                        scope.inProgress = false;
                    });
            }

            scope.restriction = null;
            refreshRestriction();
            scope.$on(REFRESH_EVENT, refreshRestriction);

        }
    }
}

export default angular.module('directives.addDevicesRange.deviceParameters', [ParametersValidatorServiceModule.name])
    .directive('deviceParametersForm', DeviceParametersFormDirective)
    .directive('deviceParametersFormOptions', DeviceParametersFormOptions)
    .directive('deviceParameterDropDown', DeviceParameterDropDownDirective);