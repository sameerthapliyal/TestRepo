///<reference path="../../../../../typings/browser.d.ts"/>

import ProxMapperServiceModule, {ProxMapperService, FieldsMapping} from "../../utilities/proxMapper";
import {ProxListController} from "../list-header/prox-list";
import DeviceServiceModule, {DeviceService, IDeviceToAdd} from "../../services/DeviceService";
import GroupOperationsServiceModule, {GroupOperationsService} from "../../services/GroupOperationsService";
import CommonServicesModule, {CommonServices} from "../../services/CommonServices";
import AuthorizationServiceModule, {AuthService} from "../../services/AuthService";
import AllowedCharactersModule from "../../directives/validators/allowedCharacters";
import ConfigServiceModule, {ConfigService} from "../../services/ConfigService";
import addDevicesGroupOperationSummaryModule from "./add-devices-group-operation-summary";
import ParametersValidatorServiceModule, {
    ParametersValidatorService,
    ParametersValidatorWrapper
} from "../../services/ParametersValidatorService";
import {ParameterRestriction} from "../../services/parameters-validator/definitions/ParameterRestriction";
import ParameterValidatorDirectiveModule from "./device-parameters/device-parameters";

interface SubjectAssertion {
    predicate: string;
    object: string;
}

interface IDeviceData {
    common: any;
    iterator: string; //number;
    deviceToAdd?: IDeviceToAdd;
    result?: {
        success?: boolean;
        asdid?: string;
        reason?: string;
        assertions_set?: boolean;
        reregistered?:boolean;
    }
    sort_status?:number;
}

interface IAddDevicesRangeScope extends ng.IScope {
    active: boolean;
    inProgress: boolean;
    added: boolean;
    successDevices: number;
    failedDevices: number;
    reregisteredDevices: number;
    inProgressDevices: number;
    totalDevices: number;
    devicesData: {
        common: any,
        range: {
            from: number;
            to: number;
        },
        mapping?: FieldsMapping;
        singleLocoId?: number;
    }
    devicesPreview: IDeviceData[];
    details: {
        visible: boolean;
    }
    /*mcsProperties: {
        visible: boolean;
    }*/
    pipe(tableState: any): void;
    start(): void;
    addDevices(addDevicesForm: ng.IFormController): void;
    close(): void;
    onAdded(): void;
    upperLocoIdLimit():number;
    lowerLocoIdLimit():number;

    operationDescriptionOneDevice:string;
    operationDescriptionManyDevice:string;

    fleetOptions:ddOptions[];
    manufacturerOptions:ddOptions[];
    typeOptions:ddOptions[];
    modelOptions:ddOptions[];
    controlerConfigOptions:ddOptions[];
    eventRecorderTypesOptions:ddOptions[];
    equipmentStatusOptions:ddOptions[];
    
    devicesToAdd: IDeviceToAdd[];
    
    duplicateLocmotive:App.Models.SearchResult<App.Models.ISystem>;
    allDevicesFromRangeExist:boolean;
    notsupportedCustormerId:boolean;
    maxNumberOfDeviceToBeSkipInRange:number;
    
    operation_id:string;
    
    getTaskDetails_Error:any;
}

interface ddOptions{
    name:string;
    value:any;
}

class AddDevicesRangeController {
    public static $inject = [
        "$scope",
        "$timeout",
        "$q",
        "ProxMapper",
        "DeviceService",
        "GroupOperationsService",
        "ParametersValidatorService",
        "AuthorizationService",
        "$config",
        "$branding"
    ];

    public addDevicesForm: ng.IFormController;

    private devicesData: IDeviceData[];
    private parameterValidators: {
        [modelVersion: string]: ParametersValidatorWrapper
    } = {};

    constructor(private $scope: IAddDevicesRangeScope,
                private $timeout: ng.ITimeoutService,
                private $q:ng.IQService,
                private ProxMapper: ProxMapperService,
                private DeviceService: DeviceService,
                private GroupOperationsService:GroupOperationsService,
                private ParametersValidatorService: ParametersValidatorService,
                private AuthService:AuthService,
                private _config:ConfigService,
                private $branding: app.branding.IBrandingService )
    {
    
        $scope.maxNumberOfDeviceToBeSkipInRange = 500;
        $scope.devicesData = {
            common: {},
            range: {
                from: null,
                to: null
            },
            singleLocoId: null,
        };
        $scope.details = {
            visible: true
        };
        /*$scope.mcsProperties = {
            visible: !this._config.$config.PRODUCTION
        };*/
        $scope.devicesPreview = [];
        $scope.totalDevices = 0;
        $scope.pipe = (tableState: any) => this.pipe(tableState);
        $scope.start = () => {
            if(this.$scope.added){
                this.reset();
            }
            $scope.active = true;
        };
        
        
        $scope.addDevices = () => this.addDevices_GO();
        //$scope.addDevices = () => this.addDevices();
        $scope.close = () =>{
            this.reset();
        };

        $scope.$on("$destroy",()=>{
            if(this.getAndDisplayTaskDetails_promise) {
                this.$timeout.cancel(this.getAndDisplayTaskDetails_promise)
            }
        });

        $scope.upperLocoIdLimit = ()=>{
            return Math.max(Math.min(this.$scope.devicesData.range.to || 9999999, 9999999),0);
        };
        $scope.lowerLocoIdLimit = ()=>{
            return Math.max(Math.min(this.$scope.devicesData.range.from || 0, 9999999),0);
        };
        $scope.devicesData.common.userName = this.AuthService.getLoginUserName();
        //this.initDropDownValues();
        var checkLocomotiveExistence_debounce = _.debounce(()=>this.checkLocomotiveExistence(),1000);
        
        $scope.$watch("devicesData.common.customerId", (new_customerId:string)=>{
            checkLocomotiveExistence_debounce();     
        });
    
        $scope.$watch("devicesData.singleLocoId", (new_customerId:string)=>{
            checkLocomotiveExistence_debounce();
        });
    
        $scope.$watch("devicesData.range.from", (new_customerId:string)=>{
            checkLocomotiveExistence_debounce();
        });
        $scope.$watch("devicesData.range.to", (new_customerId:string)=>{
            checkLocomotiveExistence_debounce();
        });
    }
    /*
    private initDropDownValues(){
        this.prepareOptionsFromAssociatedParameters("FLEET_NAMES").then((options:ddOptions[])=>{
            this.$scope.fleetOptions = options;
        });
        this.prepareOptionsFromAssociatedParameters("ASSET_MANUFACTURERS").then((options:ddOptions[])=>{
            this.$scope.manufacturerOptions = options;
        });
        this.prepareOptionsFromAssociatedParameters("ASSET_TYPES").then((options:ddOptions[])=>{
            this.$scope.typeOptions = options;
        });
        this.prepareOptionsFromAssociatedParameters("ASSET_MODELS").then((options:ddOptions[])=>{
            this.$scope.modelOptions = options;
        });
        this.prepareOptionsFromAssociatedParameters("CONTROLLER_CONFIGS").then((options:ddOptions[])=>{
            this.$scope.controlerConfigOptions = options;
        });
        this.prepareOptionsFromAssociatedParameters("EVENT_RECORDER_TYPES").then((options:ddOptions[])=>{
            this.$scope.eventRecorderTypesOptions = options;
        });
        this.prepareOptionsFromAssociatedParameters("TO_EQUIPMENT_STATUSES").then((options:ddOptions[])=>{
            this.$scope.equipmentStatusOptions = options;
        });

    }
    */
    


    private getRestriction(deviceModel: string, modelVersion: string, apiName: string) {
        let key = `${deviceModel}/${modelVersion}`;
        if(!_.has(this.parameterValidators, key)) {
            this.parameterValidators[key] = this.ParametersValidatorService.getInstance(this.$scope, deviceModel, modelVersion);
        }
        return this.parameterValidators[key].getRestriction(apiName, []); // TODO: pass current parameters
    }

    /*private prepareOptionsFromAssociatedParameters(AssociatedParametersName:string):ng.IPromise<ddOptions[]>{
        return this.CommonServices.getcAssociatedParameters(AssociatedParametersName).then((optionsDataSet:any[])=>{
            var options = [];
            _.each(optionsDataSet,(modelOption)=>{
                options.push({
                    value: modelOption.lookupName,
                    name: modelOption.lookupValue
                });
            });
            return options;
        })
    }*/

    private _last_tableState = null
    private pipe(tableState:any): void {
        if(tableState == null && this._last_tableState == null){
            return;
        }else if(tableState != null) {
            this._last_tableState = tableState;
        }else{
            tableState = this._last_tableState;
        }
        var limit = tableState.pagination.number;
        var offset = tableState.pagination.start;
        this.devicesData = (this.devicesData || []).sort(dynamicSortMultiple<IDeviceData>("sort_status","iterator"));
        this.$scope.devicesPreview = this.devicesData.slice(offset, limit + offset);
        this.$scope.inProgress = false;
        tableState.pagination.numberOfPages = Math.ceil(this.devicesData.length / tableState.pagination.number);
    }

    private addDevices_GO() {
        let getDuplicateDevicePromise:ng.IPromise<App.Models.SearchResult<App.Models.ISystem>>
        this.$scope.inProgress = true;
        if(this.$scope.devicesData.singleLocoId != null){
            getDuplicateDevicePromise = this.DeviceService.getSystems(
                {
                    attributes:{customer_id:this.$scope.devicesData.common.customerId},
                    numericLocoId:{
                        from:this.$scope.devicesData.singleLocoId,
                        to: this.$scope.devicesData.singleLocoId
                    }
                }, "loco_id", "asc", this.$scope.maxNumberOfDeviceToBeSkipInRange || 500)
            
        }else if(this.$scope.devicesData.range.from != null && this.$scope.devicesData.range.to != null){
            getDuplicateDevicePromise = this.DeviceService.getSystems(
                {
                    attributes:{customer_id:this.$scope.devicesData.common.customerId},
                    numericLocoId:{
                        from:this.$scope.devicesData.range.from,
                        to: this.$scope.devicesData.range.to
                    }
                }, "loco_id", "asc", this.$scope.maxNumberOfDeviceToBeSkipInRange || 500)
        }else{
            getDuplicateDevicePromise = this.$q.resolve({ items:[], totalCount:0 });
        }
        getDuplicateDevicePromise.then((devDuplicate:App.Models.SearchResult<App.Models.ISystem>)=>{
            if(devDuplicate.totalCount > this.$scope.maxNumberOfDeviceToBeSkipInRange){
                this.$scope.inProgress = false;
                return ;
            }
        
            
            var devicesData = [];
            var devicesToAdd = [];
            if(!this.$scope.devicesData.range.from && !this.$scope.devicesData.range.to && this.$scope.devicesData.singleLocoId){
                this.$scope.devicesData.range.from = this.$scope.devicesData.singleLocoId;
                this.$scope.devicesData.range.to = this.$scope.devicesData.singleLocoId;
            }
    
            for(var i = this.$scope.devicesData.range.from; i <= this.$scope.devicesData.range.to; i++) {
                
                
                var deviceData: IDeviceData = {
                    iterator: this.createLocoId(i),
                    common: angular.copy(this.$scope.devicesData.common)
                };
                var device: IDeviceToAdd = this.ProxMapper.map(deviceData, this.$scope.devicesData.mapping);
                deviceData.deviceToAdd = device;
                deviceData.result = {success:null, assertions_set:null};
                
                //check if this device already exist
                let existingDuplicate = _.find(devDuplicate.items, (exDev:App.Models.ISystem)=>{
                    if(exDev && exDev.attributes && device && device.attributes && exDev.attributes['loco_id'] && exDev.attributes['customer_id']) {
                        return exDev.attributes['loco_id'] == device.attributes['$attributes/loco_id'] && exDev.attributes['customer_id'] == device.attributes['$attributes/customer_id']
                    }else {
                        return false;
                    }
                });
                if(!existingDuplicate) {
                    devicesToAdd.push(device);
                    devicesData.push(deviceData);
                }
            }
            this.devicesData = devicesData;
            this.$scope.devicesToAdd = devicesToAdd;
    
            var groupOperationDetails:any ={};
    
            if(devicesData.length == 1 && this.$scope.operationDescriptionOneDevice) {
                groupOperationDetails.description = this.$scope.operationDescriptionOneDevice;
            }else if(devicesData.length > 1 && this.$scope.operationDescriptionManyDevice) {
                groupOperationDetails.description = this.$scope.operationDescriptionManyDevice;
            }
            if(devicesData.length == 0){
                this.$scope.inProgress = false;
            }else{
                this.GroupOperationsService.addDevicesGO(devicesToAdd, groupOperationDetails).then((result: eapi18.GroupOperationIdObject) => {
                    this.getAndDisplayTaskDetails_promise != null;
                    this.getAndDisplayTaskDetails(result.operation_id, 500);
                    this.$scope.operation_id = result.operation_id;
                });
    
                if (this.$scope.devicesData.range.from == this.$scope.devicesData.range.to && this.$scope.devicesData.range.to == this.$scope.devicesData.singleLocoId) {
                    this.$scope.devicesData.range.from = null;
                    this.$scope.devicesData.range.to = null;
                }
            }
        });
    }

    private createLocoId(locoId:number):string{
        //return locoId.toString();
        var locoIdStr = locoId.toString();
        var width = 1 ;
        while ( width > locoIdStr.length )
        {
            locoIdStr = "0" + locoIdStr;
        }
        return locoIdStr;
    }

    
    private _getAndDisplayTaskDetails_failCounter = 0;
    private getAndDisplayTaskDetails_promise:ng.IPromise<void>;
    private getAndDisplayTaskDetails(groupOperationId:string, delay:number){
        this.$scope.added = true;
        if(this.getAndDisplayTaskDetails_promise != null){
            return ;
        }
        this.getAndDisplayTaskDetails_promise = this.$timeout(()=>{
            this.getAndDisplayTaskDetails_promise = null;
            this.GroupOperationsService.getGroupOperationDetails(groupOperationId, "registrations").then((groupOperationDetails:models.GroupOperations.IGroupOperation)=>{
                if(groupOperationDetails == null || groupOperationDetails.items == null){
                    this.getAndDisplayTaskDetails(groupOperationId, 1000);
                    return ;
                }
                
                this._getAndDisplayTaskDetails_failCounter = 0;
                if(this.getAndDisplayGroupOperationDetails_IsGroupOperationFinish(groupOperationDetails) == false){
                    this.getAndDisplayTaskDetails(groupOperationId, 1000);
                }
                // Display information about GroupOperation
                _.each(this.devicesData, (dev:IDeviceData)=>{
                    dev.result.reason = "";
                });

                this.$scope.inProgressDevices = groupOperationDetails.items.filter((ti)=>{return ti.result == null}).length;
                var asdid_generation_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "asdid_generation");
                _.each(asdid_generation_taskItems, (ti:models.GroupOperations.ITaskItem)=>{
                    var deviceData:IDeviceData = this.devicesData.filter(d => {return (<any>ti).data && d.deviceToAdd && d.deviceToAdd.did != null && (d.deviceToAdd.did == (<any>ti).data.did || d.deviceToAdd.did == (<any>ti).details.did )})[0];
                    if(deviceData != null && ti.result == "SUCCESS") {
                        deviceData.result.asdid = ti.asdid;
                    }else if(deviceData != null && ti.data["error"]){
                        deviceData.result.reason += ti.data["error"] || "";
                        deviceData.result.reason += ", ";
                    }
                });

                var registration_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "registration");
                _.each(registration_taskItems, (ti:models.GroupOperations.ITaskItem)=>{
                    var deviceData:IDeviceData = this.devicesData.filter(d => {return d.result.asdid != null && d.result.asdid == (<any>ti).asdid})[0];
                    if(deviceData != null && ti.result == "SUCCESS") {
                        deviceData.result.success = true;
                        deviceData.result.reregistered = ti.data["reregistered"] || false;
                    }else if(deviceData != null && ti.status == "FINISHED"){
                        deviceData.result.success = false;
                        if(ti.data["error"]) {
                            deviceData.result.reason += ti.data["error"] || "";
                            deviceData.result.reason += ", ";
                        }
                    }
                });

                var assertions_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "assertions");
                _.each(assertions_taskItems, (ti:models.GroupOperations.ITaskItem)=>{
                    var deviceData:IDeviceData = this.devicesData.filter(d => {return d.result.asdid != null && d.result.asdid == (<any>ti).asdid})[0];
                    if(deviceData != null && ti.result == "SUCCESS") {
                        deviceData.result.assertions_set = true;
                    }else if(deviceData != null && ti.status == "FINISHED"){
                        deviceData.result.assertions_set = false;
                        if(ti.data["error"]) {
                            deviceData.result.reason += ti.data["error"] || "";
                            deviceData.result.reason += ", ";
                        }
                    }
                });

                this.$scope.successDevices = 0;
                this.$scope.failedDevices = 0;
                this.$scope.inProgressDevices = 0;
                this.$scope.reregisteredDevices = 0;
                this.devicesData.forEach((devAdd: IDeviceData)=>{
                    if(devAdd.result.success && devAdd.result.assertions_set && devAdd.result.asdid != null){
                        if(devAdd.result.reregistered){
                            this.$scope.reregisteredDevices++;
                            devAdd.sort_status = 0;
                        }else{
                            this.$scope.successDevices++;
                            devAdd.sort_status = 2;
                        }
                    }else if(devAdd.result.success === false || devAdd.result.assertions_set === false){
                        this.$scope.failedDevices++;
                        devAdd.sort_status = 0;
                    }else{
                        this.$scope.inProgressDevices++;
                        devAdd.sort_status = 1;
                    }
                });
                
                if(this.$scope.inProgressDevices > 0){
                    this.getAndDisplayTaskDetails(groupOperationId,1000)
                }

                this.$scope.totalDevices = this.devicesData.length;
                this.pipe(null);
            }).catch((err)=>{
                console.error(err);
                if(this._getAndDisplayTaskDetails_failCounter < 10) {
                    this.getAndDisplayTaskDetails(groupOperationId, 5000);
                }
                this._getAndDisplayTaskDetails_failCounter += 1;
            });
        }, delay);
    }

    private getAndDisplayGroupOperationDetails_IsGroupOperationFinish(groupOperationDetails:models.GroupOperations.IGroupOperation):boolean{
        if(groupOperationDetails == null || groupOperationDetails.items == null || groupOperationDetails.items.length ==0 ){
            return false;
        }
        var registration_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "registration");
        var asdid_generation_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "asdid_generation");
        if(groupOperationDetails.result == "FAILURE" && groupOperationDetails.status == "FINISHED"){
            return true
        }else if(registration_taskItems.length != asdid_generation_taskItems.length || asdid_generation_taskItems.length == 0 || registration_taskItems.length == 0){
            return false;
        }

        return groupOperationDetails.status == "FINISHED" && this.$scope.added;
    }
    private reset() {
        this.$timeout.cancel(this.getAndDisplayTaskDetails_promise);
        this.$scope.active = false;
        this.$scope.inProgress = false;
        this.$scope.added = false;
        this.$scope.totalDevices = 0;
        this.$scope.successDevices = 0;
        this.$scope.failedDevices = 0;
        this.$scope.devicesData.common = {};
        this.$scope.devicesData.range = {
            from: null,
            to: null
        };
        this.$scope.devicesData.singleLocoId = null;
        this.$scope.operation_id = null;

        if(this.addDevicesForm) {
            this.addDevicesForm.$setPristine();
        }
    }

    private checkLocomotiveExistence_lastId:number = 0;
    private checkLocomotiveExistence(){
        this.checkLocomotiveExistence_lastId++;
        var checkLocomotiveExistence_id = this.checkLocomotiveExistence_lastId;
        if(this.$scope.devicesData.common.customerId != null)
        {
            if(this.$scope.devicesData.singleLocoId != null){
                this.DeviceService.getSystems(
                    {
                        attributes:{customer_id:this.$scope.devicesData.common.customerId},
                        numericLocoId:{
                            from:this.$scope.devicesData.singleLocoId,
                            to: this.$scope.devicesData.singleLocoId
                        }
                    }, "loco_id", "asc", 20).then((duplicateLocmotive:App.Models.SearchResult<App.Models.ISystem>)=>{
                        if(checkLocomotiveExistence_id == this.checkLocomotiveExistence_lastId) {
                            this.$scope.duplicateLocmotive = duplicateLocmotive;
                            this.$scope.allDevicesFromRangeExist = duplicateLocmotive.totalCount == 1;
                        }
                    });
            }else if(this.$scope.devicesData.range.from != null && this.$scope.devicesData.range.to != null){
                this.DeviceService.getSystems(
                    {
                        attributes:{customer_id:this.$scope.devicesData.common.customerId},
                        numericLocoId:{
                            from:this.$scope.devicesData.range.from,
                            to: this.$scope.devicesData.range.to
                        }
                    }, "loco_id", "asc", 20).then((duplicateLocmotive:App.Models.SearchResult<App.Models.ISystem>)=>{
                        if(checkLocomotiveExistence_id == this.checkLocomotiveExistence_lastId) {
                            this.$scope.duplicateLocmotive = duplicateLocmotive;
                            this.$scope.allDevicesFromRangeExist = duplicateLocmotive.totalCount == this.$scope.devicesData.range.to - this.$scope.devicesData.range.from + 1;
                        }
                    });
            }else{
                this.$scope.duplicateLocmotive = null;
                this.$scope.allDevicesFromRangeExist = false;
            }
        }else {
            this.$scope.duplicateLocmotive = null;
        }
    }
    

}

function AddDevicesRangeDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('AddDevicesRangeDirective'),
        controller: AddDevicesRangeController,
        controllerAs: 'ctrl',
        require: '?^proxList',
        scope: {
            active: '=',
            start: '=',
            close: '=?',
            title: '@?',
            operationDescriptionOneDevice:'@',
            operationDescriptionManyDevice:'@'
        },
        link: (scope: IAddDevicesRangeScope, ele: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: ProxListController) => {
            scope.onAdded = () => {
                if(ctrl) {
                    ctrl.refresh();
                }
            }
        }
    }
}

export default angular.module('directives.addDevicesRange', [ProxMapperServiceModule.name, DeviceServiceModule.name, GroupOperationsServiceModule.name,
    AllowedCharactersModule.name, CommonServicesModule.name, addDevicesGroupOperationSummaryModule.name, ParametersValidatorServiceModule.name, ParameterValidatorDirectiveModule.name])
    .directive('addDevicesRange', ['$branding', AddDevicesRangeDirective]);
