/**
 * Created by rosadnik on 17-May-17.
 */
import GroupOperationsServiceModule, {GroupOperationsService} from "../../services/GroupOperationsService";
import CommonServicesModule, {CommonServices} from "../../services/CommonServices";
import AllowedCharactersModule from "../../directives/validators/allowedCharacters";
import ConfigServiceModule, {ConfigService} from "../../services/ConfigService";
import DeviceServiceModule, {IDevicesToAdd, IDeviceToAdd} from "../../services/DeviceService";

interface IAddDevicesGroupOperationSummaryeScope extends ng.IScope{
    pipe(tableState: any): void;
    groupOperationId:string;
    devicesSendToAdd:IDevicesToAdd;
    successDevices:number;
    failedDevices:number;
    inProgressDevices:number;
    reregisteredDevices:number;
    
    added:boolean;
    inProgress:boolean;
    totalDevices:number;
    devicesPreview:IDeviceData[];
    close:()=>void;
    closeParentControl:()=>void;
    deviceTypeNamePlural:string;
    deviceTypeNameSingular:string;
    
    showLocoIdColumn:boolean;
    showCustomerIdColumn:boolean;
    showDeviceNameColumn:boolean;
    expectAssertionTaskInRegistration:boolean;
}

interface IDeviceData {
    device?:eapi18.DeviceFromDSC;
    success?: boolean;
    asdid?: string;
    did?:string;
    reason?: string;
    assertions_set?: boolean;
    reregistered?:boolean;
    sort_status?:number;
}

class addDevicesGroupOperationSummaryController{
    public static $inject = ["$scope", "$timeout", "$attrs", "GroupOperationsService", "CommonServices",];
    private devicesData: IDeviceData[];
    private _last_tableState:any;
    private _getAndDisplayTaskDetails_retryCount = 0;
    
    constructor(private $scope: IAddDevicesGroupOperationSummaryeScope,
                private $timeout: ng.ITimeoutService,
                private $attrs:any,
                private GroupOperationsService:GroupOperationsService,
                private CommonServices:CommonServices)
    {
        if (!this.$attrs.showLocoIdColumn) { this.$scope.showLocoIdColumn = true; }
        if (!this.$attrs.showCustomerIdColumn) { this.$scope.showCustomerIdColumn = true; }
        if (!this.$attrs.showDeviceNameColumn) { this.$scope.showDeviceNameColumn = false; }
        if (!this.$attrs.expectAssertionTaskInRegistration) { this.$scope.expectAssertionTaskInRegistration = true; }
        
        $scope.deviceTypeNameSingular = $scope.deviceTypeNameSingular  || "Device";
        $scope.deviceTypeNamePlural = $scope.deviceTypeNamePlural  || "Devices";
        
        $scope.pipe = (tableState: any) => { this.pipe(tableState); };
        
        this.$scope.$watch("groupOperationId", (newGrOpId:string, oldGrOpId:string)=>{
            this.$scope.devicesPreview = [];
            this.devicesData = [];
            
            this._getAndDisplayTaskDetails_retryCount = 0;
            if(newGrOpId == null && this.getAndDisplayTaskDetails_promise){
                this.$timeout.cancel(this.getAndDisplayTaskDetails_promise);
            }
            if(newGrOpId != null){
                this.getAndDisplayTaskDetails(1500);
            }
        });
        
        $scope.close = ()=>{
            this.$scope.groupOperationId = null;
            this.$timeout.cancel(this.getAndDisplayTaskDetails_promise);
            if(this.$scope.closeParentControl){
                this.$scope.closeParentControl();
            }
        };
    }
    
    private getAndDisplayTaskDetails_promise:ng.IPromise<void>;
    private getAndDisplayTaskDetails(delay:number){
        if(this.getAndDisplayTaskDetails_promise){return;}
        this.$scope.added = true;
        this.getAndDisplayTaskDetails_promise = this.$timeout(()=>{
            this.getAndDisplayTaskDetails_promise = null;
            
            // skip geting information about group operation - missing id
            if(!this.$scope.groupOperationId)
                return;
            
            this.GroupOperationsService.getGroupOperationDetails( this.$scope.groupOperationId, "registrations").then((groupOperationDetails:models.GroupOperations.IGroupOperation)=>{
                this._getAndDisplayTaskDetails_retryCount = 0
                if(this.getAndDisplayGroupOperationDetails_IsGroupOperationFinish(groupOperationDetails) == false){
                    this.getAndDisplayTaskDetails(1000);
                }else{
                    this.$timeout(()=>{
                        this.$scope.$emit("smartTable:refreshRequired");
                    },500)
                }
                // Display information about GroupOperation
                this.devicesData = this.devicesData || [];
                _.each(this.devicesData, (dev:IDeviceData)=>{
                    dev.reason = "";
                });
                
                this.$scope.inProgressDevices = groupOperationDetails.items.filter((ti)=>{return ti.result == null}).length;
                
                var registration_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "registration");
                var missing_did = false;
                if(groupOperationDetails.result == "FAILURE" && groupOperationDetails.status == "FINISHED"){
                    _.each( this.devicesData, (dd:IDeviceData)=>{
                        dd.success = false;
                        dd.reason = ""
                    });
                }
                _.each(registration_taskItems, (ti:models.GroupOperations.ITaskItem)=>{
                    var deviceData:IDeviceData = this.devicesData.filter(d => {
                        return (d.asdid != null && d.asdid == (<any>ti).asdid) ||
                            (d.did && ti.details && ti.details != null && ti.details.did != null && d.did.toLowerCase() == ti.details.did.toLowerCase() );
                    })[0];
                    if(deviceData == null){
                        deviceData = {
                            asdid: ti.asdid,
                            success: null,
                            reason: null,
                            assertions_set: null,
                            reregistered: null,
                            sort_status: 0,
                            did:ti.details ? ti.details.did:null
                        };
                        missing_did = missing_did || !ti.details || !ti.details.did
                        this.devicesData.push(deviceData);
                    }else if(deviceData.asdid == null){
                        deviceData.asdid = ti.asdid;
                    }
                    if(ti.device){
                        ti.device.then((dev)=>{
                            if(dev) {
                                _.extend(deviceData.device, dev);
                                var devToAdd: IDeviceToAdd = _.filter(this.$scope.devicesSendToAdd, (devToAdd: IDeviceToAdd) => {
                                    return devToAdd.did && dev.did && devToAdd.did.toLowerCase() == dev.did.toLowerCase();
                                })[0];
                                if (devToAdd && devToAdd.attributes) {
                                    _.extend(deviceData.device.assertions, devToAdd.attributes)
                                }
                                if(missing_did && dev.did){
                                    deviceData.did = dev.did;
                                    this.getAndDisplayTaskDetails(1000);
                                }

                                this.pipe(null);
                            }
                        });
                    }
                    
                    if(deviceData != null && ti.result == "SUCCESS") {
                        deviceData.success = true;
                    }else if(deviceData != null && ti.status == "FINISHED"){
                        deviceData.success = false;
                        if(ti.data &&  ti.data["error"]) {
                            deviceData.reason += ti.data["error"] || "";
                            deviceData.reason += ", ";
                        }else if(ti.registration_result){
                            deviceData.reason = ti.registration_result;
                        }
                    }
                });
                
                _.each(this.$scope.devicesSendToAdd,(devToAdd:IDeviceToAdd)=>{
                    var deviceData:IDeviceData = this.devicesData.filter(d => {
                        return (d.did && devToAdd.did && d.did.toLowerCase() == devToAdd.did.toLowerCase() );
                    })[0];
                    if(deviceData == null && missing_did == false){
                        deviceData = {
                            asdid: null,
                            success: null,
                            reason: null,
                            assertions_set: null,
                            reregistered: null,
                            sort_status: 0,
                            did:devToAdd.did,
                            device:{
                                name:devToAdd.name,
                                asdid:null,
                                did:devToAdd.did,
                                device_model:null,
                                device_model_id:devToAdd.device_model_id,
                                device_model_version:devToAdd.device_model_version,
                                assertions:devToAdd.attributes,
                            },
                        };
                        this.devicesData.push(deviceData);
                    }else if(deviceData == null && missing_did){
                    
                    }else{
                        if(!deviceData.device ){
                            deviceData.device = {
                                name:devToAdd.name,
                                asdid:null,
                                did:devToAdd.did,
                                device_model:null,
                                device_model_id:devToAdd.device_model_id,
                                device_model_version:devToAdd.device_model_version,
                            };
                        }
                       
                        deviceData.device.name = devToAdd.name;
                        deviceData.device.did = devToAdd.did;
                        deviceData.device.device_model_id = devToAdd.device_model_id;
                        deviceData.device.device_model_version = devToAdd.device_model_version;
                        deviceData.device.assertions = devToAdd.attributes;
                    }
                });
                
                var assertions_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "assertions");
                _.each(assertions_taskItems, (ti:models.GroupOperations.ITaskItem)=>{
                    var deviceData:IDeviceData = this.devicesData.filter(d => {return d.asdid != null && d.asdid == (<any>ti).asdid})[0];
                    if(deviceData != null && ti.result == "SUCCESS") {
                        deviceData.assertions_set = true;
                    }else if(deviceData != null && ti.status == "FINISHED"){
                        deviceData.assertions_set = false;
                        if(ti.data["error"]) {
                            deviceData.reason += ti.data["error"] || "";
                            deviceData.reason += ", ";
                        }
                    }
                });
                
                this.$scope.successDevices = 0;
                this.$scope.failedDevices = 0;
                this.$scope.inProgressDevices = 0;
                this.$scope.reregisteredDevices = 0;
                this.devicesData.forEach((devAdd: IDeviceData)=>{
                    if(devAdd.success && (devAdd.assertions_set || !this.$scope.expectAssertionTaskInRegistration) && devAdd.asdid != null){
                        if(devAdd.reregistered){
                            this.$scope.reregisteredDevices++;
                            devAdd.sort_status = 0;
                        }else{
                            this.$scope.successDevices++;
                            devAdd.sort_status = 2;
                        }
                    }else if(devAdd.success === false || devAdd.assertions_set === false){
                        this.$scope.failedDevices++;
                        devAdd.sort_status = 0;
                    }else{
                        this.$scope.inProgressDevices++;
                        devAdd.sort_status = 1;
                    }
                });
                
                this.$scope.totalDevices = this.devicesData.length;
                this.pipe(null);
                if(this.$scope.inProgressDevices > 0) {
                    this.getAndDisplayTaskDetails(1000);
                }
            }).catch(()=>{
                if(this.$scope.groupOperationId != null && this._getAndDisplayTaskDetails_retryCount < 3){
                    this._getAndDisplayTaskDetails_retryCount++;
                    this.getAndDisplayTaskDetails(this._getAndDisplayTaskDetails_retryCount * 1000);
                }
            });
        }, delay)
    }
    
    private getAndDisplayGroupOperationDetails_IsGroupOperationFinish(groupOperationDetails:models.GroupOperations.IGroupOperation):boolean{
        //if(groupOperationDetails.items == null || groupOperationDetails.items.length ==0 ){
        //    return false;
        //}
        //var registration_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "registration");
        //var asdid_generation_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "asdid_generation");
        //if(registration_taskItems.length != asdid_generation_taskItems.length || asdid_generation_taskItems.length == 0 || registration_taskItems.length == 0){
        //    return false;
        //}
        if(groupOperationDetails) {
            return groupOperationDetails.status == "FINISHED" && this.$scope.added;
        } else if(groupOperationDetails == null && this.$scope.groupOperationId != null) {
            return false;
        } else{
            return true;
        }
    }
    
    private pipe(tableState:any): void {
        if(tableState == null && this._last_tableState == null){
            return;
        }else if(tableState != null) {
            this._last_tableState = tableState;
        }else{
            tableState = this._last_tableState;
        }
        var limit = tableState.pagination.number;
        var offset = tableState.pagination.start;
        this.devicesData = (this.devicesData || []).sort(dynamicSortMultiple<IDeviceData>("sort_status","iterator"));
        this.$scope.devicesPreview = this.devicesData.slice(offset, limit + offset);
        this.$scope.inProgress = false;
        tableState.pagination.numberOfPages = Math.ceil(this.devicesData.length / tableState.pagination.number);
    }
}

export default angular.module('directives.addDevicesGroupOperationSummary', [GroupOperationsServiceModule.name, AllowedCharactersModule.name, CommonServicesModule.name])
.directive('addDevicesGroupOperationSummary', ['$branding', function ($branding:app.branding.IBrandingService) {
    return {
        //templateUrl: "/components/src/directives/add-devices-range/add-devices-group-operation-summary.html", //$branding.getTemplateUrl('addDevicesGroupOperationSummaryDirective'),
        templateUrl: function(){ return $branding.getTemplateUrl('addDevicesGroupOperationSummaryDirective'); },
        controller: addDevicesGroupOperationSummaryController,
        require: '?^proxList',
        scope: {
            groupOperationId:'=',
            devicesSendToAdd:'=',
            closeParentControl:"=?close",
            deviceTypeNamePlural:"@?",
            deviceTypeNameSingular:"@?",
            showLocoIdColumn:"=?",
            showCustomerIdColumn:"=?",
            showDeviceNameColumn:"=?",
            expectAssertionTaskInRegistration:"=?"
        }
    }
}]);
