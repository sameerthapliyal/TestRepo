interface IProxFileDialogDirectiveScope extends ng.IScope {
    onFileSelected(args: {file: File}),
    eventName: string;
}

function ProxFileDialogDirective() {
    return {
        replace: true,
        scope: {
            onFileSelected: '&',
            eventName: '@?',
        },
        template: '<input type="file" style="display: none">',
        link: (scope: IProxFileDialogDirectiveScope, element: ng.IAugmentedJQuery) => {
            var eventName = scope.eventName || "proxFileDialog:open";
            console.log(angular.element(element[0]).on);
            console.log(angular.element(element[0]).click);
            element.on('change', (e: any) => {
                scope.onFileSelected({file: (e.srcElement || e.target).files[0]});
                element.val(null);
                return false;
            });
            scope.$on(eventName, () => {
                console.log(element.click);
                element[0].click();
            });

        }
    }
}

export default angular.module('directives.proxFileDialog', [])
    .directive('proxFileDialog', [ProxFileDialogDirective]);