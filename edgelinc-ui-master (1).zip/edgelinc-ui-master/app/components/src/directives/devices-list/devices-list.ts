/**
 * Created by rosadnik on 2016-03-08.
 */
///<reference path="../../../../../typings/browser.d.ts"/>

import ParameterStorageServiceModule, {ParameterStorageService, STORAGE_TYPE} from "../../services/ParameterStorageService";
import DeviceServiceModule, {DeviceService, IDeviceFilter} from "../../services/DeviceService";
import CommonServicesModule, {CommonServices} from "../../services/CommonServices";
import AuthServiceModule, {AuthService} from "../../services/AuthService";
import DeviceModelsServiceModule, {
    DeviceModelsService,
    IDeviceModelVersionDefinition
} from "../../services/DeviceModelsService";
import stCustomExportContextWrapperModule from "../../directives/smart-table/st-custom-export-context-wrapper";

interface deviceListInSystemScope extends ng.IScope {
    isLoading:boolean;
    filteredDeviceCount: number;
    displayDeviceCount: number;
    deviceTypeName:string;
    ToIndex:number;
    FromIndex:number;

    searchString: string;
    searchFields: string[];
    onFilterChange:()=> void;
    onFilterClick:()=> void;
    onClearFilterClick:()=> void;
    stateRestored:boolean;
    stateChanged:boolean;
    scopePropertiesToSave: string[];

    callServer:(tableState:any, tableCtrl:any)=> void;
    pageSize: number;
    displayed:any[];

    cmsAsdid:string;
    cmsCustormerId:string,
    cmsLocoId:string,
    tableTitle:string;
    showStatusColumn:boolean;
    showNameColumn:boolean;
    showUptimeColumn:boolean;
    showIpAddressColumn:boolean;
    showCpuColumn:boolean;
    showMemoryColumn:boolean;
    showAlertsColumn:boolean;
    showNodesColumn:boolean;
    showLastSeenColumn:boolean;
    showDeviceTypeColumn:boolean;
    showEnrollDateColumn:boolean;
    showInterfaceColumn:boolean;

    showDeviceModelOfClass: string;
    //excludedDeviceModelWithAttribute: string;

    groupProvisioningInprogres:boolean;
    groupProvisioningInprogres_loading:boolean;
    groupProvisioningInprogres_errorMessage:string;
    groupProvisioningInprogres_Message:string;
    groupProvisioningInprogres_asdids:string[];
    viscapfile?:App.Models.EAPI.IViscapfile;
    deviceModelVersionDefinition?: IDeviceModelVersionDefinition;

    groupParamsList?:App.Models.EAPI.IParameterWithStatus[];

    exportSelected: () => void;
    startGroupCommand: () => void;
    extractSetectedAsdids: (selection) => string[];
    groupCommand:boolean;

    refreshInterval?:number;

    canDeleteDevice:(device:any)=>boolean;
}

class deviceListInSystemController {
    private _lastTableState:any;
    private _tableCtrl:any;
    private _showDeviceModelOfClass:string|string[];

    private _storageType: STORAGE_TYPE;
    private _storageKey: string = "devices-list-storage";
    private _getDeviceList_RequestId = 0;
    private _getDeviceList_RequestId_Current = 0;
    private _filterChange:boolean = false;
    private _refreshingPromise:any;



    constructor(private _routeParams: App.IRootScope,
                private _scope:deviceListInSystemScope,
                private _timeout:ng.ITimeoutService,
                private _interval:ng.ITimeoutService,
                private _q:ng.IQService,
                private _branding:app.branding.IBrandingService,
                private _devicesService: DeviceService,
                private _commonService: CommonServices,
                private _storage: ParameterStorageService,
                private _deviceModelsService: DeviceModelsService,
                private authorizationService:AuthService
    )
    {
        this._scope.$watch("cmsCustormerId",()=>{
            if(this._scope.refreshInterval == null){
                this.getDeviceList( this._lastTableState, this._tableCtrl);
            }
        });
    
        this._scope.$watch("cmsLocoId",()=>{
            if(this._scope.refreshInterval == null){
                this.getDeviceList( this._lastTableState, this._tableCtrl);
            }
        });
        this.setScopeUndefineVaues();
        this._scope.isLoading = true;

        this._scope.extractSetectedAsdids = (selection) => { return selection ? selection.map((d) => { return d.asdid }) : [] };
        this._scope.callServer = (tableState:any, tableCtrl:any)=> {
            this.customSaveState();
            this._lastTableState = tableState ;
            this._tableCtrl = tableCtrl;
            this.getDeviceList(tableState, tableCtrl);
        };

        this._scope.$watch("showDeviceModelOfClass",(newWalue:string, oldValue:string)=>{
            this.on_showDeviceModelOfClass_change(newWalue, oldValue);
        });
        //if(typeof this._scope.showDeviceModelOfClass == "string") {
        //    this.on_showDeviceModelOfClass_change(this._scope.showDeviceModelOfClass, null);
        //}

        this._scope.startGroupCommand = ()=>{
            this._scope.groupCommand=!this._scope.groupCommand;
        };

        this._scope.canDeleteDevice =(device:any)=>{
            return device != null && device.operational_status!= null &&
                (
                    device.operational_status ==  0 ||    // Unreachable
                    device.operational_status == -1 ||    // Unknown
                    device.operational_status == -2       // Preprovisioned
                );
        };

        this.initTableFiter();
        this.initParameterStorageService();
        this.initRefreshing();
    }


    private _intervalPromise:any;
    private initRefreshing(){
        this._scope.$watch("refreshInterval",(newValue:number, oldValue:number)=>{
            if(this._intervalPromise){
                this._interval.cancel(this._intervalPromise);
            }
            var refreshThrottled = this._q.throttle(() => this.getDeviceList( this._lastTableState, this._tableCtrl));

            if(newValue != null && typeof newValue == "number") {
                this._intervalPromise = this._interval(refreshThrottled, newValue);
            }
            this._scope.$on("$destroy", () => {
                this._interval.cancel(this._intervalPromise);
            });
        });
    }

    private initTableFiter(){
        this._scope.searchString = "";
        this._scope.onFilterClick = ()=>{
            this.debounceDeviceListUpdate(10);
            this.customSaveState();
        };

        this._scope.onClearFilterClick = ()=>{
            this.debounceDeviceListUpdate(10, true);
            this._scope.searchString = "";
            this._filterChange = true;
            this.customSaveState();

        };
        this._scope.onFilterChange = ()=>{
            this.debounceDeviceListUpdate(1000, true);
            this._filterChange = true;
        };
    }

    private on_showDeviceModelOfClass_change(newWalue:string, oldValue:string){
        try{
            var listOfDeviceClass:string[] = JSON.parse(newWalue);
            if(Array.isArray(listOfDeviceClass)){
                this._showDeviceModelOfClass = listOfDeviceClass;
                return;
            }
        }catch(ex){}

        if(newWalue.split(",").length > 0){
            var listOfDeviceClass:string[] = [];
            _.each(newWalue.split(","),(cls)=>{ listOfDeviceClass.push(cls.trim()); });
            this._showDeviceModelOfClass = listOfDeviceClass;
            return;
        }

        this._showDeviceModelOfClass = newWalue;
    }

    private setScopeUndefineVaues() {
        if(angular.isUndefined(this._scope.showStatusColumn)) {
            this._scope.showStatusColumn = true;
        }
        if(angular.isUndefined(this._scope.showNameColumn)) {
            this._scope.showNameColumn = true;
        }
        if(angular.isUndefined(this._scope.showUptimeColumn)) {
            this._scope.showUptimeColumn = true;
        }
        if(angular.isUndefined(this._scope.showIpAddressColumn)) {
            this._scope.showIpAddressColumn = true;
        }
        if(angular.isUndefined(this._scope.showCpuColumn)) {
            this._scope.showCpuColumn = false;
        }
        if(angular.isUndefined(this._scope.showMemoryColumn)) {
            this._scope.showMemoryColumn = false;
        }
        if(angular.isUndefined(this._scope.showAlertsColumn)) {
            this._scope.showAlertsColumn = false;
        }
        if(angular.isUndefined(this._scope.showNodesColumn)) {
            this._scope.showNodesColumn = false;
        }
        if(angular.isUndefined(this._scope.showLastSeenColumn)) {
            this._scope.showLastSeenColumn = false;
        }
        if(angular.isUndefined(this._scope.showDeviceTypeColumn)) {
            this._scope.showDeviceTypeColumn = false;
        }
        if(angular.isUndefined(this._scope.showEnrollDateColumn)) {
            this._scope.showEnrollDateColumn = false;
        }
        if(angular.isUndefined(this._scope.showInterfaceColumn)) {
            this._scope.showInterfaceColumn = false;
        }
    }

    private initParameterStorageService(){
        this._storageType = STORAGE_TYPE.SESSION_STORAGE;
        //this._storageKey = "devices-list.ts_" + this._scope.deviceTypeName + "_" + this._scope.cmsAsdid;
        this._scope.stateRestored = false;
        this._scope.stateChanged = false;
        this._scope.scopePropertiesToSave = ["searchString", "pageSize"];
        this._storage.restoreState(this._storageKey,this._storageType,this._scope);
        this._scope.stateRestored = true;

        if(this._scope.pageSize == null || typeof this._scope.pageSize == "undefined")
           this._scope.pageSize = 10;

        for (var props in this._scope.scopePropertiesToSave) {
            if (this._scope.scopePropertiesToSave.hasOwnProperty(props)) {
                this._scope.$watch(this._scope.scopePropertiesToSave[props], (newVal, oldVal) => {
                    this.stateChanged();
                })
            }
        }


    }

    private getDeviceList(tableState:any, tableCtrl:any) {
        // prepare ajax request
        // search string
        var searchString = this._scope.searchString;
        var searchFields = this._scope.searchFields;


        // prepare limit offset
        var limit = tableState.pagination.number;
        var offset = tableState.pagination.start;

        // prepare sorting
        var sortColumn = null;
        var sortDir: any = null;
        if(tableState.sort && tableState.sort.predicate) {
            sortColumn = tableState.sort.predicate;
            sortDir = tableState.sort.reverse ? "desc": "asc";
        }else{
            sortColumn = "operational_status";
            sortDir = "asc";
            tableState.sort.predicate = "operational_status";
            tableState.sort.reverse = false;
        }

        // prepare filter
        var filter: IDeviceFilter = {
            deviceClass: this._showDeviceModelOfClass,
            searchPattern: searchString
        };

        if(  this._scope.cmsCustormerId && this._scope.cmsLocoId){
            filter.cmsCustormerId = this._scope.cmsCustormerId;
            filter.cmsLocoId = this._scope.cmsLocoId;
        }
        if(this._scope.cmsAsdid) {
            filter.reporterId = this._scope.cmsAsdid;
        }

        return this._devicesService.getSystemDevices_CustomFilters((deviceList:any[],filteredItemCount:number, requestId?:any)=>{
            if(requestId < this._getDeviceList_RequestId_Current){
                // We have already newest data. skip this data.
                return;
            }
            this._getDeviceList_RequestId_Current = requestId;

            this._scope.filteredDeviceCount = filteredItemCount;
            this._scope.displayDeviceCount = deviceList.length;
            this._scope.FromIndex = !deviceList.length && !offset ? 0 : offset + 1;
            this._scope.ToIndex = offset + deviceList.length;

            var deviceAsdids:string[] = [];

            _.each(deviceList, (device:any)=>{

                device.statistics = device.statistics || {};
                deviceAsdids.push(device.asdid);
                device.status_fields = this._branding.getDeviceStatus(device.operational_status);
                if(device.operational_status_text) {
                    device.status_fields.text = device.operational_status_text;
                }
                device.name = device.device_name;
                device.alertsCounts = device.aggregates._activeAlarms;
                device.ipAddress = "";
                device.uptime =  device.statistics.uptime;

                device.cpuUsage = device.statistics.cpu_usage;
                device.memoryUsage = device.statistics.memory_usage;
                device.nodesCounts = device.statistics.nodes_count;
                device.lastSeen = "--";
                device.deviceType = device.class;
                device.enrollDate = 1478336701; //"05-11-2016 10:05:01AM";
                device.lastSeen =  device.statistics.last_seen;
                device.mcsParameters = device.parameters_object;
                if(device.uptime != null) {
                    var newStr = "";
                    var nv = 0;
                    nv = Math.floor(device.uptime/(60*60*24));
                    var ss = false;
                    if(nv) {newStr +=  nv+"d "; ss=true;};
                    device.uptime -= nv *60*60*24;

                    nv = Math.floor(device.uptime/(60*60));
                    if(nv || ss){newStr +=  nv+"h "; ss = true;};
                    device.uptime -= nv *60*60;

                    nv = Math.floor(device.uptime/(60));
                    if(nv || ss) {newStr +=  nv+"m "; ss = true;};
                    device.uptime -= nv *60;

                    nv = device.uptime;
                    newStr +=  nv+"s";

                    device.uptime = newStr;
                }
            });


            //tableState.pagination.numberOfPages = Math.ceil(this._scope.filteredDeviceCount/tableState.pagination.number);
            tableState.pagination.totalItemCount = filteredItemCount;
            this._scope.isLoading = false;

            if(deviceAsdids.length > 0 && (this._scope.showNameColumn || this._scope.showIpAddressColumn)) {
                // updating device name
                this._devicesService.getManyDevices(deviceAsdids).then((devicesDetails:eapi18.DeviceFromDSC[])=> {
                    var new_displayed = [];
                    _.each(deviceList, (old_dev:any)=> {
                        var dev = _.clone(old_dev);
                        new_displayed.push(dev);
                        var deviceDetails = devicesDetails.filter((d)=> {
                            return d.asdid == dev.asdid;
                        })[0];
                        if (deviceDetails) {
                            //dev.name = this._devicesService.calculateCMSName(deviceDetails);
                            dev.name = deviceDetails.device_name;
                            dev.ipAddress = this._devicesService.getDeviceIpAddres(deviceDetails);
                        }
                    });
                    this.updateDisplayTable(new_displayed);
                });
            }else{
                this.updateDisplayTable(deviceList);
            }

        },searchString,true, limit, offset, sortColumn, sortDir, filter, this._getDeviceList_RequestId++, searchFields);
    }

    private updateDisplayTable(new_displayed){
        this._scope.displayed = new_displayed;
        this._scope.isLoading = false;
        //this._scope.$applyAsync();
    }
    private customSaveState() {
        this._storage.saveState(this._scope,this._storageKey,this._storageType, this._scope.scopePropertiesToSave);
    }

    private stateChanged(){
        if(this._scope.stateChanged){
            this.customSaveState();
            this._scope.stateChanged = false;
        }
    }


    private _resetPagination:boolean = false;
    private deviceModelListUpdateTimer:any;
    private debounceDeviceListUpdate(delay:number = 100, resetPagination:boolean = false) {
        this._resetPagination = this._resetPagination || resetPagination;
        if (!this.deviceModelListUpdateTimer && (this._scope.isLoading == false || this._filterChange == true)) {
            this.deviceModelListUpdateTimer = this._timeout(() => {
                this.deviceModelListUpdateTimer = undefined;
                if(this._resetPagination && this._tableCtrl && this._lastTableState){
                    this._tableCtrl.slice(0, this._lastTableState.pagination.number);
                } else if(this._lastTableState != null ) {
                    this._scope.callServer(this._lastTableState, null);
                }
                this._resetPagination = false;
            }, delay);
            this.deviceModelListUpdateTimer.finally(() => {
                this.deviceModelListUpdateTimer = undefined;
            });
        }else{
            console.log("debounceDeviceListUpdate - cancel refresh request");
        }
    }
}

var angularModule = angular.module('directives.deviceList',[CommonServicesModule.name, DeviceServiceModule.name,
    ParameterStorageServiceModule.name, DeviceModelsServiceModule.name, stCustomExportContextWrapperModule.name, AuthServiceModule.name]);
export default angularModule;

angularModule.controller("deviceListInSystemController",[ '$routeParams', '$scope', '$timeout', '$interval', '$q', '$branding', 'DeviceService', 'CommonServices', 'ParameterStorageService','DeviceModelsService', 'AuthorizationService', deviceListInSystemController]);
angularModule.directive("deviceListInSystem", ['$branding', function($branding: app.branding.IBrandingService){
    return {
        templateUrl: $branding.getTemplateUrl("directives.deviceList.deviceListInSystem"),
        restrict:"E",
        controller:"deviceListInSystemController",
        scope:{
            cmsAsdid:"@",
            cmsCustormerId:"@?",
            cmsLocoId:"@?",
            tableTitle:"@?",
            showStatusColumn:"=?",
            showNameColumn:"=?",
            showUptimeColumn:"=?",
            showIpAddressColumn:"=?",
            showCpuColumn:"=?",
            showMemoryColumn:"=?",
            showAlertsColumn:"=?",
            showNodesColumn:"=?",
            showLastSeenColumn:"=?",
            showDeviceTypeColumn:"=?",
            showEnrollDateColumn:"=?",
            showInterfaceColumn:"=?",

            deviceTypeName:  "@",
            showDeviceModelOfClass: "@?",
            refreshInterval:"=?"
        }
    }
}]);
