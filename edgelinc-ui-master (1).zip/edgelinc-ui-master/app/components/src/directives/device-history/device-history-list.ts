///<reference path="../../../../../typings/browser.d.ts"/>

import DeviceHistoryDataSourceModule, {
    DeviceHistoryDataSource, IEventHistoryFilter, DeviceHistoryItem,
    EventType
} from "../../services/DeviceHistoryDataSource";
import {IListItem} from "../list-filters/list-filters";
import ParameterStorageServiceModule, {IParameterStorageService, STORAGE_TYPE} from "../../services/ParameterStorageService";

interface IDisplayHistoryItem extends DeviceHistoryItem {
    showDetails?: boolean;
}

interface IDeviceHistoryTableScope extends ng.IScope {
    systemId: string;
    asdid: string;
    listFilter: IEventHistoryFilter;
    historyItems: IDisplayHistoryItem[];
    selection: any[];
    visibleCount: number;
    filteredCount: number;
    offset: number;
    inProgress: boolean;
    isLoading: boolean;
    pipe(tableState:any, tableCtrl:any): void;
    pageSize: number;
}

interface IDeviceHistoryListScope extends ng.IScope {
    systemId: string;
    asdid: string;
    enableQueryBinding: boolean;
    listFilter: IEventHistoryFilter;
    selection: any[];
    visibleCount: number;
    filteredCount: number;
    offset: number;
    isLoading: boolean;
    onFilterChange(): void;
    onFilterClick(): void;
    onClearFilterClick(): void;
    refreshTable(): void;
    stateRestored:boolean;
}

interface IDeviceHistoryFiltersScope extends ng.IScope {
    listFilter: IEventHistoryFilter;
    filterChanged(): void;
    filterQueryBinding: string;
    onFilterChange(): void;
}

class DeviceHistoryTableController {
    public static $inject = ['$scope', '$q', '$timeout', 'DeviceHistoryDataSource', 'ParameterStorageService'];

    private tableState: any;

    private scopePropertiesToSave:string[] = ["pageSize"];
    private storageKey:string = "device-history-table-storage";
    private storageType:STORAGE_TYPE;

    constructor(private $scope: IDeviceHistoryTableScope,
                private $q: ng.IQService,
                private $timeout: ng.ITimeoutService,
                private DeviceHistoryDataSource: DeviceHistoryDataSource,
                private ParameterStorageService: IParameterStorageService
    ) {
        $scope.historyItems = [];
        $scope.visibleCount = 0;
        $scope.filteredCount = 0;
        $scope.inProgress = true;
        $scope.isLoading = true;
        var doRequestThrottled = $q.throttle(() => this.doRequest());

        this.initTableParameterStorageService();

        $scope.pipe = (_tableState:any) => {
            this.customSaveState();
            this.tableState = _tableState;

            doRequestThrottled();
        };
    }

    private initTableParameterStorageService(){
         this.storageType = STORAGE_TYPE.SESSION_STORAGE;
         this.ParameterStorageService.restoreState(this.storageKey,this.storageType,this.$scope);
         if(this.$scope.pageSize == null || typeof this.$scope.pageSize == "undefined")
            this.$scope.pageSize = 10;
     }

    private customSaveState() {
        this.ParameterStorageService.saveState(this.$scope,this.storageKey,this.storageType, this.scopePropertiesToSave);
    }

    private doRequest() {
        var sortColumn = null;
        var sortDir:any = null;
        if (this.tableState.sort && this.tableState.sort.predicate) {
            sortColumn = this.tableState.sort.predicate;
            sortDir = this.tableState.sort.reverse ? "desc" : "asc";
        } else {
            sortColumn = "timestamp";
            sortDir = "desc";
            this.tableState.sort.predicate = "timestamp";
            this.tableState.sort.reverse = true;
        }
        var limit = this.tableState.pagination.number;
        this.$scope.offset = this.tableState.pagination.start;

        var listFilter = this.$scope.listFilter;
        /*var listFilter = JSON.parse(JSON.stringify(this.$scope.listFilter));
        if(typeof listFilter.systemId != "undefined" || typeof listFilter.asdid != "undefined") {
          listFilter.deviceModel = null;
        }*/
        return this.DeviceHistoryDataSource.getDeviceHistoryItems(listFilter, sortColumn, sortDir, limit, this.$scope.offset)
            .then((result:App.Models.SearchResult<DeviceHistoryItem>) => {
                this.$scope.inProgress = false;
                this.$scope.isLoading = false;
                var oldItems = _.indexBy(this.$scope.historyItems, (item: IDisplayHistoryItem) => item.data.id);
                this.$scope.historyItems = _.map(result.items, (item: DeviceHistoryItem) => {
                    var mappedItem: IDisplayHistoryItem = _.clone(item);
                    if(oldItems[item.data.id]) {
                        mappedItem.showDetails = oldItems[item.data.id].showDetails;
                    }
                    //item.additionalDataPromise.then(additionalData => {
                    //    mappedItem.additionalData = additionalData;
                    //});
                    return mappedItem;
                });
                this.$scope.visibleCount = this.$scope.historyItems.length;
                this.$scope.filteredCount = result.totalCount;
                //this.tableState.pagination.numberOfPages = Math.ceil(result.totalCount / this.tableState.pagination.number);
                this.tableState.pagination.totalItemCount = result.totalCount;
            })
    }
}

class DeviceHistoryListController {

    public static $inject = ['$scope', '$timeout', 'ParameterStorageService'];

    private filterChange:boolean = false;
    private scopePropertiesToSave:string[];

    private storageKey:string;
    private storageType:STORAGE_TYPE;

    constructor(private $scope: IDeviceHistoryListScope,
                private $timeout: ng.ITimeoutService,
                private ParameterStorageService: IParameterStorageService
    ) {

        $scope.listFilter = {};
        if(typeof $scope.systemId != "undefined" || typeof $scope.asdid != "undefined") {
          this.storageKey = "device-history-list-filters-with-systemId";
          this.scopePropertiesToSave = ["listFilter.dateRange.from", "listFilter.dateRange.to", "listFilter.eventType", "listFilter.searchPattern"];
        } else {
          this.storageKey = "device-history-list-filters";
          this.scopePropertiesToSave = ["listFilter.dateRange.from", "listFilter.dateRange.to", "listFilter.deviceModel", "listFilter.eventType", "listFilter.searchPattern"];
        }

        this.initParameterStorageService();
        //$scope.listFilter["asdid"] = $scope.asdid;
        //$scope.listFilter["systemId"] = $scope.systemId;

        $scope.$watch("asdid", ()=>{
            $scope.listFilter["asdid"] = $scope.asdid;
            $scope.refreshTable();
        });
        $scope.$watch("systemId", ()=>{
            $scope.listFilter["systemId"] = $scope.systemId;
            $scope.refreshTable();
        });


        $scope.onFilterChange = _.throttle(() => this.onFilterChanged(), 1000);
        $scope.onFilterClick = () => this.onFilterChanged();
        $scope.onClearFilterClick = () => this.clearFilters();
        $scope.refreshTable = () => this.onRefreshTable();
    }

    private clearFilters() {
        this.$scope.listFilter = {
            asdid: this.$scope.asdid,
            systemId: this.$scope.systemId
        };
        this.customSaveState();
        this.onFilterChanged();
    }

    private onFilterChanged() {
        this.$scope.$broadcast('smartTable:refreshRequired');
        if(this.$scope.stateRestored ){
          this.customSaveState();
        }
    }

    private onRefreshTable(){
        this.$scope.$broadcast('smartTable:refreshRequired');
    };

    private initParameterStorageService(){
         this.storageType = STORAGE_TYPE.SESSION_STORAGE;
         this.$scope.stateRestored = false;
         this.filterChange = false;
         //this.scopePropertiesToSave = ["listFilter.dateRange.from", "listFilter.dateRange.to", "listFilter.deviceModel", "listFilter.eventType", "listFilter.searchPattern"];
         this.ParameterStorageService.restoreState(this.storageKey,this.storageType,this.$scope);
         this.$scope.stateRestored = true;
     }

     private customSaveState() {
         this.$timeout(()=>{
             this.ParameterStorageService.saveState(this.$scope,this.storageKey,this.storageType, this.scopePropertiesToSave);
         });
     }
}




function createListDirective(templateNamePrefix: string, bindings: any) {
    var scope = _.extend({
        enableQueryBinding: '=?'
    }, bindings);

    return ['$branding', function($branding: app.branding.IBrandingService) {
        return {
            templateUrl: $branding.getTemplateUrl([templateNamePrefix + "DeviceHistoryListDirective", "DeviceHistoryListDirective"]),
            controller: DeviceHistoryListController,
            scope: scope
        }
    }]
}
function createSystemHisotryTableDirective(templateNamePrefix: string, bindings: any) {
    var scope = _.extend({
        listFilter: '=',
        visibleCount: '=',
        filteredCount: '=',
        offset: '=?',
        isLoading: '=',
        tableType: '@?'
    }, bindings);

    return ['$branding', function($branding: app.branding.IBrandingService) {
        return {
            templateUrl: $branding.getTemplateUrl([templateNamePrefix + "SystemHistoryTableDirective", "SystemHistoryTableDirective"]),
            controller: DeviceHistoryTableController,
            scope: scope
        }
    }]
}
function createGlobalHisotryTableDirective(templateNamePrefix: string, bindings: any) {
    var scope = _.extend({
        listFilter: '=',
        visibleCount: '=',
        filteredCount: '=',
        offset: '=?',
        isLoading: '=',
        tableType: '@?'
    }, bindings);

    return ['$branding', function($branding: app.branding.IBrandingService) {
        return {
            templateUrl: $branding.getTemplateUrl([templateNamePrefix + "GlobalHistoryTableDirective", "GlobalHistoryTableDirective"]),
            controller: DeviceHistoryTableController,
            scope: scope
        }
    }]
}
function createFiltersDirective(templateNamePrefix: string, bindings: any) {
    var scope = {
        listFilter: '=',
        filterChanged: '&',
        enableQueryBinding: '=?'
    };

    return ['$branding', function($branding: app.branding.IBrandingService) {
        return {
            templateUrl: $branding.getTemplateUrl([templateNamePrefix + "DeviceHistoryFiltersDirective", "DeviceHistoryFiltersDirective"]),
            scope: scope,
            link: (scope: IDeviceHistoryFiltersScope) => {
                scope.onFilterChange = () => scope.filterChanged();
            }
        }
    }]
}



interface IListFilterEventTypeScope extends ng.IScope {
    title:string,
    eventTypeKeys:string[];
    eventTypes:IListItem[];
    filterChanged:(model:string[]) => void;
    EventTypesListFilter:(query:string) => ng.IPromise<IListItem[]>;
    onFilterChanged:() => void;
}

function ListFilterEventTypeDirective(DeviceHistoryDataSource: DeviceHistoryDataSource) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            title: '@',
            eventTypeKeys: '=ngModel',
            filterChanged: "&",
        },
        templateUrl: "/components/src/directives/device-history/list-filter-event-type.html",
        link: (scope:IListFilterEventTypeScope) => {
            if (angular.isUndefined(scope.title)) {
                scope.title = 'Event Type:';
            }

            function getEventTypes(query?:string) {
                return DeviceHistoryDataSource.getEventTypes(query)
                    .then(eventTypes => {
                        return _.map(eventTypes, (eventType: EventType) => {
                            return {
                                text: eventType.name,
                                id: eventType.type,
                            }
                        });
                    })
            }

            scope.EventTypesListFilter = (query:string) => {
                return getEventTypes(query);
            };

            scope.onFilterChanged = () => {
                scope.eventTypeKeys = _.map(scope.eventTypes, t => t.id);
                if (scope.eventTypeKeys.length == 0) {
                    scope.eventTypeKeys = null;
                }
                scope.filterChanged(scope.eventTypeKeys);
            };
            scope.$watch('eventTypeKeys', (keys:string[]) => {
                if (keys == null || keys.length == 0) {
                    scope.eventTypes = [];
                } else {
                    getEventTypes()
                        .then(types => {
                            scope.eventTypes = _.filter(types, t => keys.indexOf(t.id) >= 0);
                        })
                }
            })
        }
    };
}

export default angular.module("directives.deviceHistory", [DeviceHistoryDataSourceModule.name])
    .directive("singleDeviceHistoryList", createListDirective("Single", {asdid: "="}))
    .directive("singleDeviceHistoryTable", createSystemHisotryTableDirective("Single", {asdid: "="}))
    .directive("singleDeviceHistoryFilters", createFiltersDirective("Single", {asdid: "="}))
    .directive("systemDeviceHistoryList", createListDirective("System", {systemId: "="}))
    .directive("systemDeviceHistoryTable", createSystemHisotryTableDirective("System", {systemId: "="}))
    .directive("systemDeviceHistoryFilters", createFiltersDirective("System", {systemId: "="}))
    .directive("globalDeviceHistoryList", createListDirective("Global", {}))
    .directive("globalDeviceHistoryTable", createGlobalHisotryTableDirective("Global", {}))
    .directive("globalDeviceHistoryFilters", createFiltersDirective("Global", {}))
    .directive("listFilterEventType", ["DeviceHistoryDataSource", ListFilterEventTypeDirective])

;
