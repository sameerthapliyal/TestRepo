///<reference path="../../../../../typings/browser.d.ts"/>

import CommonServicesModule, {CommonServices} from "../../services/CommonServices";
import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";

var angularModule = angular.module('directives.deviceHistoryStats', [CommonServicesModule.name]);
export default angularModule;

export interface IDeviceHistoryStatsController extends ng.IScope{
    rowStatItem: any;
    statsToDisplay: any;
}

export class DeviceHistoryStatsController{
    private deviceModel: string;
    private modelVersion: string;
    private viscapfile: any;
    private statsFromVis: any;

    constructor(private $scope: IDeviceHistoryStatsController,
                private $q:ng.IQService,
                private $branding: app.branding.IBrandingService,
                private CommonService: CommonServices,
                private DeviceModelsService: DeviceModelsService
    ) {
          this.$scope.statsToDisplay = null;
          this.deviceModel = this.$scope.rowStatItem.data.device_model;
          this.modelVersion = this.$scope.rowStatItem.data.model_version;

          this.DeviceModelsService.getVisCapfile(this.deviceModel, this.modelVersion).then((viscapfile)=>{
            if(viscapfile) {
              this.statsFromVis = this.createStatsFromViscapfile(viscapfile);
              this.$scope.statsToDisplay = this.connectRowDataWithVisStats(this.$scope.rowStatItem.data.details_json, this.statsFromVis);
            }
          });

    }

    private createStatsFromViscapfile(viscapfile: any){
      let viscapfileStats = [];
      let tempObject: any = {};
      let tempNumber: any;

      _.each(viscapfile.StatisticsView.Series, (series: string, api_name: string)=>{
          tempObject["apiName"] = api_name;
          tempNumber = viscapfile.StatisticsView.Series[api_name].StatisticName;
        _.each(viscapfile.Statistics, (stats: string, num: number)=>{
          if(num == tempNumber) {
            tempObject["statistic"] = stats;
            viscapfileStats.push(tempObject);
            tempObject = {};
          }
        });
      });

      return viscapfileStats;
    }

    private connectRowDataWithVisStats(detailsJSON: any, visStats: any){
      if(typeof detailsJSON == "string") {
        try{
          detailsJSON = JSON.parse(detailsJSON);
        } catch(err) {
          console.log(err);
        }

      }
      let displayStats = [];

      _.each(detailsJSON.snapshot, (statSnapshot: any) => {
        _.each(visStats, (visStat: any) => {
          if(statSnapshot.name == visStat.apiName){
            visStat["timestamp"] = statSnapshot.timestamp;
            visStat["displayValue"] = statSnapshot.value;
            if(visStat.statistic.Enumeration) {
                visStat["value"] = visStat["displayValue"];
                visStat["displayValue"] = visStat.statistic.Enumeration[visStat["displayValue"]];
            }

            displayStats.push(visStat);
            this.$scope.rowStatItem.hasDetailsToShow = true;
          }
        });
      });

      return displayStats;
    }
}

angularModule.controller('DeviceHistoryStatsController', DeviceHistoryStatsController);

angularModule.directive('deviceHistoryStats', ['CommonServices', 'DeviceModelsService', function() {
    return {
        templateUrl: '/components/src/directives/device-history-stats/device-history-stats.html',
        controller: ['$scope', '$q', '$branding', 'CommonServices', 'DeviceModelsService', DeviceHistoryStatsController],
        transclude: true,
        scope: {
            "rowStatItem": '='
        }
    }
}]);
