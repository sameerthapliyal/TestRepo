
interface IPdmSearchDirectiveScope extends ng.IScope {
    enableRegexp?: boolean;
    useRegexp: boolean;
    active: boolean;
    searchString: string;
    search(): void;
}
function PdmSearchDirective($location: ng.ILocationService, $branding: app.branding.IBrandingService) {
    return {
        restrict: "A",
        scope: {
            enableRegexp: '=?'
        },
        templateUrl: "/components/src/directives/pdm-search/pdm-search.html",
        link: (scope: IPdmSearchDirectiveScope, element: ng.IAugmentedJQuery) => {
            if(scope.enableRegexp == null) {
                scope.enableRegexp = $branding.getUISettings().enableRegexpSearch;
            }
            scope.useRegexp = false;
            scope.active = false;


            scope.search = () => {
                if (scope.searchString && scope.searchString != "") {
                    let param:{q:string; regexp?:string} = { q: scope.searchString };
                    if( scope.useRegexp){ param.regexp = scope.useRegexp.toString();}
                    $location.path("/views/search").search(param);
                    angular.element(document.querySelector(".mobile-search")).removeClass('active');
                    scope.searchString = "";
                }
            };

            scope.$watch('active', (active) => {
                if(active) {
                    let inputElement = <HTMLInputElement>element[0].querySelector('.pdm-search-input');
                    if(inputElement) {
                        inputElement.focus();
                    }
                    element.addClass('active');
                } else {
                    element.removeClass('active');
                }
            });

            function onDocumentMouseUp(e) {
                if (element[0] != e.target.parentElement && !element[0].contains(e.target.parentElement)) {
                    scope.active = false;
                    scope.$apply();
                }
            }

            angular.element(document).on("mouseup", onDocumentMouseUp);

            scope.$on('destroy', () => {
                angular.element(document).off("mouseup", onDocumentMouseUp);
            });
        }
    }
}

PdmSearchDirective.$inject = ['$location', '$branding'];

export default angular.module('directives.pdmSearch', [])
    .directive('pdmSearch', PdmSearchDirective);