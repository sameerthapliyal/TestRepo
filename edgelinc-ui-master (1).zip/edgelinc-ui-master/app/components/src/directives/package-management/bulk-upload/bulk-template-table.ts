///<reference path="../../../../../../typings/browser.d.ts"/>

interface IBulkTemplateTableScope extends ng.IScope{
    updateData:(tableState:any, tableCtrl:any)=> void;
    visibleItem: any;
    lastTableState: any;
    lastTableCtrl: any;
    tableData: any;
    total: number;
}

class BulkTemplateTableCtrl {

    private static $inject = ['$scope', 'McsStatusService'];


    constructor(private $scope: IBulkTemplateTableScope) {
        this.$scope.updateData = (tableState:any, tableCtrl:any) => {
            this.$scope.lastTableState = tableState;
            this.$scope.lastTableCtrl = tableCtrl;
            this.updateData();
        };

        $scope.$watch("tableData.templateArray", (templateArr: any) => {
            this.updateData();
        });
    }

    private updateData(){
        if(this.$scope.lastTableState == null || this.$scope.lastTableCtrl == null){
            return;
        }
        if(this.$scope.tableData.templateArray) {
          this.$scope.lastTableState.pagination.totalItemCount = this.$scope.tableData.templateArray.length;
          this.$scope.lastTableState.pagination.numberOfPages = Math.ceil(this.$scope.tableData.templateArray.length / this.$scope.lastTableState.pagination.number);
          this.$scope.total = this.$scope.lastTableState.pagination.totalItemCount;
          var end = this.visibleItemsEndCalculation(this.$scope.lastTableState);
          this.$scope.visibleItem = this.$scope.tableData.templateArray.slice(this.$scope.lastTableState.pagination.start, end);
        } else {
          this.$scope.visibleItem = [];
        }

    }

    public visibleItemsEndCalculation(tableState: any) {
      if(tableState.pagination.totalItemCount - tableState.pagination.start >= tableState.pagination.number) {
          return tableState.pagination.number + tableState.pagination.start;
      } else {
          return tableState.pagination.totalItemCount;
      }
    }

}

export default angular.module("directives.bulkTemplateTable", [])
.directive('bulkTemplateTable', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            tableData: "=",
        },
        controller: BulkTemplateTableCtrl,
        templateUrl: $branding.getTemplateUrl("directives.bulkTemplateTable"),
    }
}]);
