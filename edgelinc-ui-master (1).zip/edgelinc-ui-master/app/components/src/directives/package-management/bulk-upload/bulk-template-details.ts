///<reference path="../../../../../../typings/browser.d.ts"/>

interface IBulkTemplateDetailsScope {
    templateItem: any;
    templateDetails: any;
    stringRestriction: string;
}

export class BulkTemplateDetailController {
    private static $inject = ['$scope']
    constructor (
        private $scope: IBulkTemplateDetailsScope
        ) {
          this.$scope.templateDetails = this.$scope.templateItem.attributes;
          this.convertRestrictionArrayToString();
    }

    private convertRestrictionArrayToString(){
        this.$scope.stringRestriction = null;
        if(this.$scope.templateDetails && this.$scope.templateDetails.restrict_to) {
            _.each(this.$scope.templateDetails.restrict_to, (value: string) => {
                if(!this.$scope.stringRestriction) {
                    if(value !== "") {
                        this.$scope.stringRestriction = value;
                    }
                } else {
                    this.$scope.stringRestriction = `${this.$scope.stringRestriction}, ${value}`;
                }
            });
        }
    }
}
function bulkTemplateDetailsDirective ($branding) {
    return {
        restrict: "E",
        scope: {
            templateItem: '=',
        },
        controller: BulkTemplateDetailController,
        templateUrl: $branding.getTemplateUrl("directives.bulkTemplateDetails"),

    }
};

export default angular.module("directives.bulkTemplateDetails", [])
    .directive('bulkTemplateDetails', ['$branding', bulkTemplateDetailsDirective]);
