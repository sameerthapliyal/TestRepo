///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageEditControllerModule, {
    PackageEditController,
    IPackageEditControllerScope
} from "./../PackageEditController";
import {IRepositoryPackage} from "../../../services/PackageRepositoryService";
import BulkTemplateTableModule from "./bulk-template-table";
import BulkTemplateDetailsModule from "./bulk-template-details";

interface IBulkUploadDirectiveScope extends IPackageEditControllerScope {
    onBackToList(): void;
}

function BulkUploadDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('BulkUploadDirective'),
        controller: 'PackageEditController',
        scope: {
            onBackToList: '&'
        },
        link: (scope: IBulkUploadDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageEditController) => {
            ctrl.onBackToList = () => scope.onBackToList();
            ctrl.initialize("BULK");
        }
    }
}

export default angular.module('directives.packageManagement.bulkUpload', [PackageEditControllerModule.name, BulkTemplateTableModule.name, BulkTemplateDetailsModule.name])
    .directive("bulkUpload", ['$branding', BulkUploadDirective]);
