///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageRepositoryServiceModule, {
    PackageRepositoryService, IRepositoryPackage, IRepositoryQnxPackage,
    IRepositoryPackageFilter, IQnxRepositoryPackageFilter, Restrictions, RepositoryTemplateTypes, IRepositoryQnxTemplateType, ISystemPackage, IAgentPackage
} from "../../../services/PackageRepositoryService";
import {IStSelectableRow as ICheckableRow} from "../../smart-table/st-custom-selection";
import {IStSelectableRow as ISelectableRow} from "../../smart-table/st-custom-radio-selection";
import CreatePackageModule from "../../../../../views/package-management/create-package";
import BulkUploadModule from "../../../../../views/package-management/bulk-upload/bulk-upload";
import PackageEditModule from "../../../../../views/package-management/edit-package";
import PackageReviseModule from "../../../../../views/package-management/revise-package";
import PackageViewModule from "../../../../../views/package-management/view-package";
import CreateQnxPackageModule from "../../../../../views/package-management/mcs-package-mgmt/create-qnx-package";
import EditQnxPackageModule from "../../../../../views/package-management/mcs-package-mgmt/edit-qnx-package";
import ReviseQnxPackageModule from "../../../../../views/package-management/mcs-package-mgmt/revise-qnx-package";
import ParameterStorageServiceModule, {IParameterStorageService, STORAGE_TYPE} from "../../../services/ParameterStorageService";
import AuthServiceModule, {AuthService} from "../../../services/AuthService";
import McsTemplateServiceModule, { McsTemplateService, IRepositoryQnxTemplate } from "../../../services/mcs/mcsTemplateService";
import McsGeneralServiceModule, {McsGeneralService} from "../../../services/mcs/McsGeneralService";
import MCSControllerBase, {DataSetEntry} from "../../../services/parameters-validator/controllers/MCSControllerBase";
import * as _ from "lodash";

export interface IRepositoryPackageDisplay extends ISelectableRow, ICheckableRow, IRepositoryPackage {

}

export type RepositoryPackageStatus = eapi19.RepositoryPackageStatus;

export interface ISystemPackageToDisplay {
    agentData?: IAgentPackage,
    status: boolean,
    serverVersion?: string,
    nodeVersion?: string,
    fusDescription?: string,
    fusRevision?: number
    displayDescription?: string,
    displayType?: string
}

interface IRepositoryPackagesCommonBoundableScope extends ng.IScope {
    enableSelection: boolean;
    selectedId: string;
    selectedItem: IRepositoryPackageDisplay;
    onSelectorClick(args: { selectedItem: IRepositoryPackageDisplay });
    showCheckboxes: boolean;
    checkedItems: IRepositoryPackageDisplay[];
    refreshEvent: string;
}

interface IRepositoryQnxPackagesCommonBoundableScope extends IRepositoryPackagesCommonBoundableScope {
    onQnxSelectorClick(args: { selectedQnxItem: IRepositoryQnxPackage });
    selectedQnxItem: IRepositoryQnxPackage;
    checkedQnxTemplatess: IRepositoryQnxPackage[];
    refreshQnxTableEvent: string;
}

interface IRepositoryPackagesTableCustomDirectiveScope extends IRepositoryPackagesCommonBoundableScope {
    visibleItems: IRepositoryPackageDisplay[];
    pipe(tableState: any, tableCtrl: any): void;
    selectRow(row: IRepositoryPackageDisplay);
}

interface IRepositoryPackagesTableDirectiveScope extends IRepositoryPackagesCommonBoundableScope {
    listFilter: IRepositoryPackageFilter;
    visible: {
      visibleCount: number;
      visibleQnxCount?: number;
    }
    filtered: {
        filteredCount: number;
        filteredQnxCount?: number;
    }
    offset: number;
    isLoading: boolean;
    inProgress: boolean;
    error: Error;
    route: string;
    getRestrictions(query: string): ng.IPromise<Restrictions>;
    visibleItems: IRepositoryPackageDisplay[];
    pipe(tableState: any, tableCtrl: any): void;
    pageSize: number;
    selectRow(row: IRepositoryPackageDisplay);
    view(repositoryPackage: IRepositoryPackage);
}


interface IRepositoryQnxPackagesTableDirectiveScope extends IRepositoryQnxPackagesCommonBoundableScope {
    qnxListFilter: IQnxRepositoryPackageFilter;
    visible: {
      visibleCount: number;
      visibleQnxCount?: number;
    }
    filtered: {
        filteredCount: number;
        filteredQnxCount?: number;
    }
    offset: number;
    isLoading: boolean;
    inProgress: boolean;
    error: Error;
    route: string;
    getRestrictions(query: string): ng.IPromise<Restrictions>;
    visibleTemplates: IRepositoryQnxTemplateType[];
    pipe(tableState: any, tableCtrl: any): void;
    pageSize: number;
    selectQnxRow(row: IRepositoryQnxPackage);
    viewQnx(repositoryPackage: IRepositoryQnxPackage);
    errorQnx: Error;
    templateChanged: {
        isChanged: boolean;
    };
}

interface IRepositoryPackagesListDirectiveScope extends IRepositoryQnxPackagesCommonBoundableScope {
    defaultListFilter: IRepositoryPackageFilter;
    listFilter: IRepositoryPackageFilter;
    qnxListFilter: IQnxRepositoryPackageFilter;
    visible: {
      visibleCount: number;
      visibleQnxCount?: number;
    }
    filtered: {
        filteredCount: number;
        filteredQnxCount?: number;
    }
    offset:number;
    isLoading: boolean;
    inProgress: boolean;
    error: Error;
    errorQnx: Error;
    onFilterChange(): void;
    onFilterClick(): void;
    onClearFilterClick(): void;
    raiseSelectorClick(selectedItem: IRepositoryPackageDisplay): void;
    raiseQnxSelectorClick(selectedQnxItem: IRepositoryQnxPackage): void;
    apply(repositoryPackage: IRepositoryPackage);
    edit(repositoryPackage: IRepositoryPackage);
    revise(repositoryPackage: IRepositoryPackage);
    approve(repositoryPackage: IRepositoryPackage);
    onApply(args: { packageId: string, packageVersion: string, templateType: string });
    onEdit(args: { packageId: string, packageVersion: string, templateType: string });
    onRevise(args: { packageId: string, packageVersion: string, templateType: string });
    onApprove(args: { packageId: string, packageVersion: string, templateType: string });
    editQnx(repositoryQnxPackage: IRepositoryQnxPackage);
    reviseQnx(repositoryQnxPackage: IRepositoryQnxPackage);
    approveQnx(repositoryQnxPackage: IRepositoryQnxPackage);
    onEditQnx(args: { tempObjid: string, tempTypeObjid: number });
    onReviseQnx(args: { tempObjid: string, tempTypeObjid: number });
    onApproveQnx(args: { tempObjid: string, tempTypeObjid: number });
    newPackage(): void;
    bulkUpload(): void;
    newQnxPackage(qnxListFilter: any, selectedItem: any): void;
    onNewQnxPackage(args: {qnxListFilter: any, selectedItem: any}):void;
    onApplyQnx(): void;
    listQnxTemplate(): void;
    stateRestored:boolean;
    searchStringMinLenght:number;
    templateInterfaces: { [key: string]: string };
    interface: string;
    listFilteredItems: boolean;
    canManageTemplates(): void;
}
interface IRepositoryPackagesFiltersDirectiveScope extends ng.IScope {
    listFilter: IRepositoryPackageFilter;
    filterChanged(): void;
    onFilterChange(): void;
    getTemplateTypes(query: string): ng.IPromise<RepositoryTemplateTypes>;
    getRestrictions(query: string): ng.IPromise<Restrictions>;
}

interface IRepositoryQnxPackagesFiltersDirectiveScope extends ng.IScope {
    qnxListFilter: IQnxRepositoryPackageFilter;
    qnxTemplateTypes: IRepositoryQnxPackage[];
    getTemplateTypes(query: string): ng.IPromise<any>;
    getRestrictions(query: string): ng.IPromise<Restrictions>;
    qnxStatuses: any;
    filterChanged(): void;
    onFilterChange(): void;
}

interface ISystemPackagesTableScope extends ng.IScope {
    systemId: string;
    enableQueryBinding: boolean;
    visibleItems: ISystemPackageToDisplay[];
    pipe(tableState: any, tableCtrl: any): void;
    pageSize: number;
    sortField: string;
    limit:number;
    offset:number;
    lastItemIndex:number;
    filteredCount: number;
    showPagination: boolean;
    isLoading: boolean;
}

class RepositoryPackagesListController {
    public static $inject = ['$scope', "$location", '$timeout', 'ParameterStorageService', "RouteHelpers","AuthorizationService"];

    private filterChange:boolean = false;
    private scopePropertiesToSave:string[];

    private storageKey:string = "package-list-filters";
    private storageType:STORAGE_TYPE;

    constructor(private $scope: IRepositoryPackagesListDirectiveScope,
                private $location: ng.ILocationService,
                private $timeout: ng.ITimeoutService,
                private ParameterStorageService: IParameterStorageService,
                private RouteHelpers: app.IRouteHelpers,
                private authService:AuthService
    ) {
        $scope.qnxListFilter = {};
        this.initParameterStorageService();
        $scope.searchStringMinLenght = 3;
        $scope.visible = {
            visibleCount: null
        };
        $scope.filtered = {
            filteredCount: null
        }
      
        $scope.inProgress = null;
        $scope.isLoading = null;
        //$scope.listFilter = _.clone($scope.defaultListFilter);
        $scope.onFilterChange = _.throttle(() => this.onFilterChanged(), 1000);
        $scope.onFilterClick = () => this.onFilterChanged();
        $scope.onClearFilterClick = () => this.clearFilters();
        $scope.raiseSelectorClick = (selectedItem: IRepositoryPackageDisplay) => $scope.onSelectorClick({ selectedItem: selectedItem });
        $scope.raiseQnxSelectorClick = (selectedQnxItem: IRepositoryQnxPackage) => $scope.onQnxSelectorClick({ selectedQnxItem: selectedQnxItem });
        $scope.apply = p => $scope.onApply({ packageId: p.packageId, packageVersion: p.version, templateType: p.templateType });
        $scope.edit = p =>  $scope.onEdit({ packageId: p.packageId, packageVersion: p.version, templateType: p.templateType });
        $scope.editQnx = p =>  $scope.onEditQnx({ tempObjid: p.tempObjid, tempTypeObjid: $scope.qnxListFilter.tempTypeObjid });
        $scope.revise = p => $scope.onRevise({ packageId: p.packageId, packageVersion: p.version, templateType: p.templateType });
        $scope.reviseQnx = p =>  $scope.onReviseQnx({ tempObjid: p.tempObjid, tempTypeObjid: $scope.qnxListFilter.tempTypeObjid });
        $scope.approve = p => $scope.onApprove({ packageId: p.packageId, packageVersion: p.version, templateType: p.templateType });
        $scope.approveQnx = p =>  $scope.onApproveQnx({ tempObjid: p.tempObjid, tempTypeObjid: $scope.qnxListFilter.tempTypeObjid });
        $scope.newPackage = () => this.newPackage();
        $scope.bulkUpload = () => this.bulkUpload();
        $scope.newQnxPackage = (qnxListFilter, selectedItem) => this.onNewQnxPackage(qnxListFilter, selectedItem);
        $scope.listQnxTemplate = () => this.listQnxTemplate();
        this.$scope.canManageTemplates = ()=>{
            return this.authService.hasLoginUserAnyOfPermissions(["Manage Template","Approve Template","Apply Templates"]);
        }

        this.$scope.templateInterfaces = {
            "qnx": "QNX Gateway",
            "uplinc": "UpLINC Gateway"
        };

        this.$scope.interface = this.$scope.interface ? this.$scope.interface : "uplinc";

    }

    private clearFilters() {
        this.$scope.listFilter = _.clone(this.$scope.defaultListFilter);
        this.customSaveState();
        this.onFilterChanged();
    }

    private onFilterChanged() {
        this.$scope.$broadcast(this.$scope.refreshEvent || 'smartTable:refreshRequired');
        if(this.$scope.stateRestored ){
          this.customSaveState();
        }
    }

   private initParameterStorageService(){
        this.storageType = STORAGE_TYPE.SESSION_STORAGE;
        this.$scope.stateRestored = false;
        this.filterChange = false;
        this.scopePropertiesToSave = ["listFilter.description", "listFilter.number", "listFilter.restrictions", "listFilter.searchPattern",
                                      "listFilter.status", "listFilter.templateType", "listFilter.version", "listFilter.last_updated_ts.from", "listFilter.last_updated_ts.to"
                                      ,"qnxListFilter.tempTypeObjid","qnxListFilter.templateNumber", "qnxListFilter.templateVersion", "qnxListFilter.status"
                                      ,"qnxListFilter.description", "qnxListFilter.templateOnlyAppliesToArray"
                                      ];
        this.ParameterStorageService.restoreState(this.storageKey,this.storageType,this.$scope);
        this.$scope.stateRestored = true;
    }

    private customSaveState() {
        this.$timeout(()=>{
            // delay to wait for scope to be updated by the change operation
            this.ParameterStorageService.saveState(this.$scope,this.storageKey,this.storageType, this.scopePropertiesToSave);
        });
    }

    private newPackage() {
        var createPackageModuleName = CreatePackageModule.name;
        var route = (<any>window).BRANDING.menu.config[createPackageModuleName].route;
        this.$location.url(this.RouteHelpers.routeToLocation(route, {}));
    }

    private bulkUpload() {
        var bulkUploadModuleName = BulkUploadModule.name;
        var route = (<any>window).BRANDING.menu.config[bulkUploadModuleName].route;
        this.$location.url(this.RouteHelpers.routeToLocation(route, {}));
    }

    private onNewQnxPackage(qnxListFilter: any, selectedItem: any) {
        if(selectedItem && qnxListFilter) {
          var route = (<any>window).BRANDING.menu.config['views.packageManagement.createQnxPackageModuleWithSelectedTemplate'].route;
          this.$location.url(this.RouteHelpers.routeToLocation(route, {tempObjid: selectedItem.tempObjid, tempTypeObjid: qnxListFilter.tempTypeObjid}));
        } else if(qnxListFilter && qnxListFilter.tempTypeObjid) {
            var route = (<any>window).BRANDING.menu.config['views.packageManagement.createQnxPackageModuleWithTempId'].route;
            this.$location.url(this.RouteHelpers.routeToLocation(route, {templateType: qnxListFilter.tempTypeObjid}));
        } else {
            var route = (<any>window).BRANDING.menu.config['views.packageManagement.createQnxPackageModule'].route;
            this.$location.url(this.RouteHelpers.routeToLocation(route, {}));
        }
    }

    private listQnxTemplate() {
        this.$scope.listFilteredItems = this.$scope.listFilteredItems ? !this.$scope.listFilteredItems : true;
    }
}

class RepositoryPackagesTableController {
    public static $inject = ['$scope', '$q', '$timeout', 'PackageRepositoryService', '$location', 'RouteHelpers', 'ParameterStorageService'];

    private tableState: any;
    private scopePropertiesToSave:string[] = ["pageSize"];
    private storageKey:string = "packages-table-storage";
    private storageType:STORAGE_TYPE;

    constructor(private $scope: IRepositoryPackagesTableDirectiveScope,
		            private $q: ng.IQService,
		            private $timeout: ng.ITimeoutService,
		            private PackageRepositoryService: PackageRepositoryService,
                private $location: ng.ILocationService, private RouteHelpers: app.IRouteHelpers,
                private ParameterStorageService: IParameterStorageService
	  ) {
        $scope.offset = 0;
        $scope.visibleItems = [];
        $scope.inProgress = true;
        $scope.isLoading = true;
        $scope.view = p => {
          this.view(p.packageId, p.version, p.templateType)
		}

        var doRequestThrottled = $q.throttle(() => this.doRequest());

        this.initTableParameterStorageService();

        $scope.pipe = (_tableState: any) => {
            this.customSaveState();
            this.tableState = _tableState;
            doRequestThrottled();
        };
        $scope.selectRow = (row: IRepositoryPackageDisplay) => {
            if (row) {
                $scope.selectedId = row.packageId;
            }
            $scope.selectedItem = row;
            $scope.onSelectorClick({ selectedItem: row });
        };
    }

    private view(packageId: string, packageVersion: string, templateType: string) {
        var viewPackageModuleName = PackageViewModule.name;
        var route = (<any>window).BRANDING.menu.config[viewPackageModuleName].route;
        this.$location.url(this.RouteHelpers.routeToLocation(route, { packageId: packageId, packageVersion: packageVersion, templateType: templateType }));
    }

    private initTableParameterStorageService(){
         this.storageType = STORAGE_TYPE.SESSION_STORAGE;
         this.ParameterStorageService.restoreState(this.storageKey,this.storageType,this.$scope);
         if(this.$scope.pageSize == null || typeof this.$scope.pageSize == "undefined")
            this.$scope.pageSize = 10;
     }

     private customSaveState() {
        this.ParameterStorageService.saveState(this.$scope,this.storageKey,this.storageType, this.scopePropertiesToSave);
     }

    private doRequest() {
        var sortColumn = null;
        var sortDir: any = null;
        if (this.tableState.sort && this.tableState.sort.predicate) {
            sortColumn = this.tableState.sort.predicate;
            sortDir = this.tableState.sort.reverse ? "desc" : "asc";
        } else {
            sortColumn = "timestamp";
            sortDir = "desc";
            this.tableState.sort.predicate = "timestamp";
            this.tableState.sort.reverse = true;
        }
        var limit = this.tableState.pagination.number;
        var offset = this.tableState.pagination.start;
        var listFilter = this.$scope.listFilter;
        return this.PackageRepositoryService.getPackages(listFilter, sortColumn, sortDir, limit, offset)
            .then((result: App.Models.SearchResult<IRepositoryPackage>) => {
                this.$scope.visibleItems = _.map(result.items, (repositoryPackage: IRepositoryPackage) => {
                    return repositoryPackage;
                });
                this.$scope.offset = offset;
                this.$scope.visible.visibleCount = this.$scope.visibleItems.length;
                this.$scope.filtered.filteredCount = result.totalCount;
                //this.tableState.pagination.numberOfPages = Math.ceil(result.totalCount / this.tableState.pagination.number);
                this.tableState.pagination.totalItemCount = result.totalCount;
                this.$scope.error = null;
                this.$timeout(()=>{
                    this.$scope.$emit("stCustomSelection:selectedItemsChanged", result.items);
                },100);

            })
            .catch(err => {
                console.error(err);
                this.$scope.visibleItems = [];
                this.$scope.visible.visibleCount = 0;
                this.$scope.filtered.filteredCount = 0;
                //this.tableState.pagination.numberOfPages = 0;
                this.tableState.pagination.totalItemCoun = 0;
                this.$scope.error = err;
            })
            .finally(() => {
                this.$scope.inProgress = false;
                this.$scope.isLoading = false;
            })
    }
}

class RepositoryPackagesFiltersController {
    public static $inject = ['$scope', '$q', 'PackageRepositoryService'];

    private templateTypes: RepositoryTemplateTypes = [];
    private restrictions: Restrictions = [];

    constructor(private $scope: IRepositoryPackagesFiltersDirectiveScope, private $q: ng.IQService, private PackageRepositoryService: PackageRepositoryService) {
        $scope.onFilterChange = () => $scope.filterChanged();
        this.getTemplateTypes().then(tt => { this.templateTypes = tt });
        this.getRestrictions().then(rest => { this.restrictions = rest});
        $scope.getTemplateTypes = (query: string) => {
            var regexp = new RegExp(query, "i");
            return $q.when(_.filter(this.templateTypes, r => regexp.test(r.name)));
        };
        $scope.getRestrictions = (query: string) => {
          var regexp = new RegExp(query, "i");
          return $q.when(_.filter(this.restrictions, r => regexp.test(r.name)));
        }
    }

    private getTemplateTypes(): ng.IPromise<RepositoryTemplateTypes> {
        return this.PackageRepositoryService.getTemplateTypes();
    }

    private getRestrictions(): ng.IPromise<Restrictions> {
        return this.PackageRepositoryService.getRestrictions();
    }

}

class RepositoryQnxPackagesFiltersController {
    public static $inject = ['$scope', '$q', 'McsGeneralService', 'McsTemplateService'];

    constructor(private $scope: IRepositoryQnxPackagesFiltersDirectiveScope,
                private $q: ng.IQService,
                private McsGeneralService: McsGeneralService,
                private McsTemplateService: McsTemplateService) {
        $scope.onFilterChange = () => $scope.filterChanged();
        
        this.getTemplateTypes().then(res => {
            $scope.qnxTemplateTypes = res;
        }).catch(err => {
            console.log(err);
            $scope.qnxTemplateTypes = [];
        });

        this.getQnxStatuses().then(response => {
            $scope.qnxStatuses = response;
        }).catch(err => {
            console.log(err);
            $scope.qnxStatuses = [];
        });
        
        this.$scope.$watch(()=>{return JSON.stringify(this.$scope.qnxListFilter.templateOnlyAppliesToArray)}, ()=>{
            this.$scope.filterChanged();
        })
    }

    private getTemplateTypes(): ng.IPromise<IRepositoryQnxPackage[]> {
        return this.McsGeneralService.getTemplateTypes();
    }

    private getQnxStatuses(): ng.IPromise<DataSetEntry[]> {
        return this.McsTemplateService.getTemplateStatuses();
    }

}

class RepositoryQnxPackagesTableController {
    public static $inject = ['$scope', '$q', '$timeout', 'PackageRepositoryService', '$location', 'RouteHelpers', 'McsTemplateService'];

    private tableState: any;
    private scopePropertiesToSave:string[] = ["pageSize"];
    private storageKey:string = "packages-table-storage";
    private storageType:STORAGE_TYPE;

    constructor(private $scope: IRepositoryQnxPackagesTableDirectiveScope,
		            private $q: ng.IQService,
		            private $timeout: ng.ITimeoutService,
		            private PackageRepositoryService: PackageRepositoryService,
                private $location: ng.ILocationService,
                private RouteHelpers: app.IRouteHelpers,
                private McsTemplateService: McsTemplateService
	  ) {
        $scope.offset = 0;
        $scope.visibleTemplates = [];
        $scope.inProgress = true;
        $scope.isLoading = true;
        $scope.viewQnx = p => {
          this.viewQnx(p.tempObjid, this.$scope.qnxListFilter.tempTypeObjid);
        }

        var doRequestThrottled = $q.throttle(() => this.doRequest());

        $scope.pipe = (_tableState: any) => {
            this.tableState = _tableState;
            if($scope.templateChanged && $scope.templateChanged.isChanged) {
                // LDARS-276 - DE78044: Dev3:Pagination is not getting reset while applying templates
                this.tableState.pagination.start = 0;
                $scope.templateChanged.isChanged = false;
            }
            //LDARS-151 - DE74473: Template Management Screen: System is showing all the matching template records before clicking the list button.
            if (this.$scope.qnxListFilter.tempTypeObjid) {
                $scope.errorQnx = null;
                return doRequestThrottled();
            }
            $scope.inProgress = false;
            $scope.isLoading = false;
        };
        $scope.selectQnxRow = (row: IRepositoryQnxPackage) => {
            if (row) {
                $scope.selectedId = row.tempObjid;
            }
            $scope.selectedQnxItem = row;
            $scope.onQnxSelectorClick({ selectedQnxItem: row });
        };

        $scope.$watch('listFilteredItems', (newFilterdItemsValue:any) => {
            if(typeof newFilterdItemsValue != "undefined" && this.$scope.qnxListFilter.tempTypeObjid) {
                this.tableState.pagination.start = 0;
                this.doRequest();
            }
        });

        if(typeof $scope.qnxListFilter == "undefined") {
            $scope.qnxListFilter = {};
        }
    }

    private viewQnx(tempObjid: string, tempTypeObjid: number) {
        var route = (<any>window).BRANDING.menu.config['views.packageManagement.viewQnxPackageModule'].route;
        this.$location.url(this.RouteHelpers.routeToLocation(route, { tempObjid: tempObjid, tempTypeObjid: tempTypeObjid}));
    }


    private doRequest() {
        this.$scope.visibleTemplates = [];
        this.$scope.inProgress = true;
        this.$scope.isLoading = true
        if(this.$scope.qnxListFilter.templateOnlyAppliesToArray) {
            if(this.$scope.qnxListFilter.templateOnlyAppliesToArray.length > 0) {
                this.$scope.qnxListFilter.templateOnlyAppliesTo = this.McsTemplateService.generateStringWithRestrictions(this.$scope.qnxListFilter.templateOnlyAppliesToArray);
            } else {
                this.$scope.qnxListFilter.templateOnlyAppliesTo = null;
            }
        }

        let qnxListFilter = this.mapQnxListFilter();
        qnxListFilter = _.omitBy(qnxListFilter, _.isNil);  //remove all undefined and null value from filters
        let parameters = {
            params: qnxListFilter
        }

        return this.McsTemplateService.getTemplatesConf(parameters)
            .then((result: IRepositoryQnxTemplate) => {
                this.$scope.visibleTemplates = result.data;
                this.$scope.visible.visibleQnxCount = this.$scope.visibleTemplates.length;
                this.$scope.filtered.filteredQnxCount = result.totalCount;
                //this.tableState.pagination.numberOfPages = Math.ceil(result.totalCount / this.tableState.pagination.number);
                this.tableState.pagination.totalItemCount = result.totalCount;
                this.$scope.errorQnx = null;
            })
            .catch(err => {
                console.error(err);
                this.$scope.visibleTemplates = [];
                this.$scope.visible.visibleQnxCount = 0;
                this.$scope.filtered.filteredQnxCount = 0;
                //this.tableState.pagination.numberOfPages = 0;
                this.tableState.pagination.totalItemCoun = 0;
                this.$scope.errorQnx = err;
            })
            .finally(() => {
                this.$scope.inProgress = false;
                this.$scope.isLoading = false;
            })
    }

    private mapQnxListFilter() :IQnxRepositoryPackageFilter{
        var item = {
            tempTypeObjid: this.$scope.qnxListFilter.tempTypeObjid,
            description: this.$scope.qnxListFilter.description != "" ? this.$scope.qnxListFilter.description : null,
            status: this.$scope.qnxListFilter.status,
            templateNumber: this.$scope.qnxListFilter.templateNumber ? this.$scope.qnxListFilter.templateNumber.toString() : undefined,
            templateVersion: this.$scope.qnxListFilter.templateVersion ? this.$scope.qnxListFilter.templateVersion.toString() : undefined,
            templateOnlyAppliesTo: this.$scope.qnxListFilter.templateOnlyAppliesTo,
            limit: this.tableState.pagination.number,
            offset: this.tableState.pagination.start
          }
        return item;
    }
}

class SystemPackagesTableController {
    public static $inject = ['$scope', '$q', '$timeout', 'PackageRepositoryService', '$location', 'RouteHelpers', 'ParameterStorageService'];

    private tableState: any;

    constructor(private $scope: ISystemPackagesTableScope,
		            private $q: ng.IQService,
		            private $timeout: ng.ITimeoutService,
		            private PackageRepositoryService: PackageRepositoryService,
                private $location: ng.ILocationService, private RouteHelpers: app.IRouteHelpers,
                private ParameterStorageService: IParameterStorageService
	  ) {

      $scope.visibleItems = [];
      $scope.filteredCount = 0;
      $scope.isLoading = true;

      $scope.pipe = (_tableState: any) => {
          this.tableState = _tableState;
          this.getPackList();
      };

      this.getPackList();
		}

    private getPackList() {
        if(typeof this.tableState != "undefined") {
          if(this.tableState.pagination) {
            this.$scope.offset = this.tableState.pagination.start;
            this.$scope.limit = this.tableState.pagination.number;
          }

          if(this.tableState.sort) {
            this.$scope.sortField = this.tableState.sort.predicate;

            if(this.tableState.sort.reverse) {
              this.$scope.sortField = "-" + this.$scope.sortField;
            }
          }
        }

        this.PackageRepositoryService.getSystemPackageFromFusAndAgent(this.$scope.systemId).then((result: ISystemPackage) => {
          this.$scope.visibleItems = [];
          let packageAgent;
          let packageFus;
          if(typeof result.agent == "undefined") {
              packageAgent = {};
          } else {
              packageAgent  = result.agent;
          }

          if(typeof result.fus == "undefined") {
              packageFus = {};
          } else {
              packageFus = result.fus;
          }

          _.each(packageAgent, (agentObject: IAgentPackage) => {
              let nodeVer = agentObject.number + "." + agentObject.revision;
              let descriptDisplay = agentObject.description;
              let typeDisplay = agentObject.type;
              if(packageFus[agentObject.key] && packageFus[agentObject.key][agentObject.type] && packageFus[agentObject.key][agentObject.type][agentObject.number]) {
                let fusObject = packageFus[agentObject.key][agentObject.type][agentObject.number];
                descriptDisplay = fusObject.description ? fusObject.description : agentObject.description;
                if(agentObject.revision == fusObject.revision) {
                  let serverVer = nodeVer;
                  this.$scope.visibleItems.push({agentData: agentObject, status: true, serverVersion: serverVer, nodeVersion: nodeVer, fusDescription: fusObject.description, fusRevision: fusObject.revision, displayDescription: descriptDisplay, displayType: typeDisplay});
                } else {
                  let serverVer = agentObject.number + "." + fusObject.revision;
                  this.$scope.visibleItems.push({agentData: agentObject, status: false, serverVersion: serverVer, nodeVersion: nodeVer, displayDescription: descriptDisplay, displayType: typeDisplay});
                }
              }else {
                this.$scope.visibleItems.push({agentData: agentObject, status: false, nodeVersion: nodeVer, displayDescription: descriptDisplay, displayType: typeDisplay});
              }
          });

          _.each(packageFus, (fusTypes, fusTypeKey:number) => {
            _.each(fusTypes, (fusObjects, fusObjectType) => {
              this.mapFusPackage(fusObjects, fusObjectType, fusTypeKey, packageAgent, this.$scope.visibleItems);
            });
          })

          this.$scope.filteredCount = this.$scope.visibleItems.length;

          if(typeof this.tableState != "undefined") {
            this.$scope.lastItemIndex = Math.min(this.$scope.offset+this.$scope.limit , this.$scope.filteredCount);
            this.tableState.pagination.totalItemCount = this.$scope.visibleItems.length;
            if(this.$scope.filteredCount <= this.$scope.limit) {
            }

          }
        }).catch(err => {
            console.error(err);
            this.$scope.visibleItems = [];
            this.$scope.filteredCount = 0;
            //this.tableState.pagination.numberOfPages = 0;
            //this.tableState.pagination.totalItemCount = 0;
        })
        .finally(() => {
            this.$scope.isLoading = false;
        });
    }

    private mapFusPackage(fusObjects, fusType, fusKey, agentData, visibleItems){
        _.each(fusObjects, (fusObject, fusNumber: number) => {
          let fusObjectExist = false;
          _.each(agentData, (agentObject) => {
            if(agentObject.key == fusKey && agentObject.type == fusType && agentObject.number == fusNumber) {
              fusObjectExist = true;
            }
          });

          if(!fusObjectExist) {
            let serverVer = fusNumber + "." + fusObject.revision;
            visibleItems.push({status: false, serverVersion: serverVer, displayDescription: fusObject.description, displayType: fusType});
          }
        });
    }

}


function RepositoryPackagesListDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('RepositoryPackagesListDirective'),
        controller: 'RepositoryPackagesListController',
        scope: {
            enableSelection: '=?',
            selectedId: '=?',
            selectedItem: '=?',
            selectedQnxItem: '=?',
            onSelectorClick: '&',
            onQnxSelectorClick: '&',
            showCheckboxes: '=?',
            checkedItems: '=?',
            defaultListFilter: '=?',
            refreshEvent: '@?',
            onApply: '&',
            onEdit: '&',
            onRevise: '&',
            onApprove: '&',
            onEditQnx: '&',
            onNewQnxPackage: '&',
            onReviseQnx: '&',
            onApproveQnx: '&',
            onApplyQnx: '&'
        }
    }
}


function RepositoryPackagesTableDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('RepositoryPackagesTableDirective'),
        controller: 'RepositoryPackagesTableController',
        scope: {
            enableSelection: '=?',
            selectedId: '=?',
            selectedItem: '=?',
            onSelectorClick: '&',
            showCheckboxes: '=?',
            checkedItems: '=?',
            listFilter: '=?',
            refreshEvent: '@?',
            showPageSizeSelector: '=?',
            visible: '=?visibleCount',
            filtered: '=?filteredCount',
            offset: '=?',
            isLoading: '=?',
            inProgress: '=?',
            error: '=?',
            qnxFilters: '=?'
        }
    }
}

function RepositoryPackagesTableCustomDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('RepositoryPackagesTableDirective'),
        scope: {
            enableSelection: '=?',
            selectedId: '=?',
            selectedItem: '=?',
            onSelectorClick: '&',
            showCheckboxes: '=?',
            checkedItems: '=?',
            refreshEvent: '@?',
            showPageSizeSelector: '=?',
            visibleItems: '=',
            pipe: '=?'
        },
        link: (scope: IRepositoryPackagesTableCustomDirectiveScope) => {
            scope.selectRow = (row: IRepositoryPackageDisplay) => {
                if (row) {
                    scope.selectedId = row.packageId;
                }
                scope.selectedItem = row;
                scope.onSelectorClick({ selectedItem: row });
            };
        }
    }
}

function RepositoryQnxPackagesTableDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: (el, attr) => {
            if(attr.template && attr.template.length) {
                return `/components/src/directives/package-management/packages-list/packages-table_qnx-${attr.template}.html`
            } else {
                return $branding.getTemplateUrl('RepositoryQnxPackagesTableDirective')
            }
        },
        controller: 'RepositoryQnxPackagesTableController',
        scope: {
            enableSelection: '=?',
            selectedId: '=?',
            selectedQnxItem: '=?',
            onQnxSelectorClick: '&',
            showCheckboxes: '=?',
            checkedItems: '=?',
            qnxListFilter: '=?',
            refreshQnxTableEvent: '@?',
            showPageSizeSelector: '=?',
            visible: '=?visibleCount',
            filtered: '=?filteredCount',
            offset: '=?',
            isLoading: '=?',
            inProgress: '=?',
            errorQnx: '=?',
            listFilteredItems: '=?',
            templateChanged: '=?'
        }
    }
}

function RepositoryQnxPackagesTableCustomDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: (el, attr) => {
            if(attr.template && attr.template.length) {
              return `/components/src/directives/package-management/packages-list/packages-table_qnx-${attr.template}.html`
            } else {
                return $branding.getTemplateUrl('RepositoryQnxPackagesTableDirective')
              }
        },
        scope: {
            enableSelection: '=?',
            selectedId: '=?',
            selectedItem: '=?',
            onSelectorClick: '&',
            showCheckboxes: '=?',
            checkedItems: '=?',
            refreshEvent: '@?',
            showPageSizeSelector: '=?',
            visibleTemplates: '=',
            pipe: '=?',
            templateChanged: '=?'
        }
    }
}

function RepositoryPackagesFiltersDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('RepositoryPackagesFiltersDirective'),
        controller: 'RepositoryPackagesFiltersController',
        scope: {
            listFilter: '=',
            filterChanged: '&'
        }
    }
}

function RepositoryQnxPackagesFiltersDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: (el, attr) => {
            if(attr.template && attr.template.length) {
              return `/components/src/directives/package-management/packages-list/packages-filters-mcs-${attr.template}.html`
            } else {
                return $branding.getTemplateUrl('RepositoryQnxPackagesFiltersDirective')
              }
        },
        controller: 'RepositoryQnxPackagesFiltersController',
        scope: {
            qnxListFilter: '=',
            qnxFilterForm: '=?',
            filterChanged: '&',
            templateTypeChange: '&'
        }
    }
}

function SystemPackagesTableDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('SystemPackagesTableDirective'),
        controller: 'SystemPackagesTableController',
        scope: {
          systemId: '=',
          enableQueryBinding: '=?',
          //visibleItems: '='
        }
    }
}


export default angular.module('directives.packageManagement.packagesList', [PackageRepositoryServiceModule.name])
    .controller('RepositoryPackagesListController', RepositoryPackagesListController)
    .controller('RepositoryPackagesTableController', RepositoryPackagesTableController)
    .controller('RepositoryQnxPackagesTableController', RepositoryQnxPackagesTableController)
    .controller('SystemPackagesTableController', SystemPackagesTableController)
    .controller('RepositoryPackagesFiltersController', RepositoryPackagesFiltersController)
    .controller('RepositoryQnxPackagesFiltersController', RepositoryQnxPackagesFiltersController)
    .directive('repositoryPackagesList', ['$branding', RepositoryPackagesListDirective])
    .directive('repositoryPackagesTable', ['$branding', RepositoryPackagesTableDirective])
    .directive('repositoryQnxPackagesTable', ['$branding', RepositoryQnxPackagesTableDirective])
    .directive('repositoryQnxPackagesTableCustom', ['$branding', RepositoryQnxPackagesTableCustomDirective])
    .directive('systemPackagesTable', ['$branding', SystemPackagesTableDirective])
    .directive('repositoryPackagesTableCustom', ['$branding', RepositoryPackagesTableCustomDirective])
    .directive('repositoryPackagesFilters', ['$branding', RepositoryPackagesFiltersDirective])
    .directive('repositoryQnxPackagesFilters', ['$branding', RepositoryQnxPackagesFiltersDirective]);
