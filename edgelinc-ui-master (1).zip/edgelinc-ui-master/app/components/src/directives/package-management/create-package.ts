///<reference path="../../../../../typings/browser.d.ts"/>

import PackageEditControllerModule, {
    PackageEditController,
    IPackageEditControllerScope
} from "./PackageEditController";
import {IRepositoryPackage} from "../../services/PackageRepositoryService";

interface ICreatePackageDirectiveScope extends IPackageEditControllerScope {
    onBackToList(): void;
    onEdit(args: {packageId: string, packageVersion: string, templateType: string;}): void;
}

function CreatePackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('CreatePackageDirective'),
        controller: 'PackageEditController',
        scope: {
            onBackToList: '&',
            onEdit: '&'
        },
        link: (scope: ICreatePackageDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageEditController) => {
            ctrl.onBackToList = () => scope.onBackToList();
            ctrl.initialize("CREATE");
            ctrl.onEdit = (repositoryPackage: IRepositoryPackage) => scope.onEdit({packageId: repositoryPackage.packageId, packageVersion: repositoryPackage.version, templateType: repositoryPackage.templateType});
        }
    }
}

export default angular.module('directives.packageManagement.createPackage', [PackageEditControllerModule.name])
    .directive("createPackage", ['$branding', CreatePackageDirective]);
