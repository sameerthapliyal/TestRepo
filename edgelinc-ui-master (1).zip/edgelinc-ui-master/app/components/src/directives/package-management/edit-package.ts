///<reference path="../../../../../typings/browser.d.ts"/>

import PackageEditControllerModule, {
    PackageEditController,
    IPackageEditControllerScope
} from "./PackageEditController";
import {IRepositoryPackage} from "../../services/PackageRepositoryService";



interface IEditPackageDirectiveScope extends IPackageEditControllerScope {
    approve: boolean;
    onBackToList(): void;
    onRevise(args: {packageId: string, packageVersion: string, templateType: string}): void;
}

function EditPackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('EditPackageDirective'),
        controller: 'PackageEditController',
        scope: {
            packageId: '=',
            packageVersion: '=',
            templateType: '=',
            approve: '=',
            onBackToList: '&',
            onRevise: '&'
        },
        link: (scope: IEditPackageDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageEditController) => {
            ctrl.onBackToList = () => scope.onBackToList();
            ctrl.onRevise = (repositoryPackage: IRepositoryPackage) => scope.onRevise({packageId: repositoryPackage.packageId, packageVersion: repositoryPackage.version, templateType: repositoryPackage.templateType});
            ctrl.emptyPackageFactory = (originalPackage: IRepositoryPackage) => {
                return {
                     packageId: originalPackage.packageId,
                     version: originalPackage.version,
                     templateType: {
                         name: originalPackage.templateType,
                         device_enum: originalPackage.deviceEnum,
                         package_type: originalPackage.packageType,
                         config: originalPackage.config
                     },
                     templateDefinition: originalPackage.templateDefinition,
                     description: originalPackage.description,
                     status: scope.approve ? "Approved" : originalPackage.status,
                     restrict_to: originalPackage.restrict_to,
                     packageFile: null,
                     signatureFile: null,
                     softwareVersionDate: originalPackage.softwareVersionDate,
                     fileSize: originalPackage.fileSize,
                     address: originalPackage.address,
                     software_name: originalPackage.software_name
                }
            }
            ctrl.initialize("UPDATE");
        }
    }
}

export default angular.module('directives.packageManagement.editPackage', [PackageEditControllerModule.name])
    .directive("editPackage", ['$branding', EditPackageDirective]);
