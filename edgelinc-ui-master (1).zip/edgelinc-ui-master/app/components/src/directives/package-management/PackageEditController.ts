///<reference path="../../../../../typings/browser.d.ts"/>

import PackageRepositoryServiceModule, {
    IRepositoryPackageToUpdate, PackageRepositoryService,
    IRepositoryPackage, Restrictions, RepositoryTemplateTypes
} from "../../services/PackageRepositoryService";
import UserManagementServiceModule, {UserManagementService} from "../../services/UserManagementService";
import AuthServiceModule, {AuthService} from "../../services/AuthService";
import {NotifyData} from "../../utilities/NotifyHelper";
import McsGeneralServiceModule, {McsGeneralService} from "../../services/mcs/McsGeneralService";
import AclServiceModule, {ACLService} from "../../services/ACLService";

export type PackageEditControllerMode = "CREATE" | "UPDATE" | "REVISE" | "VIEW" | "BULK" | "REVISE | VIEW";

interface IAdditionalLog {
    value:string;
    caption:string;
}

export interface IPackageEditControllerScope extends ng.IScope {
    packageId?: string;
    packageVersion?: string;
    templateType?: string;
    originalPackage: IRepositoryPackage;
    otherPendingPackage?: IRepositoryPackage;
    packageToUpdate: IRepositoryPackageToUpdate;
    savedPackage: IRepositoryPackage;
    lastChoosenPackageFile: File;
    lastChoosenSignatureFile: File;
    templateTypes: RepositoryTemplateTypes;
    restrictions: Restrictions;
    statuses: { [key: string]: string };
    isStatusesDisabled(status:string);
    softwareVersionDate: string;
    fileSize: number;
    initialized: boolean;
    templateNumber: number;
    inProgress: boolean;
    inProgressMessage:string;
    inProgressTemplateFileProgres:number;
    inProgressTemplateFileDetailedProgres: NotifyData;
    error?: Error;
    additional_logs?: IAdditionalLog[];
    getRestrictions(query: string): ng.IPromise<Restrictions>;
    createPackage(form: ng.IFormController): void;
    updatePackage(form: ng.IFormController): void;
    revisePackage(form: ng.IFormController): void;
    reset(form: ng.IFormController): void;
    backToList(): void;
    edit(repositoryPackage: IRepositoryPackage): void;
    revise(repositoryPackage: IRepositoryPackage): void;
    view(repositoryPackage: IRepositoryPackage): void;
    templateInterfaces: { [key: string]: string };
    qnxRestrictions: {
        name: string;
    }[];
    uplincTemplateTypes: any;
    packageIsEdited: boolean;
    bulkTemplate: File;
    bulkUploadProcess(form: ng.IFormController): void;
    bulkResponse: {
        templateArray?: any,
        blobId?: string;
    };
    confirmTemplates(bulkArrayTemplates: any): void;
    canConfirmTemplates: boolean;
    confirmationInProgress: boolean;
    uploadBulkError?: Error;
    confirmBulkError?: Error;
    confirmBulkSuccess?: boolean;
    confirmBulkWarning?: boolean;
    hasPermissionManageTemplate:boolean;
    resetUploadedPackage(blobId: string): void;
    showConfirmButton: boolean;
    askForConfirmBtusRaport: any;
    showProcessPackageBtn: boolean;
}

export class PackageEditController {
    public static $inject = ["$scope", "$q", "PackageRepositoryService", "UserManagementService", "AuthorizationService", "McsGeneralService"];

    private mode: PackageEditControllerMode;

    public emptyPackageFactory: (originalPackage: IRepositoryPackage) => IRepositoryPackageToUpdate;
    public onBackToList: () => void;
    public onEdit: (repositoryPackage: IRepositoryPackage) => void;
    public onRevise: (repositoryPackage: IRepositoryPackage) => void;
    public onView: (repositoryPackage: IRepositoryPackage) => void;


    constructor(private $scope: IPackageEditControllerScope,
        private $q: ng.IQService,
        private PackageRepositoryService: PackageRepositoryService,
        private UserManagementService: UserManagementService,
        private AuthorizationService: AuthService,
        private McsGeneralService: McsGeneralService) {

        this.onBackToList = _.noop;
        this.onEdit = _.noop;
        this.onRevise = _.noop;
        this.onView = _.noop;
        this.emptyPackageFactory = () => {
            return <any>{}
        };
        this.$scope.hasPermissionManageTemplate = this.AuthorizationService.hasLoginUserPermission("Manage Template");

        this.$scope.additional_logs = [
            {caption:'dpkg.log', value:"dpkg.log"},
            {caption:'boot.log', value:"boot.log"},
        ];

        this.$scope.packageIsEdited = true;
        this.$scope.bulkResponse = {};
        this.$scope.confirmBulkSuccess = false;
        this.$scope.confirmBulkWarning = false;
        this.$scope.confirmationInProgress = false;
        this.$scope.showConfirmButton = false;

        this.$scope.createPackage = (form: ng.IFormController) => this.createPackage(form);
        this.$scope.updatePackage = (form: ng.IFormController) => this.updatePackage(form);
        this.$scope.revisePackage = (form: ng.IFormController) => this.revisePackage(form);
        this.$scope.bulkUploadProcess = (form: ng.IFormController) => this.bulkUploadProcess(form);
        this.$scope.reset = (form: ng.IFormController) => this.reset(form);
        this.$scope.backToList = () => this.backToList();
        this.$scope.resetUploadedPackage = (blobId: string) => this.resetUploadedPackages(blobId);
        this.$scope.confirmTemplates = (bulkArrayTemplates: any) => this.confirmTemplates(bulkArrayTemplates);
        this.$scope.edit = (repositoryPackage: IRepositoryPackage) => this.edit(repositoryPackage);
        this.$scope.revise = (repositoryPackage: IRepositoryPackage) => this.revise(repositoryPackage);
        this.$scope.statuses = {
            "Pending": "Pending",
            "Approved": "Approved",
            "Obsolete": "Obsolete"
        };

        this.$scope.templateInterfaces = {
            "qnx": "QNX Gateway",
            "uplinc": "UpLINC Gateway"
        };

        this.PackageRepositoryService.getRestrictions().then(restrictions => this.$scope.restrictions = restrictions)
        this.$scope.getRestrictions = (query: string) => {
          var regexp = new RegExp(query, "i");
          return $q.when(_.filter(this.$scope.restrictions, r => regexp.test(r.name)));
        }
        this.PackageRepositoryService.getTemplateTypes().then((tt) => {
            this.$scope.templateTypes = tt;
            this.$scope.uplincTemplateTypes = tt;
        });
        if (this.$scope.packageId != null && this.$scope.packageVersion != null && this.$scope.templateType) {
            this.PackageRepositoryService.getPackage(this.$scope.packageId, this.$scope.packageVersion, this.$scope.templateType)
                .then((repositoryPackage:IRepositoryPackage) => {
                    this.$scope.originalPackage = repositoryPackage;
                    this.resetData();
                    this.$scope.initialized = true;
                })
        } else {
            this.resetData();
            this.$scope.initialized = true;
        }
        $scope.$on("$routeChangeStart",(event: ng.IAngularEvent, next:any, current:any)=>{
            var message = null;
            if(this.$scope.inProgress) {
                if (this.mode == "CREATE") {
                    message = "Template creation is in progress. You might cause this process to fail when you left the page";
                } else if (this.mode == "REVISE | VIEW") {
                    message = "Template revise is in progress. You might cause this process to fail when you left the page";
                } else if (this.mode == "UPDATE") {
                    message = "Template update is in progress. You might cause this process to fail when you left the page";
                } else if (this.mode == "BULK") {
                    message = "Template upload is in progress. You will cause the process to fail when you left the page";
                }
            } else if(this.$scope.confirmationInProgress) {
                if (this.mode == "BULK") {
                    message = "Template confirmation is in progress. You will cause the process to fail when you left the page";
                }
            }
            if(message != null) {
                if(confirm(message) == false){
                    event.preventDefault();
                }
            }
        });
        $scope.$on("$destroy", ()=>{
            window.onbeforeunload = null;
        });
        window.onbeforeunload = (event: BeforeUnloadEvent)=>{
            if(this.$scope.inProgress) {
                if (this.mode == "CREATE") {
                    return "Template creation is in progress. You will cause the process to fail when you left the page";
                } else if (this.mode == "REVISE | VIEW") {
                    return "Template revise is in progress. You will cause the process to fail when you left the page";
                } else if (this.mode == "UPDATE") {
                    return "Template update is in progress. You will cause the process to fail when you left the page";
                } else if (this.mode == "BULK") {
                    return "Template upload is in progress. You will cause the process to fail when you left the page";
                }
            }else if(this.$scope.confirmationInProgress) {
                if (this.mode == "BULK") {
                    return "Template confirmation is in progress. You will cause the process to fail when you left the page";
                }
            }else{
                window.onbeforeunload = null;
            }
        };

        $scope.$watch("bulkTemplate.name", (newBulk) => {
            this.$scope.showProcessPackageBtn = true;
        });

        this.$scope.isStatusesDisabled = (status:string)=> this.isStatusesDisabled(status);
    }

    public initialize(mode: PackageEditControllerMode) {
        this.mode = mode;
        if(this.mode == "REVISE | VIEW"){
            // check if template can be revised
            this.PackageRepositoryService.getPackage(this.$scope.packageId, "", this.$scope.templateType).then((repositoryPackages:IRepositoryPackage[]) => {
                var otherPendingPackages = _.filter(repositoryPackages, p=> p.status == "Pending" && p.version != this.$scope.packageVersion);
                if(otherPendingPackages.length == 1){
                    this.$scope.otherPendingPackage = otherPendingPackages[0];
                }else if(otherPendingPackages.length  > 1){
                    console.error("One template has more then 1 Packages with status 'Pending'", otherPendingPackages );
                }

            });
        }
    }


    private createPackage(form: ng.IFormController) {
        if (this.$scope.inProgress) {
            return;
        }
        this.$scope.inProgress = true;
        this.$scope.error = null;
        this.$scope.packageToUpdate.isDraft = false;
        // if config.template_generation equals 'syslog' then set package as draft
        if(this.$scope.packageToUpdate.templateType.config) {
            if(this.$scope.packageToUpdate.templateType.config.template_generation == "syslog") {
                // set package as draft
                this.$scope.packageToUpdate.isDraft = true;
            }
        }

        this.PackageRepositoryService.createPackage(this.$scope.packageToUpdate)
            .then(repositoryPackage => {
                this.$scope.inProgress = false;
                this.$scope.savedPackage = repositoryPackage;
            },null,(notifyData:NotifyData)=> this.PackageProgresNotifyHandle(notifyData))
            .catch(err => {
                console.error(err);
                this.$scope.inProgress = false;
                this.$scope.error = err;
            })
    }

    private bulkUploadProcess(form: ng.IFormController) {
        if (this.$scope.inProgress) {
            return;
        }
        this.$scope.inProgress = true;
        this.$scope.canConfirmTemplates = false;
        this.$scope.confirmBulkSuccess = false;
        this.$scope.confirmBulkWarning = false;
        this.$scope.showProcessPackageBtn = false;
        this.$scope.uploadBulkError = null;
        this.$scope.confirmBulkError = null;
        this.$scope.bulkResponse.templateArray = [];
        this.$scope.showConfirmButton = true;

        this.PackageRepositoryService.bulkUploadProcess(this.$scope.bulkTemplate)
            .then(response => {
                this.$scope.inProgress = false;
                this.$scope.canConfirmTemplates = true;
                this.$scope.bulkResponse.templateArray = response.template_array;
                this.$scope.bulkResponse.blobId = response.blob_id;
            },null,(notifyData:NotifyData)=> this.PackageProgresNotifyHandle(notifyData))
            .catch(err => {
                console.error(err);
                this.$scope.inProgress = false;
                this.$scope.canConfirmTemplates = false;
                this.$scope.uploadBulkError = err;
            })
    }

    private confirmTemplates(blobId: string) {
        let sync_confirmation = (<any>window).CONFIG.BTUS_USE_SYNC_CONFIRMATION;
        this.$scope.confirmationInProgress = true;
        this.$scope.canConfirmTemplates = false;
        this.$scope.confirmBulkError = null;
        this.$scope.confirmBulkSuccess = false;
        this.$scope.confirmBulkWarning = false;

        /* if(sync_confirmation) { // synchronic BTUS confirmation (firs/old version)
          this.PackageRepositoryService.confirmBulkTemplates(blobId, sync_confirmation)
          .then(response => {
                this.btusSuccessHandling(response.results);
            })
            .catch(err => {
                console.error(err);
                this.btusErrorHandling(err);
            });
        } else { */
        // asynchronic BTUS confirmation (new version)
        this.PackageRepositoryService.confirmBulkTemplates(blobId, sync_confirmation)
          .then(response => {
              this.$scope.askForConfirmBtusRaport = setInterval(() => {
                  this.PackageRepositoryService.askForBulkReports(blobId)
                    .then(response => {
                        if(!response.isRunning) {
                            clearInterval(this.$scope.askForConfirmBtusRaport);
                            this.PackageRepositoryService.deleteBulkPackages(blobId);
                            if(response.result == "SUCCESS") {
                              this.btusSuccessHandling(response.results);
                            } else {
                              this.btusErrorHandling(response.result);
                            }

                        }
                    })
              }, 5000);
          })
          .catch(err => {
              console.error(err);
              this.btusErrorHandling(err);
          });
    }

    private allBulkTemplatesCreated(templateArray: any) {
      var filteredNotAddedTemplates = templateArray.filter(function(template){
          return template.creation_status == 400;
      });
      if(filteredNotAddedTemplates.length > 0) {
          return false;
      } else {
          return true;
      }
    }

    private resetUploadedPackages(blobId: string) {
        if(blobId) {
          this.PackageRepositoryService.deleteBulkPackages(blobId)
              .then(response => {
                  this.backToList();
              })
              .catch(err => {
                  this.backToList();
              })
        } else {
          this.backToList();
        }
    }

    private mapBulkResponse(arr: any) {
      let responseArr = []

      _.each(arr, (to) => {
          let tempobj = to["details"];
          tempobj["creation_status"] = to["creation_status"];
          responseArr.push(tempobj);
      })
      return responseArr;
    }

    private btusErrorHandling(error: any) {
        this.$scope.canConfirmTemplates = true;
        this.$scope.confirmBulkSuccess = false;
        this.$scope.confirmBulkError = error;
        this.$scope.confirmationInProgress = false;
        this.$scope.showConfirmButton = true;
        this.$scope.showProcessPackageBtn = true;
    }

    private btusSuccessHandling(templatesArray: any) {
      if(!this.allBulkTemplatesCreated(templatesArray)) {
          this.$scope.confirmBulkWarning = true;
      } else {
          this.$scope.confirmBulkSuccess = true;
      }
      this.$scope.bulkResponse.templateArray = this.mapBulkResponse(templatesArray);
      this.$scope.confirmationInProgress = false;
      this.$scope.showConfirmButton = false;
      this.$scope.showProcessPackageBtn = true;
    }

    private updatePackage(form: ng.IFormController) {
        if (this.$scope.inProgress) {
            return;
        }
        this.$scope.inProgress = true;
        this.$scope.error = null;
        this.$scope.packageToUpdate.isDraft = false;

        this.PackageRepositoryService.updatePackage(this.$scope.packageToUpdate, this.$scope.originalPackage)
            .then(repositoryPackage => {
                this.$scope.inProgress = false;
                this.$scope.savedPackage = repositoryPackage;
            },null,(notifyData:NotifyData)=> this.PackageProgresNotifyHandle(notifyData))
            .catch(err => {
                console.error(err);
                this.$scope.inProgress = false;
                this.$scope.error = err;
            });
    }

    private revisePackage(form: ng.IFormController) {
        if (this.$scope.inProgress) {
            return;
        }
        this.$scope.inProgress = true;
        this.$scope.error = null;
        this.$scope.packageToUpdate.isDraft = false;

        // if config.template_generation equals 'syslog' then set package as draft
        if(this.$scope.packageToUpdate.templateType.config) {
            if(this.$scope.packageToUpdate.templateType.config.template_generation == "syslog") {
                this.$scope.packageToUpdate.isDraft = true;
            }
        }

        this.PackageRepositoryService.revisePackage(this.$scope.packageToUpdate)
            .then(repositoryPackage => {
                this.$scope.inProgress = false;
                this.$scope.savedPackage = repositoryPackage;
            },null,(notifyData:NotifyData)=> this.PackageProgresNotifyHandle(notifyData))
            .catch(err => {
                console.error(err);
                this.$scope.inProgress = false;
                this.$scope.error = err;
            });
    }

    private PackageProgresNotifyHandle(notifyData:NotifyData){
        if(notifyData && notifyData.message) {
            this.$scope.inProgressMessage = notifyData.message;
        }
        if(this.$scope.packageToUpdate.packageFile) {
            if(notifyData && notifyData.fileName && notifyData.progress != null && this.$scope.packageToUpdate && this.$scope.packageToUpdate.packageFile.name == notifyData.fileName){
                this.$scope.inProgressTemplateFileProgres =  notifyData.progress;
                this.$scope.inProgressTemplateFileDetailedProgres = notifyData;
            }
        }
        if(this.$scope.bulkTemplate) {
            if(notifyData && notifyData.fileName && notifyData.progress != null && this.$scope.bulkTemplate.name == notifyData.fileName){
                this.$scope.inProgressTemplateFileProgres =  notifyData.progress;
                this.$scope.inProgressTemplateFileDetailedProgres = notifyData;
            }
        }
    }

    private reset(form: ng.IFormController) {
        if (this.$scope.inProgress) {
            return;
        }
        this.resetData();
    }

    private backToList() {
        if (this.$scope.inProgress) {
            return;
        }
        this.onBackToList();
    }

    private edit(repositoryPackage: IRepositoryPackage) {
        if (this.$scope.inProgress || !repositoryPackage) {
            return;
        }
        this.onEdit(repositoryPackage);
    }

    private revise(repositoryPackage: IRepositoryPackage) {
        if (this.$scope.inProgress || !repositoryPackage) {
            return;
        }
        this.onRevise(repositoryPackage);
    }

    private view(repositoryPackage: IRepositoryPackage) {
        if (this.$scope.inProgress || !repositoryPackage) {
            return;
        }
        this.onView(repositoryPackage);
    }

    public resetData() {
        if (this.$scope.savedPackage) {
            this.$scope.originalPackage = this.$scope.savedPackage;
        }
        this.$scope.packageToUpdate = this.emptyPackageFactory(this.$scope.originalPackage);
        this.$scope.savedPackage = null;
        this.$scope.error = null;
        this.$scope.inProgress = false;
    }

    private isStatusesDisabled(statusName:string){
        switch(this.mode){
            case "CREATE":
                switch(statusName){
                    case 'Approved':
                        return !this.AuthorizationService.hasLoginUserPermission("Approve Template");
                    case 'Pending':
                        return !this.AuthorizationService.hasLoginUserPermission("Manage Template");;
                    case 'Obsolete':
                        return true;
                    default:
                        return true;
                }
            case "UPDATE":
                switch(statusName){
                    case 'Approved':
                        return this.$scope.packageToUpdate.status == "Obsolete" || !this.AuthorizationService.hasLoginUserPermission("Approve Template");;
                    case 'Pending':
                        return this.$scope.packageToUpdate.status == "Obsolete" || this.$scope.packageToUpdate.status == "Approved" || !this.AuthorizationService.hasLoginUserPermission("Manage Template");
                    case 'Obsolete':
                        return !this.AuthorizationService.hasLoginUserPermission("Manage Template");
                    default:
                        return true;
                }
            case "REVISE | VIEW":
                switch(statusName){
                    case 'Approved':
                        return !this.AuthorizationService.hasLoginUserPermission("Approve Template");;
                    case 'Pending':
                        return !this.AuthorizationService.hasLoginUserPermission("Manage Template");
                    case 'Obsolete':
                        return !this.AuthorizationService.hasLoginUserPermission("Manage Template");
                    default:
                        return true;
                }
            default:
                return true;
        }
    }

}

var angularModule = angular.module('directives.packageManagement.packageEditController', [PackageRepositoryServiceModule.name, UserManagementServiceModule.name,
    AuthServiceModule.name, McsGeneralServiceModule.name, AclServiceModule.name])
    .controller("PackageEditController", PackageEditController);

angularModule.directive('fileValidate', function($branding: app.branding.IBrandingService) {
    return {
        require: 'ngModel',
        link: function(scope: IPackageEditControllerScope, el, attrs: any, ctrl: any) {
            var validate = function(ctrl, type) {
                var branding = (<any>$branding).getBrandingConstants();
                var test_ext: boolean = true, test_name: boolean = true, test_size: boolean = true, size: number, re_name: RegExp, re_ext: RegExp = /\.([a-z.]+)/, val: any, file: string, svd: string, extensions: any, ext: string;
                var test_ext_exist: boolean = true;
                var max_file_size: number;
                var options = type.split(' ');
                if (options[0] == 'template' || options[0] == 'templateWithoutNameValidation') {
                    extensions = branding.extensionsTemplate;
                    scope.packageToUpdate.packageFile = ctrl.$modelValue ? ctrl.$modelValue : scope.lastChoosenPackageFile;
                    val = scope.packageToUpdate.packageFile ? scope.packageToUpdate.packageFile.name : null;
                    max_file_size = 1.5 * 1024 * 1024 * 1024; // 1.5GB
                    size = ctrl.$modelValue ? ctrl.$modelValue.size : scope.lastChoosenPackageFile.size;
                    let fileExtChecking = val.split('.');
                    if(fileExtChecking.length <= 1) {
                        test_ext_exist = false;
                    }
                    if(test_ext_exist) {
                      ext = scope.packageToUpdate.packageFile.name ? scope.packageToUpdate.packageFile.name.match(re_ext)[1] : null;

                    }

                    if(ctrl.$modelValue) {
                        scope.lastChoosenPackageFile = ctrl.$modelValue;
                    }
                    file = 'Template';
                    if(options[0] == 'template') {
                        re_name = new RegExp(branding.templateRegExp);
                        test_name = re_name.test(val)
                    }
                }
                else if (options[0] == 'signature') {
                    file = 'Signature';
                    extensions = branding.extensionsSignature;
                    scope.packageToUpdate.signatureFile = ctrl.$modelValue ? ctrl.$modelValue : scope.lastChoosenSignatureFile;
                    val = scope.packageToUpdate.signatureFile ? scope.packageToUpdate.signatureFile.name : null;
                    max_file_size = 1 * 1024 * 1024;    // 1MB
                    size = ctrl.$modelValue ? ctrl.$modelValue.size : scope.lastChoosenSignatureFile.size;
                    let fileExtChecking = val.split('.');
                    if(fileExtChecking.length > 1) {
                      ext = scope.packageToUpdate.signatureFile.name ? scope.packageToUpdate.signatureFile.name.match(re_ext)[1] : null;
                    }

                    if(ctrl.$modelValue) {
                        scope.lastChoosenSignatureFile = ctrl.$modelValue;
                    }
                } else if(options[0] == 'bulkTemplate') {
                  scope.bulkTemplate = ctrl.$modelValue ? ctrl.$modelValue : scope.lastChoosenPackageFile;
                  val = scope.bulkTemplate ? scope.bulkTemplate.name : null;

                  let fileExtChecking = val.split('.');
                  if(fileExtChecking.length < 3) {
                      test_ext_exist = false;
                  }

                  let bulkFileExtension = `${fileExtChecking[fileExtChecking.length-2]}.${fileExtChecking[fileExtChecking.length-1]}`;  // variable got bulk file extension (should be tar.gz)
                  if(bulkFileExtension != 'tar.gz') {
                      ctrl.validationMsg = 'Wrong file extension! Only tar.gz files are acceptable.'
                      test_ext = false;
                  }

                  if(ctrl.$modelValue) {
                      scope.lastChoosenPackageFile = ctrl.$modelValue;
                  }
                }
                if (extensions != null) {
                    test_ext = extensions.some((el, i, arr) => {
                        return el == ext;
                    })
                }
                if (options[1] && options[1] == 'edit' && val == null) {
                    ctrl.validationMsg = '';
                    return true;
                }
                if (!val) {
                    if (options[0] == 'signature') {
                        ctrl.validationMsg = '';
                        return true;
                    }
                    else {
                        ctrl.validationMsg = file + ' file is required.';
                    }
                }
                else if(val && !test_ext_exist) {
                    if(options[0] != 'bulkTemplate') {
                        ctrl.validationMsg = 'File without extension are unacceptable!';
                    }

                }
                else if (val && test_ext_exist && !test_ext) {
                    if(options[0] != 'bulkTemplate') {
                        ctrl.validationMsg = 'Wrong file extension! Only ' + extensions.join(', ') + ' files are acceptable.';
                    }
                }
                else if (val && test_ext_exist && test_ext && !test_name) {
                    scope.packageToUpdate.softwareVersionDate = null;
                    ctrl.validationMsg = branding.templateRegExp_Message ||
                        'Wrong file name! Correct file name have to match regular expression: "' + branding.templateRegExp + '". Visit page https://regex101.com may help';
                }
                else if (val && size > max_file_size) {
                    test_size = false;
                    let $filter = angular.element(document.body).injector().get("$filter");
                    let fileSize = $filter('sizeInBytes')(max_file_size);
                    ctrl.validationMsg = `Wrong, file is too large. Max size is ${fileSize}`;
                } else if(val && size == 0) {
                    test_size = false;
                    ctrl.validationMsg = `Wrong, file is too small. File size must be greater than 0MB`;
                }
                else {
                    ctrl.validationMsg = "";
                }
                if (file == 'Template' && test_name && test_ext && test_size) {
                    if(re_name) {
                        scope.packageToUpdate.softwareVersionDate = re_name.exec(val)[1];
                    }
                    scope.packageToUpdate.fileSize = size;
                }
                return test_ext && test_name && test_size;
            }
            el.bind('change', function() {
                ctrl.$setValidity('fileValidate', validate(ctrl, attrs.fileValidate));
                ctrl.$setDirty();
                scope.$apply(function() {
                    ctrl.$render();
                });
            })
        }
    };
});

angularModule.directive('ipValidate', function($branding: app.branding.IBrandingService) {
    return {
        require: 'ngModel',
        link: function(scope: IPackageEditControllerScope, el, attrs: any, ctrl: any) {
            var validate = function(val) {
                var ip_v4_regex: RegExp = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

                if(val.$modelValue) {
                    if (ip_v4_regex.test(val.$modelValue)) {
                        ctrl.validationMsg = "";
                        return true;
                    } else {
                      ctrl.validationMsg = "Invalid IP address";
                      return false;
                    }
                } else {
                  ctrl.validationMsg = "";
                  return true;
                }
            }

            el.bind('keyup', function() {
                  ctrl.$setValidity('ipValidate', validate(ctrl));
                  ctrl.$setDirty();
                  scope.$apply(function() {
                      ctrl.$render();
                  });
            })
        }
    };
});

export default angularModule;
