///<reference path="../../../../../typings/browser.d.ts"/>


function PackageDetailsDirective($branding: app.branding.IBrandingService) {
    return {
        restrict: "E",
        templateUrl: $branding.getTemplateUrl("PackageDetailsDirective"),
        scope: {
            packageToShow: '='
        }
    }
}

export default angular.module("directives.packageManagement.packageDetails", [])
    .directive("packageDetails", ["$branding", PackageDetailsDirective]);