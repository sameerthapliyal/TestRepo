import McsSystemParametersServiceModule, {McsSystemParametersService} from "../../../services/mcs/McsSystemParametersService";

export interface IRoad {
    roadInitial: number;
    roadNumberFrom: number;
    roadNumberTo: number;

}

export interface IMcsSshRoadInitialController {
    numberRanges: IRoad[];
    numberRangesString: string;
    roadInitials: any[];
    newRoad: IRoad;
    isMaxRangeLoaded: boolean;
    hasMaxRangeError: boolean;
    maxRange: number;
    addRoad(newRoad: IRoad): void;
    removeRoad(roadIndex: number): void;
    numberRagesToString(numberRanges: IRoad[]): void;
    getRoadInitialsValue(roadObjId: number): string;

}

export class McsSshRoadInitialController implements IMcsSshRoadInitialController {

    public static $inject = ['$scope', 'McsSystemParametersService'];
     
    /**
     * List of number ranges to add
     * @type Array
     * @memberof McsSshRoadInitialController
     */
    public numberRanges = [];

    /**
     * 
     * string representation of numberRanges list, includes in request
     * @type {string}
     * @memberof McsSshRoadInitialController
     */
    public numberRangesString:string = '';

    /**
     * Road initials lookup data filtered by owner name
     * @memberof McsSshRoadInitialController
     */
    public roadInitials = [];
    /**
     * List of every Road Initials lookup data
     * @memberof McsSshRoadInitialController
     */
    public roadInitialsRaw = [];
    /**
     * List of every Road Initials lookup data
     * @memberOf McsSshRoadInitialController
     */
    public selectedCustomer;

    /**
     * 
     * newRoad object formed before adding it to numberRanges
     * @memberof McsSshRoadInitialController
     */
    public newRoad = {
        roadInitial: null,
        roadNumberFrom: null,
        roadNumberTo: null
    };

    /**
     * Defining If maxRange is loaded
     * @memberof McsSshRoadInitialController
     */
    public isMaxRangeLoaded = false;

    /**
     * Defining if maxRange has parse error problem
     * @memberof McsSshRoadInitialController
     */
    public hasMaxRangeError = false;

    /**
     * APPLY_TEMP_MAX_RN_RANGE MCS system parameters defining max size of numberRanges length
     * @memberof McsSshRoadInitialController
     */
    public maxRange;

    /**
     * 
     * default maxRange existed if controller isn't in isParameterBased state
     * @memberof McsSshRoadInitialController
     */
    private defaultMaxRange = 1000;

    /**
     * 
     * If the controller should be based on APPLY_TEMP_MAX_RN_RANGE systemParameter or hard-coded default
     * @private
     * 
     * @memberOf McsSshRoadInitialController
     */
    public isParameterBased = false;

    constructor (
        private $scope,
        private _systemParametersService
    ) {
        this.roadInitialsRaw = $scope.roadInitials;
        this.numberRangesString = $scope.numberRanges;
        this.selectedCustomer = $scope.selectedCustomer || {};
        this.isParameterBased = this.$scope.isParameterBased || this.isParameterBased;
        
        this.assignNumberRanges(this.numberRangesString);

        this.isParameterBased 
            ? this._systemParametersService
                .getSystemParameters(['APPLY_TEMP_MAX_RN_RANGE'])
                .then(this.assignSystemParameters.bind(this))
            : this.assignHardCodedRange();

        $scope.$watchCollection(
            () => this.numberRanges,
            this.numberRagesToString.bind(this)
        );

        $scope.$watch(
            'selectedCustomer',
            this.filterRoadInitials.bind(this)
        );


    }


    /**
     * Helper method to transforming array into hashed object
     *
     * @private
     * @param {string[]} hashCollection
     * @returns {*}
     *
     * @memberOf McsSshRoadInitialController
     */
    private hashArray(hashCollection: string[]): (Array)=> any {
        return arrayToHash => hashCollection
            .reduce((accumulator, hash, index) => {
                accumulator[hash] = arrayToHash[index];
                return accumulator;
            }, {});
    }

    /**
     * Helper method to extracting fields which client would demand (in the order declared in array)
     *
     * @private
     * @param {string[]} keysArray
     * @returns {any}
     *
     * @memberOf McsSshRoadInitialController
     */
    private getFields(keysArray: string[]): any {
        return (obj) => keysArray.map(key => obj[key]);
    }

    private resetNewRoad () {
        /** set the roadInitialFrom field as untouched for validation */
        this.$scope.formContext.roadNumberFrom.$setUntouched()
        
        // reset newRoad object
        this.newRoad = {
            roadInitial: null,
            roadNumberFrom: null,
            roadNumberTo: null
        };
    }

    private hasInCollection (collection: any[], object: any): boolean {
        return _.find(collection, item =>
            angular.toJson(object) === angular.toJson(item)
        );
    }


    private assignNumberRanges (numberRangesString) {
        if (numberRangesString) {
            try {
                this.numberRanges = this.parseNumberRanges(numberRangesString);
            } catch (err) {
                console.warn(err);
            }
        }
    }

    private assignSystemParameters (result) {
        try {
            this.maxRange = parseInt(
                result.data ?
                    result.data[0].parameterValue : 
                    result[0].parameterValue
                );
            this.isMaxRangeLoaded = true;
        } catch (e) {
            this.isMaxRangeLoaded = false;
            this.hasMaxRangeError = true;
        }
    }

    private assignHardCodedRange () {
        this.maxRange = this.defaultMaxRange;
        this.isMaxRangeLoaded = true;
    }

    private hasRangeConflict (collection: IRoad[], object: IRoad) {
        object = _.clone(object);
        if (!object.roadNumberTo) {
            object.roadNumberTo = object.roadNumberFrom;
        }
        let fitered = collection
            .filter(road => road.roadInitial === object.roadInitial)
            .reduce((accumulator:boolean, current: IRoad) => {
                if (
                    !(
                        object.roadNumberTo < current.roadNumberFrom 
                        ||
                        object.roadNumberFrom > current.roadNumberTo
                    )
                ) {
                    return true;
                }
            },
            false);
            
            return fitered;
    }

    public getRange (newRoad: IRoad) {
        return newRoad.roadNumberTo - newRoad.roadNumberFrom;
    }

    private parseNumberRanges (rangesString: string): any {
        const addHashToArray = this.hashArray(['roadInitial', 'roadNumberFrom', 'roadNumberTo'])
        return rangesString.split(';')
            .map(numberRangeStr => addHashToArray(numberRangeStr.split(',')))
    }

    private filterRoadInitials (customer) {
        if (customer) {
            this.roadInitials = this.roadInitialsRaw
                .filter(road => road.parentLookupName == customer.lookupName); // inconsistency in mcs data type

            }
        }
        
        public addRoad (newRoad: IRoad): void {
            if(newRoad.roadNumberTo == null) {
                newRoad.roadNumberTo = newRoad.roadNumberFrom;
            }
        this.numberRanges = [...this.numberRanges, _.clone(newRoad)];
        this.resetNewRoad();
    }
    
    public canBeAdd (newRoad: IRoad): boolean {
        return this.numberRanges.length === 0
        ||
        (
            !this.hasInCollection(this.numberRanges, newRoad)
            &&
            !this.hasRangeConflict(this.numberRanges, newRoad)
            &&
            this.getRange(newRoad) < this.maxRange
        );
        
    }

    public removeRoad (index: number): void {
        this.numberRanges = [
            ...this.numberRanges.slice(0, index),
            ...this.numberRanges.slice(index + 1, this.numberRanges.length)
        ];
    }

    public numberRagesToString (newNumberRanges) {
        const getNumberRangesFields = this.getFields(['roadInitial', 'roadNumberFrom', 'roadNumberTo'])

        this.numberRangesString = this.$scope.numberRanges = newNumberRanges
            .map(numberRange => getNumberRangesFields(numberRange).join(',') )
            .join(';');
    }

    public getRoadInitialsValue (id) {
        return this.roadInitials ?
            this.roadInitials.filter(road => road.lookupObjid === id)[0].lookupValue :
             '-';
    }

    public isValid (newRoad: IRoad): boolean {
        return (
            newRoad.roadNumberTo === null
            ||
            newRoad.roadNumberFrom <= newRoad.roadNumberTo
        )
    }

}



const mcsSshRoadInitialDirective = ($branding: app.branding.IBrandingService) => ({
        restrict: "E",
        replace: true,
        scope: {
            numberRanges: "=ngModel",
            roadInitials: "=",
            selectedCustomer: "=",
            isParameterBased: "=?",
            formContext: "=?"
        },
        controller: McsSshRoadInitialController,
        templateUrl: $branding.getTemplateUrl('directives.McsSshRoadInitials'),
        controllerAs: 'ctrl'
    });


export default angular.module('directives.McsSshRoadInitial', [McsSystemParametersServiceModule.name])
    .controller('mcsSshRoadInitialsController', McsSshRoadInitialController)
    .directive('mcsSshRoadInitials',['$branding', mcsSshRoadInitialDirective]);
