///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import {IRepositoryPackage, IRepositoryQnxPackage} from "../../../services/PackageRepositoryService";
import AuthServiceModule, {AuthService} from "../../../services/AuthService";

interface IReviseQnxPackageDirectiveScope extends IPackageQnxControllerScope {
    onBackToList(): void;
    onEditQnx(args: {tempObjid: string, templateTypeObjid: number;}): void;
    package: any;
    templates: {
        name: string;
    }[];
    tempObjid: string;
    tempTypeObjid: string;
}

function ReviseQnxPackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('ReviseQnxPackageDirective'),
        controller: 'PackageQnxController',
        controllerAs: 'ctrl',
        scope: {
            onBackToList: '&',
            onEditQnx: '&',
            package: '=?',
            tempObjid: '=?',
	          tempTypeObjid: '=?',
            mode: '=?'
        },
        link: (scope: IReviseQnxPackageDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageQnxController) => {
            ctrl.onBackToList = () => scope.onBackToList();
            ctrl.onEditQnx = (repositoryPackage: IRepositoryQnxPackage) => scope.onEditQnx({ tempObjid: repositoryPackage.objid, templateTypeObjid: repositoryPackage.tempTypeObjid });
            ctrl.initialize("REVISE");
            ctrl.restoreQnxTemplate(false);
        }
    }
}

export default angular.module('views.packageManagement.reviseQnxPackage', [PackageQnxControllerModule.name])
    .directive("reviseQnxPackage", ['$branding', ReviseQnxPackageDirective])
