///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import {IRepositoryPackage, IRepositoryQnxPackage} from "../../../services/PackageRepositoryService";
import AuthServiceModule, {AuthService} from "../../../services/AuthService";

interface IEditQnxPackageDirectiveScope extends IPackageQnxControllerScope {
    onBackToList(): void;
    onReviseQnx(args: {tempObjid: string, tempTypeObjid: number;}): void;
    approve: boolean;
    package: any;
    templates: {
        name: string;
    }[];
    tempObjid: string;
    tempTypeObjid: string;
}

function EditQnxPackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('EditQnxPackageDirective'),
        controller: 'PackageQnxController',
        controllerAs: 'ctrl',
        scope: {
            onBackToList: '&',
            onReviseQnx: '&',
            approve: '=?',
            package: '=?',
            tempObjid: '=?',
            tempTypeObjid: '=?'
        },
        link: (scope: IEditQnxPackageDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageQnxController) => {
            ctrl.onBackToList = () => scope.onBackToList();
            ctrl.onReviseQnx = (repositoryPackage: IRepositoryQnxPackage) => scope.onReviseQnx({ tempObjid: repositoryPackage.objid, tempTypeObjid: repositoryPackage.tempTypeObjid });
            ctrl.initialize("EDIT");
            ctrl.restoreQnxTemplate(scope.approve);
        }
    }
}

export default angular.module('views.packageManagement.editQnxPackage', [PackageQnxControllerModule.name])
    .directive("editQnxPackage", ['$branding', EditQnxPackageDirective])
