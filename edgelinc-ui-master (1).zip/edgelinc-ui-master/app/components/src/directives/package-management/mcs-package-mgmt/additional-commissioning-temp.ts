///<reference path="../../../../../../typings/browser.d.ts"/>

import McsTemplateServiceModule, { McsTemplateService } from "../../../services/mcs/mcsTemplateService";

interface approvedTemplatesList{
    category: string;
    categoryId: string;
    description: string;
    lastUpdatedDate: string;
    status: string;
    tempObjid: string;
    templateType: string;
    templateVersion: string;
    templateVersionNumber?: number;
}

interface IAdditionalCommissioningTempScope extends ng.IScope{
    package: any;
    originalPackage: any;
    templatesList: approvedTemplatesList[];
    getDataAdditional:(tableState:any, tableCtrl:any)=> void;
    getDataSelected:(tableState:any, tableCtrl:any)=> void;
    lastTableState: any;
    lastTableCtrl: any;
    lastSelectedTableState: any;
    lastSelectedTableCtrl: any;
    addTemplates(): void;
    removeTemplates(): void;
    close(): void;
    selection: any;
    checkedItems: any;
    selectionToRemove: any;
    selectionToAdd: any;
    warningInformation: boolean;
    filteredCount: number;
    visibleCount: number;
    clearClicked(): void;
    isLoading: boolean;
    searchBox: string;
    searchChange(): void;
    getCommisioningTempError: any;
    restrictionSelected: boolean;
    mode: string;
}

class AdditionalCommissioningTempController {
    public static $inject = ['$scope', 'McsTemplateService'];


    constructor(private $scope: IAdditionalCommissioningTempScope,
                private McsTemplateService: McsTemplateService) {
        this.$scope.warningInformation = false;
        this.$scope.selectionToAdd = [];
        this.$scope.selectionToRemove = [];
        this.$scope.package.selectedTemplatesList = this.$scope.package.selectedTemplatesList ? this.$scope.package.selectedTemplatesList : [];
        this.$scope.isLoading = false;
        this.$scope.searchChange = () => this.searchBoxChanged();
        this.$scope.getCommisioningTempError = null;
        this.$scope.restrictionSelected = false;

        this.$scope.getDataAdditional = (tableState:any, tableCtrl:any) => {
            this.$scope.lastTableState = tableState;
            this.$scope.lastTableCtrl = tableCtrl;
            if(this.$scope.package.templateOnlyAppliesTo) {
                if(this.$scope.package.templateOnlyAppliesTo.length > 0) {
                    this.$scope.restrictionSelected = true;
                    this.$scope.isLoading = true;
                    this.getTemplatesList().then(templates => {
                        this.$scope.templatesList = templates;
                        this.$scope.isLoading = false;
                    });
                }
            }
        };

        this.$scope.clearClicked = () => {
            this.$scope.selectionToAdd = [];
            if(this.$scope.searchBox != "" && this.$scope.searchBox) {
                this.$scope.searchBox = "";
                this.searchBoxChanged();
            }
        }

        this.$scope.getDataSelected = (tableState:any, tableCtrl:any) => {
            this.$scope.lastSelectedTableState = tableState;
            this.$scope.lastSelectedTableCtrl = tableCtrl;
            this.$scope.lastSelectedTableState.pagination.totalItemCount = this.$scope.package.selectedTemplatesList.length;
            this.$scope.lastSelectedTableState.pagination.numberOfPages = Math.ceil(this.$scope.package.selectedTemplatesList.length / this.$scope.lastTableState.pagination.number);
        }

        this.$scope.addTemplates = () => this.addTemplates();
        this.$scope.removeTemplates = () => this.removeTemplates();

        this.$scope.close = () => {
            this.$scope.warningInformation = false;
        }

        $scope.$watch('package.selectedTemplatesList.length', (selectedTemplatesList:any) => {
            if(this.$scope.lastSelectedTableState && this.$scope.lastSelectedTableCtrl) {
              this.$scope.getDataSelected(this.$scope.lastSelectedTableState, this.$scope.lastSelectedTableCtrl);
            }
        });

        $scope.$watch("package.templateOnlyAppliesTo.length", (tempAppliesLen: any) => {
            if(this.$scope.lastTableState != null && this.$scope.lastTableCtrl != null) {
                this.$scope.templatesList = [];
                this.$scope.package.selectedTemplatesList = [];
                if(tempAppliesLen > 0){
                    this.$scope.restrictionSelected = true;
                    this.$scope.isLoading = true;
                    this.getTemplatesList().then(templates => {
                        this.$scope.templatesList = templates;
                        this.checkIfTemplatesListCoverSelectedList();
                        this.$scope.isLoading = false;
                    });
                } else {
                    this.$scope.restrictionSelected = false;
                }
            }
        });
    }

    private getTemplatesList(): ng.IPromise<any> {
        this.$scope.getCommisioningTempError = null;

        let params = {
            category: 'Commissioning Child Template',
            limit: 10,
            offset: this.$scope.lastTableState.pagination.start ? this.$scope.lastTableState.pagination.start : 0,
            status: 'Approved'
        }
        if(this.$scope.searchBox && this.$scope.searchBox != "") {
            params.offset = 0;
            params = angular.extend(
                params,
                {templateNumber: this.$scope.searchBox}
            )
        }

        if(this.$scope.package.templateOnlyAppliesTo) {
            if(this.$scope.package.templateOnlyAppliesTo.length > 0) {
                let restr = this.McsTemplateService.generateStringWithRestrictions(this.$scope.package.templateOnlyAppliesTo);
                params["templateOnlyAppliesTo"] = restr;
            }
        }

        let parameters = {
            params: params
        };

        return this.McsTemplateService.getTemplatesConf(parameters).then(response => {
            this.$scope.filteredCount = response.totalCount;
            if(response) {
                this.$scope.visibleCount = response.data.length;
                this.$scope.lastTableState.pagination.totalItemCount = this.$scope.filteredCount;
                this.$scope.lastTableState.pagination.numberOfPages = Math.ceil(this.$scope.filteredCount / this.$scope.lastTableState.pagination.number);
                return this.changeTemplateVersionToNumber(response.data);
            }
        }).catch(err => {
            this.$scope.visibleCount = 0;
            this.$scope.getCommisioningTempError = err;
        });
    }

    private addTemplates() {
        if(this.$scope.package.editionEnd || this.$scope.mode=='VIEW') {
            if(this.$scope.originalPackage) {
                if(this.$scope.originalPackage.status == 'Approved' || this.$scope.originalPackage.status == 'Obsolete') {
                    return;
                }
            } else {
                return;
            }
        }
        if(this.$scope.package.selectedTemplatesList) {
            if(this.$scope.package.selectedTemplatesList.length == 0) {
              this.addToSelectedTemplatesList();
            } else if(this.$scope.package.selectedTemplatesList) {
                if(this.checkIfCanBeAdded()) {
                    this.addToSelectedTemplatesList();
                } else {
                    this.$scope.warningInformation = true;
                }
            }
        } else {
            this.$scope.package.selectedTemplatesList = [];
            this.addToSelectedTemplatesList();
        }

        this.$scope.selectionToAdd = [];
    }

    private addToSelectedTemplatesList() {
      _.map(this.$scope.selectionToAdd, (selectedTemplate: any) => {
          var item:any = this.createDispalySelectedItem(selectedTemplate);
          this.$scope.package.selectedTemplatesList.push(item);
      });
    }

    private createDispalySelectedItem(selectedTemplate: any):any{
        var item = {
            tempType: selectedTemplate.templateType,
            tempVersion: selectedTemplate.templateVersion,
            tempDescription: selectedTemplate.description,
            objId: selectedTemplate.tempObjid
          }
        return item;
    }

    //Function to generate additional field with templateVersion as Number -> casue we need sort by this field
    private changeTemplateVersionToNumber(data: any) {
        _.each(data, (value: approvedTemplatesList)=> {
            value.templateVersionNumber = Number(value.templateVersion);
        });
        return data;
    }

    private checkIfTemplatesListCoverSelectedList() {
        if(this.$scope.package.selectedTemplatesList) {
            _.each(this.$scope.package.selectedTemplatesList, (selectedTemplate: any, key: number) => {
                let tempList = this.$scope.templatesList.filter(function(template){
                    return template.tempObjid == selectedTemplate.objId;
                });

                if(tempList.length == 0) {
                    this.$scope.package.selectedTemplatesList.splice(key, 1);
                }
            });
        }
    }

    private checkIfCanBeAdded() {
        let canBeAdded = true;
        _.each(this.$scope.selectionToAdd, (selectedItem: any) => {
            _.each(this.$scope.package.selectedTemplatesList, (existSelection: any) => {
                if(existSelection.objId == selectedItem.tempObjid) {
                    canBeAdded = false;
                }
            });
        });

        return canBeAdded;
    }

    private removeTemplates() {
        if(this.$scope.package.editionEnd || this.$scope.mode=='VIEW') {
          return;
        }
        if(this.$scope.originalPackage) {
            if(this.$scope.originalPackage.status == 'Approved' || this.$scope.originalPackage.status == 'Obsolete') {
                return;
            }
        }
        this.$scope.selectionToRemove = this.$scope.lastSelectedTableState.customSelection.selectionState;
        _.each(this.$scope.selectionToRemove, (selectedItem: any, selectedItemKey:number) => {
            _.each(this.$scope.package.selectedTemplatesList, (template: any, templateKey: number) => {
                if(template) {
                    if(template.objId == selectedItemKey) {
                        this.$scope.package.selectedTemplatesList.splice(templateKey, 1);
                    }
                }
            });
        });

        this.$scope.selectionToRemove = [];
    }

    private searchBoxChanged() {
        this.$scope.isLoading = true;
        this.$scope.templatesList = [];
        this.getTemplatesList().then(templates => {
            this.$scope.templatesList = templates;
            //this.checkIfTemplatesListCoverSelectedList();
            this.$scope.isLoading = false;
        });
    }
}

function AdditionalCommissioningTempDirective($branding: app.branding.IBrandingService) {
    return {
        restrict: "E",
        templateUrl: $branding.getTemplateUrl("AdditionalCommissioningTempDirective"),
        controller: AdditionalCommissioningTempController,
        scope: {
            package: '=',
            mode: '=?',
            originalPackage: '=?'
        }
    }
}

export default angular.module("directives.packageManagement.additionalCommissioningTemp", [McsTemplateServiceModule.name])
    .directive("additionalCommissioningTemp", ["$branding", AdditionalCommissioningTempDirective]);
