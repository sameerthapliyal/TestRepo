
export function McsSShKeyTransferValidateModalController($scope, formState, mode) {
    const dataName = mode === 'validation' ? 'validationResponse' : 'applyResponse'
    const fieldsArray = mode === 'validation' ?
        ['roadInitial', 'roadNumber', 'expectedFileName', 'expectedFileName', 'excludeReason'] : 
        ['roadInitial', 'roadNumber', 'status', 'messageOutObjid']

    angular.extend(
        this,
        formState,
        { mode }
    );


    const filterByString =(str, data, fieldsArray) => {
        let newRegexp = new RegExp(str, 'i');
        const getFieldsResults = fields => fields
            .map(
                field => data.filter(
                    item => item[field] ? item[field].match(newRegexp) : false
                )
            )
            .sort((a, b) => b.length - a.length); 
       
      return  _.compose(
            _.uniq,
            _.flatten,
            getFieldsResults
       )(fieldsArray);
    }
    


    this.pipe = (tableState) => {
        const {
            pagination: {
                start,
                number
            },
            search
        } = this.tableState = tableState;

        angular.extend(
            this,
            { tableState }
        );

        return new Promise((resolve, reject) => {
            let data = this[dataName]
            if (search.string) {
                data = filterByString(search.string, data, fieldsArray)
            }
            if (data) {
                const result:any = {
                    items: data.slice(start, start + number),
                    totalCount: data.length
                };
                resolve(result);

            }
        });
    };

    $scope.$watch(
        () => this[dataName],
        newValidationResponse => {
            this.excluded = newValidationResponse ?
                newValidationResponse
                    .filter(response => response.sshkeyLocated === 'N')
                    .map(response => response.roadInitial + response.roadNumber) :
                [];
        }
    );

    // $scope.$watch(
    // () => this.searchString,
    // this.pipe
    // )

}


export default angular.module('McsSshKeyTransferValidateModalController', [])
    .controller(
        'McsSshKeyTransferValidateModalController',
        ['$scope', 'formState', McsSShKeyTransferValidateModalController]
    );