///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import {IRepositoryPackage, IRepositoryQnxPackage} from "../../../services/PackageRepositoryService";
import AuthServiceModule, {AuthService} from "../../../services/AuthService";

interface ICreateQnxPackageDirectiveScope extends IPackageQnxControllerScope {
    onBackToList(): void;
    onEditQnx(args: {tempObjid: string, templateTypeObjid: number;}): void;
    package: any;
    templates: {
        name: string;
    }[];
    tempObjid: string;
    templateType: string;
}

function CreateQnxPackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('CreateQnxPackageDirective'),
        controller: 'PackageQnxController',
        controllerAs: 'ctrl',
        scope: {
            onBackToList: '&',
            onEditQnx: '&',
            package: '=?',
            tempObjid: '=?',
	          templateType: '=?',
            tempTypeObjid: '=?'
        },
        link: (scope: ICreateQnxPackageDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageQnxController) => {
            ctrl.onBackToList = () => scope.onBackToList();
            ctrl.onEditQnx = (repositoryPackage: IRepositoryQnxPackage) => scope.onEditQnx({ tempObjid: repositoryPackage.objid, templateTypeObjid: repositoryPackage.tempTypeObjid});
            ctrl.initialize("CREATE");
            if(scope.tempTypeObjid && scope.tempObjid) {
                ctrl.restoreQnxTemplateForCreate(false);
            } else if (scope.templateType) {
                ctrl.getCurrentTemplateType(scope.templateType);
            }
        }
    }
}

export default angular.module('views.packageManagement.createQnxPackage', [PackageQnxControllerModule.name])
    .directive("createQnxPackage", ['$branding', CreateQnxPackageDirective])
