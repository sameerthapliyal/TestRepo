///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import {IRepositoryPackage, IRepositoryQnxPackage, IRepositoryQnxPackageFromView} from "../../../services/PackageRepositoryService";
import AuthServiceModule, {AuthService} from "../../../services/AuthService";



interface IViewQnxPackageDirectiveScope extends IPackageQnxControllerScope {
    onBackToList(): void;
    onEditQnxFromView(args: {tempObjid: string, tempTypeObjid: number;}): void;
    package: any;
    templates: {
        name: string;
    }[];
    tempObjid: string;
    templateType: string;
}

function ViewQnxPackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('ViewQnxPackageDirective'),
        controller: 'PackageQnxController',
        controllerAs: 'ctrl',
        scope: {
            onBackToList: '&',
            onEditQnxFromView: '&',
            package: '=?',
            tempObjid: '=?',
	          templateType: '=?',
            tempTypeObjid: '=?'
        },
        link: (scope: IViewQnxPackageDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageQnxController) => {
            ctrl.onBackToList = () => scope.onBackToList();
            ctrl.onEditQnxFromView = (repositoryPackage: IRepositoryQnxPackageFromView) => scope.onEditQnxFromView({ tempObjid: repositoryPackage.objid, tempTypeObjid: repositoryPackage.tempTypeObjid });
            ctrl.initialize("VIEW");
            ctrl.restoreQnxTemplate(false);
        }
    }
}

export default angular.module('views.packageManagement.viewQnxPackage', [PackageQnxControllerModule.name])
    .directive("viewQnxPackage", ['$branding', ViewQnxPackageDirective])
