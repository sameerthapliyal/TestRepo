import McsSystemParametersService from './../../../services/mcs/McsSystemParametersService';
///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import {IRepositoryPackage} from "../../../services/PackageRepositoryService";
import McsGeoZonesService from '../../../services/mcs/McsGeozonesService';

interface geoZone  {
    geozoneObjid: number,
    geoZoneId: number,
    geoZoneName: string,
    assetOwnerId: string,
    latitude1: string,
    longitude1: string,
    latitude3: string,
    longitude3: string,
    active: 'Y' | 'N'
}

interface ICreateQnxSpecificLdvrDownloadPackageDirectiveScope extends IPackageQnxControllerScope {
    onBackToList(): void;
    //onEdit(args: {packageId: string, packageVersion: string, templateType: string;}): void;
    package: any;
    templates: {
        name: string;
    }[];
    addedGeoZones: geoZone[];
    now: Date;
    getGeoZones(tableState: any, selectedCustomer: any): Promise<geoZone[]>;
    addGeoZones(geoZoneToAdd: geoZone[]): void;
    removeGeoZones(geoZoneToRemove: geoZone[]): void;
    getCameraList(): Promise<any>;
    loadCameras(): void;
    filteredCount?: number;
    visibleCount?: number;
}

function CreateQnxSpecificLdvrDownloadPackageDirective(
    $branding: app.branding.IBrandingService,
    sysParamsService,
    geoZonesService
) {
    return {
        templateUrl: $branding.getTemplateUrl('CreateQnxPackageLdvrDownloadDirective'),
        scope: {
            onBackToList: '&',
            onEdit: '&',
            package: '=',
            statuses: '=',
            viewStatus: '=',
            qnxTemplateTypes: "=templateTypes",
            lookupData: "=",
            mode: "=?",
            approve: "=?"
        },
        link: ( scope: ICreateQnxSpecificLdvrDownloadPackageDirectiveScope,
                elem: ng.IAugmentedJQuery,
                attrs: ng.IAttributes ) => {

            scope.package.templateDetails = scope.package.templateDetails || {};
            scope.package.templateDetails.geoZone = {};
            scope.addedGeoZones = [];
            scope.now = new Date();

            const makeCamera = number => ({ name: `Camera ${number + 1}`, id: number + 1});

            scope.getCameraList = () =>
                sysParamsService.getSystemParameters(['Default_Max_Num_Of_Camera'])
                    .then(result => result[0])
                    .then(result => result.parameterValue)
                    .then(camerasNumber => _.times(camerasNumber, makeCamera))
                    .then(cameras => scope.lookupData.cameras = cameras)
                    .catch(response => {
                        scope.viewStatus.cameraError = response
                    });
                    
            scope.getGeoZones  = (tableStatus, selectedCustomer):Promise<geoZone[]> => {
                const query = {
                    params: {
                        customerName: selectedCustomer,
                        active: 'Y',
                        limit: tableStatus.pagination.number,
                        offset: tableStatus.pagination.start
                    }
                };
                scope.viewStatus.geozonesError = null
                return geoZonesService
                    .getGeozones(query)
                    .then(response => {
                        let items = response.data.filter(item => item.active === 'Y')
                        scope.viewStatus.geozonesError = null;
                        scope.filteredCount = response.totalCount;
                        scope.visibleCount = Math.min(tableStatus.pagination.start+tableStatus.pagination.number , response.data.length);
                        return angular.extend({}, { items, totalCount: response.totalCount });
                    })
                    .catch(error => {
                        scope.viewStatus.geozonesError = error;
                    })
            }

            // TO DO: better implementation of viewStatus change handling
            scope.$on('restrictionCustomerSelectChange', (event, newCustomerSelectState, newCustomer) => {
                scope.viewStatus.selectedCustomer = newCustomerSelectState ? newCustomer.lookupName : null;
                scope.viewStatus.isCustomerSelect = newCustomerSelectState
            });

            scope.package.templateDetails.cameraList =
                scope.package.templateDetails.cameraList ?
                    scope.package.templateDetails.cameraList :
                    []

            scope.package.selectCamera = cameraId => {
                let maxCamerasLength = scope.lookupData.cameras.length

                let cameras = scope.package.templateDetails.cameraList;
                const cameraIndex = cameras.indexOf(cameraId);
                if (cameraIndex === -1) {
                    cameras.push(cameraId);
                } else {
                    cameras.splice(cameraIndex, 1);
                }

                scope.viewStatus.allSelected = cameras.length === 0  ? false : 
                    cameras.length === maxCamerasLength ? true : null;
            }

            scope.package.selectAllCameras = () => {
                if (scope.package.templateDetails.cameraList.length === scope.lookupData.cameras.length) {
                    return scope.package
                        .templateDetails.cameraList
                        .splice(0, scope.package.templateDetails.cameraList.length);
                }

                return scope.package
                    .templateDetails.cameraList = _.chain(scope.lookupData.cameras)
                        .map(camera => camera.id)
                        .value();
            }

            scope.$watch('package.templateDetails.cameraList', (cameras: any[]) => console.log(cameras.length))

            scope.package.isCameraCheckboxSelected = () => {
                return scope.package.templateDetails
            }

            const isNotInCollection = collection => zone => {
                return collection.reduce(
                    (prev, curr) => curr.geozoneObjid === zone.geozoneObjid ? false : prev,
                    true
                );
            };

            const assignToPackage = geoZones => {
                scope.package.templateDetails.geoZone = {
                    geoZoneObjid: geoZones.map(zone => zone.geozoneObjid)
                };
            }

            scope.addGeoZones = selected => {
                const selectedClone = selected.map(item => angular.extend({}, item, { isChecked: false}))
                scope.addedGeoZones = _.uniq([...scope.addedGeoZones, ...selectedClone], e => e.geozoneObjid);
                assignToPackage(scope.addedGeoZones)
            };

            scope.removeGeoZones = geoZonesToRemove => {
                scope.addedGeoZones = scope.addedGeoZones
                    .filter(isNotInCollection(geoZonesToRemove));
                assignToPackage(scope.addedGeoZones);
            };

            if(scope.package.templateDetails.geoZones) {
                if (scope.package.templateDetails.geoZones.length > 0) {
                    scope.addGeoZones(scope.package.templateDetails.geoZones);
                    scope.viewStatus.showGeoZones = true;
                }
            }

            scope.loadCameras = () => {
                scope.viewStatus.cameraError = null;
                scope.viewStatus.allSelected = false;
                scope.getCameraList();
            }
            scope.loadCameras();

        }
    };
}


CreateQnxSpecificLdvrDownloadPackageDirective.$inject = [
    '$branding',
    'McsSystemParametersService',
    'McsGeozonesService'
]

export default angular.module('createQnxSpecificLdvrDownloadPackage', [
    PackageQnxControllerModule.name,
    McsSystemParametersService.name,
    McsGeoZonesService.name,

])
    .directive("createQnxSpecificLdvrDownloadPackage", CreateQnxSpecificLdvrDownloadPackageDirective);
