import { ITemplateAction } from './../../../services/mcs/mcsTemplateService';

///<reference path="../../../../../../typings/browser.d.ts"/>
///<reference path="../../utilities/mcs/mcs-mapper/mcsPackageMethodMapping.ts"/>

import PackageRepositoryServiceModule, {
    IRepositoryPackageToUpdate, IRepositoryQnxPackageToUpdate, IRepositoryQnxTemplateType, PackageRepositoryService, IRepositoryQnxPackageFromView,
    IRepositoryPackage, IRepositoryQnxPackage, Restrictions, RepositoryTemplateTypes
} from "../../../services/PackageRepositoryService";
import UserManagementServiceModule, { UserManagementService } from "../../../services/UserManagementService";
import AuthServiceModule, { AuthService } from "../../../services/AuthService";
import { NotifyData } from "../../../utilities/NotifyHelper";
import McsGeneralServiceModule, { McsGeneralService } from "../../../services/mcs/McsGeneralService";
import McsTemplateServiceModule, { McsTemplateService } from "../../../services/mcs/mcsTemplateService";

import _ from 'lodash';

export type PackageQnxControllerMode = "CREATE" | "EDIT" | "REVISE" | "VIEW";

export interface IPackageQnxControllerScope extends ng.IScope {
    tempObjid?: string;
    tempTypeObjid?: string;
    templateType?: string;
    mode: string;
    originalPackage: IRepositoryQnxPackage;
    savedPackage: IRepositoryQnxPackage;
    templateTypes: RepositoryTemplateTypes;
    templateTypesSpinner: boolean;
    restrictions: Restrictions;
    statuses: {
        lookupName?: string;
        lookupValue?: string;
        lookupObjid?: number;
        lookupOrder?: number;
    }[];
    statusesSpinner: boolean;
    templateNumber: number;
    inProgress: boolean;
    inProgressMessage: string;
    inProgressTemplateFileProgres: number;
    inProgressTemplateFileDetailedProgres: NotifyData;
    error?: Error;
    createPackage(form: ng.IFormController, e): void;
    updatePackage(form: ng.IFormController, e): void;
    editQnx(repositoryPackage: IRepositoryQnxPackage): void;
    editQnxFromView(repositoryPackage: IRepositoryQnxPackageFromView): void;
    reviseQnx(repositoryPackage: IRepositoryQnxPackage): void;
    editTemplate(savedPackage): void;
    backToList(): void;
    view(repositoryPackage: IRepositoryPackage): void;
    qnxTemplateTypes: IRepositoryQnxTemplateType[];
    qnxRestrictions: {
        name: string;
        values: string[];
    }[];
    package: any;
    select(selectedItem): void;
    subRestrictSelected: IRepositoryQnxPackageToUpdate;
    lookupData: {
        mpParameters?: any;
        mpConditions?: any;
        cameras?:{ name: string; id: number }[];
    };
    viewStatus: {
        hasErrors?: boolean;
        errorMsg?: any;
        isCustomerSelect?: boolean;
        isEventLoaded?: boolean;
        isEventLoading?: boolean;
        errors?: any;
        allSelected?: boolean;
        showGeoZones?: boolean;
        geoZonesExpand?: boolean;
        eventBasedExpand?: boolean;
        timeFrameBasedExpand?: boolean;
        selectedCustomer?: any;
        isObsolete?: boolean;
        isApproved?: boolean;
        showMessage?: boolean;
        cameraError?: any;
        geozonesError?: any;
        lookupsError?: any;
        retry?: (form: ng.IFormController) => void;
        isCreatedAndRestored?: boolean;
    };
    waitForQnxTemplateTypes: any;
    responseEmptyMessage: boolean;
    waitForRestored: boolean;
    templateIdDefined: boolean;
    close(): void;
}

export class PackageQnxController {
    public static $inject = ["$scope", "$q", "$location", "RouteHelpers", "PackageRepositoryService", "UserManagementService", "AuthorizationService", "McsGeneralService", "McsTemplateService"];

    public emptyPackageFactory: (originalPackage: IRepositoryPackage) => IRepositoryPackageToUpdate;
    public onBackToList: () => void;
    public onEditQnx: (repositoryPackage: IRepositoryQnxPackage) => void;
    public onEditQnxFromView: (repositoryPackage: IRepositoryQnxPackageFromView) => void;
    public onReviseQnx: (repositoryPackage: IRepositoryQnxPackage) => void;
    private _options: {[templateType: string]: any} = {};
    private approveWarning = (`
    The submission of a template with the 'Approved'
    status will obsolete all its previous versions.
    In addition, if the previous version is contained
    in any other templates, the corresponding parent
    templates will also be obsoleted. If you would
    like to continue using the existing Approved
    version, please create a new Template instead
    of a new Version. Please click OK to continue or
    Cancel to return to the previous page.`)
        .replace(/\s\s+/g, ' ');

    public get specificOptions() {
        let templateType = _.get<string>(this.$scope, 'package.templateType.objid');
        if(!templateType) {
            return {};
        }
        let templateTypeStr = templateType.toString();
        if(!_.has(this._options, templateTypeStr)) {
            this._options[templateTypeStr] = {};
        }
        return this._options[templateTypeStr];
    }

    public set specificOptions(options: any) {
        let templateType = _.get<string>(this.$scope, 'package.templateType.objid');
        if(templateType) {
            let templateTypeStr = templateType.toString();
            this._options[templateTypeStr] = options;
        }
    }

    constructor(private $scope: IPackageQnxControllerScope,
        private $q: ng.IQService,
        private $location: ng.ILocationService,
        private RouteHelpers: app.IRouteHelpers,
        private PackageRepositoryService: PackageRepositoryService,
        private UserManagementService: UserManagementService,
        private AuthorizationService: AuthService,
        private McsGeneralService: McsGeneralService,
        private McsTemplateService: McsTemplateService) {

        this.onBackToList = _.noop;
        this.onEditQnx = _.noop;
        this.onEditQnxFromView = _.noop;
        this.onReviseQnx = _.noop;

        this.emptyPackageFactory = () => {
            return <any>{}
        };
        let vm = $scope;
        if(typeof this.$scope.package == "undefined") {
            this.$scope.package = {};
        }
        this.$scope.createPackage = (form: ng.IFormController) => this.createPackage(form);
        this.$scope.updatePackage = (form: ng.IFormController) => this.updatePackage(form);
        this.$scope.editTemplate = (savedPackage) => this.editTemplate(savedPackage);
        this.$scope.editQnx = (repositoryPackage: IRepositoryQnxPackage) => this.editQnx(repositoryPackage);
        this.$scope.editQnxFromView = (repositoryPackage: IRepositoryQnxPackageFromView) => this.editQnxFromView(repositoryPackage);
        this.$scope.reviseQnx = (repositoryPackage: IRepositoryQnxPackage) => this.reviseQnx(repositoryPackage);
        this.$scope.backToList = () => this.backToList();
        //this.$scope.isCustomerSelected = () => this.isCustomerSelected();
        this.$scope.viewStatus = {};
        this.$scope.viewStatus.hasErrors = false;
        this.$scope.viewStatus.errorMsg = '';
        this.$scope.package.mconCommTemplateDpd = [];
        this.$scope.package.PFSTemplateDpd = [];
        this.$scope.waitForQnxTemplateTypes = [];
        this.$scope.responseEmptyMessage = false;
        this.$scope.waitForRestored = false;
        this.$scope.templateIdDefined = false;

        if (typeof this.$scope.statuses == "undefined") {
            this.$scope.statusesSpinner = true;
            this.$scope.statuses = [];
            this.McsTemplateService.getTemplateStatuses().then(response => {
                /*if (this.$scope.mode === 'CREATE') {
                    response = response
                        .filter(status => status.lookupValue === 'Work In Process')
                }*/
                this.$scope.statuses = response;
                this.$scope.statusesSpinner = false;
            })
                .catch(err => {
                    this.$scope.statusesSpinner = false;
                    console.log(err);
                });
        }

        if (typeof this.$scope.qnxTemplateTypes == "undefined") {
            this.$scope.templateTypesSpinner = true;
            this.$scope.qnxTemplateTypes = [];
            this.$scope.waitForQnxTemplateTypes.push(this.McsGeneralService.getTemplateTypes()
                .then(res => {
                    this.$scope.qnxTemplateTypes = res;
                    this.$scope.templateTypesSpinner = false;
                })
                .catch(err => {
                    console.log(err);
                    this.$scope.templateTypesSpinner = false;
                }));
        }

        if (this.$scope.package) {
            this.$scope.package.zeroSpeedTimeoutEnabled = false;
            this.$scope.package.zeroSpeedTimeout = 0;
            this.$scope.package.editionEnd = false;
            this.getDropdownIfNecessary();
        }

        if (!this.$scope.qnxRestrictions) {
            this.$scope.qnxRestrictions = [];
            this.McsGeneralService.getAllRestrictions()
                .then(response => {
                    if(response) {
                      _.each(response, (responseObj: any) => {
                          if(responseObj.hasOwnProperty("category") && responseObj.category == "Template") {
                              this.$scope.qnxRestrictions = responseObj.types;
                          }
                      });
                    }
                })
        }

        vm.viewStatus = {};
        vm.viewStatus.isCustomerSelect = false
        this.$scope.lookupData = {};

        $scope.$on('restrictionCustomerSelectChange', (event, isCustomerSelect) => {
            vm.viewStatus.isCustomerSelect = isCustomerSelect;
        });

        $scope.select = function (selectedItem) {
            $scope.subRestrictSelected = selectedItem;
        };

        $scope.$on("$routeChangeStart", (event: ng.IAngularEvent, next: any, current: any) => {
            if (this.$scope.inProgress) {
                var message = null;
                if (this.$scope.mode == "CREATE") {
                    message = "Template creation is in progress. You might cause this process to fail when you left the page";
                }
                if (confirm(message) == false) {
                    event.preventDefault()
                }
            }
        });

        $scope.$on("$destroy", () => {
            window.onbeforeunload = null;
        });

        $scope.$watch('viewStatus.eventBasedExpand', isEventBaseExpand => {
            if (isEventBaseExpand && !this.$scope.viewStatus.isEventLoaded) {
                this.$scope.viewStatus.isEventLoading = true;
                this.getEventLookup.apply(this);
            }
        });

        window.onbeforeunload = (event: BeforeUnloadEvent) => {
            if (this.$scope.inProgress) {
                if (this.$scope.mode == "CREATE") {
                    return "Template creation is in progress. You will cause the process to fail when you left the page";
                }
            } else {
                window.onbeforeunload = null;
            }
        };

        $scope.$watch("package.templateOnlyAppliesTo.length", (newValue: any) => {
            if (typeof newValue != "undefined") {
                if (newValue > 0) {
                    this.getDropdownIfNecessary();
                } else {
                    this.$scope.package.mconCommTemplateDpd = [];
                    this.$scope.package.PFSTemplateDpd = [];
                }
            }
        });

        $scope.$watch("package.templateType", (templateType: any) => {
            if (typeof templateType != "undefined") {
                this.getDropdownIfNecessary();
                if(templateType.objid == 11 && this.$scope.package.templateOnlyAppliesTo) {
                    this.$scope.package.templateOnlyAppliesTo = [];
                }
            }
            this.$scope.viewStatus.retry = null;
        });

        let requestEndTimeUnWatch = $scope.$watch('package.templateDetails.requestedEndTime', (requestTime:number) => {
            if(requestTime) {
                $scope.package.templateDetails.requestedEndTime = new Date(requestTime).getTime();
                requestEndTimeUnWatch();
            }
        })

        let requestStartTimeUnWatch = $scope.$watch('package.templateDetails.timeframe.requestedStartTime', (requestTime:number)=> {
            if(requestTime) {
                $scope.package.templateDetails.requestedStartTime = new Date(requestTime).getTime();
                requestStartTimeUnWatch();
            }
        })

        $scope.$watch("package.zeroSpeedTimeoutEnabled", (newZeroSpeedTimeout: any) => {
            if (!this.$scope.package) {
                return;
            }
            if(this.$scope.mode == 'CREATE' && !this.$scope.package.zeroSpeedTimeoutEnabled) {
                if(!this.$scope.package.zeroSpeedTimeout) {
                    this.$scope.package.zeroSpeedTimeout = 0;
                } else {
                    this.$scope.package.zeroSpeedTimeoutEnabled = true;
                }
            } else if(this.$scope.package.zeroSpeedTimeoutEnabled == false) {
                this.$scope.package.zeroSpeedTimeout = 0;
            } else if(this.$scope.package.zeroSpeedTimeout != 0) {
                this.$scope.package.zeroSpeedTimeoutEnabled = true;
            }
        });

        $scope.close = () => {
            this.$scope.viewStatus.showMessage = false;
            this.$scope.viewStatus.retry = null;
        }
    }

    public initialize(mode: PackageQnxControllerMode) {
        this.$scope.mode = mode;
        this.initViewStatus();
    }

    public initViewStatus() {
        this.$scope.viewStatus = angular.extend(
            {},
            this.$scope.viewStatus,
            {
                eventBasedExpand: false,
                isEventExpand: false,
                isEventLoading: false,
                geoZonesExpand: false,
                timeFrameBasedExpand: false,
                isCreatedAndRestored: false
            }
        )
        this.$scope.lookupData = angular.extend(
            {},
            this.$scope.lookupData ? this.$scope.lookupData : {},
            {
                cameras: null,
                mpParameters: null,
                mpConditions: null
            }
        )
    }

    public updateViewStatus (pack) {
        this.$scope.viewStatus = angular.extend(
            {},
            this.$scope.viewStatus,
            {
                eventBasedExpand: !!_.get<any[]>(pack,'event.mps.length'),
                geoZonesExpand: !!_.get<Number[]>(pack, 'templateDetails.geoZones.length'),
                timeFrameBasedExpand: !!_.get(pack,'templateDetails.timeframe.requestedStartTime')
            }
        )
    }

    public restoreQnxTemplate(approve: any) {
        this.$scope.waitForRestored = true;
        const argsArr = [this.$scope.tempObjid];
        this.getPackageDetailsMapMethod(this.$scope.tempTypeObjid)(...argsArr).then(response => {
            this.$scope.package = response;
            this.$scope.package.status = this.$scope.package.status ? this.$scope.package.status : this.$scope.package.templateStatus;
            if(this.$scope.waitForQnxTemplateTypes != null && this.$scope.waitForQnxTemplateTypes.length > 0){
                return this.$q.all(this.$scope.waitForQnxTemplateTypes).then(()=>{
                        this.$scope.package = this.McsTemplateService.prepareRestoredPackageDetails(approve, this.$scope.package, this.$scope.tempTypeObjid, this.$scope.qnxTemplateTypes);
                        const tempStatus = this.$scope.package.templateStatus;
                        if(this.$scope.package.PFSTemplate && this.$scope.package.PFSTemplateDpd) {
                            this.$scope.package.PFSTemplate = this.McsTemplateService.getProperPFSTemplateValue(this.$scope.package.PFSTemplate, this.$scope.package.PFSTemplateDpd);
                        }
                        this.$scope.viewStatus.isObsolete = tempStatus === 'Obsolete';
                        this.$scope.viewStatus.isApproved = tempStatus === 'Approved';
                        this.$scope.statuses = this.McsTemplateService.mapStatusesFields(this.$scope.package.status, this.$scope.mode, this.$scope.statuses);
                        this.$scope.originalPackage = JSON.parse(JSON.stringify(this.$scope.package));
                        this.$scope.waitForRestored = false;
                        this.updateViewStatus(this.$scope.package);
                });
            }
        }).catch(err => {
            this.$scope.responseEmptyMessage = true;
            this.$scope.viewStatus.errorMsg = err;
            this.$scope.waitForRestored = false;
        });
    }

    public restoreQnxTemplateForCreate(approve: any) {
        this.$scope.waitForRestored = true;
        this.$scope.viewStatus.isCreatedAndRestored = true;
        const argsArr = [this.$scope.tempObjid];
        this.getPackageDetailsMapMethod(this.$scope.tempTypeObjid)(...argsArr).then(response => {
            this.$scope.package = response;
            if(this.$scope.package.templateNumber && this.$scope.package.templateVersion) {
                delete this.$scope.package.templateNumber;
                delete this.$scope.package.templateVersion;
            }
            this.$scope.package.status = "Work In Process";
            if(this.$scope.waitForQnxTemplateTypes != null && this.$scope.waitForQnxTemplateTypes.length > 0){
                return this.$q.all(this.$scope.waitForQnxTemplateTypes).then(()=>{
                        this.$scope.package = this.McsTemplateService.prepareRestoredPackageDetails(approve, this.$scope.package, this.$scope.tempTypeObjid, this.$scope.qnxTemplateTypes);
                        const tempStatus = this.$scope.package.templateStatus;
                        this.$scope.originalPackage = JSON.parse(JSON.stringify(this.$scope.package));
                        this.$scope.waitForRestored = false;
                        this.updateViewStatus(this.$scope.package);
                });
            }
        }).catch(err => {
            this.$scope.responseEmptyMessage = true;
            this.$scope.viewStatus.errorMsg = err;
            this.$scope.waitForRestored = false;
        });
    }

    public getCurrentTemplateType(templateTypeId: string) {
        this.$scope.templateIdDefined = true;
        if(this.$scope.waitForQnxTemplateTypes != null && this.$scope.waitForQnxTemplateTypes.length > 0){
            return this.$q.all(this.$scope.waitForQnxTemplateTypes).then(()=>{
                  this.$scope.package.templateType = {};
                  this.$scope.package.templateType.objid = templateTypeId;
                  this.$scope.package.templateType.templateType = this.McsTemplateService.getQnxTemplateTypeFromTypeId(templateTypeId, this.$scope.qnxTemplateTypes);
            });
        }
    }

    public getEventLookup() {
        return this.McsGeneralService.getLookupData(['LCV_MP_PARAMETERS', 'LCV_MP_CONDITIONS',])
            .then(lookups => {
                this.$scope.lookupData.mpParameters = lookups['LCV_MP_PARAMETERS'];
                this.$scope.lookupData.mpConditions = lookups['LCV_MP_CONDITIONS'];
                this.$scope.viewStatus.isEventLoaded = true;
                this.$scope.viewStatus.isEventLoading = false;
            })
            .catch(error => {
                this.$scope.viewStatus.lookupsError = error;
                this.$scope.viewStatus.isEventLoading = false;

            });
    }

    private getPackageCreateMethod(templateTypeId) {
        const templatePathArray = createPackageMethodMap[templateTypeId];
        try {
            return this[templatePathArray[0]][templatePathArray[1]].bind(this[templatePathArray[0]]);
        } catch (e) {
            return this['PackageRepositoryService']['createQnxPackage'].bind(this['PackageRepositoryService']);
        }
    }

    private getPackageUpdateMethod(templateTypeId) {
        const templatePathArray = updatePackageMethodMap[templateTypeId];
        try {
            return this[templatePathArray[0]][templatePathArray[1]].bind(this[templatePathArray[0]]);
        } catch (e) {
            return this['PackageRepositoryService']['updateQnxPackage'].bind(this['PackageRepositoryService']);
        }
    }

    private editTemplate(savedPackage) {
        const status = savedPackage.status || savedPackage.templateStatus;
        this.$scope.package.editionEnd = false;
        this.$scope.viewStatus.hasErrors = false;
        this.$scope.viewStatus.isApproved = status === 'Approved';
        this.$scope.viewStatus.isObsolete = status === 'Obsolete';
        this.$scope.viewStatus.errorMsg = "";
        this.$scope.originalPackage = JSON.parse(JSON.stringify(savedPackage));
        this.$scope.statuses = this.McsTemplateService.mapStatusesFields(this.$scope.originalPackage.status, this.$scope.mode, this.$scope.statuses, this.$scope.originalPackage.templateStatus);
    }

    private getPackageDetailsMapMethod(templateTypeId) {
        const templatePathArray = getPackageDetailsMethodMap[templateTypeId];
        try {
            return this[templatePathArray[0]][templatePathArray[1]].bind(this[templatePathArray[0]]);
        } catch (e) {
            return this['McsTemplateService']['getGenericTemplateDetails'].bind(this['McsTemplateService']);
        }
    }

    private createPackage(form: ng.IFormController) {
        if (this.$scope.inProgress) {
            return;
        }

        // For LDVR preservation / download template customer restriction is mandatory
        // if (!this.isCustomerSelected() && this.isPreservationDownloadTemplate()) {
        //     return this.customerReasonFail();
        // }
        this.$scope.inProgress = true;
        this.$scope.error = null;

        if (this.$scope.mode === 'REVISE' && this.$scope.package.status === 'Approved') {
            const isConfirmed = confirm(this.approveWarning);

            if (!isConfirmed) {
                this.$scope.inProgress = false;
                return false;
            }

        }


        let packageToSave = this.McsTemplateService.preparePackageDetailsToSave(this.$scope.package, this.$scope.viewStatus);

        const templateTypeId = this.$scope.package.templateType.objid;
        const packageFile = this.$scope.package.packageFile || null;
        const argumentsArray = [packageToSave, packageFile];

        this.getPackageCreateMethod(templateTypeId)(...argumentsArray)
            .then(this.assignCreatePackageResponse.bind(this))
            .catch(this.handleErrors.bind(this));
    }

    private updatePackage(form: ng.IFormController) {
        if (this.$scope.inProgress) {
            return;
        }

        // For LDVR preservation / download template customer restriction is mandatory
        // if (!this.isCustomerSelected() && this.isPreservationDownloadTemplate()) {
        //     return this.customerReasonFail();
        // }

        this.$scope.inProgress = true;
        this.$scope.error = null;

        let packageToSave = this.McsTemplateService.preparePackageDetailsToSave(this.$scope.package, this.$scope.viewStatus);
        if (this.$scope.tempObjid) {
            packageToSave["objid"] = this.$scope.tempObjid;
        }

        const templateTypeId = this.$scope.package.templateType.objid;
        const packageFile = this.$scope.package.packageFile || null;
        const argumentsArray = [packageToSave, packageFile];

        this.getPackageUpdateMethod(templateTypeId)(...argumentsArray)
            .then(this.assignCreatePackageResponse.bind(this))
            .catch(this.handleErrors.bind(this));
    }

    private assignCreatePackageResponse(response) {
        this.$scope.package.editionEnd = true;
        const data = response;
        this.$scope.inProgress = false;
        this.$scope.viewStatus.hasErrors = false;
        this.$scope.viewStatus.showMessage = true;

        let savedPackage = angular.extend(
            data,
            { objid: data.objid || data.templateObjId },
            { tempTypeObjid: data.tempTypeObjid || this.$scope.package.templateType.objid } // inconsistency in save response, tempTypeObjId is necessary for editing
        );
        angular.extend(
            this.$scope,
            { savedPackage }
        );
    }

    private handleErrors(errors) {
        this.$scope.viewStatus.showMessage = true;
        this.$scope.viewStatus.hasErrors = true;
        this.$scope.inProgress = false;
        this.$scope.viewStatus.errorMsg = errors;
    }

    private backToList() {
        if (this.$scope.inProgress) {
            return;
        }
        this.onBackToList();
    }

    private editQnx(repositoryPackage: IRepositoryQnxPackage) {
        if (this.$scope.inProgress) {
            return;
        }
        if(repositoryPackage) {
            this.onEditQnx(repositoryPackage);
        } else {
          this.$scope.package.editionEnd  = false;
          this.$scope.viewStatus.hasErrors = false;
          this.$scope.viewStatus.errorMsg = "";
        }
    }

    private editQnxFromView(repositoryPackage: IRepositoryQnxPackageFromView) {
        if (this.$scope.inProgress || !repositoryPackage) {
            return;
        }
        this.onEditQnxFromView(repositoryPackage);
    }

    private reviseQnx(repositoryPackage: IRepositoryQnxPackage) {
        if (this.$scope.inProgress || !repositoryPackage) {
            return;
        }
        this.onReviseQnx(repositoryPackage);
    }

    private getDropdownIfNecessary() {
        if(this.$scope.package.templateType) {
          let objid = this.$scope.package.templateType.objid;

          if(typeof this.$scope.package.templateType.objid == "string") {
              objid = Number(this.$scope.package.templateType.objid);
          }
          switch(objid) {
              case 1:
                  let restr = "";
                  var parameters = {};
                  var params = {};
                  this.$scope.package.mconCommTemplateDpd = [];
                  this.$scope.package.PFSTemplateDpd = [];

                  if(this.$scope.package.templateOnlyAppliesTo) {
                      if(this.$scope.package.templateOnlyAppliesTo.length > 0) {
                          restr = this.McsTemplateService.generateStringWithRestrictions(this.$scope.package.templateOnlyAppliesTo);
                          params["templateOnlyAppliesTo"] = restr;

                          /* Get dropdown for MCON Commissioning Template */
                          params["tempTypeObjid"] = 9; //tempTypeObjid for MCON: Commissioning Template
                          params["status"] = 'Approved';
                          params["limit"] = -1;
                          parameters = {
                              params: params
                          }
                          this.McsTemplateService.getTemplatesConf(parameters).then(res => {
                              if(res) {
                                  this.$scope.package.mconCommTemplateDpd = this.McsTemplateService.prepareMconAndPfsCommTemplateDpd(res.data);
                                  let actualUrl = window.location.href.split("?");
                                  if(actualUrl.length < 2 && actualUrl[1] != "approve" && this.$scope.package.status == "Work In Process") {
                                      this.$scope.package.mconCommTemplate = this.McsTemplateService.getFirstValueFromDropdown(this.$scope.package.mconCommTemplateDpd, this.$scope.package.mconCommTemplate);
                                  }
                              }
                          });

                          /* Get dropdown for Primary faultsource Commissining Template */
                          parameters = {};
                          params = {};
                          params["category"] = 'Commissioning Child PFS Template';
                          params["status"] = 'Approved';
                          params["limit"] = -1;
                          if(restr != "") {
                              params["templateOnlyAppliesTo"] = restr;
                          }
                          parameters = {
                              params: params
                          }
                          this.McsTemplateService.getTemplatesConf(parameters).then(res => {
                              if(res) {
                                  this.$scope.package.PFSTemplateDpd = this.McsTemplateService.prepareMconAndPfsCommTemplateDpd(res.data);
                                  if(this.$scope.package.PFSTemplate) {
                                      this.$scope.package.PFSTemplate = this.McsTemplateService.getProperPFSTemplateValue(this.$scope.package.PFSTemplate, this.$scope.package.PFSTemplateDpd);
                                  }
                              }
                          });
                      }
                  }
              break;
          }
        }
    }

    //private isCustomerSelected() {
    //    return !!_.find(this.$scope.package.templateOnlyAppliesTo, { id: "4" });
    //}

    private isPreservationDownloadTemplate () {
        return this.$scope.package.templateType.objid === "12";
    }

    private customerReasonFail () {
        this.$scope.viewStatus.hasErrors = true;
        this.$scope.viewStatus.errorMsg = {
            isKnownError: true,
            message: "Customer restriction is mandatory"
        };
        this.$scope.viewStatus.showMessage = true;
    }
}

var angularModule = angular.module('directives.packageManagement.packageQnxController', [
    PackageRepositoryServiceModule.name,
    UserManagementServiceModule.name,
    AuthServiceModule.name,
    McsGeneralServiceModule.name,
    McsTemplateServiceModule.name
])
    .controller("PackageQnxController", PackageQnxController);

export default angularModule;
