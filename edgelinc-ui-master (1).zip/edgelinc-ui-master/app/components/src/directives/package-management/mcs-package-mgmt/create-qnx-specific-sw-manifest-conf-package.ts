///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    IPackageQnxControllerScope
} from "./PackageQnxController";
import {McsTemplateService} from "../../../services/mcs/mcsTemplateService";
import {HttpError} from "../../../utilities/RestHelper";

interface ICreateQnxGenericPackageDirectiveScope extends IPackageQnxControllerScope {
    onBackToList(): void;
    onEdit(args: {packageId: string, packageVersion: string, templateType: string;}): void;
    mode: string;
    packageToSave: any;
    templates: {
        name: string;
    }[];
    viewStatus: { hasErrors?: boolean, errorMsg?: any, showMessage?: boolean, retry?(form: ng.IFormController): void};
    specificTemplateOptions: {disableStatus: boolean; hasSwVersion: boolean};
}

class QnxSwManifestConfPackageController {
    public processingFileInProgress: boolean;
    public processingFileCompleted: boolean;
    public fileResults: any;
    public tableState: any;

    constructor(private $scope: ICreateQnxGenericPackageDirectiveScope, private $q: ng.IQService, private $timeout: ng.ITimeoutService, private McsTemplateService: McsTemplateService) {
        this.processingFileInProgress = false;
        if($scope.mode == 'EDIT') {
            this.fileResults = $scope.packageToSave;
            this.$scope.specificTemplateOptions.disableStatus = false;
        } else {
            this.$scope.packageToSave.status = "Work In Process";
        }
        this.$scope.viewStatus = this.$scope.viewStatus || {};
    }

    public processFile() {
        this.processingFileInProgress = true;
        this.$scope.specificTemplateOptions.disableStatus = true;
        this.$scope.packageToSave.status = "Work In Process";
        this.$scope.viewStatus.showMessage = false;
        this.McsTemplateService.saveSoftwareManifestConfigurationTemplate(this.$scope.packageToSave)
            .then(fileResults => {
                this.$scope.specificTemplateOptions.disableStatus = false;
                this.$scope.packageToSave.objid = fileResults.objid;
                this.fileResults = fileResults;
                this.processingFileInProgress = false;
                this.processingFileCompleted = true;
                this.$scope.viewStatus.hasErrors = false;
                this.$scope.viewStatus.errorMsg = null;
                this.$scope.viewStatus.retry = null;
            })
            .catch((err: HttpError) => {
                this.$scope.viewStatus.hasErrors = true;
                this.$scope.viewStatus.errorMsg = err;
                this.$scope.viewStatus.showMessage = true;
                this.$scope.viewStatus.retry = this.processFile.bind(this);
                this.processingFileInProgress = false;
            })

    }

    public getSoftwareComponents(tableState) {
        this.tableState = tableState;
        let items = [];
        if (this.fileResults && this.fileResults.softwareComponents) {
            items = this.fileResults.softwareComponents;
        }
        let limit = this.tableState ? this.tableState.pagination.number : 10;
        let offset = this.tableState ? this.tableState.pagination.start : 0;

        let pagedItems = items.slice(offset, limit + offset);
        return this.$q.resolve({
            items: pagedItems,
            totalCount: items.length
        });
    }
}

function CreateQnxSwManifestConfPackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('CreateQnxSwManifestConfPackageDirective'),
        controller: QnxSwManifestConfPackageController,
        controllerAs: 'ctrl',
        scope: {
            onBackToList: '&',
            //onEdit: '&',
            packageToSave: '=',
            statuses: '=',
            qnxTemplateTypes: "=templateTypes",
            mode: '=?',
            viewStatus: '=?',
            specificTemplateOptions: '='
        },
        link: (scope: ICreateQnxGenericPackageDirectiveScope, elem, attrs, ctrl: QnxSwManifestConfPackageController) => {
            scope.specificTemplateOptions = {
                disableStatus: !ctrl.fileResults,
                hasSwVersion: true
            };
        }
    }
}

interface ISwManifestPackageFileProcessedAttrs extends ng.IAttributes {
    swManifestPackageFileProcessed: string;
}

function SwManifestPackageFileProcessedDirective($parse: ng.IParseService) {
    return {
        restrict: "A",
        require: 'ngModel',
        link: (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: ISwManifestPackageFileProcessedAttrs, ctrl: ng.INgModelController) => {
            let processedGetter = $parse(attrs.swManifestPackageFileProcessed).bind(this, scope);
            scope.$watch(processedGetter, () => ctrl.$validate());
            ctrl.$validators['swManifestPackageFileProcessed'] = function() {
                return !!processedGetter();
            };
        }
    }
}
SwManifestPackageFileProcessedDirective.$inject = ['$parse'];

export default angular.module('directives.packageManagement.createQnxSwManifestConfPackage', [PackageQnxControllerModule.name])
    .directive("createQnxSwManifestConfPackage", ['$branding', CreateQnxSwManifestConfPackageDirective])
    .directive('swManifestPackageFileProcessed', SwManifestPackageFileProcessedDirective);
