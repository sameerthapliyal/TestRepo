
import McsGeneralServiceModule, { McsGeneralService } from "../../../services/mcs/McsGeneralService";
import McsTemplateServiceModule, { McsTemplateService } from "../../../services/mcs/mcsTemplateService";
import { IMessageType } from "../../../services/mcs/McsServiceBase";
import AuthServiceModule, { AuthService } from "../../../services/AuthService";
import { McsSShKeyTransferValidateModalController } from './McsSshKeyTransferValidateModalController';


interface IMcsSshKeyTransferControllerScope extends ng.IScope {

}

interface iSshFormState {
    assetRange: string;
    selectedCustomer: any;
    validated: boolean;
    applied: boolean;
    hasErrors: boolean;
    initDataError: boolean;
    validationResponse?: any[];
    applyResponse?: any[];
    isAnyValid?: boolean;
    isLoading: boolean;
    error?: any;

}

interface IMcsSshKeyTransferController {
    sshKeyTransfer: ng.IFormController;
    messageTypes: IMessageType[];
    request: ShhKeyTransferRequest;
    formState: iSshFormState | {};
    lookups: any,

}

interface ShhKeyTransferRequest {
    customer: string;
    messageType: string;
    directoryPath: string;
    deviceType: string;
    fileExtension: string;
    roadNumberRanges: string;
    userName: string
}

interface ILoadersNames {
    loaderName: 'isValidationLoading' | 'isApplyLoading';
    loaderFailName: 'isValidationFail' | 'isApplyFail';
    modePropsName: 'validated' | 'applied';
    responsePropsName: 'validationResponse' | 'applyResponse';
    errorsName: 'validationErrors' | 'applyErrors'
}


export class McsSshKeyTransferController implements IMcsSshKeyTransferController {
    public static $inject = ['$scope', '$q', '$window', '$uibModal', 'McsGeneralService', 'AuthorizationService', 'McsTemplateService'];

    public messageTypes: IMessageType[];

    public request: ShhKeyTransferRequest;

    public formState: iSshFormState;

    public sshKeyTransfer: ng.IFormController;

    public neededDataSets = ['OWNER_NAMES', 'ROAD_INITIALS', 'ASSET_DEVICES', 'SSH_KEY_EXTENSION'];

    public lookups;

    constructor(
        private _scope: IMcsSshKeyTransferControllerScope,
        private _q: ng.IQService,
        private _window: ng.IWindowService,
        private _modalInstance,
        private _mcsGeneralService: McsGeneralService,
        private _authService: AuthService,
        private _mcsTemplateService: McsTemplateService
    ) {


        this.initFormState();
        this.initFormRequest();
        this.initDataRequests();

        _scope.$watch(
            () => this.request.customer,
            this.traceSelectedCustomer.bind(this)
        );

        _scope.$watch(
            () => this.formState.assetRange,
            this.traceAssetRange.bind(this)
        );

        _scope.$watch(
            () => this.formState.validationResponse,
            this.countSuccessValidation.bind(this)
        )
    }

    private watchForOwnerNames() {
        this._scope.$watch(
            () => this.lookups.OWNER_NAMES,
            this.catchSingleOwnerName.bind(this)
        )

    }

    public initDataRequests(): void {
        this.formState.isLoading = true;
        this.formState.initDataError = false;
        this.formState.error = null;


        const messageTypesQuery = {
            group: 'SSH_KEY_MESSAGE_TYPES'
        }
        this._q.all([
            this._mcsGeneralService.getLookupData(this.neededDataSets),
            this._mcsGeneralService.getMessageTypes(messageTypesQuery),
        ])
            .then(
            response => {
                this.watchForOwnerNames.apply(this);
                angular.extend(
                    this,
                    { lookups: response[0] },
                    { messageTypes: response[1] },
                    {
                        formState: angular.extend(
                            {},
                            this.formState,
                            {
                                isLoading: false
                            }
                        )
                    }
                )
            })
            .catch(error => angular.extend(
                this,
                {
                    formsState: angular.extend(
                        this.formState,
                        {
                            error,
                            isInitDataError: true,
                            isLoading: false
                        }
                    )
                }
            ));

    }

    private initFormRequest(): void {
        this.request = {
            customer: '',
            messageType: '',
            directoryPath: '',
            deviceType: '',
            fileExtension: '',
            roadNumberRanges: 'ALL',
            userName: this._authService.getLoginUserName()
        };
    }

    private initFormState(): void {
        this.formState = {
            assetRange: 'All Assets',
            selectedCustomer: null,
            validated: false,
            applied: false,
            hasErrors: false,
            initDataError: false,
            error: null,
            isLoading: true
        }
    }

    private catchSingleOwnerName() {
        if (this.lookups.OWNER_NAMES.length === 1) {
            const customer = this.lookups.OWNER_NAMES[0];

            this.formState.selectedCustomer = customer;
            this.request.customer = customer.lookupValue;
        }
    }

    private traceSelectedCustomer(customerName) {
        if (!this.lookups || !this.lookups.OWNER_NAMES) return;
        this.formState.selectedCustomer = this.lookups.OWNER_NAMES
            .filter(owner => owner.lookupValue === customerName)[0]

    }

    private traceAssetRange(assetRange) {
        this.request.roadNumberRanges = assetRange === 'All Assets' ? 'ALL' : '';
    }

    private getLoadersNames(mode: string): ILoadersNames {
        return {
            loaderName: mode === 'validate' ? 'isValidationLoading' : 'isApplyLoading',
            loaderFailName: mode === 'validate' ? 'isValidationFail' : 'isApplyFail',
            modePropsName: mode === 'validate' ? 'validated' : 'applied',
            responsePropsName: mode === 'validate' ? 'validationResponse' : 'applyResponse',
            errorsName: mode === 'validate' ? 'validationErrors' : 'applyErrors'
        }
    }
    private prepareFormStateBeforeRequest(formState, loadersNames: ILoadersNames) {
        formState.applied = false;
        formState[loadersNames.modePropsName] = false;
        formState[loadersNames.loaderFailName] = false;
        formState[loadersNames.loaderName] = true
        formState[loadersNames.responsePropsName] = [];
        return formState;
    }

    private getRequestPromise(mode: string, request: ShhKeyTransferRequest) {
        return mode === 'validate' ?
            this._mcsTemplateService.validateSshBasedTemplate(request) :
            this._mcsTemplateService.applySshBasedTemplate(request);
    }

    public submitRequest(request, mode) {
        const loadersNames = this.getLoadersNames(mode)
        this.formState = this
            .prepareFormStateBeforeRequest(
            this.formState,
            loadersNames
            )

        this.getRequestPromise(mode, request)
            .then(this.successHandler.call(this, loadersNames))
            .catch(this.errorsHandler.call(this, loadersNames))
            .finally(this.responseEndHandler.call(this, loadersNames));
    }

    private successHandler(loadersNames: ILoadersNames) {
        return (resp) => {
            const responseData = (loadersNames.modePropsName === 'applied') ?
                resp.data.filter(this.applyDataFilter) :
                resp.data.filter(this.validationDataFilter);

            this.resetErrorHandler.call(this, loadersNames)
            this.formState[loadersNames.responsePropsName] = responseData;
        }
    }


    private errorsHandler(loadersNames: ILoadersNames) {
        return (err) => {
            this.formState.hasErrors = true;
            this.formState[loadersNames.errorsName] = err.data;
            this.formState[loadersNames.loaderFailName] = true;
        }
    }

    private responseEndHandler(loadersNames: ILoadersNames) {
        return (resp) => {
            this.formState[loadersNames.modePropsName] = true;
            this.formState[loadersNames.loaderName] = false;
        }
    }

    private resetErrorHandler(loadersNames: ILoadersNames) {
        if (this.formState[loadersNames.errorsName]) {
            this.formState[loadersNames.errorsName].errorMessage = null;
        }
        this.formState.hasErrors = false;
    }

    private validationDataFilter(item) {
        return true; //TODO: to implementation
    }

    private applyDataFilter(item) {
        return item.status === 'Success';
    }

    private countSuccessValidation(validationResults) {
        console.log(_.find(validationResults, { excludeReason: null }))
        this.formState.isAnyValid = !!_.find(validationResults, { excludeReason: null });

    }

    public openReport(mode) {
        const templateUrl = mode === 'validation' ?
            '/components/src/directives/package-management/mcs-package-mgmt/mcs-ssh-key-transfer-validate-modal.html' :
            '/components/src/directives/package-management/mcs-package-mgmt/mcs-ssh-key-transfer-apply-modal.html';
        this._modalInstance
            .open({
                animation: true,
                templateUrl: templateUrl,
                controller: McsSShKeyTransferValidateModalController,
                controllerAs: 'ctrl',
                scope: this._scope,
                size: 'lg',
                backdrop: 'static',
                resolve: {
                    formState: () => this.formState,
                    mode: () => mode

                }
            });

    }

    public setFormAsUntouched() {
        this.sshKeyTransfer.$setPristine();
        angular.forEach(this.sshKeyTransfer, function (input) {
            if (input && input.hasOwnProperty('$viewValue')) {
                input.$setUntouched();
            }
        })

    }

    private resetForm() {
        this.initFormRequest();
        this.initFormState();
        this.setFormAsUntouched();
        this.formState.isLoading = false;

    }

    public backToPrevious() {
        this._window.history.back();

    }

}


export default angular.module('directive.McsSshKeyTransferControllerModule', [
    McsGeneralServiceModule.name,
    AuthServiceModule.name,
    McsTemplateServiceModule.name
])
    .controller('McsSshKeyTransferControllerModule', McsSshKeyTransferController)