import { IScopeBinder } from './../../../utilities/ScopeBinder';
///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import { IRepositoryPackage } from "../../../services/PackageRepositoryService";

interface IInternalResult extends ng.IScope {
    id: string;
    lookupObjid: string;
    type: string;
    lookupName: string;
    $$hashKey?: number;
}

interface IQnxTemplateRestrictionsScope extends ng.IScope {

    results: IInternalResult[];
    selectLookup(row: any): void;
    selectPair(row: any): void;
    makePairs(): void;
    removePairs(): void;
    pairedRestriction: any;
    selectedLookups: any;
    selectedPairs: any;
    restriction: any;
    isCustomerSelected: boolean;
    readMode: boolean;
    qnxRestrictions: any;
    //checkIfSelected(lookupName, row): void;
    package: any;
}



function QnxTemplateRestrictions($branding: app.branding.IBrandingService, $q: ng.IQService) {
    return {
        templateUrl: $branding.getTemplateUrl('QnxTemplateRestrictions'),
        controller: 'PackageQnxController',
        scope: {
            restriction: '=?',
            pairedRestriction: '=?ngModel',
            statuses: '=?',
            qnxTemplateTypes: '=?templateTypes',
            package: '=?',
            qnxRestrictions: '=?',
            mode: '=?',
            originalPackage: '=?',
            ngDisabled: '='
        },
        link: (scope: IQnxTemplateRestrictionsScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageQnxController) => {
            scope.selectedLookups = [];
            scope.selectedPairs = [];
            scope.results = [];
            scope.readMode = false;

            const removeDuplicates = arr => _.uniq(arr, (item:any) => item.lookupObjid)

            const removeUnnecessarilyFields = (results: IInternalResult[]) =>
                results.map(item => ({
                    id: item.id,
                    lookupObjid: item.lookupObjid
                }))

            const unselectAll = (action?: string) => {
                if (!scope.restriction || !scope.restriction.dataSet) {
                    return false;
                }
                switch(action) {
                    case "make":
                        scope.selectedLookups = [];
                        break;
                    case "remove":
                        scope.selectedPairs = [];
                        break;
                    case "removeAll":
                        scope.selectedPairs = [];
                        scope.restriction.dataSet.forEach(singleDataSet => {
                            singleDataSet.hide = false;
                        });
                        break;
                    default:
                        scope.selectedLookups = [];
                        scope.selectedPairs = [];
                }

                scope.restriction.dataSet
                .forEach(singleDataSet => {
                    singleDataSet.selected = false;
                });

            }

            const select = (selectionArrayName: string, identyId: string) => row => {
                row.selected = !row.selected;
                if (row.selected) {
                    return scope[selectionArrayName].push(row);
                }
                scope[selectionArrayName] = scope[selectionArrayName]
                    .filter(item => item[identyId] !== row[identyId]);

            }

            const checkCustomerSelection = () => {
                const customerId = '4';
                return scope.results.reduce((prev, curr) => {
                    if (curr.id === customerId) {
                        return true;
                    }
                }, false);
            }

            const getCustomerData = () => _.find(scope.results, { id: '4'})

            const emitGlobalEvent = newState => {
                const customer = getCustomerData()
                scope.$parent.$parent.$emit('restrictionCustomerSelectChange', newState, customer);
                scope.$parent.$parent.$broadcast('restrictionCustomerSelectChange', newState, customer);
            }


            scope.selectLookup = select('selectedLookups', 'lookupObjid');
            scope.selectPair = select('selectedPairs', '$$hashKey');

            scope.makePairs = () => {
                let newSelection = scope.selectedLookups
                    .map(lookup => ({
                        id: scope.restriction.id,
                        lookupObjid: lookup.lookupObjid,
                        type: scope.restriction.type,
                        lookupName: lookup.lookupName
                    }))
                scope.results = removeDuplicates(
                    [...scope.results, ...newSelection]
                );

                scope.pairedRestriction = removeUnnecessarilyFields(scope.results);
                checkIfSelected(true, scope.selectedLookups);
                scope.isCustomerSelected = checkCustomerSelection();
                unselectAll("make");
            }

            scope.removePairs = () => {
                scope.results = scope.results.filter(
                    pair => scope.selectedPairs
                        .filter(selected => pair.$$hashKey === selected.$$hashKey)
                        .length === 0

                );
                scope.pairedRestriction = removeUnnecessarilyFields(scope.results);
                checkIfSelected(false, scope.selectedPairs);
                scope.isCustomerSelected = checkCustomerSelection();
                unselectAll("remove");
            }

            const removeAllPairsWhenServiceTemplate = () => {
                if (!scope.readMode && scope.package.templateType) {
                    if(scope.package.templateType.objid == 11) {
                      scope.results = [];
                      scope.isCustomerSelected = checkCustomerSelection();
                      unselectAll("removeAll");
                    }
                }
            }

            const getCaptions = pair => {
                const restriction = _.findWhere(scope.qnxRestrictions, {id: pair.id});
                const lookup = _.findWhere(restriction["dataSet"], { lookupObjid: pair.lookupObjid });
                return {
                    type: _.property('type')(restriction),
                    lookupName: _.property('lookupName')(lookup)
                };
            }

            const readMode = (editedPair) =>  {
                scope.readMode = true;
                scope.results = editedPair.map(pair => angular.extend({}, pair, getCaptions(pair)))
                scope.pairedRestriction = removeUnnecessarilyFields(scope.results)
                scope.isCustomerSelected = checkCustomerSelection();
                checkIfSelected(true, scope.pairedRestriction); //hide selected fields while template edition
                unselectAll();
            }

            const checkIfSelected = (setStatus, selections) => {
                if(selections && selections.length > 0) {
                  _.each(scope.qnxRestrictions, (restrictions: any) => {  // need to check all dataSets, from all restricions, cause user could remove pair for different restrictions at once
                    _.each(restrictions.dataSet, (dataSet: any) => {
                      _.each(selections, (selection: any) => {
                          if(selection.lookupObjid == dataSet.lookupObjid) {
                              dataSet["hide"] = setStatus;
                          }
                      });
                    });
                  });

                }
            }

            scope.$watch('isCustomerSelected', emitGlobalEvent);
            scope.$watch('restriction', unselectAll);
            scope.$watch('package.templateType.templateType', removeAllPairsWhenServiceTemplate);

            let waitForRestriction = $q.defer();
            let unWatchScope = scope.$watch('qnxRestrictions', (restriction: Array<any>) => {
                if (restriction.length > 0) {
                    waitForRestriction.resolve(restriction);
                    unWatchScope();
                }
            });

            if (scope.pairedRestriction) {
                waitForRestriction.promise.then(readMode.bind(null, scope.pairedRestriction));
            }

        }
    }
}

export default angular.module('directives.packageManagement.qnxTemplateRestrictions', [PackageQnxControllerModule.name])
    .directive("qnxTemplateRestrictions", ['$branding', '$q', QnxTemplateRestrictions]);
