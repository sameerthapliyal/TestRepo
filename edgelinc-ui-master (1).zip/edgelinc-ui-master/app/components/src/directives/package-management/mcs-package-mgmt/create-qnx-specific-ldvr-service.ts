///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import {IRepositoryPackage} from "../../../services/PackageRepositoryService";

interface ICreateQnxGenericPackageDirectiveScope extends IPackageQnxControllerScope {
    onBackToList(): void;
    package: any;
    templates: {
        name: string;
    }[];
    empPortMessage: string;
}

function CreateQnxSpecificLdvrServiceDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('CreateQnxPackageLdvrServiceDirective'),
        scope: {
            onBackToList: '&',
            package: '=',
            statuses: '=',
            qnxTemplateTypes: "=templateTypes",
            mode: "=?",
            originalPackage: '=?'
        },
        link: (scope: ICreateQnxGenericPackageDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes) => {

            scope.$watch("package.itcmEnabled", (newITCMState: boolean) => {
                if(newITCMState) {   //if itcm checked set valid state
                    setValidState();
                } else {             //if itcm unchecked then empNetworkAddress and appGatewayPort should be null, except Obsolete and Approved state
                  if(scope.originalPackage) {
                        if(scope.originalPackage.status != "Obsolete" && scope.originalPackage.status != "Approved") {
                            scope.package.empNetworkAddress = null;
                            scope.package.appGatewayPort = null;
                        }
                  } else {
                    scope.package.empNetworkAddress = null;
                    scope.package.appGatewayPort = null;
                  }
                }
            });

            scope.$watch("package.empNetworkAddress", (newEmpNetwork: any) => {
                if(scope.package.itcmEnabled) {
                  if(typeof(newEmpNetwork) != "undefined") {
                      checkValidateTwoFields(newEmpNetwork, scope.package.appGatewayPort);
                  } else {
                      setValidState();
                  }
                }
            });

            scope.$watch("package.appGatewayPort", (newAppGatewayPort: any) => {
                if(scope.package.itcmEnabled) {
                    checkValidateTwoFields(newAppGatewayPort, scope.package.empNetworkAddress);
                }
            });

            var checkValidateTwoFields = (firstField: any, secondField: any) => {
                if((firstField && !secondField) || (!firstField && secondField)) {
                    setInvalidState();
                } else {
                    setValidState();
                }
            }

            var setInvalidState = () => {
                scope.empPortMessage = "It is necessary that either both 'EMP Network Address' and 'Application Gateway Port' are provided, or both are empty";
                scope.package.empAndPortAreInvalid = true;
            }

            var setValidState = () => {
                scope.empPortMessage = "";
                scope.package.empAndPortAreInvalid = false;
            }
        }
    }
}

export default angular.module('createQnxSpecificLdvrServicePackage', [PackageQnxControllerModule.name])
    .directive("createQnxSpecificLdvrServicePackage", ['$branding', CreateQnxSpecificLdvrServiceDirective]);
