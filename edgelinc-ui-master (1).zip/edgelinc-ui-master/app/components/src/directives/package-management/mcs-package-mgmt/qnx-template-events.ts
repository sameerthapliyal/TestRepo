///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import { IRepositoryPackage } from "../../../services/PackageRepositoryService";

interface ILookupDataSet {
    lookupObjid: number;
    lookupName:string;
    lookupValue:string;
    lookupOrder:number;
    parentLookupObjid?: number;
    parentLookupName?:string
}
interface IInput {
    mpConditions: ILookupDataSet[];
    mpParameters: ILookupDataSet[];
}

interface INewEvent {
    mpOperator?: number;
    mpParams?: number;
    mpValue?: string
}


interface IInternalResult extends ng.IScope {
    id: string;
    lookupObjid: string;
    type: string;
    lookupName: string,
     
}

interface IEventOutput {
    preTriggerAndPostTrigger: any;
    mps: INewEvent[];
}


interface IqnxTemplateEventsScope extends ng.IScope {

    output: IEventOutput;
    input: IInput;
    events: INewEvent[]; 
    newEvent: INewEvent;
    selectLookup(row: any): void;
    selectPair(row: any): void;
    makePairs(): void;
    removePairs(): void;
    addNewEvent(event: INewEvent): void;
    deleteEvent(index: number): void;
    getParamName(objid: number): string;
    getOperatorName(objid: number): string;


} 



function QnxTemplateEvents($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('qnxTemplateEvents'),
        controller: 'PackageQnxController',
        scope: {
            input: '=lookupData',
            output: '=ngModel',
            ngDisabled: "="
        },
        link: (scope: IqnxTemplateEventsScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageQnxController) => {

            const get = paramTypes => lookupObjid => 
                !!scope.input[paramTypes] ?
                scope.input[paramTypes]
                    .reduce(
                        (prev, curr) => lookupObjid == curr.lookupObjid ?
                            prev + curr.lookupName :
                            prev + '' , ''
                    ) : 
                null;
            
            function extractOnly<T>(indexArray):(obj:any)=>T {
                return function(obj) {
                    let newObj:T = <any>{};
                    indexArray.forEach(item => {
                        if(obj[item]) {
                            newObj[item] = obj[item];
                        };
                    });
                    return newObj;
                }
            }
            
            

            const extractOnlyMpsParams = extractOnly<INewEvent>(['mpParams', 'mpOperator', 'mpValue']);

            const initDirective = () => {
                scope.output = scope.output || {preTriggerAndPostTrigger: null, mps: []};
                scope.output.mps = scope.events = scope.output.mps.map(extractOnlyMpsParams) || [];
                scope.output = {
                    preTriggerAndPostTrigger: parseInt(scope.output.preTriggerAndPostTrigger) || 1,
                    mps: scope.events
                };
            }

            scope.addNewEvent = newEvent => {
                const clone = _.extend({}, newEvent);
                scope.events.push(clone);
                scope.newEvent = {};

            }

            scope.deleteEvent = index => {
                scope.events.splice(index, 1);
            }



            scope.getParamName = get('mpParameters');
            scope.getOperatorName = get('mpConditions');

            initDirective();
        }
    }
}

export default angular.module('directives.packageManagement.qnxTemplateEvents', [PackageQnxControllerModule.name])
    .directive("qnxTemplateEvents", ['$branding', QnxTemplateEvents]);
