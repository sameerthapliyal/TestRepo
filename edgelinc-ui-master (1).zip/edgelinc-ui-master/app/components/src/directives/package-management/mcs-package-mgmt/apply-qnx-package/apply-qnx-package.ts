///<reference path="../../../../../../../typings/browser.d.ts"/>
import DeviceServiceModule, { DeviceService } from "../../../../services/DeviceService";
import McsGeneralServiceModule, { McsGeneralService } from "../../../../services/mcs/McsGeneralService";
import McsTemplateServiceModule, { McsTemplateService } from "../../../../services/mcs/mcsTemplateService";
import McsSystemParametersServiceModule, { McsSystemParametersService } from "../../../../services/mcs/McsSystemParametersService";


import _ from 'lodash';

enum Step {
  templatesSelection,
  locomotivesSelection,
  apply,
  sent
}

interface IApplyPackageDirectiveScope extends ng.IScope {
  wizard: {
    steps: any,
    step: Step,
    apply(): void,
    proceed(): void,
    cancel(): void,
    back(): void
  },
  isLoading: {
    templateList: boolean,
    templateValidation: boolean,
    assetValidation: boolean,
    dataSets: boolean,
    apply: boolean
  },
  error: {
    general: string,
    templateValidation: boolean,
    assetValidation: boolean,
    apply: boolean
  },
  checkedTemplates: {
    selectionAdd: any,
    selectionRemove: any[],
    visibleTemplates: any[],
    hasTemplates: boolean,
    pipe(tableState: any, tableCtrl: any): void
  },
  appliedTo: {
    visibleLocomotives: any[],
    pipe(tableState: any, tableCtrl: any): void;
  },
  locoForm: ng.IFormController,
  locoModel: {
    customer: string,
    customerID: string,
    from: number,
    to: number,
    device: string
  },
  selectedTemplates: any[],
  appliedTemplates: any[],
  skipTemplates: any[],
  selectedLocomotives: IMCSLocomotive[],
  showTemplates: boolean,
  visible: {},
  filtered: {},
  qnxListFilter: {},
  offset: {},
  lookupData: {},
  maxRange: any,
  fn: {
    clearFilters(): void
    listTemplates(): void,
    addTemplate(): void,
    removeTemplates(): void,
    removeTemplate(template): void,
    addLocomotives(): void,
    removeLocomotive(loco): void
  }
  onBackToList(): void,
  templateTypeChange(): void
  templateChanged: {
      isChanged?: boolean;
  }
}

interface IMCSLocomotive {
  customerName: string,
  details: any[],
  roadInitial: string,
  allExcluded: string,
  deviceType: string,
  roadNumberFrom: string,
  roadNumberTo: string,
  warningDetected: string
}

interface ModalApplyCtrlScope extends ng.IScope {
  close(): void,
  data: IMCSLocomotive,
  filteredDetails: any[],
  excludedPipe(tableState: any, tableCtrl: any): void,
  warningPipe(tableState: any, tableCtrl: any): void
}

class ApplyQnxPackageController {
  public static $inject = ['$scope', 'DeviceService', 'McsGeneralService', 'McsTemplateService', 'McsSystemParametersService'];
  private selectedTemplates = [];
  private selectedLocomotives = [];
  private templateTypeChanged = false;
  private restrictionsChanged = false;
  private defaultValues = {};
  private appliedTo = [];
  constructor(private $scope: IApplyPackageDirectiveScope,
    private DeviceService: DeviceService,
    private McsGeneralService: McsGeneralService,
    private McsTemplateService: McsTemplateService,
    private McsSystemParametersService: McsSystemParametersService) {
    //$scope.$on('restrictionCustomerSelectChange', () => this.restrictionsChanged = true);
    $scope.templateTypeChange = () => this.templateTypeChanged = true;
    $scope.wizard = {
      steps: Step,
      step: Step.templatesSelection,
      apply: () => this.apply(),
      proceed: () => this.proceed(),
      cancel: () => this.cancel(),
      back: () => this.back()
    };
    $scope.isLoading = {
      templateList: false,
      templateValidation: false,
      assetValidation: false,
      dataSets: false,
      apply: false
    };
    $scope.checkedTemplates = {
      selectionAdd: null,
      selectionRemove: [],
      visibleTemplates: [],
      pipe: (tableState: any, tableCtrl: any) => this.selectedTemplatesPipe(tableState, tableCtrl),
      hasTemplates: false
    };
    $scope.appliedTo = {
      visibleLocomotives: [],
      pipe: (tableState: any, tableCtrl: any) => this.appliedToPipe(tableState, tableCtrl),
    };
    $scope.error = {
      general: '',
      templateValidation: false,
      assetValidation: false,
      apply: false
    };
    $scope.locoModel = {
      customer: '',
      customerID: '',
      from: null,
      to: null,
      device: ''
    },
      $scope.selectedTemplates = [];
    $scope.selectedLocomotives = [];
    $scope.showTemplates = false;
    $scope.offset = {};
    $scope.visible = {};
    $scope.filtered = {};
    $scope.lookupData = {};
    $scope.templateChanged = {}; // if template changed, then pagination set as 0
    $scope.qnxListFilter = {
      status: "Approved"
    };
    $scope.fn = {
      clearFilters: () => this.clearFilters(),
      listTemplates: () => this.listTemplates(),
      addTemplate: () => this.addTemplate(),
      removeTemplates: () => this.removeTemplates(),
      removeTemplate: template => this.removeTemplate(template),
      addLocomotives: () => this.addLocomotives(),
      removeLocomotive: loco => this.removeLocomotive(loco)
    };
    $scope.$watch('locoModel.customer', () => this.rangeValidate());
    $scope.$watch('locoModel.customerID', () => this.rangeValidate());
    this.getMaxRange()
      .then(range => {
        $scope.maxRange = range && range[0] ? range[0].parameterValue : 500
      })
      .catch(err => {
        console.error(err);
        $scope.maxRange = 500;
      });

    $scope.$watch("qnxListFilter.templateOnlyAppliesToArray", (templateRestriction:any)=>{
        this.restrictionsChanged = true;
    });
  }

  private listTemplates() {
    this.templateTypeChanged === true ? this.$scope.error.templateValidation = false : null;
    this.restrictionsChanged === true ? this.removeAllTemplates() : null;
    this.$scope.showTemplates = true;
    this.$scope.templateChanged.isChanged = this.templateTypeChanged;
    this.$scope.$broadcast('smartTable:refreshRequired');
    this.templateTypeChanged = false;
    this.restrictionsChanged = false;
  }

  private selectedTemplatesPipe(tableState, tableCtrl) {
    const limit = tableState.pagination.number;
    const offset = tableState.pagination.start;
    this.$scope.checkedTemplates.visibleTemplates = this.selectedTemplates.slice(offset, offset + limit);
    tableState.pagination.totalItemCount = this.selectedTemplates.length;
  }

  private appliedToPipe(tableState, tableCtrl) {
    const limit = tableState.pagination.number;
    const offset = tableState.pagination.start;
    this.$scope.appliedTo.visibleLocomotives = this.appliedTo.slice(offset, offset + limit);
    tableState.pagination.totalItemCount = this.appliedTo.length;
  }

  private getLookupData(dataSetNames: string[]): ng.IPromise<any> {
    return this.McsGeneralService.getLookupData(dataSetNames);
  }

  private getMaxRange() {
    return this.McsSystemParametersService.getSystemParameters(['APPLY_TEMP_MAX_RN_RANGE']);
  }

  private getDataSets() {
    this.getLookupData(['OWNER_NAMES', 'ROAD_INITIALS', 'ASSET_DEVICES'])
      .then(result => {
        this.$scope.lookupData = {
          ownerNames: result['OWNER_NAMES'],
          roadInitials: result['ROAD_INITIALS'],
          assetDevices: result['ASSET_DEVICES']
        }
      })
      .catch(err => {
        console.error(err)
        this.$scope.error.general = err.data.errorMessage || 'An error has occured.';
      });
  }

  private clearErrors() {
    this.$scope.error.general = '';
    this.$scope.error.templateValidation = false;
    this.$scope.error.assetValidation = false;
    this.$scope.error.apply = false;
  }

  private clearFilters() {
    this.$scope.qnxListFilter = {
      status: "Approved"
    }
  }

  private addTemplate() {
    const current = this.selectedTemplates;
    const selection = this.$scope.checkedTemplates.selectionAdd;
    const list = _.map(this.selectedTemplates, 'tempObjid');
    if (!_.some(current, t => t.tempObjid === selection.tempObjid)) {
      this.$scope.isLoading.templateValidation = true;
      this.validateTemplateList(list, selection.tempObjid)
        .then(valid => {
          let clone = _.clone(selection);
          this.selectedTemplates.push(clone)
          this.$scope.$broadcast('selectedTemplates:refresh');
          this.$scope.checkedTemplates.hasTemplates = this.selectedTemplates.length > 0;
          this.$scope.selectedTemplates = this.selectedTemplates;
          this.$scope.error.templateValidation = false;
        })
        .catch(err => {
          this.$scope.error.templateValidation = true;
          this.$scope.error.general = err.data ? err.data.errorMessage : '';
          this.$scope.checkedTemplates.selectionAdd = null;
        })
        .then(() => {
          this.$scope.isLoading.templateValidation = false
        })
    }
  }

  private removeTemplates() {
    this.selectedTemplates = _.difference(this.selectedTemplates, this.$scope.checkedTemplates.selectionRemove);
    this.$scope.checkedTemplates.hasTemplates = this.selectedTemplates.length > 0;
    this.$scope.selectedTemplates = this.selectedTemplates;
    this.$scope.checkedTemplates.selectionRemove = null;
    this.$scope.error.templateValidation = false;
    this.$scope.$broadcast('selectedTemplates:refresh');
  }

  private removeTemplate(template) {
    this.selectedTemplates = _.reject(this.selectedTemplates, template)
    this.$scope.selectedTemplates = this.selectedTemplates;
    this.$scope.checkedTemplates.hasTemplates = this.selectedTemplates.length > 0;
    this.$scope.$broadcast('selectedTemplates:refresh');
    if (!this.$scope.checkedTemplates.hasTemplates) this.back();
  }

  private removeAllTemplates() {
    this.selectedTemplates = [];
  }

  private validateTemplateList(list, sel) {
    return new Promise((resolve, reject) => {
      if (list.length > 0) {
        const data = {
          existingTemplateObjidList: list.toString(),
          newTemplateObjid: sel
        };
        this.McsTemplateService.buildTemplateListToApply(data)
          .then(result => {
            return resolve(true)
          })
          .catch(err => reject(err))
      }
      else {
        return resolve(true)
      }
    })
  }

  private addLocomotives() {
    this.$scope.isLoading.assetValidation = true;
    this.$scope.locoForm.$pending = true;
    this.validateLocomotives()
      .then(result => {
        this.selectedLocomotives.push(result)
        this.$scope.selectedLocomotives = this.selectedLocomotives;
        this.$scope.error.assetValidation = null;
        this.$scope.isLoading.assetValidation = false;
        this.$scope.locoModel = {
          customer: null,
          customerID: null,
          from: null,
          to: null,
          device: this.$scope.locoModel.device
        }
      })
      .catch(err => {
        this.$scope.locoForm.$pending = false;
        this.$scope.error.assetValidation = err.data.errorMessage || 'An error has occured.';
        this.$scope.isLoading.assetValidation = false;
      })
  }

  private removeLocomotive(loco) {
    this.selectedLocomotives = _.reject(this.selectedLocomotives, loco);
    this.$scope.selectedLocomotives = this.selectedLocomotives;
  }

  private validateLocomotives() {
    const model = this.$scope.locoModel;
    const data = {
      templateObjidList: _.map(this.selectedTemplates, 'tempObjid').toString(),
      roadNumberRange: `${model.customer},${model.customerID},${model.from},${model.to || model.from}`,
      deviceType: model.device
    }
    return this.McsTemplateService.buildAssetListForTemplates(data);
  }

  private applyTemplates() {
    const roadNumberRanges = this.selectedLocomotives.reduce((prev, curr, i, arr) => {
      return prev + `${curr.customerName},${curr.roadInitial},${curr.roadNumberFrom},${curr.roadNumberTo};`
    }, '');
    const deviceType = this.$scope.locoModel.device;
    const request = {
      templateObjidList: _.map(this.selectedTemplates, 'tempObjid').toString(),
      roadNumberRanges,
      deviceType
    }
    this.$scope.isLoading.apply = true;
    this.McsTemplateService.applyTemplates(request)
      .then(response => {
        this.$scope.isLoading.apply = false;
        this.$scope.wizard.step = Step.sent;
        this.$scope.appliedTemplates = response.applyTemplates;
        this.$scope.skipTemplates = response.skipTemplates;
        if (response.applyTemplates && response.applyTemplates.length > 0) {
          const locomotives = _.reduce(response.applyTemplates, (res, val: any, key) => {
            (res[val.roadInitial] || (res[val.roadInitial] = [])).push(val.roadNumber)
            return res;
          }, []);
          return this.getLocomotivesInfo(locomotives);
        }
      })
      .then(locomotives => {
        if (!locomotives) return;
        const ret = locomotives.reduce((prev, curr) => curr.items, []);
        this.appliedTo = ret;
        this.$scope.$broadcast('appliedTo:refresh');
      })
      .catch(err => {
        this.$scope.isLoading.apply = false;
        this.$scope.error.apply = true;
        this.$scope.error.general = err.data.errorMessage || 'An error has occured.'
      })
  }

  private getLocomotivesInfo(locomotives): any {
    let promises = [];
    for(let customer in locomotives) {
      if(locomotives.hasOwnProperty(customer)) {
        promises.push(new Promise((resolve, reject) => {
          this.DeviceService.getSystems({numericLocoId: {arr: locomotives[customer]}, attributes: {'customer_id': customer}})
              .then(res => resolve(res))
              .catch(err => reject(err))
        }))
      }
    }
    return Promise.all(promises)
  }

  private rangeValidate() {
    this.$scope.locoForm['from'].$validate();
  }

  /* Wizard */

  private apply() {
    this.$scope.wizard.step = Step.apply;
    this.applyTemplates()
  }

  private proceed() {
    this.getDataSets();
    this.$scope.wizard.step++;
  }

  private cancel() {
    this.$scope.$destroy()
    this.$scope.onBackToList();
  }

  private back() {
    this.$scope.wizard.step--;
    this.clearErrors();
  }
}

class ModalApplyDialogCtrl {
  allExcluded = [];
  allWarnings = [];
  scope = null;
  constructor($scope: ModalApplyCtrlScope, $uibModalInstance: ng.ui.bootstrap.IModalServiceInstance, data) {
    this.scope = $scope;
    $scope.data = data;
    $scope.excludedPipe = (tableState: any, tableCtrl: any) => this.selectedExcludedPipe(tableState, tableCtrl);
    $scope.warningPipe = (tableState: any, tableCtrl: any) => this.selectedWarningPipe(tableState, tableCtrl);
    this.allExcluded = data.details.filter(d => d.excluded === 'Y');
    this.allWarnings = data.details.filter(d => d.excluded === 'N' && d.warning);
    $scope.close = function() {
      $uibModalInstance.close();
    }
  }

  private selectedExcludedPipe(tableState, tableCtrl) {
    const limit = tableState.pagination.number;
    const offset = tableState.pagination.start;
    const maxRange = offset + limit;
    this.scope.totalCountE = this.allExcluded.length;
    this.scope.visibleExcluded = this.allExcluded.slice(offset, offset + limit);
    this.scope.fromE = offset + 1;
    this.scope.toE = maxRange < this.scope.totalCountE ? maxRange : this.scope.totalCountE;
    tableState.pagination.totalItemCount = this.allExcluded.length;
  }

  private selectedWarningPipe(tableState, tableCtrl) {
    const limit = tableState.pagination.number;
    const offset = tableState.pagination.start;
    const maxRange = offset + limit;
    this.scope.totalCountW = this.allWarnings.length;
    this.scope.visibleWarnings = this.allWarnings.slice(offset, offset + limit);
    this.scope.fromW = offset + 1;
    this.scope.toW = maxRange < this.scope.totalCountW ? maxRange : this.scope.totalCountW;
    tableState.pagination.totalItemCount = this.allWarnings.length;
  }
}

function ApplyQnxPackageDirective($branding: app.branding.IBrandingService, $uibModal: ng.ui.bootstrap.IModalService) {
  return {
    templateUrl: $branding.getTemplateUrl('ApplyQnxPackageDirective'),
    controller: 'ApplyQnxPackageController',
    scope: {
      onBackToList: '&'
    },
    link: function(scope, el, attrs) {
      scope.openModal = function(data) {
        var modalInstance = $uibModal.open({
          animation: scope.animationsEnabled,
          templateUrl: $branding.getTemplateUrl('ApplyQnxModal'),
          controller: ModalApplyDialogCtrl,
          size: 'lg',
          backdrop: true,
          resolve: {
            data: () => data
          }
        });
      }
    }
  }
}

function locoRangeValidator() {
  return {
    require: 'ngModel',
    link: function(scope, el, attr, ctrl) {
      ctrl.$validators.minmax = function(modelValue, viewValue) {
        const val = viewValue || 1;
        return val <= 999999 && val >= 1
      }
      ctrl.$validators.range = function(modelValue, viewValue) {
        if (ctrl.$pristine) return true;
        const from = scope.locoModel.from;
        const to = scope.locoModel.to;
        if ((-(from - to) >= 0 && -(from - to) <= scope.maxRange) || to === null) {
          scope.locoForm.to.$setValidity('range', true);
          scope.locoForm.from.$setValidity('range', true);
          return true;
        }
        else {
          scope.locoForm.to.$setValidity('range', false);
          scope.locoForm.from.$setValidity('range', false);
          return false;
        }
      }
      ctrl.$validators.unique = function(modelValue, viewValue) {
        const customer = scope.locoModel.customer;
        const customerID = scope.locoModel.customerID;
        const from = +scope.locoModel.from;
        const to = +scope.locoModel.to || from;
        const sel = scope.selectedLocomotives;
        if (!customer || !customerID) return true;
        for (let i = 0, len = sel.length; i < len; ++i) {
          if (customer != sel[i].customerName || customerID != sel[i].roadInitial) continue;
          if (_.inRange(from, sel[i].roadNumberFrom, sel[i].roadNumberTo) ||
            _.inRange(to, sel[i].roadNumberFrom, sel[i].roadNumberTo) ||
            _.inRange(sel[i].roadNumberFrom, from, to) ||
            _.inRange(sel[i].roadNumberTo, from, to) ||
            from === +sel[i].roadNumberFrom ||
            from === +sel[i].roadNumberTo) {
            scope.locoForm.to.$setValidity('unique', false);
            scope.locoForm.from.$setValidity('unique', false);
            return false;
          }
        }
        scope.locoForm.to.$setValidity('unique', true);
        scope.locoForm.from.$setValidity('unique', true);
        return true;
      }
    }
  }
}


export default angular.module('applyQnxPackage', [DeviceServiceModule.name, McsGeneralServiceModule.name, McsTemplateServiceModule.name, McsSystemParametersServiceModule.name])
  .controller('ApplyQnxPackageController', ApplyQnxPackageController)
  .directive('applyQnxPackage', ['$branding', '$uibModal', ApplyQnxPackageDirective])
  .directive('locoRangeValidator', [locoRangeValidator]);
