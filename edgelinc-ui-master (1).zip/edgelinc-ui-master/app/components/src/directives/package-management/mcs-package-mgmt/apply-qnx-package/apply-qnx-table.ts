interface IApplyQnxTableDirectiveScope extends ng.IScope {

}

// class ApplyQnxTableController {
//   private static $inject = ['$scope'];
//   constructor(private $scope: IApplyQnxTableDirectiveScope) {
//     debugger
//   }
// }

function ApplyQnxTableDirective($branding: app.branding.IBrandingService) {
  return {
    templateUrl: (elem, attr) => {
        if(attr.template && attr.template.length) {
            return `/components/src/directives/package-management/mcs-package-mgmt/apply-qnx-package/${attr.template}.html`
        } else {
            return `/components/src/directives/package-management/mcs-package-mgmt/apply-qnx-package/apply-qnx-table.html`
        }
    },
    restrict: "E",
    scope: {
      selectedTemplates: '=?',
      selectedLocomotives: '=?',
      appliedTo: '=?',
      removeEnable: '=?',
      disabled: '=?',
      openModal: '&',
      remove: '&'
    }
  }
}

export default angular.module('directives.applyQnxTable', [])
  .directive('applyQnxTable', ['$branding', ApplyQnxTableDirective])
