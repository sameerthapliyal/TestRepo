import McsSshKeyTransferControllerModule, { McsSshKeyTransferController } from './McsSshKeyTransferController';
import SshRoadInitialModule from './mcs-ssh-road-initials'



const mcsSshKeyTransferDirective = ($branding: app.branding.IBrandingService) => ({
    restrict: "E",
    replace: true,
    scope: true,
    controller: McsSshKeyTransferController,
    templateUrl: $branding.getTemplateUrl('directives.McsSshKeyTransfer'),
    controllerAs: 'ctrl'
});


export default angular.module('directives.McsSshKeyTransfer', [
    McsSshKeyTransferControllerModule.name,
    SshRoadInitialModule.name
])
    .directive('mcsSshKeyTransfer', ['$branding', mcsSshKeyTransferDirective]);