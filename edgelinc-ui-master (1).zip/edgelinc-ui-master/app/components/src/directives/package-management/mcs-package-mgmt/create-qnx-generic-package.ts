///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import {IRepositoryPackage, IRepositoryQnxPackage} from "../../../services/PackageRepositoryService";

interface ICreateQnxGenericPackageDirectiveScope extends IPackageQnxControllerScope {
    onBackToList(): void;
    onEdit(args: {packageId: string, packageVersion: string, templateType: string;}): void;
    package: any;
    templates: {
        name: string;
    }[];
}

function CreateQnxGenericPackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('CreateQnxGenericPackageDirective'),
        scope: {
            onBackToList: '&',
            //onEdit: '&',
            package: '=',
            statuses: '=',
            qnxTemplateTypes: "=templateTypes",
            mode: '=?',
            originalPackage: '=?'
        }
    }
}

export default angular.module('directives.packageManagement.createQnxGenericPackage', [PackageQnxControllerModule.name])
    .directive("createQnxGenericPackage", ['$branding', CreateQnxGenericPackageDirective]);
