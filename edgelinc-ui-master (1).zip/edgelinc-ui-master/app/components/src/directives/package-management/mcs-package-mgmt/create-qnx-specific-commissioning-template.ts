///<reference path="../../../../../../typings/browser.d.ts"/>

import PackageQnxControllerModule, {
    PackageQnxController,
    IPackageQnxControllerScope
} from "./PackageQnxController";
import {IRepositoryPackage} from "../../../services/PackageRepositoryService";

interface ICreateQnxGenericPackageDirectiveScope extends IPackageQnxControllerScope {
    onBackToList(): void;
    package: any;
    templates: {
        name: string;
    }[];
}

function CreateQnxSpecificCommissioningPackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('CreateQnxPackageCommissioningDirective'),
        scope: {
            onBackToList: '&',
            onEdit: '&',
            package: '=',
            statuses: '=',
            qnxTemplateTypes: '=templateTypes',
            selectedTemplatesList: '=',
            mode: '=?',
            originalPackage: '=?'
        }
    }
}

export default angular.module('directives.packageManagement.createQnxSpecificCommissioningPackage', [PackageQnxControllerModule.name])
    .directive("createQnxSpecificCommissioningPackage", ['$branding', CreateQnxSpecificCommissioningPackageDirective]);
