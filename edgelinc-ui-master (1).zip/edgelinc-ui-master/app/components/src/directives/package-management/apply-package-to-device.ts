///<reference path="../../../../../typings/browser.d.ts"/>
// obsolete directive - it hasn't been finish
/*
import PackageRepositoryServiceModule, {
    PackageRepositoryService, IRepositoryPackage,
    IRepositoryPackageFilter
} from "../../services/PackageRepositoryService";
import {IRepositoryPackageDisplay} from "./packages-list/packages-table";

enum Step {
    packageSelection,
    deviceSelection,
    finalize,
    confirmation
}

interface IApplyPackageToDeviceDirectiveScope extends ng.IScope {
    devAsdid: string;
    listFilter: IRepositoryPackageFilter;
    packages: {
        selectedPackage: IRepositoryPackageDisplay;
        applied: boolean;
    }
    selectPackage(repositoryPackage: IRepositoryPackageDisplay): void;
    applyPackage(): void;
    clear(): void;
}

class ApplyPackageToDeviceController {
    public static $inject = ['$scope', 'PackageRepositoryService'];
    constructor(
        private $scope: IApplyPackageToDeviceDirectiveScope,
        private PackageRepositoryService: PackageRepositoryService
    ) {
        $scope.listFilter = {
            validForAsdid: $scope.devAsdid
        };
        $scope.packages = {
            selectedPackage: null,
            applied: false
        };
        $scope.selectPackage = (repositoryPackage: IRepositoryPackageDisplay) => this.selectPackage(repositoryPackage);
        $scope.applyPackage = () => this.applyPackage();
        $scope.clear = () => this.clear();
    }

    private selectPackage(repositoryPackage: IRepositoryPackageDisplay): void {
        this.$scope.packages.selectedPackage = repositoryPackage;
    }

    private applyPackage(): void {
        this.PackageRepositoryService.applyPackage(this.$scope.packages.selectedPackage.packageId, this.$scope.packages.selectedPackage.templateType, this.$scope.packages.selectedPackage.version, [this.$scope.devAsdid])
            .then(() => {
                this.$scope.packages.applied = true;
            });
    }

    private clear(): void {
        this.$scope.packages.applied = false;
        this.$scope.packages.selectedPackage = null;
    }
}

function ApplyPackageToDeviceDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('ApplyPackageToDeviceDirective'),
        controller:'ApplyPackageToDeviceController',
        scope: {
            devAsdid: "="
        }
    }
}
*/
// obsolete directive - it hasn't been finish
/*
export default angular.module("directives.packageManagement.applyPackageToDevice", [PackageRepositoryServiceModule.name])
    .controller("ApplyPackageToDeviceController", ApplyPackageToDeviceController)
    .directive("applyPackageToDevice", ['$branding', ApplyPackageToDeviceDirective]);
*/