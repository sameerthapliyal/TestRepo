///<reference path="../../../../../typings/browser.d.ts"/>

import PackageEditControllerModule, {
    PackageEditController,
    IPackageEditControllerScope
} from "./PackageEditController";
import {IRepositoryPackage} from "../../services/PackageRepositoryService";



interface IRevisePackageDirectiveScope extends IPackageEditControllerScope {
    onBackToList(): void;
    onEdit(args: {packageId: string, packageVersion: string, templateType: string;}): void;
    onRevise(args: {packageId: string, packageVersion: string, templateType: string}): void;
}

function RevisePackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('RevisePackageDirective'),
        controller: 'PackageEditController',
        scope: {
            packageId: '=',
            packageVersion: '=',
            templateType: '=',
            onBackToList: '&',
            onEdit: '&',
            onRevise: '&'
        },
        link: (scope: IRevisePackageDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PackageEditController) => {
            ctrl.onBackToList = () => scope.onBackToList();
            ctrl.onEdit = (repositoryPackage: IRepositoryPackage) => scope.onEdit({packageId: repositoryPackage.packageId, packageVersion: repositoryPackage.version, templateType: repositoryPackage.templateType});
            ctrl.onRevise = (repositoryPackage: IRepositoryPackage) => scope.onRevise({packageId: repositoryPackage.packageId, packageVersion: repositoryPackage.version, templateType: repositoryPackage.templateType});
            ctrl.initialize("REVISE | VIEW");

            ctrl.emptyPackageFactory = (originalPackage: IRepositoryPackage) => {
                return {
                    packageId: originalPackage.packageId,
                    version: originalPackage.version,
                    templateType: {
                        name: originalPackage.templateType,
                        device_enum: originalPackage.deviceEnum,
                        package_type: originalPackage.packageType,
                        config: originalPackage.config
                    },
                    templateDefinition: originalPackage.templateDefinition,
                    description: originalPackage.description,
                    status: "Pending",
                    restrict_to: originalPackage.restrict_to,
                    packageFile: null,
                    signatureFile: null,
                    softwareVersionDate: originalPackage.softwareVersionDate,
                    fileSize: originalPackage.fileSize,
                    address: originalPackage.address,
                    software_name: originalPackage.software_name
                }
            }
        }
    }
}

export default angular.module('directives.packageManagement.revisePackage', [PackageEditControllerModule.name])
    .directive("revisePackage", ['$branding', RevisePackageDirective]);
