///<reference path="../../../../../typings/browser.d.ts"/>

import PackageRepositoryServiceModule, {PackageRepositoryService, IRepositoryPackage} from "../../services/PackageRepositoryService";
import {IRepositoryPackageDisplay} from "./packages-list/packages-table";
import {ISystemDisplay} from "../systems-list/systems-list";
import RequestManagementModule from "../../../../views/requestmanagement/requestmanagement";
var groupOperationListModule = "views.GroupOperationList";

enum Step {
    deviceSelection,
    finalize,
    apply,
    sent
}

interface IApplyPackageDirectiveScope extends ng.IScope {
    wizard: {
        step: Step,
        steps: any;
        back(): void;
        cancel(): void;
        finalize(): void;
        submitRequest():void;
        send(): void;
    }
    packageId: string,
    packageVersion: string,
    templateType: string,
    selectedPackage: IRepositoryPackage,
    inProgress: boolean,
    operation_id: string,
    selectedLocomotives: ISystemDisplay[];
    checkedLocomotives: {
        selectionAdd: ISystemDisplay[];
        selectionRemove: ISystemDisplay[];
        visibleLocomotives: ISystemDisplay[];
        pipe(tableState: any, tableCtrl: any): void;
        removeLocomotives(): void;
        addLocomotives(): void
        hasLocomotives: boolean;
    }
    onBackToList(): void;
    goToTask(id): void;
    send(): void;
    minDate:Date;
    scheduleDate:Date;
    clearFilter(): void;
    listFilter: any;
    errMsgs: any;
    disableSubmit:boolean;
    successMsgs: any;
}

class ApplyPackageController {
    public static $inject = ['$scope', 'PackageRepositoryService', '$routeParams', '$location', 'RouteHelpers','$rootScope','$timeout'];
    private selectedLocomotives: ISystemDisplay[] = [];
    constructor(
      private $scope: IApplyPackageDirectiveScope,
      private prs: PackageRepositoryService,
      private $routeParams: any,
      private $location: ng.ILocationService,
      private RouteHelpers: app.IRouteHelpers,
      private $rootScope: any,
      private $timeout:any) {
        $scope.listFilter = $scope.listFilter  || {};
        $scope.wizard = {
            step: Step.deviceSelection,
            steps: Step,
            back: () => this.back(),
            cancel: () => this.cancel(),
            finalize: () => this.finalize(),
            submitRequest: () => this.submitRequest(),
            send: () => this.send()
        };
        $scope.successMsgs = [];
        $scope.errMsgs = [];
        $scope.disableSubmit= true;
        $scope.packageId = $routeParams.packageId;
        $scope.packageVersion = $routeParams.packageVersion;
        $scope.templateType = $routeParams.templateType;
        prs.getPackage($scope.packageId, $scope.packageVersion, $scope.templateType).then((result:IRepositoryPackage) => {
            $scope.selectedPackage = result;
        })

        $scope.checkedLocomotives = {
            selectionAdd: [],
            selectionRemove: [],
            visibleLocomotives: [],
            pipe: (tableState: any, tableCtrl: any) => this.selectedLocomotivesPipe(tableState, tableCtrl),
            addLocomotives: () => this.addLocomotives(),
            removeLocomotives: () => this.removeLocomotives(),
            hasLocomotives: false
        }
        $scope.goToTask = (id) => this.goToTask(id);
        $scope.minDate = new Date();

        $scope.clearFilter = () => this.clearFilters();
          $rootScope.$on('showMsg', (evt, res:any)=>{
              $scope.disableSubmit = true;
              if(res.data && res.data.length){
                  res.data.forEach( item => 
                      {
                          if(item.created)  
                              $scope.successMsgs.push(item.requestId);
                      });
                  console.log($scope.successMsgs);
                  $scope.errMsgs = res.data.filter( item => !item.created);
                   this.$timeout( () => {$scope.errMsgs = []; $scope.successMsgs = [];}, 100000);
              } 
          });
          $rootScope.$on('changeDesc', (evt, obj:any)=>{
              $scope.disableSubmit = true;
              if(obj.data.description && obj.data.dataType != "" && obj.data.downloadServer != "" && obj.data.priority != "" && obj.data.associationDateRange.from ){
                  $scope.disableSubmit = false;
              } 
          });
      }

    private addLocomotives(): void {
        var currentSelectedLocomotives = _.indexBy(this.selectedLocomotives, p => p.asdid);
        _.each(this.$scope.checkedLocomotives.selectionAdd, p => {
            if (!_.has(currentSelectedLocomotives, p.asdid)) {
                var clone = _.clone(p);
                clone.isChecked = false;
                this.selectedLocomotives.push(clone);
            }
        });
        this.$scope.checkedLocomotives.hasLocomotives = this.selectedLocomotives.length > 0;
        this.$scope.checkedLocomotives.selectionAdd = null;
        this.$scope.selectedLocomotives = this.selectedLocomotives;
        this.$scope.$broadcast("selectedLocomotives:refresh");
    }

    private removeLocomotives(): void {
        this.selectedLocomotives = _.difference(this.selectedLocomotives, this.$scope.checkedLocomotives.selectionRemove);
        this.$scope.checkedLocomotives.hasLocomotives = this.selectedLocomotives.length > 0;
        this.$scope.checkedLocomotives.selectionRemove = null;
        this.$scope.selectedLocomotives = this.selectedLocomotives;
        this.$scope.$broadcast("selectedLocomotives:refresh");
    }

    private selectedLocomotivesPipe(tableState: any,tableCtrl:any): void {
        var limit = tableState.pagination.number;
        var offset = tableState.pagination.start;
        this.$scope.checkedLocomotives.visibleLocomotives = this.selectedLocomotives.slice(offset, offset + limit);
        //tableState.pagination.numberOfPages = Math.ceil(this.selectedLocomotives.length / tableState.pagination.number);
        tableState.pagination.totalItemCount = this.selectedLocomotives.length;
    }

    private finalize() {
        this.$scope.wizard.step = Step.finalize;
        this.$scope.$broadcast("selectedLocomotives:refresh");
    }
    private submitRequest() {
        // this.$scope.errMsg = '';
        // this.$scope.isSuccess = false;
        this.$rootScope.$broadcast("selectedLocomotives:addRequest", {selectedLocomotives: this.selectedLocomotives});
    }

    private back() {
        this.$scope.wizard.step--;
    }

    private cancel() {
        this.selectedLocomotives = [];
        this.$scope.$destroy()
        this.$scope.onBackToList();
    }

    private send(){
      this.$scope.wizard.step = Step.apply;
      this.$scope.inProgress = true;
      var asdids = [];
      var packageId = this.$scope.selectedPackage.packageId;
      var packageVersion = this.$scope.selectedPackage.version;
      var templateType = this.$scope.selectedPackage.templateType;
      var scheduleDate = this.$scope.scheduleDate;
      asdids = _.map(this.$scope.selectedLocomotives, (val) => {
        return val.asdid;
      });
      this.prs.applyPackage(packageId, packageVersion, templateType, asdids, scheduleDate).then(response => {
        this.$scope.operation_id = response.operation_id;
        this.$scope.inProgress = false;
        this.$scope.wizard.step = Step.sent;
      })
    }

    private goToTask(id) {
      var route = (<any>window).BRANDING.menu.config[groupOperationListModule].route + '/' + id + '/packages' ;
      this.$location.url(this.RouteHelpers.routeToLocation(route, {}));
    }

    private clearFilters() {
        this.$scope.listFilter = {
            searchFields: this.$scope.listFilter.searchFields
        }
    }
}

function ApplyPackageDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('ApplyPackageDirective'),
        link: function (scope: any, element: any, attr: any, ctrl: any) {
            scope.paginationLimit = 9007199254740991
        },
        controller: 'ApplyPackageController',
        scope: {
            onBackToList: '&',
            fromAddRequest: '@'
        }
    }
}


export default angular.module("directives.packageManagement.applyPackage", [PackageRepositoryServiceModule.name])
    .controller("ApplyPackageController", ApplyPackageController)
    .directive("applyPackage", ['$branding', ApplyPackageDirective]);
