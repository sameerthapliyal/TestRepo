import CommonServicesModule, {CommonServices} from "../services/CommonServices";

import DeviceModelsServiceModule, {DeviceModelsService} from "../services/DeviceModelsService";

/// <reference path="../../../typings/browser.d.ts" />



interface IAngularCompileControllerScope extends ng.IScope {

}


export class alarmNameController{

    
    constructor (
                    private _scope,
                    private _deviceModelsService
                )
    {   

        const getCurrentAlarm = alarm => _scope.data.alarm_id === alarm.id

        const assignAlarmName = (devModelVersion) => {
            const alarm = devModelVersion
                .alarms
                .filter(getCurrentAlarm)[0]

            if (alarm) {
                _scope.alarmName = alarm.display_name
            }
        }

       _deviceModelsService
       .getDeviceModelVersion(
           _scope.data.device_model,
           _scope.data.model_version
        )
        .then(assignAlarmName)

    }
}

export default angular.module('directives.alarmName', [DeviceModelsServiceModule.name])

.directive("alarmName",()=>{
    return {
        controller: ['$scope', 'DeviceModelsService', alarmNameController],
        template:`<span>{{ alarmName }}</span>`,
        replace: true,
        scope: {
            deviceModel: '=',
            modelVersion: '=',
            data: '='
        },
        restrict: "E",
        }
    }

);
