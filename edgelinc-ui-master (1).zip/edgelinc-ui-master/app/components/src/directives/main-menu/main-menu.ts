///<reference path="../../../../../typings/browser.d.ts"/>


import NavigationServiceModule, {INavigationService, IMenuItem} from "../../services/navigation/NavigationService";

var angularModule = angular.module('directives.mainMenu', [NavigationServiceModule.name]);
export default angularModule;

angularModule.controller('MainMenuController', MainMenuController);

angularModule.directive("mainMenu", function(){
    return{
        templateUrl: "/components/src/directives/main-menu/main-menu.html",
        restrict:"E",
        controller: "MainMenuController",
        scope:{
            navSmall: "=navSmall",
            navCollapsed: "=navCollapsed"
        },
        link: (scope: IMainMenuControllerScope, element: ng.IAugmentedJQuery) => {
            scope.$watch('navSmall',(newValue, oldValue)=>{
                if(newValue == true){
                    var $item = element[0].querySelectorAll(".open");
                    for (var i in $item) {
                        if ($item.hasOwnProperty(i)) {
                            angular.element($item[i]).toggleClass('open');
                        }
                    }
                }
            });

            angular.element( element[0].querySelectorAll('#sidebar-nav,#nav-col-submenu')).on('click', function (e) {
    
                var $item = e.target.querySelectorParent('li');
                var menuItemScope:any = angular.element(_.last($item)).scope().$parent;
                var menuMainItemScope:any = angular.element(_.first($item)).scope().$parent;
                if (e.target.querySelectorParent('.dropdown-toggle').length == 0) {

                    if(window.innerWidth < 992){
                        scope.navCollapsed = true
                    } else if(e.target.querySelectorParent(".nav-small").length > 0){
                        
                        for (var i in $item) {
                            if ($item.hasOwnProperty(i)) {
                                angular.element($item[i].parentElement.querySelectorAll('.open')).toggleClass('open');
                            }
                        }
                    }else if(menuItemScope == menuMainItemScope && menuItemScope && menuItemScope.menuItem && menuItemScope.menuItem.submenu == null ){
                        //e.preventDefault();
                        var itemToReopen = angular.element($item[0].parentElement.querySelectorAll('.open'));
                        setTimeout(()=>{
                            for (var i in $item) {
                                if ($item.hasOwnProperty(i)) {
                                    itemToReopen.addClass('open');
                                }
                            }
                        },10);
                       
                    }
                    return;
                } else {
                    e.preventDefault();
                    if (!angular.element($item).hasClass('open')) {
                        for (var i in $item) {
                            if ($item.hasOwnProperty(i)) {
                                angular.element($item[i].parentElement.querySelectorAll('.open')).toggleClass('open');
                            }
                        }
                    }
                    angular.element($item).toggleClass('open');
                }
            });

            var sheduledMenuHide = null;
            element.on("mouseleave", function(e){
                var menu = e.target.querySelectorParent("#nav-col");
                if(menu.length > 0 && sheduledMenuHide == null && scope.navSmall){
                    sheduledMenuHide = setTimeout(()=>{
                        sheduledMenuHide = null;
                        var $item =  menu[0].querySelectorAll(".open");
                        for (var i in $item) {
                            if ($item.hasOwnProperty(i)) {
                                angular.element($item[i]).toggleClass('open');
                            }
                        }
                    },300);
                }

                var $item = e.target.querySelectorParent('#page-wrapper.nav-small #sidebar-nav > .nav-pills > li');
                if ($item.length === 0) {
                    return;
                }

                if (window.innerWidth >= 992) {
                    var $element = angular.element($item);
                    if ($element.hasClass('open')) {
                        $element.find('.open').removeClass('open');
                    }

                    $element.removeClass('open');
                }
            });
            element.on("mouseenter", function(e){
                var menu = e.target.querySelectorParent("#nav-col");
                if(menu.length > 0 && sheduledMenuHide != null) {
                    clearTimeout(sheduledMenuHide);
                    sheduledMenuHide = null;
                }

                var $item = e.target.querySelectorParent('#page-wrapper.nav-small #sidebar-nav .dropdown-toggle');
                if ($item.length === 0) {
                    return;
                }

                if (window.innerWidth >= 992) {
                    angular.element($item).addClass('open');
                }
            });
        }
    };
});

interface IMainMenuControllerScope extends ng.IScope {
    config: app.config.IConfigConstant;
    menuItems: IMenuItem[];
    navSmall: boolean;
    navCollapsed: boolean;
}


export function MainMenuController($scope: IMainMenuControllerScope, $config: app.config.IConfigConstant, NavigationService: INavigationService) {
    $scope.config = $config;
    $scope.menuItems = NavigationService.getMenuItems();
    $scope.$on(NavigationService.changedEventName, () => {
        $scope.menuItems = NavigationService.getMenuItems();
    })
}
MainMenuController.$inject = ['$scope', '$config', 'NavigationService'];
