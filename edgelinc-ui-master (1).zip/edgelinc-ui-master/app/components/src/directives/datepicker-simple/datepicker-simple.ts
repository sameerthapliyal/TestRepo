/**
 * Created by rosadnik on 2015-12-01.
 */
///<reference path="../../../../../typings/browser.d.ts"/>

var angularModule = angular.module('directives.datepickerSimple', ['ngRoute', 'ui.bootstrap']);
export default angularModule;

angularModule.controller('datepickerSimpleController', ['$scope', '$element','$timeout','$branding','$filter',function($scope, $element,$timeout,$branding,$filter){
    return new datepickerSimpleController($scope, $element, $timeout, $branding, $filter);
}]);
angularModule.directive("datepickerSimple", function(){
    return{
        templateUrl: "/components/src/directives/datepicker-simple/datepicker-simple.html",
        restrict:"E",
        controller: "datepickerSimpleController",
        require: ['datepickerSimple', '?ngModel'],
        scope:{
            date: "=?",
            dateFormatInControl: "@",
            onChange: "&",
            minDate: "<?",
            maxDate: "<?",
            showSeconds: "=?",
            notShowTimeTab: "=?",
            required: "@?required",
            title: '=?',
            ngDisabled: '=?'
        },
        link: (scope, elem, attrs, ctrls) => {
            var ctrl: datepickerSimpleController = ctrls[0];
            var ngModelCtrl: ng.INgModelController = ctrls[1];
            if(ngModelCtrl) {
                ctrl.setModelCtrl(ngModelCtrl);
            }
            scope['ngModel'] = ngModelCtrl;
        }
    };
});

interface datepickerSimpleControllerScope extends ng.IScope {
    datePickerOptions: angular.ui.bootstrap.IDatepickerConfig,
    status:{opened: boolean};
    open:(event:any)=>void;
    onClearClick:()=> void;
    onCloseClick:()=> void;
    date: number;
    minDate: number;
    maxDate: number;
    dateDisplay: string;
    onChange:()=> void;
    hasErrorDate:()=>boolean;
    showSeconds:boolean;
    showMeridian:boolean;
    required:boolean|string;
}

class datepickerSimpleController{
    private _element:any;
    private _timeout:ng.ITimeoutService;
    private _scope:datepickerSimpleControllerScope;
    private ngModelCtrl: ng.INgModelController;

    constructor ($scope:any,$element:any, $timeout:ng.ITimeoutService,  private $branding, private $filter){
        this._element =$element;
        this._timeout = $timeout;
        this._scope = $scope;
        $scope.datePickerOptions = {
            showWeeks: false
        };
        if(this._scope.maxDate){
            this._scope.datePickerOptions.maxDate = this._scope.maxDate;
        }
        if(this._scope.minDate){
            this._scope.datePickerOptions.minDate = this._scope.minDate;
        }

        $scope.status = {
            opened: false
        };
        $scope.open = ($event)=> {
            if (!$scope.ngDisabled) {
                $scope.status.opened = true;
            }
        };

        $scope.onClearClick = ()=>{
            // update time pickers
            var timepickerElements = $element[0].querySelectorAll(".timepicker-range");
            for(var i in timepickerElements){
                if(timepickerElements.hasOwnProperty(i)){
                    var angularElement = angular.element(timepickerElements[i]);
                    if(angularElement.data()["$uibTimepickerController"] != null){
                        angularElement.data()['$ngModelController'].$setViewValue(null);
                        angularElement.data()["$uibTimepickerController"].render();
                    }
                }
            }

            $scope.date = null;
            $scope.dateDisplay = $scope.formatDate($scope.date);

        };
        $scope.onCloseClick = ()=>{
            $scope.status.opened = false;
        };

        $scope.formatDate = (ts:number)=>{
            if(ts == null || ts == 0){
                return "not set";
            }else {
                //return  moment(ts).format($scope.dateFormatInControl);
                if($scope.dateFormatInControl) {
                  var date = new Date(ts);
                  return this.$filter('date')(date, $scope.dateFormatInControl);
                } else {
                  var dateTimeFormat = $branding.getUISettings().dateTimeFormat;
                  if(this._scope.showSeconds == false  && dateTimeFormat.indexOf(":ss") >= 0){
                      dateTimeFormat = dateTimeFormat.replace(":ss","");
                  }
                  return this.$filter('date')(new Date(ts), dateTimeFormat);
                }
            }
        };

        $scope.showMeridian = $branding.getUISettings().dateTimeFormat.indexOf('a') >= 0;

        $scope.$watch("date",(newValue:number, oldValue:number)=>{
            if(newValue != oldValue) {
              if($scope.date && !this._scope.showSeconds && new Date($scope.date).getSeconds() != 0){
                  if(typeof $scope.date == "number") {
                      $scope.date -= new Date($scope.date).getSeconds();
                  }else if(typeof $scope.date == "object" && $scope.date.setSeconds){
                      $scope.date.setSeconds(0,0);
                  }
              }

              if($scope.date && typeof $scope.date != "number" && typeof $scope.date != "string") {
                let date = $scope.date.getTime();
              }

              if(this._scope.onChange != null ) {
                  this._scope.onChange();
              }

            }
            $scope.dateDisplay = $scope.formatDate($scope.date);
        });

        $scope.hasErrorDate = ()=>{
            if (this._scope.date != null && this._scope.minDate != null){
                if (this._scope.minDate > this._scope.date){
                    return true;
                } else {
                    return false;
                }
            }else {
                return false;
            }
        };

        var clickOutOfControl:(ev: MouseEvent) => any = (ev: MouseEvent)=>{

            if(this._scope.status.opened === true) {
                if(this._element[0].contains(ev.srcElement || ev.target)== false){
                    this._scope.onCloseClick();
                }
            }
        };
        document.addEventListener("mousedown", clickOutOfControl);
        $scope.$on("$destroy",()=>{
            document.removeEventListener("mousedown", clickOutOfControl)
        });
    }

    public setModelCtrl(ngModelCtrl: ng.INgModelController) {
        this.ngModelCtrl = ngModelCtrl;
        this.ngModelCtrl.$render = () => {
            this._scope.date = this.ngModelCtrl.$viewValue;
        };
        this._scope.$watch('date', date => {
            this.ngModelCtrl.$setViewValue(date);
        })
    }
}
