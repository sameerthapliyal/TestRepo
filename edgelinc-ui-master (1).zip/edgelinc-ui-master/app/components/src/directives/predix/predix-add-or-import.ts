interface predixAddOrImportScope extends ng.IScope {
    startPredixAddOrImport:()=> void;
    close:()=>void;
    showPredixAddOrImport:boolean;
}

class predixAddOrImportController{
    constructor(private _scope: predixAddOrImportScope)
    {
        this._scope.startPredixAddOrImport = ()=> {
            this._scope.showPredixAddOrImport = !this._scope.showPredixAddOrImport;
        };
    }
}

var angularModule = angular.module("directives.predix.predixAddOrImport", []);
export default angularModule;

angularModule.directive("predixAddOrImport", ['$rootScope',function($rootScope) {
    return {
        scope:{
            startPredixAddOrImport: "=",
            close: "=?"
        },
        restrict: "E",
        controller: ["$scope", predixAddOrImportController],
        templateUrl: "/components/src/directives/predix/predix-add-or-import.html"
    };
}]);
