import PredixDevicesServiceModule, {
    IPredixDevice, PredixDevicesService,
    IPredixDeviceFilter
} from "../../../../services/predix/PredixDevicesService";
import {PredixListController} from "./predix-list";
import ldarsAddDevicesRangeModule from  "../../../../directives/add-devices-range/ldars-add-devices-range";
import {DeviceService} from "../../../../services/DeviceService" ;
import ParameterStorageServiceModule, {IParameterStorageService, STORAGE_TYPE} from "../../../../services/ParameterStorageService";

interface predixDeviceTableScope extends ng.IScope {
    predixDevices:IPredixDevice[];
    offset:number;
    visibleCount:number;
    filteredCount:number;
    inProgress:boolean;
    isLoading:boolean;
    checkedDevices:IPredixDevice[];
    disableCheckboxes:boolean;
    isTableLocked: boolean;
    listFilter:IPredixDeviceFilter;
    pipe(tableState:any, tableCtrl:any):void;
    pageSize: number;
    detaillink: string;
}

class predixDeviceTableController {
    private tableState:any;

    public static $inject = ['$scope', '$q', '$branding', 'PredixDevicesService', 'DeviceService', 'ParameterStorageService'];

    private scopePropertiesToSave:string[] = ["pageSize"];
    private storageKey:string = "predix-device-table-storage";
    private storageType:STORAGE_TYPE;
    private doRequest_retryCount:number;

    constructor(private $scope:predixDeviceTableScope,
                private $q:ng.IQService,
                private $branding: app.branding.IBrandingService,
                private PredixDevicesService:PredixDevicesService,
                private DeviceService: DeviceService,
                private ParameterStorageService: IParameterStorageService
                ) {
        $scope.predixDevices = [];
        $scope.filteredCount = 0;
        $scope.inProgress = true;
        $scope.isLoading = true;
        //var doRequestThrottled = $q.throttle(() => this.doRequest(),1000);
        var doRequestThrottled = _.debounce(() =>{
            this.doRequest_retryCount = 0;
            this.doRequest()
        },100,false);

        this.initTableParameterStorageService();

        $scope.pipe = (_tableState:any) => {
            this.customSaveState();
            this.tableState = _tableState;

            doRequestThrottled();
        };
        $scope.detaillink=(<any>window).BRANDING.ui.device_details_route.replace(":asdid","");
    }

    private initTableParameterStorageService(){
         this.storageType = STORAGE_TYPE.SESSION_STORAGE;
         this.ParameterStorageService.restoreState(this.storageKey,this.storageType,this.$scope);
         if(this.$scope.pageSize == null || typeof this.$scope.pageSize == "undefined")
            this.$scope.pageSize = 10;
     }

     private customSaveState() {
        this.ParameterStorageService.saveState(this.$scope,this.storageKey,this.storageType, this.scopePropertiesToSave);
     }

    private doRequest() {
        this.$scope.inProgress = true;
        var sortColumn = null;
        var sortDir: any = null;
        if (this.tableState.sort && this.tableState.sort.predicate) {
            sortColumn = this.tableState.sort.predicate;
            sortDir = this.tableState.sort.reverse ? "desc" : "asc";
        } else {
            sortColumn = "timestamp";
            sortDir = "desc";
            this.tableState.sort.predicate = "timestamp";
            this.tableState.sort.reverse = true;
        }
        var limit = this.tableState.pagination.number;
        var offset = this.tableState.pagination.start;
        var listFilter = this.$scope.listFilter;

        return this.PredixDevicesService.getDevicesInventory(listFilter, sortColumn, sortDir, limit, offset)
            .then((result:App.Models.SearchResult<IPredixDevice>) => {
                this.doRequest_retryCount = 0;
                this.$scope.predixDevices = _.map(result.items, (predixDevice:IPredixDevice) => {
                  /*if(predixDevice != undefined && predixDevice != null) {
                      var re_deviceDid: RegExp = /(^[^_]+)_(\d+)_([^_]+$)/g;
                      var deviceDidSplit = re_deviceDid.exec(predixDevice["did"]);
                      if(deviceDidSplit != null) {
                        predixDevice["deviceName"] = deviceDidSplit[1];
                        predixDevice["serialNumber"] = deviceDidSplit[2];
                        predixDevice["deviceType"] = deviceDidSplit[3].toUpperCase();
                    }
                  }*/
                  return predixDevice;
                });
                this.$scope.visibleCount = this.$scope.predixDevices.length;
                this.$scope.filteredCount = result.totalCount;
                this.$scope.offset = offset;
                //this.tableState.pagination.numberOfPages = Math.ceil(result.totalCount / this.tableState.pagination.number);
                this.tableState.pagination.totalItemCount = result.totalCount;
            })
            .catch(reason => {
                if(this.doRequest_retryCount < 3){
                    this.doRequest_retryCount++;
                    setTimeout(()=>{this.doRequest()},this.doRequest_retryCount*1000);
                }
                console.error("Cannot load devices list", reason);
                this.$scope.predixDevices = [];
                this.$scope.visibleCount = 0;
                this.$scope.filteredCount = 0;
                this.$scope.offset = 0;
                //this.tableState.pagination.numberOfPages = 0;
                this.tableState.pagination.totalItemCount = 0;
            })
            .finally(() => {
                this.$scope.inProgress = false;
                this.$scope.isLoading = false;
            })
    }
}

interface predixDeviceListScope extends ng.IScope {
    listFilter:IPredixDeviceFilter;
    getDeviceStatuses: (query: string) => any[];
    selectedDevStatus: any;
    table:{
        offset:number;
        visibleCount:number;
        filteredCount:number;
        isLoading:boolean;
        checkedDevices:IPredixDevice[];
    }
    onFilterChange():void;
    onFilterClick():void;
    onClearFilterClick():void;
    refreshTable(): void;
    stateRestored:boolean;
}

class predixDeviceListController {
    public static $inject = ['$scope', '$branding', '$timeout', 'DeviceService', 'ParameterStorageService'];

    private filterChange:boolean = false;
    private scopePropertiesToSave:string[];

    private storageKey:string = "predix-device-list-filters";
    private storageType:STORAGE_TYPE;

    constructor(private $scope:predixDeviceListScope,
                private $branding: app.branding.IBrandingService,
                private $timeout: ng.ITimeoutService,
                private DeviceService:DeviceService,
                private ParameterStorageService: IParameterStorageService
    ) {
        $scope.table = {
            offset: 0,
            visibleCount: 0,
            filteredCount: 0,
            isLoading: true,
            checkedDevices: []
        };
        this.initParameterStorageService();
        $scope.listFilter = {
            deviceModel: this.getEnrolledDeviceModels()
        };
        $scope.onFilterChange = _.throttle(() => this.onFilterChanged(), 1000);
        $scope.onFilterClick = () => this.onFilterChanged();
        $scope.onClearFilterClick = () => this.clearFilters();
        $scope.refreshTable = () => this.onRefreshTable();
        var deviceStatuses = [
            {text:'Inventory', id:"Inventory", value:"Inventory"},
            {text:'Assigned', id:"Assigned", value:"Assigned"},
            {text:'Enrolled', id:"Enrolled", value:"Enrolled"}
        ];
        $scope.getDeviceStatuses = (query: string) => {
            if (query != null && query.trim().length > 0) {
                var pattern = new RegExp(query, "i");
                return deviceStatuses.filter((m) => {
                    return pattern.test(m.text);
                })
            } else {
                return deviceStatuses;
            }
        };

        $scope.$watch(()=>{ return (this.$scope.selectedDevStatus || []).length; } ,()=>{
            if(this.$scope.selectedDevStatus && !!this.$scope.selectedDevStatus.length){
                this.$scope.listFilter.status = this.$scope.selectedDevStatus.map((devStat)=>{return devStat.id;});
            }else{
                delete  this.$scope.listFilter.status;
            }
        });
    }

    private clearFilters() {
        this.$scope.listFilter = {
            deviceModel: this.getEnrolledDeviceModels(),
            searchFields: this.$scope.listFilter.searchFields
        };
        this.$scope.selectedDevStatus = [];
        this.customSaveState();
        this.onFilterChanged();
    }

    private onFilterChanged() {
        this.$scope.$broadcast('smartTable:refreshRequired');
        if(this.$scope.stateRestored ){
          this.customSaveState();
        }
    }

    private onRefreshTable(){
        this.$scope.$broadcast('smartTable:refreshRequired');
    };

    private initParameterStorageService(){
         this.storageType = STORAGE_TYPE.SESSION_STORAGE;
         this.$scope.stateRestored = false;
         this.filterChange = false;
         this.scopePropertiesToSave = ["listFilter.searchString", /*"listFilter.deviceModel",*/ "listFilter.status", "selectedDevStatus",
                                       "listFilter.associationDateRange.from", "listFilter.associationDateRange.to"];
         this.ParameterStorageService.restoreState(this.storageKey,this.storageType,this.$scope);
         this.$scope.stateRestored = true;
     }

     private customSaveState() {
         this.$timeout(()=>{
             // delay to wait for scope to be updated by the change operation
             this.ParameterStorageService.saveState(this.$scope,this.storageKey,this.storageType, this.scopePropertiesToSave);
         });
     }

    private getEnrolledDeviceModels(): string[] {
        var brandingConstants = this.$branding.getBrandingConstants<any>();
        var enrolledDeviceModels = null;
        if(brandingConstants && brandingConstants.enrolledDeviceTypes) {
            enrolledDeviceModels =  _.map(brandingConstants.enrolledDeviceTypes, (dt: any) => dt.deviceModel);
        }
        if(brandingConstants && brandingConstants.mcsEnrolledDeviceTypes) {
            enrolledDeviceModels =  enrolledDeviceModels || [];
            _.each(brandingConstants.mcsEnrolledDeviceTypes, (dt:any)=>{ enrolledDeviceModels.push(dt.deviceModel); });
        }
        return enrolledDeviceModels;
    }
}

var angularModule = angular.module('directives.predix.predixDeviceList', [ldarsAddDevicesRangeModule.name]);
export default angularModule;


angularModule.directive("predixDeviceList", function ($branding: app.branding.IBrandingService) {
    return {
        //templateUrl: "/components/src/directives/predix/devices/predix-device-list/predix-device-list.html",
        templateUrl: $branding.getTemplateUrl('PredixDeviceListDirective'),
        restrict: "E",
        controller: 'predixDeviceListController',
        scope: {}
    }
});

angularModule.controller('predixDeviceListController', predixDeviceListController);


angularModule.directive("predixDeviceTable", function ($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('PredixDeviceTableDirective'),
        restrict: "E",
        require: '?^predixList',
        controller: 'predixDeviceTableController',
        scope: {
            listFilter: '=',
            visibleCount: '=',
            filteredCount: '=',
            offset: '=',
            isLoading: '=',
            checkedDevices: '=',
            disableCheckboxes: '='
        },
        link: (scope: predixDeviceTableScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PredixListController) => {
            scope.isTableLocked = false;
            if(ctrl) {
                scope.$watch(() => ctrl.isTableLocked, locked => scope.isTableLocked = locked);
            }
        }
    }
});

angularModule.controller('predixDeviceTableController', predixDeviceTableController);
