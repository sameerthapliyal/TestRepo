///<reference path="../../../../../../../typings/browser.d.ts"/>

export interface IListComponent {
    getComponentKey(): string;
    attach(predixListController: PredixListController): void;
    start(): boolean;
    close(): boolean;
    isActive(): boolean;
    isEnabled(): boolean;
    getTooltip?(): string;
}

export class PredixListController {
    private _locks: {[componentKey: string]: boolean} = {};
    private _isLocked: boolean = false;
    private _components: {[componentKey: string]: IListComponent} = {};

    public static $inject = ["$scope"];
    constructor(private $scope: ng.IScope) {}

    lockTable(component: IListComponent): void {
        this._locks[component.getComponentKey()] = true;
        this._isLocked = true;
    }
    unlockTable(component: IListComponent): void {
        delete this._locks[component.getComponentKey()];
        if(_.keys(this._locks).length == 0) {
            this._isLocked = false;
        }
    }

    refresh(refreshEventName: string = 'smartTable:refreshRequired') {
        this.$scope.$broadcast(refreshEventName);
    }

    registerComponent(component: IListComponent) {
        if(this._components[component.getComponentKey()]) {
            throw new Error("Cannot register more than one table component with given key");
        }
        this._components[component.getComponentKey()] = component;
        component.attach(this);
    }

    toggleComponent(componentKey: string): boolean {
        var component = this.getComponent(componentKey);
        if(!component) {
            return false;
        }
        if (component.isActive()) {
            return component.close();
        } else {
            var allClosed:boolean = true;
            _.each(this._components, c => {
                allClosed = allClosed && c.close();
            });
            if (allClosed) {
                return component.start();
            } else {
                return false;
            }
        }
    }

    isComponentActive(componentKey: string): boolean {
        var component = this.getComponent(componentKey);
        return component && component.isActive();
    }

    isComponentEnabled(componentKey: string): boolean {
        var component = this.getComponent(componentKey);
        return component && component.isEnabled();
    }

    getComponent(componentKey: string): IListComponent {
        return this._components[componentKey];
    }

    getComponentTooltip(componentKey: string): string {
        var component = this.getComponent(componentKey);
        return component && _.isFunction(component.getTooltip) ? component.getTooltip() : null;
    }

    get isTableLocked(): boolean {
        return this._isLocked;
    }
}

function PredixListDirective() {
    return {
        restrict: "A",
        controller: PredixListController
    }
}

export function makeListComponent(directiveName: string, directive: ng.IDirective): ng.IDirective {
    var require: string[] = [];
    var originalRequire = directive.require;
    if(typeof originalRequire === "string") {
        require = [originalRequire];
    } else if (_.isArray(originalRequire)) {
        require = originalRequire;
    }
    var baseIndex = require.length;
    directive.require = require.concat("^predixList", directiveName);

    var originalLink: any = directive.link || angular.noop;

    directive.link = function (scope:ng.IScope, elem:ng.IAugmentedJQuery, attrs:ng.IAttributes, ctrls: any[]) {
        originalLink.apply(this, arguments);
        var predixListController: PredixListController = ctrls[baseIndex];
        var ctrl: IListComponent = ctrls[baseIndex + 1];
        predixListController.registerComponent(ctrl);
    };

    return directive;
}

export function makeListComponentButton(componentKey: string) {
    return {
        restrict: "A",
        require: "^predixList",
        link: (scope:ng.IScope, elem:ng.IAugmentedJQuery, attrs:ng.IAttributes, ctrl:PredixListController) => {
            elem.on('click', () => {
                ctrl.toggleComponent(componentKey);
                scope.$applyAsync();
            });
            scope.$watch(() => ctrl.isComponentActive(componentKey), isActive => {
                elem.toggleClass("active", !!isActive);
            });
            scope.$watch(() => ctrl.isComponentEnabled(componentKey), isEnabled => {
                if(isEnabled) {
                    elem.removeAttr("disabled");
                } else {
                    elem.attr("disabled", "disabled");
                }
            });
            scope.$watch(() => ctrl.getComponentTooltip(componentKey), tooltip => {
                if(tooltip) {
                    elem.attr("title", tooltip);
                } else {
                    elem.removeAttr("title");
                }
            });

        }
    }
}

export default angular.module('directives.predix.proxList', [])
    .directive('predixList', PredixListDirective);