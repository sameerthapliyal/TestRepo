import {PredixListController, IListComponent, makeListComponent, makeListComponentButton} from "./predix-list";
import {IPredixDevice, PredixDevicesService, IBatchDeleteOperationStatus} from "../../../../services/predix/PredixDevicesService";
import {BrandingService} from "../../../../services/BrandingService";
import {GroupOperationsService} from "../../../../services/GroupOperationsService";

var directiveName = "predixDeleteDevices";

interface IPredixDeleteDevicesControllerScope extends ng.IScope {
    devices: IPredixDevice[];
    condition(args: {item: IPredixDevice}): boolean;
    conditionTooltip: string;
    state: {
        enabled: boolean;
        tooltip: string;
        active: boolean;
        deleted: boolean;
        success: boolean;
        notDeletedCount?: number;
        notDeletedDevices?: {[did: string]: IBatchDeleteOperationStatus};
        errorMessage?: string;
    }
    delete(): void;
    cancel(): void;
    operation_id:string;
}

interface IPredixDeleteDevicesControllerAttrs extends ng.IAttributes {
    condition: string;
}

interface IBrandingConstants_devModelToRegister{
    displayName:string;
    deviceModel:string;
    modelVersion:string
};
interface IBrandingConstants{
    enrolledDeviceTypes:{[devModelName:string]:IBrandingConstants_devModelToRegister;};
    mcsEnrolledDeviceTypes:{[devModelName:string]:IBrandingConstants_devModelToRegister;};
};

class PredixDeleteDevicesController implements IListComponent{

    public predixListController: PredixListController;
    private _devices: IPredixDevice[];
    private brandConstants:IBrandingConstants;

    public static $inject = ["$scope", "$q", "$attrs", "$timeout", "PredixDevicesService", "GroupOperationsService", "$branding"];
    constructor(private $scope: IPredixDeleteDevicesControllerScope,
                private $q: ng.IQService,
                private $attrs: IPredixDeleteDevicesControllerAttrs,
                private $timeout: ng.ITimeoutService,
                private PredixDevicesService: PredixDevicesService,
                private groupOperationsService: GroupOperationsService,
                private $branding:BrandingService ) {
        $scope.state = {
            enabled: false,
            tooltip: null,
            active: false,
            deleted: false,
            success: null
        };
        $scope.delete = () => this.deleteDevices();
        $scope.cancel = () => this.close();

        $scope.$watchCollection("devices", (devices: IPredixDevice[]) => {
            let validation = this.validate(devices);
            $scope.state.enabled = validation === true;
            $scope.state.tooltip = (typeof validation === "string") ? validation : null;
        });
        $scope.$on("$destroy",()=>{
            if(this._getGoDetils_Promise) {
                this.$timeout.cancel(this._getGoDetils_Promise);
            }
        });
    
        this.brandConstants = $branding.getBrandingConstants<IBrandingConstants>();
    }

    getComponentKey(): string {
        return directiveName;
    }

    attach(predixListController: PredixListController) {
        this.predixListController = predixListController;
    }

    start(): boolean {
        this.$scope.state.active = true;
        this.$scope.state.deleted = false;
        this.predixListController.lockTable(this);
        this._devices = this.$scope.devices;
        this.$scope.operation_id = null;
        return true;
    }

    close(): boolean {
        this.$scope.state.active = false;
        this.predixListController.unlockTable(this);
        return true;
    }

    isEnabled(): boolean {
        return this.$scope.state.enabled;
    }

    getTooltip(): string {
        return this.$scope.state.tooltip;
    }

    isActive(): boolean {
        return this.$scope.state.active;
    }

    deleteDevices(): void {
        this.$scope.operation_id = null;
        var predixModel = _.map(this.brandConstants.enrolledDeviceTypes, (dt:IBrandingConstants_devModelToRegister)=>{
            return dt.deviceModel;
        });
        var mcsModel = _.map(this.brandConstants.mcsEnrolledDeviceTypes, (dt:IBrandingConstants_devModelToRegister)=>{
            return dt.deviceModel;
        });

        var devDelByPredix:IPredixDevice[] = _.filter(this._devices,(dev)=>{
            return predixModel.indexOf(dev.deviceModel)>=0;
        });
        var devDelByGo:IPredixDevice[] = _.filter(this._devices,(dev)=>{
            return mcsModel.indexOf(dev.deviceModel)>=0;
        });
        
        var devDelByPredix_dids = _.map(devDelByPredix, d => d.did);
        var delPromise:ng.IPromise<any>[] = [];
        if(devDelByPredix_dids.length > 0) {
            delPromise.push(this.PredixDevicesService.deleteDevices(devDelByPredix_dids)
                .then(response => {
                    this.$scope.state.notDeletedDevices = _.pick(response, s => !s.success);
                    this.$scope.state.notDeletedCount = _.keys(this.$scope.state.notDeletedDevices).length;
                    this.$scope.state.deleted = true;
                    this.$scope.state.success = this.$scope.state.notDeletedCount == 0;
                    this.$scope.state.errorMessage = null;
                    this.$scope.devices = _.filter(this.$scope.devices, d => !response[d.did] || !response[d.did].success);
                    this.predixListController.refresh();
                }).catch(err => {
                    this.$scope.state.notDeletedDevices = {};
                    this.$scope.state.notDeletedCount = 0;
                    this.$scope.state.deleted = true;
                    this.$scope.state.success = false;
                    this.$scope.state.errorMessage = err.message;
                    this.predixListController.refresh();
                }));
        }
        
        var  deleteDeviceGo:eapi18.requests.UnregistrationOperation= {
            asdids: _.map(devDelByGo, d => d.asdid)
        };
        if(devDelByGo.length > 0) {
            delPromise.push(this.groupOperationsService.deleteDevices(deleteDeviceGo).then((goId: eapi18.GroupOperationIdObject) => {
                console.log();
                this.predixListController.refresh();
                this.$scope.operation_id = goId.operation_id;
                this.getGoDetils(this.$scope.operation_id);
            }).catch((err)=>{
                this.$scope.state.success = false;
                this.$scope.state.errorMessage = err.message;
            }));
        }
        this.$q.all(delPromise).then(()=>{
            this.$scope.state.success = true;
            this.$scope.state.errorMessage = null;
        }).finally(()=>{
            this.$scope.state.deleted = true;
        });
    }

    private validate(devices: IPredixDevice[]): string|boolean {
        if(devices.length <= 0) {
            return "No devices to delete";
        }
        if(this.$attrs.condition) {
            return  _.all(devices, d => this.$scope.condition({item: d})) ? true : (this.$scope.conditionTooltip || false);
        } else {
            return true;
        }
    }
    
    private _getGoDetils_Promise = null;
    private getGoDetils(goId:string, delay:number = 1000) {
        if (goId){
            this._getGoDetils_Promise = this.$timeout(() => {
                this._getGoDetils_Promise = null;
                this.groupOperationsService.getGroupOperationDetails(goId,"unregistrations").then((groupOperationDetails)=>{
                    if(groupOperationDetails.status == "FINISHED"){
                        this.$timeout(()=>{
                            this.$scope.$emit("smartTable:refreshRequired");
                        },500);
                    }else{
                        this.getGoDetils(goId);
                    }
                });
            }, delay);
        }
    }
}

function PredixDeleteDevicesDirective() {
    return makeListComponent(directiveName, {
        restrict: "E",
        controller: PredixDeleteDevicesController,
        templateUrl: "/components/src/directives/predix/devices/predix-device-list/predix-delete-devices.html",
        scope: {
            devices: '=',
            condition: '&?',
            conditionTooltip: '@?'
        }
    });
}
function PredixDeleteDevicesButtonDirective() {
    return makeListComponentButton(directiveName);
}

/*function PredixDeleteDevicesDirective() {
    return {
        restrict: "E",
        require: ["^predixList", "predixDeleteDevices"],
        controller: PredixDeleteDevicesController,
        templateUrl: "/components/src/directives/predix/devices/predix-device-list/predix-delete-devices.html",
        scope: {
            devices: '=',
            condition: '&?'
        },
        link: (scope:ng.IScope, elem:ng.IAugmentedJQuery, attrs:ng.IAttributes, ctrls: [PredixListController, PredixDeleteDevicesController]) => {
            var predixListController = ctrls[0];
            var predixDeleteDevicesController = ctrls[1];
            predixListController.registerComponent( predixDeleteDevicesController);
            predixDeleteDevicesController.predixListController = predixListController;
        }

    }
}
function PredixDeleteDevicesButtonDirective() {
    return {
        restrict: "A",
        require: "^predixList",
        link: (scope:ng.IScope, elem:ng.IAugmentedJQuery, attrs:ng.IAttributes, ctrl:PredixListController) => {
            elem.on('click', () => {
                ctrl.toggleComponent(componentKey);
                scope.$applyAsync();
            });
            scope.$watch(() => ctrl.isComponentActive(componentKey), isActive => {
                elem.toggleClass("active", isActive);
            });
            scope.$watch(() => ctrl.isComponentEnabled(componentKey), isEnabled => {
                if(isEnabled) {
                    elem.removeAttr("disabled");
                } else {
                    elem.attr("disabled", "disabled");
                }
            });
            
        }
    }
}*/



export default angular.module('directives.predix.devices.deleteDevices', [])
    .directive("predixDeleteDevices", PredixDeleteDevicesDirective)
    .directive("predixDeleteDevicesButton", PredixDeleteDevicesButtonDirective);