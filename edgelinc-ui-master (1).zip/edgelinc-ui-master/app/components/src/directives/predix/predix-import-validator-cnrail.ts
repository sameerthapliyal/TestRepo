///<reference path="../../../../../typings/browser.d.ts"/>

interface IDeviceImport {
    deviceName: string;
    serialNumber: string;
    deviceType: string;
}

interface IBrandingConstants {
    "customer_id": string,
    "enrolledDeviceNames": string[],
    "enrolledDeviceTypes": {
        [type: string]: {
            "displayName": string,
            "deviceModel": string,
            "modelVersion": string
        }
    },
    "locomotiveModel": string
}

interface IPredixImportValidatorCnrailDirectiveScope extends ng.IScope {
    validationKey: string;
    validate(obj: IDeviceImport[]): ng.IPromise<boolean>;
    reset(): void;
    errorMessage: any;
}

function PredixImportValidatorCnrailDirective($q: ng.IQService, $translate: ng.translate.ITranslateService, $branding: app.branding.IBrandingService) {
    return {
        restrict: 'E',
        require: ['?ngModel', '^?form'],
        scope: {
            validationKey: '@?',
            validate: '=',
            reset: '=',
            errorMessage: '='
        },
        link: (scope: IPredixImportValidatorCnrailDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrls: [ng.INgModelController, ng.IFormController]) => {
            var constants = $branding.getBrandingConstants<IBrandingConstants>();
            var ngModelController: ng.INgModelController = ctrls[0];
            var formController: ng.IFormController = ctrls[1];
            var errorMessagePromise: ng.IPromise<string> = $q.resolve(null);

            function assertContains(value: any, valuesSet: any[], errorMessage: ng.IPromise<string>) {
                if(valuesSet.indexOf(value) < 0) {
                    errorMessagePromise = errorMessage;
                    throw new Error();
                }
            }
            function assertNonEmpty(value: any, errorMessage: ng.IPromise<string>) {
                if(!value) {
                    errorMessagePromise = errorMessage;
                    throw new Error();
                }
            }
            
            function validateRow(obj: IDeviceImport, index: number) {
                var allowedDeviceNames = constants.enrolledDeviceNames;
                assertContains(obj.deviceName, allowedDeviceNames, $translate("predix.import.messages.invalidDeviceName", {value: obj.deviceName, values: allowedDeviceNames}));
                assertNonEmpty(obj.serialNumber, $translate("predix.import.messages.emptySerialNumber"));
                var allowedDeviceTypes = _.keys(constants.enrolledDeviceTypes);
                assertContains(obj.deviceType, allowedDeviceTypes, $translate("predix.import.messages.invalidDeviceType", {value: obj.deviceType, values: allowedDeviceTypes}));
            }
            
            function setValidity(valid: boolean) {
                var validationKey = scope.validationKey || "importData";
                if(ngModelController) {
                    ngModelController.$setValidity(validationKey, valid);
                } else if(formController) {
                    formController.$setValidity(validationKey, valid, <any>formController);
                }
            }

            var invalidIndex = null;
            scope.validate = (objects: IDeviceImport[]) => {
                var invalid = _.find(objects, (obj: IDeviceImport, index: number) => {
                    try {
                        validateRow(obj, index);
                        return false;
                    } catch(err) {
                        invalidIndex = index;
                        //scope.errorMessage = `Error in record ${index + 1}. ${err.message}`;
                        return true;
                    }
                });
                if(invalid != null) {
                    setValidity(false);
                    return errorMessagePromise
                        .then(errorMessage => {
                            scope.errorMessage = `Error in record ${invalidIndex + 1}. ${errorMessage}`;
                            return $q.reject(scope.errorMessage);
                        });
                } else {
                    setValidity(true);
                    scope.errorMessage = null;
                    return $q.resolve(true);
                }
            };

            scope.reset = () => {
                setValidity(true);
                scope.errorMessage = null;
            }
        }
    }
}

export default angular.module('directives.predix.validators.cnrail', [])
    .directive('predixImportValidatorCnrail', ['$q', '$translate', '$branding', PredixImportValidatorCnrailDirective]);