///<reference path="../../../../../typings/browser.d.ts"/>

import PredixDevicesServiceModule, {
    PredixDevicesService,
    IPredixDeviceToAdd
} from "../../services/predix/PredixDevicesService";
import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";
import CsvSerializerModule, {
    CsvSerializer, CsvError
} from "../../utilities/CsvSerializer";
import IDeviceModel = Models.DeviceModel.IDeviceModel;
import IRootScope = App.IRootScope;
import ProxMapperServiceModule, {ProxMapperService, FieldsMapping} from "../../utilities/proxMapper";
import {ProxListController} from "../list-header/prox-list";
import {
    IListComponent, PredixListController, makeListComponent,
    makeListComponentButton
} from "./devices/predix-device-list/predix-list";

var directiveName = "predixImportDevices";

interface IPredixImportDevicesScope extends ng.IScope {
    active: boolean;
    activator: () => void;
    devicesPreview: any[];
    totalDevices: number;
    devicesLoaded: boolean;
    added: boolean;
    inProgress: boolean;
    importDevicesForm: ng.IFormController;
    mappings: {
        csvToJson?: FieldsMapping;
        csvRequiredColumns?: string[];
        jsonToPredix?: FieldsMapping;
    },
    validation: {
        validate(objects: any[]): ng.IPromise<any>;
        reset(): void;
        errors: {
            lackingColumns?: string[];
            csvParseError?: Error;
            genericError?: Error;
            validationErrorMessage?: string;
            httpError?: any;
            invalidSerialNumber?:string[];
        }
        warnings: {
            devicesLimit?: { limit: number };
        },
    },
    pipe(tableState:any, tableCtrl:any): void;
    addDevices(): void;
    close(): void;
    onFileSelected(file: File): void;
    onAdded(): void;
    closeButtonText():string;
    showImportResult:boolean;
}

var LIMIT = 300;


class PredixImportDevicesController implements IListComponent {
    public static $inject = ["$scope", "$rootScope", "$q", "CsvSerializer", "ProxMapper", "PredixDevicesService"];

    private _predixListController: PredixListController;
    private devices: IPredixDeviceToAdd[];
    private devicesData: any[];


    /*private CSVMapping: FieldsMapping = {
        deviceName: "Device Name",
        serialNumber: "Serial Number",
        deviceType: "Device Type"
    };
    private JsonMapping: FieldsMapping = {
        did: obj => `${obj.deviceName}_${obj.serialNumber}_${obj.deviceType}`,
        name: obj => `${obj.deviceType}`,
        deviceModel: obj => this.$rootScope.brandConstants.enrolledDeviceTypes[obj.deviceType].deviceModel,
        modelVersion: obj => this.$rootScope.brandConstants.enrolledDeviceTypes[obj.deviceType].modelVersion
    };

    private RequiredColumns: RequiredColumns = {
        "Device Name": true,
        "Serial Number": true,
        "Device Type": true
    };*/
    
    constructor(
        private $scope: IPredixImportDevicesScope,
        private $rootScope: IRootScope,
        private $q: ng.IQService,
        private CsvSerializer: CsvSerializer,
        private ProxMapper: ProxMapperService,
        private PredixDevicesService: PredixDevicesService
    ) {
        this.$scope.importDevicesForm = null;
        this.$scope.onAdded = angular.noop;
        this.$scope.mappings = {};
        this.$scope.validation = {
            validate: () => $q.resolve(),
            reset: angular.noop,
            errors: {},
            warnings: {}
        };
        this.$scope.addDevices = () => this.addDevices();
        this.$scope.close = () => this.close();
        this.$scope.activator = () => this.start();
        this.$scope.onFileSelected = (file: File) => this.onFileSelected(file);
        this.$scope.pipe = (tableState:any) => this.pipe(tableState);
        this.reset();
        
        this.$scope.closeButtonText = ()=> {
            if (this.$scope.added) {
                return "Close";
            }else if(this.$scope.importDevicesForm.$valid == false){
                return "Close";
            }else{
                return "Cancel";
            }
        };
    }

    getComponentKey():string {
        return directiveName;
    }

    attach(predixListController: PredixListController):void {
        this._predixListController = predixListController;
    }

    start(): boolean {
        if(this.$scope.inProgress) {
            return false;
        }
        this.reset();
        if(!this.$scope.active) {
            this.$scope.$broadcast("proxFileDialog:open");
            return true;
        } else {
            return false;
        }
    }

    close(): boolean {
        if(this.$scope.inProgress) {
            return false;
        }
        this.$scope.active = false;
        return true;
    }

    isActive():boolean {
        return this.$scope.active;
    }

    isEnabled():boolean {
        return !this.$scope.inProgress;
    }

    private addDevices() {
        this.$scope.showImportResult = false;
        if(this.$scope.inProgress) {
            return;
        }
        this.$scope.inProgress = true;
        this.PredixDevicesService.addDevicesToInventory(this.devices)
            .then((data) => {
                this.$scope.added = true;
                this.$scope.onAdded();
                setTimeout(()=>{
                    this.$scope.$emit('smartTable:refreshRequired');
                },1000);
                _.each(this.$scope.devicesPreview, (devImportSummary)=>{
                    try {
                        let did = devImportSummary.$device.did.toLowerCase();
                        var devData = _.find(data, (d)=>{return d.did == did})
                        if(devData){
                            this.$scope.showImportResult = true;
                            devImportSummary.result = "Ok";
                        }
                    }catch(err){}
                })
            })
            .catch((err) => {
                console.error(err);
                if(err.message) {
                    this.$scope.importDevicesForm.$setValidity("httpError", false, <any>(this.$scope.importDevicesForm));
                    this.$scope.validation.errors.httpError = err.message;
                } else {
                    this.$scope.importDevicesForm.$setValidity("genericError", false, <any>(this.$scope.importDevicesForm));
                }
                // applay details information
                _.each(this.$scope.devicesPreview, (devImportSummary)=>{
                    try {
                        let did = devImportSummary.$device.did.toLowerCase();
                        devImportSummary.result = err.details[did];
                        this.$scope.showImportResult = true;
                    }catch(err){}
                })
                setTimeout(()=>{
                    this.$scope.$emit('smartTable:refreshRequired');
                },1000);
            })
            .finally(() => {
                this.$scope.inProgress = false;
            });
    }

    private onFileSelected(file: File) {
        this.$scope.active = true;
        this.$scope.inProgress = true;
        var reader = new FileReader();

        reader.onload = (onLoadEvent) => {
            this.$scope.$apply(() => {
                var valid = true;
                var csvReader;
                try {
                    this.$scope.validation.errors = {};
                    this.$scope.validation.warnings = {};
                    csvReader = this.CsvSerializer.createCsvReader(reader.result);
                    var header = csvReader.readHeader();
                    var lackingColumns = _.filter(this.$scope.mappings.csvRequiredColumns, c => {
                        return header.indexOf(c) < 0;
                    });
                    if (lackingColumns.length > 0) {
                        this.$scope.importDevicesForm.$setValidity("csvHeaders", false, <any>(this.$scope.importDevicesForm));
                        this.$scope.validation.errors.lackingColumns = lackingColumns;
                        valid = false;
                    }

                    csvReader.mapping = this.$scope.mappings.csvToJson;
                    /*csvReader.setValidator(this.$scope.mappings.csvValidator, (obj: any, mapped: any, index: number, result: IProxMapperValidationResult) => {
                        if(!result.valid) {
                            this.$scope.importDevicesForm.$setValidity("dataError", false, <any>(this.$scope.importDevicesForm));
                            this.$scope.importDevicesForm.$errorData.dataError = this.$scope.importDevicesForm.$errorData.dataError || {
                                    errors: []
                                };
                            if(result.missingSourceFields) {
                                this.$scope.importDevicesForm.$errorData.dataError.errors.push({
                                    index: index,
                                    error: `Missing data in required columns: ${result.missingSourceFields.join(', ')}`
                                })
                            } else {
                                var errors = _.map(result.errors, err => {
                                    return {
                                        index: index,
                                        error: err
                                    }
                                });
                                this.$scope.importDevicesForm.$errorData.dataError.errors = this.$scope.importDevicesForm.$errorData.dataError.errors.concat(errors)
                            }
                        }
                    });*/
                    
                    var serialNumber_regex = /^(\d{2})(1[0-2]|0[1-9])(\d{5})$/;
                    if(valid) {
                        var devices = [];
                        var deviceData: any;
                        //var validationPromises: ng.IPromise<string[]>[] = [];
                        while(deviceData = csvReader.readRecord(true)) {
                            if(devices.length == LIMIT) {
                                this.$scope.validation.warnings.devicesLimit = { limit: LIMIT };
                                break;
                            }
                            
                            var device: IPredixDeviceToAdd = this.ProxMapper.map(deviceData, this.$scope.mappings.jsonToPredix);
                            deviceData.$device = device;
                            //validationPromises.push(this.PredixDevicesService.validateDeviceToAdd(device));
                        
                            devices.push(device);
                            this.devicesData.push(deviceData);
                            
                            if(serialNumber_regex.test(deviceData.serialNumber)== false){
                                this.$scope.validation.errors.invalidSerialNumber = this.$scope.validation.errors.invalidSerialNumber || [];
                                this.$scope.validation.errors.invalidSerialNumber.push(deviceData.serialNumber);
                                this.$scope.importDevicesForm.$setValidity("invalidSerialNumber", false, <any>(this.$scope.importDevicesForm));
                            }
                        }

                        this.$scope.validation.validate(this.devicesData)
                            .then(() => {
                                this.devices = devices;
                                this.$scope.devicesLoaded = true;
                                this.$scope.inProgress = false;
                            }).catch(() => {
                                this.devices = devices;
                                this.$scope.devicesLoaded = true;
                                this.$scope.inProgress = false;
                            });

                        /*this.$q.all(validationPromises)
                            .then((errors: string[][]) => {
                                var allErrors = _.map(errors, (rowErrors, index) => {
                                    return _.map(rowErrors, error => {
                                        return {
                                            index: index,
                                            error: error
                                        }
                                    });
                                });
                                allErrors = _.flatten(allErrors);
                                this.devices = devices;
                                this.$scope.devicesLoaded = true;
                                if(allErrors.length > 0) {
                                    this.$scope.importDevicesForm.$setValidity("dataError", false, <any>(this.$scope.importDevicesForm));
                                    this.$scope.importDevicesForm.$errorData.dataError = this.$scope.importDevicesForm.$errorData.dataError || {
                                        errors: []
                                    };
                                    this.$scope.importDevicesForm.$errorData.dataError.errors = this.$scope.importDevicesForm.$errorData.dataError.errors.concat(allErrors);
                                }
                            });*/
                    } else {
                        this.$scope.inProgress = false;
                    }
                } catch(err) {
                    if(err instanceof CsvError) {
                        this.$scope.importDevicesForm.$setValidity("csvParse", false, <any>(this.$scope.importDevicesForm));
                        this.$scope.validation.errors.csvParseError = err;
                    } else {
                        this.$scope.importDevicesForm.$setValidity("genericError", false, <any>(this.$scope.importDevicesForm));
                        this.$scope.validation.errors.genericError = err;
                    }
                    valid = false;
                    this.$scope.inProgress = false;
                }
            });
        };

        reader.readAsText(file);
    }

    private pipe(tableState:any): void {
        var limit = tableState.pagination.number;
        var offset = tableState.pagination.start;
        this.$scope.devicesPreview = this.devicesData.slice(offset, limit + offset);
        this.$scope.totalDevices = this.devicesData.length;
        this.$scope.inProgress = false;
        tableState.pagination.numberOfPages = Math.ceil(this.devicesData.length / tableState.pagination.number);
        tableState.pagination.totalItemCount = this.devicesData.length;
    }

    private reset() {
        this.$scope.showImportResult = false;
        this.devices = [];
        this.devicesData = [];
        this.$scope.devicesPreview = [];
        this.$scope.devicesLoaded = false;
        this.$scope.active = false;
        this.$scope.added = false;
        this.$scope.inProgress = false;
        if(this.$scope.importDevicesForm) {
            this.$scope.importDevicesForm.$setPristine();
            this.$scope.importDevicesForm.$setUntouched();
            this.$scope.importDevicesForm.$setValidity("csvParse", true, <any>(this.$scope.importDevicesForm));
            this.$scope.importDevicesForm.$setValidity("csvHeaders", true, <any>(this.$scope.importDevicesForm));
            this.$scope.importDevicesForm.$setValidity("genericError", true, <any>(this.$scope.importDevicesForm));
            this.$scope.importDevicesForm.$setValidity("httpError", true, <any>(this.$scope.importDevicesForm));
            this.$scope.importDevicesForm.$setValidity("invalidSerialNumber", true, <any>(this.$scope.importDevicesForm));
        }
        this.$scope.validation.reset();
        this.$scope.validation.errors = {};
        this.$scope.validation.warnings = {};
    }
}

function PredixImportDevicesDirective($branding: app.branding.IBrandingService) {
    return makeListComponent(directiveName, {
        templateUrl: $branding.getTemplateUrl('PredixImportDevicesDirective'),
        controller: PredixImportDevicesController,
        scope: {
            active: '=?',
            activator: '=?',
            onAdded: '&'
        }
    });
}

function PredixImportDevicesButtonDirective() {
    return makeListComponentButton(directiveName);
}

export default angular.module('directives.predix.importDevices', [CsvSerializerModule.name, ProxMapperServiceModule.name, PredixDevicesServiceModule.name, DeviceModelsServiceModule.name])
    .directive("predixImportDevices", ['$branding', PredixImportDevicesDirective])
    .directive("predixImportDevicesButton", PredixImportDevicesButtonDirective)
;