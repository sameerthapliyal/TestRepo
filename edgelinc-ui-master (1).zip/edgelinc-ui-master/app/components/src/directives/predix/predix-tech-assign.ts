import PredixDevicesServiceModule, {
    PredixDevicesService,
    IPredixDevice
} from "../../services/predix/PredixDevicesService";
import {
    IListComponent, PredixListController, makeListComponent,
    makeListComponentButton
} from "./devices/predix-device-list/predix-list";

var directiveName = "predixTechAssign";

interface PredixTechnician {
    tech: string;
    desc: string;
}

interface predixTechAssignScope extends ng.IScope {
    technicians: any[];
    assignClose: () => void;
    startPredixTechAssign: () => void;
    inProgress:()=> boolean;
    enabled: boolean;
    showPredixTechAssign: boolean;
    techAssigningInProgress: boolean;
    techAssigningStarted: boolean;
    assigned: boolean;
    success: boolean;
    errorMessage: string;
    qnxAsignError: string;
    assign: PredixTechnician;
    devicesToAssign: IPredixDevice[];
    assignDevice(form: ng.IFormController): void;
    condition(args: {item: IPredixDevice}): boolean;
    assignDeviceForm:ng.IFormController;
    assignDevices: IPredixDevice[];
}

interface predixTechAssignAttrs extends ng.IAttributes {
    condition: string;
}

class predixTechAssignController implements IListComponent {
    private _selectedItems: IPredixDevice[];
    private _predixListController: PredixListController;

    constructor(
        private _scope: predixTechAssignScope,
        private _attrs: predixTechAssignAttrs,
        private _predixDevicesService: PredixDevicesService) {
        this._scope.assign = {
            tech: null,
            desc: null
        };
        this._scope.enabled = false;
        this._scope.assigned = false;
        this._scope.assignDevice = (form: ng.IFormController) => this.assignDevice(form);
        this._scope.startPredixTechAssign = () => {
            this._scope.showPredixTechAssign = true;
            this._scope.techAssigningStarted = true;
            this.startTechAssigning();
            return
        };
        this._scope.$on("stCustomSelection:selectedItemsChanged", (event: any, checkedDevices: any[]) => {
            if (event.defaultPrevented == false) {
                this._selectedItems =  checkedDevices;
                this._scope.enabled = this.validate(checkedDevices);
                this._scope.devicesToAssign = checkedDevices;
            }
        });
        this._scope.assignClose = () => {
            this._scope.showPredixTechAssign = false;
            this._scope.techAssigningStarted = false;
            this._scope.assigned = false;
            this._scope.assign = {
              tech: null,
              desc: null
            };
            return;
        };
        this._scope.inProgress = ()=>{
            return this._scope.techAssigningStarted;
        };
        this.loadTechnicians();
    }

    getComponentKey():string {
        return directiveName;
    }

    attach(predixListController:PredixListController):void {
        this._predixListController = predixListController;
    }

    start():boolean {
        this._scope.showPredixTechAssign = true;
        this._scope.techAssigningStarted = true;
        this.startTechAssigning();
        return true;
    }

    close():boolean {
        this._scope.showPredixTechAssign = false;
        this._scope.techAssigningStarted = false;
        this._scope.assigned = false;
        this._scope.assign = {
            tech: null,
            desc: null
        };
        return true;
    }

    isActive():boolean {
        return this._scope.showPredixTechAssign;
    }

    isEnabled():boolean {
        return this._scope.enabled;
    }


    private startTechAssigning() {
        this._scope.devicesToAssign = this._selectedItems;
        var currentTechnicians = _.chain(this._scope.devicesToAssign).map(d => d.technician).uniq().value();
        if(currentTechnicians.length == 1) {
            this._scope.assign.tech = currentTechnicians[0];
        } else {
            this._scope.assign.tech = null;
        }
        this._scope.assignDeviceForm.$setPristine();
    }

    private assignDevice(form: ng.IFormController) {
        if (this._scope.techAssigningInProgress) {
            return;
        }
        var devices = this.devideDevices();
        var physicalDids = [];
        var qnxAsdids = [];
        var tech = this._scope.assign.tech;
        var desc = this._scope.assign.desc;
        this._scope.assignDevices = [];

        physicalDids = this.createDidOrAsdidArray(devices.physicalDevices, 'did');
        qnxAsdids = this.createDidOrAsdidArray(devices.qnxDevices, 'asdid');

        if(physicalDids.length > 0) {
          this._scope.techAssigningInProgress = true;
          this._predixDevicesService.assignDevices(physicalDids, tech, desc)
              .then(() => {
                  this._scope.success = true;
                  this._scope.errorMessage = null;
                  this._predixListController.refresh();
                  this._scope.assignDevices.push.apply(this._scope.assignDevices, devices.physicalDevices);
              })
              .catch((response) => {
                  this._scope.success = false;
                  this._scope.errorMessage = response.message;
              })
              .finally(() => {
                  this._scope.techAssigningInProgress = false;
                  this._scope.assigned = true;
              });
        }

        if(qnxAsdids.length > 0 ) {
            var devicesAssertions = this.prepareArrayAssertions(qnxAsdids, tech);

            this._predixDevicesService.assignQnxDevices(devicesAssertions)
                .then(() => {
                    this._scope.success = true;
                    this._scope.qnxAsignError = null;
                    this._scope.assignDevices.push.apply(this._scope.assignDevices, devices.qnxDevices);
                    this._predixListController.refresh();
                })
                .catch((response) => {
                    this._scope.success = false;
                    this._scope.qnxAsignError = "Error during processing request";
                })
                .finally(() => {
                    this._scope.techAssigningInProgress = false;
                    this._scope.assigned = true;
                });

        }

    }

    private loadTechnicians() {
        this._predixDevicesService.getTechnicians()
            .then(technicians => this._scope.technicians = technicians);
    }
    private validate(devices: IPredixDevice[]): boolean {
        if(devices.length <= 0) {
            return false;
        }
        if(this._attrs.condition) {
            return  _.all(devices, d => this._scope.condition({item: d}));
        } else {
            return true;
        }
    }

    private devideDevices() {
        // devide devices for Qnx -> class "Gateway" and Physical -> other classes
        var devices = {
            qnxDevices: [],
            physicalDevices: []
        };

        devices.qnxDevices = this._scope.devicesToAssign.filter(function(devToAssign){
            return devToAssign.class == "Gateway";
        });

        devices.physicalDevices = this._scope.devicesToAssign.filter(function(devToAssign){
            return devToAssign.class != "Gateway";
        });

        return devices;
    }

    private prepareArrayAssertions(qnxAsdids: string[], assignTech: string) {
        var devicesAssertionArray = [];
        _.each(qnxAsdids, (qnxAsdid) => {
            let assertionObject = {
                subject: `$devices/${qnxAsdid}`,
                predicate: `$attributes/technicianId`,
                object: assignTech
            }
            devicesAssertionArray.push(assertionObject);
        });
        return devicesAssertionArray;
    }

    private createDidOrAsdidArray(devArray: any, parameter: string){
        let responseArray = [];
        devArray.forEach(function(value, index) {
            responseArray.push((<any>value)[parameter]);
        });
        return responseArray;
    }
}

function PredixTechAssignDirective() {
    return makeListComponent(directiveName, {
        scope: {
            condition: "&"
        },
        restrict: "E",
        controller: ["$scope", "$attrs", 'PredixDevicesService', predixTechAssignController],
        templateUrl: "/components/src/directives/predix/predix-tech-assign.html"
    });
}

function PredixTechAssignButtonDirective() {
    return makeListComponentButton(directiveName);
}


export default angular.module("directives.predix.predixTechAssign", [PredixDevicesServiceModule.name])
    .directive("predixTechAssign", [PredixTechAssignDirective])
    .directive("predixTechAssignButton", PredixTechAssignButtonDirective)
;
