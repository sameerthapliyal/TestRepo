///<reference path="../../../../../typings/browser.d.ts"/>

import PredixDevicesServiceModule, {
    PredixDevicesService,
    IPredixDeviceToAdd, IPredixDevice
} from "../../services/predix/PredixDevicesService";
import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";
import GroupOperationsServiceModule, {GroupOperationsService} from "../../services/GroupOperationsService";
import DeviceServiceModule, {IDevicesToAdd, IDeviceToAdd,IAddDevicesResult} from "../../services/DeviceService";
import AuthServiceModule, {AuthService} from "../../services/AuthService";
import ProxMapperServiceModule, {FieldsMapping, ProxMapperService} from "../../utilities/proxMapper";
import {ProxListController} from "../list-header/prox-list";
import addDevicesGroupOperationSummaryModule from "../add-devices-range/add-devices-group-operation-summary";
import {
    IListComponent, PredixListController, makeListComponent,
    makeListComponentButton
} from "./devices/predix-device-list/predix-list";
import ConfigServiceModule, {ConfigService} from "../../components/src/services/ConfigService";

var directiveName = "predixAddDevice";

interface IAddDeviceViaMcs {
    interfaces: {
        options: Array<string>;
        selectedInterface: string;
    }
    uplincgateway: {
        addDevice: {
            devices: Array<string>;
            selectedDevice: string;
            range:{
                from:number;
                to:number;
            }
            singleLocoId:number;
        },
        addSerialNumber: {
            number: number;
        }
    }
    qnxGateway: {
        addQNXCustomerId: {
            selectedId: string;
        }
        addQNXDevice: {
            devices: Array<string>;
            selectedDevice: string;
        }
        addQNXAntennaMfg: {
            antennas: Array<string>;
            selectedAntennaMfg: string;
        }
        addQNXAntennaModel: {
            antennaModels: Array<string>;
            selectedModel: string;
        }
    }
}

interface IDeviceData {
    iterator: string; //number;
    deviceToAdd?: IDeviceToAdd;
    result?: {
        success?: boolean;
        asdid?: string;
        reason?: string;
        assertions_set?: boolean;
        reregistered?:boolean;
    }
    sort_status?:number;
}

interface IPredixAddDeviceScope extends ng.IScope {
    state: {
        active: boolean;
        completed: boolean;
        success: boolean;
        errorMessage: boolean;
        inProgress: boolean;
    }
    device: any;
    mapping_predix: FieldsMapping;
    mapping_qnx: FieldsMapping;
    predixDevice: IPredixDeviceToAdd | IDevicesToAdd;
    addedDevice: IPredixDeviceToAdd | IDevicesToAdd;
    addDevice(form: ng.IFormController): void;
    close(): void;
    onAdded(): void;
    formChange(): void;
    showWarning: boolean;
    mcsProperties: IAddDeviceViaMcs;
    
    upperLocoIdLimit():number;
    lowerLocoIdLimit():number;
    iterator:number;
    //user_login:string;
    
    // group operation summary
    added:boolean;
    successDevices:number;
    failedDevices:number;
    inProgressDevices:number;
    reregisteredDevices:number;
    totalDevices:number;
    devicesData:IDeviceData[];
}

class PredixAddDeviceController implements IListComponent {
    public static $inject = ["$scope", "$q", "$timeout", "ProxMapper", "PredixDevicesService", "DeviceModelsService", "GroupOperationsService", "AuthorizationService", "$config"];

    public addDeviceForm: ng.IFormController;

    private _predixListController: PredixListController;

    constructor(
        private $scope: IPredixAddDeviceScope,
        private $q: ng.IQService,
        private $timeout: ng.ITimeoutService,
        private ProxMapper: ProxMapperService,
        private PredixDevicesService: PredixDevicesService,
        private DeviceModelsService: DeviceModelsService,
        private GroupOperationsService: GroupOperationsService,
        private authorizationService: AuthService,
        private _config:ConfigService
    ) {
        this.$scope.state = {
            active: false,
            completed: false,
            success: null,
            errorMessage: null,
            inProgress: false
        };
        this.$scope.showWarning = false;
        this.$scope.addDevice = (form: ng.IFormController) => this.addDevice(form);
        this.$scope.close = () => this.close();
        this.$scope.formChange = () => this.formChanged();
        this.$scope.mcsProperties = {
            interfaces: {
                options: ['UpLINCGateway', 'QNX Gateway'],
                selectedInterface: ''
            },
            uplincgateway: {
                addDevice: {
                    devices: ['HPEAP'],
                    selectedDevice: '',
                    range:{
                        from:null,
                        to:null
                    },
                    singleLocoId:null
                },
                addSerialNumber: {
                    number: 0
                }
            },
            qnxGateway: {
                addQNXCustomerId: {
                    selectedId: ''
                },
                addQNXDevice: {
                    devices: ['LIG','HPEAP'],
                    selectedDevice: ''
                },
                addQNXAntennaMfg: {
                    antennas: ['General Electric'],
                    selectedAntennaMfg: ''
                },
                addQNXAntennaModel: {
                    antennaModels: ['CellWMP1'],
                    selectedModel: ''
                }
            },
        };
        this.reset();
    
        $scope.upperLocoIdLimit = ()=>{
            return Math.max(Math.min(this.$scope.mcsProperties.uplincgateway.addDevice.range.to || 9999999, 9999999),0);
        };
        $scope.lowerLocoIdLimit = ()=>{
            return Math.max(Math.min(this.$scope.mcsProperties.uplincgateway.addDevice.range.from || 0, 9999999),0);
        };

        $scope.device.user_login = this.authorizationService.getLoginUserName();
    }

    getComponentKey():string {
        return directiveName;
    }

    attach(predixListController:PredixListController):void {
        this._predixListController = predixListController;
    }

    start(): boolean {
        this.reset();
        this.$scope.state.active = true;
        return true;
    }

    close(): boolean {
        if(this.$scope.state.inProgress) {
            return false;
        }
        this.$scope.state.active = false;
        return true;
    }

    isActive(): boolean {
        return this.$scope.state.active;
    }

    isEnabled(): boolean {
        return !this.$scope.state.inProgress;
    }
    
    private addDevice(form: ng.IFormController) {
        if(this.$scope.mcsProperties.interfaces.selectedInterface == "QNX Gateway"){
            this.addDevice_Go(form);
        }else{
            this.addDevice_Predix(form);
        }
    }
    
    private addDevice_Predix(form: ng.IFormController) {
        if(this.$scope.state.inProgress) {
            return;
        }

        if(!this.$scope.device.serialNumber && !this.$scope.mcsProperties.uplincgateway.addSerialNumber.number){
          this.$scope.showWarning = true;
          return;
        }
        this.$scope.state.inProgress = true;
        var device: IPredixDeviceToAdd = this.ProxMapper.map(this.$scope.device, this.$scope.mapping_predix);
        this.$scope.predixDevice = device;

        this.PredixDevicesService.addDeviceToInventory(device)
            .then(addedDevice => {
                this.$scope.addedDevice = addedDevice;
                this.$scope.state.success = true;
                this.$scope.onAdded();
                if(this._predixListController) {
                    this._predixListController.refresh();
                }
                //this.tryGetNewCreatedDeviceActivationCode(device.did);
            })
            .catch(err => {
                this.$scope.state.errorMessage = err.message;
                this.$scope.state.success = false;
            })
            .finally(() => {
                this.$scope.state.inProgress = false;
                this.$scope.state.completed = true;
                this.$scope.$emit('smartTable:refreshRequired');
            });
    }
    
    private addDevice_Go(form: ng.IFormController) {
        if(this.$scope.state.inProgress) {
            return;
        }
        // add device using gooup operation
        this.$scope.state.inProgress = true;
        var devicesToAdd:IDevicesToAdd = [];
        
        this.devicesData = [];
        for( this.$scope.iterator = parseInt(<any>this.$scope.mcsProperties.uplincgateway.addDevice.range.from || this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId || 0);
             this.$scope.iterator <= parseInt(<any>this.$scope.mcsProperties.uplincgateway.addDevice.range.to || this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId || 0);
             this.$scope.iterator++)
        {
            var device: IDeviceToAdd = this.ProxMapper.map(this.$scope, this.$scope.mapping_qnx);
            devicesToAdd.push(device);
            this.devicesData.push({
                iterator: this.$scope.iterator.toString(),
                deviceToAdd: device,
                result: {success:null, assertions_set:null}
            });
        }
        this.$scope.predixDevice = devicesToAdd;
        this.GroupOperationsService.addDevicesGO(devicesToAdd).then((result:eapi18.GroupOperationIdObject)=>{
            //this.getAndDisplayTaskDetails(result.operation_id, 0);
            this.$scope.state.inProgress = false;
            this.$scope.state.success = true;
        }).catch((err)=>{
            this.$scope.state.errorMessage = err.message;
            this.$scope.state.success = false;
        }).finally(()=>{
            this.$scope.state.inProgress = false;
            this.$scope.state.completed = true;
            this.$scope.$emit('smartTable:refreshRequired');
        });
        
    }
    /*
    private tryGetNewCreatedDeviceActivationCode(device_id:string, retry_count=10){
        this.PredixDevicesService.getDevicesInventory({dids: device_id}, "asdid").then((device:any) => {
            if(typeof device === "undefined" || device == null || device["items"].length <= 0){
                console.log("Can't get device.");
                setTimeout(()=>{
                    this.tryGetNewCreatedDeviceActivationCode(device_id, retry_count--);
                },1000);
            } else {
                this.$scope.predixDevice = device["items"][0];
                if(this.$scope.predixDevice.predix_activation_code == null && retry_count > 0){
                    setTimeout(()=>{
                        this.tryGetNewCreatedDeviceActivationCode(device_id, retry_count--);
                    },1000);
                }else if(this._predixListController) {
                    this._predixListController.refresh();
                }
            }
        }).catch(err => {
            console.log(err.message);
            setTimeout(()=>{
                this.tryGetNewCreatedDeviceActivationCode(device_id, retry_count--);
            },1000);
        });
    }
    */
    private reset() {
        this.$scope.device = {};
        this.$scope.predixDevice = null;
        this.$scope.addedDevice = null;
        this.$scope.state.active = false;
        this.$scope.state.completed = false;
        this.$scope.state.success = null;
        this.$scope.state.errorMessage = null;
        this.$scope.state.inProgress = false;
    
        this.$scope.mcsProperties.interfaces.selectedInterface = '';
        this.$scope.mcsProperties.uplincgateway.addDevice.selectedDevice ="";
        this.$scope.mcsProperties.uplincgateway.addDevice.range.from = null;
        this.$scope.mcsProperties.uplincgateway.addDevice.range.to = null;
        this.$scope.mcsProperties.uplincgateway.addDevice.singleLocoId = null;
        this.$scope.mcsProperties.qnxGateway.addQNXCustomerId.selectedId ="";
        this.$scope.mcsProperties.qnxGateway.addQNXAntennaMfg.selectedAntennaMfg ="";
        this.$scope.mcsProperties.qnxGateway.addQNXAntennaModel.selectedModel ="";
        this.$scope.mcsProperties.qnxGateway.addQNXDevice.selectedDevice ="";

        if(this.addDeviceForm) {
            this.addDeviceForm.$setPristine();
        }
    }

    private formChanged() {
      this.$scope.showWarning = false;
    }
    
    private devicesData: IDeviceData[];
    /*
    private getAndDisplayTaskDetails_promise:ng.IPromise<void>;
    private getAndDisplayTaskDetails(groupOperationId:string, delay:number){
        this.$scope.added = true;
        this.getAndDisplayTaskDetails_promise = this.$timeout(()=>{
            this.getAndDisplayTaskDetails_promise = null;
            this.GroupOperationsService.getGroupOperationDetails(groupOperationId, "registrations").then((groupOperationDetails:models.GroupOperations.IGroupOperation)=>{
                if(this.getAndDisplayGroupOperationDetails_IsGroupOperationFinish(groupOperationDetails) == false){
                    this.getAndDisplayTaskDetails(groupOperationId, 100);
                }
                // Display information about GroupOperation
                _.each(this.devicesData, (dev:IDeviceData)=>{
                    dev.result.reason = "";
                });
                
                this.$scope.inProgressDevices = groupOperationDetails.items.filter((ti)=>{return ti.result == null}).length;
                var asdid_generation_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "asdid_generation");
                _.each(asdid_generation_taskItems, (ti:models.GroupOperations.ITaskItem)=>{
                    var deviceData:IDeviceData = this.devicesData.filter(d => {return d.deviceToAdd.did != null && d.deviceToAdd.did == (<any>ti).data.did})[0];
                    if(deviceData != null && ti.result == "SUCCESS") {
                        deviceData.result.asdid = ti.asdid;
                    }else if(deviceData != null && ti.data["error"]){
                        deviceData.result.reason += ti.data["error"] || "";
                        deviceData.result.reason += ", ";
                    }
                });
                
                var registration_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "registration");
                _.each(registration_taskItems, (ti:models.GroupOperations.ITaskItem)=>{
                    var deviceData:IDeviceData = this.devicesData.filter(d => {return d.result.asdid != null && d.result.asdid == (<any>ti).asdid})[0];
                    if(deviceData != null && ti.result == "SUCCESS") {
                        deviceData.result.success = true;
                        deviceData.result.reregistered = ti.data["reregistered"] || false;
                    }else if(deviceData != null && ti.status == "FINISHED"){
                        deviceData.result.success = false;
                        if(ti.data["error"]) {
                            deviceData.result.reason += ti.data["error"] || "";
                            deviceData.result.reason += ", ";
                        }
                    }
                });
                
                var assertions_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "assertions");
                _.each(assertions_taskItems, (ti:models.GroupOperations.ITaskItem)=>{
                    var deviceData:IDeviceData = this.devicesData.filter(d => {return d.result.asdid != null && d.result.asdid == (<any>ti).asdid})[0];
                    if(deviceData != null && ti.result == "SUCCESS") {
                        deviceData.result.assertions_set = true;
                    }else if(deviceData != null && ti.status == "FINISHED"){
                        deviceData.result.assertions_set = false;
                        if(ti.data["error"]) {
                            deviceData.result.reason += ti.data["error"] || "";
                            deviceData.result.reason += ", ";
                        }
                    }
                });
                
                this.$scope.successDevices = 0;
                this.$scope.failedDevices = 0;
                this.$scope.inProgressDevices = 0;
                this.$scope.reregisteredDevices = 0;
                this.devicesData.forEach((devAdd: IDeviceData)=>{
                    if(devAdd.result.success && devAdd.result.assertions_set && devAdd.result.asdid != null){
                        if(devAdd.result.reregistered){
                            this.$scope.reregisteredDevices++;
                            devAdd.sort_status = 0;
                        }else{
                            this.$scope.successDevices++;
                            devAdd.sort_status = 2;
                        }
                    }else if(devAdd.result.success === false || devAdd.result.assertions_set === false){
                        this.$scope.failedDevices++;
                        devAdd.sort_status = 0;
                    }else{
                        this.$scope.inProgressDevices++;
                        devAdd.sort_status = 1;
                    }
                });
                
                this.$scope.totalDevices = this.devicesData.length;
            });
        }, delay);
    }
    
    private getAndDisplayGroupOperationDetails_IsGroupOperationFinish(groupOperationDetails:models.GroupOperations.IGroupOperation):boolean{
        if(groupOperationDetails.items == null || groupOperationDetails.items.length ==0 ){
            return false;
        }
        var registration_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "registration");
        var asdid_generation_taskItems  = groupOperationDetails.items.filter(ti=>ti.type == "asdid_generation");
        if(registration_taskItems.length != asdid_generation_taskItems.length || asdid_generation_taskItems.length == 0 || registration_taskItems.length == 0){
            return false;
        }
        
        return groupOperationDetails.status == "FINISHED" && this.$scope.added;
    }
    */
}

function PredixAddDeviceDirective($branding: app.branding.IBrandingService) {
    return makeListComponent(directiveName, {
        templateUrl: $branding.getTemplateUrl('PredixAddDeviceDirective'),
        controller: PredixAddDeviceController,
        controllerAs: 'ctrl',
        scope: {
            onAdded: "&"
        }
    });
}

function PredixAddDeviceButtonDirective() {
    return makeListComponentButton(directiveName);
}

export default angular.module('directives.predix.addDevice', [ProxMapperServiceModule.name, PredixDevicesServiceModule.name, DeviceModelsServiceModule.name, GroupOperationsServiceModule.name,
    DeviceServiceModule.name, AuthServiceModule.name, addDevicesGroupOperationSummaryModule.name])
    .directive("predixAddDevice", ['$branding', PredixAddDeviceDirective])
    .directive("predixAddDeviceButton", PredixAddDeviceButtonDirective)
;
