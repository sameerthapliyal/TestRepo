/**
 * Created by rosadnik on 05-Jul-17.
 */

import McsTemplateServiceModule, { McsTemplateService, IMcsTemplateItem, IMcsTemplatesResponce, ITemplateAction, ITemplateActionResponse} from "../../../services/mcs/mcsTemplateService";

interface mcsTemplateScope extends ng.IScope{
    asdid: string;
    isLoading: boolean;
    getDataError:any;
    TemplateList:IMcsTemplatesResponce;
    
    ReviseReapply:()=>void;
    ReviseReapply_cancel:()=>void;
    ReviseReapply_confirm:()=>void;
    ReviseReapply_showConfirmationMassage:boolean;
    ReviseReapply_OperationList:mcsTemplateActionToConfirm[];
    ReviseReapply_error:any
    ReviseReapply_inProgres:boolean;
    ReviseReapply_success:ITemplateActionResponse;
}

interface mcsTemplateActionToConfirm{
    tempObjid:string;
    action:"Remove"|"Reapply";
    templateType:string;
    tempVer:string;
}

interface mcsTempalteItemRowControllerScope extends ng.IScope{
    item:IMcsTemplateItem;
}

interface  mcsTempalteHeaderRowControllerScope extends ng.IScope{
    title:string;
    expand:boolean;
}

interface IMcsTemplateItemDisplay extends IMcsTemplateItem{
    remove_check?:boolean;
    reapply_check?:boolean;
}

class McsTempalteController{
    private static $inject = ['$scope', '$timeout', 'McsTemplateService'];
    
    constructor( private $scope:mcsTemplateScope,private $timeout:ng.ITimeoutService, private _mcsTemplateService:McsTemplateService ){
        this.$scope.isLoading = true;
        this._mcsTemplateService.getTemplates(this.$scope.asdid).then((templateData:IMcsTemplatesResponce)=>{
            
            this.$scope.TemplateList = templateData;
            this.$scope.isLoading = false;
            this.$scope.getDataError = null;
        }).catch((err)=>{
            this.$scope.getDataError = err;
            this.$scope.isLoading = false;
        });
        this.$scope.ReviseReapply = ()=> {
            this.$scope.ReviseReapply_error = null;
            this.$scope.ReviseReapply_success = null;
            this.$scope.ReviseReapply_inProgres = false;
            this.$scope.ReviseReapply_showConfirmationMassage = !this.$scope.ReviseReapply_showConfirmationMassage;
            this.$scope.ReviseReapply_showConfirmationMassage && this.createListOfActionToConfirm();
        };
        this.$scope.ReviseReapply_cancel = ()=>{
            this.$scope.ReviseReapply_showConfirmationMassage = false
            this.$scope.ReviseReapply_error = null;
            this.$scope.ReviseReapply_success = null;
            this.$scope.ReviseReapply_inProgres = false;
        };
        this.$scope.ReviseReapply_confirm = ()=> this.ReviseReapply();
        
        this.$scope.$watch(()=>{
            return JSON.stringify(this.$scope.TemplateList);
        },()=>{
            this.createListOfActionToConfirm();
        });
    }
    
    private ReviseReapply(){
        let actions:ITemplateAction[] = this.$scope.ReviseReapply_OperationList.map((ta:mcsTemplateActionToConfirm)=>{return {
            templateObjid:ta.tempObjid,
            action: ta.action
        }});
        this.$scope.ReviseReapply_showConfirmationMassage = false;
        this.$scope.ReviseReapply_inProgres = true;
        this._mcsTemplateService.removeReapplyTemplates(this.$scope.asdid,actions).then((data:ITemplateActionResponse)=>{
            this.$scope.ReviseReapply_success = data;
            this.$scope.ReviseReapply_inProgres = false;
            this.$scope.TemplateList = data;
        }).catch((err)=>{
            this.$scope.ReviseReapply_error = err;
            this.$scope.ReviseReapply_inProgres = false;
        });
    }
    
    private createListOfActionToConfirm(){
        this.$scope.ReviseReapply_OperationList = [];
        if(this.$scope.TemplateList) {
            this.createListOfActionToConfirm_partial(this.$scope.TemplateList.commissioningTemplates);
            this.createListOfActionToConfirm_partial(this.$scope.TemplateList.configurationTemplates);
            this.createListOfActionToConfirm_partial(this.$scope.TemplateList.geServiceTemplates);
            this.createListOfActionToConfirm_partial(this.$scope.TemplateList.serviceConfigurationTemplates);
            this.createListOfActionToConfirm_partial(this.$scope.TemplateList.commissioningChildTemplates);
            this.createListOfActionToConfirm_partial(this.$scope.TemplateList.commissioningChildPfsTemplates);
        }
    }
    
    private createListOfActionToConfirm_partial(list:IMcsTemplateItemDisplay[]){
        _.each(list, (templateItem:IMcsTemplateItemDisplay)=>{
            if(templateItem.remove_check){
                this.$scope.ReviseReapply_OperationList.push({
                    tempObjid:templateItem.tempObjid,
                    action:"Remove",
                    templateType:templateItem.templateType,
                    tempVer:templateItem.tempVer,
                });
            }
    
            if(templateItem.reapply_check){
                this.$scope.ReviseReapply_OperationList.push({
                    tempObjid:templateItem.tempObjid,
                    action:"Reapply",
                    templateType:templateItem.templateType,
                    tempVer:templateItem.tempVer,
                });
            }
        })
    }
}

class McsTempalteItemRowController{
    private static $inject = ['$scope'];
    
    constructor(private $scope:mcsTempalteItemRowControllerScope){
    
    }
}

class mcsTemplateHeaderRowController{
    private static $inject = ['$scope','$element'];
    
    constructor(private $scope:mcsTempalteHeaderRowControllerScope, private $element:ng.IAugmentedJQuery){
        this.$scope.expand = true;
        this.$element.addClass("mcs-template-header-row");
    }
}

var angularModule = angular.module("directives.mcsTemplate", [McsTemplateServiceModule.name])
.directive('mcsTemplate', ['$branding', ($branding) => {
    return {
        restrict: "E",
        replace: true,
        scope: {
            asdid: '=devAsdid',
        },
        controller: McsTempalteController,
        templateUrl: $branding.getTemplateUrl("directives.mcsTemplate"),
    }
}]);

angularModule.directive("mcsTemplateItemRow", [()=>{
    return{
        scope:{
            item:"=mcsTemplateItemRow",
        },
        controller: McsTempalteItemRowController,
        templateUrl: "/components/src/directives/mcs/mcs-template/mcs-template-item-row.html",
    };
}]);

angularModule.directive("mcsTemplateHeaderRow", [()=>{
    return {
        scope:{
            items:"=mcsTemplateItems",
            title:"@",
            expand:"="
        },
        controller:mcsTemplateHeaderRowController,
        templateUrl: "/components/src/directives/mcs/mcs-template/mcs-template-header-row.html",
    };
}]);

export default angularModule;