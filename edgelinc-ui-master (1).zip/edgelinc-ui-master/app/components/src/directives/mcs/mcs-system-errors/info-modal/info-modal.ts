///<reference path="../../../../../../../typings/browser.d.ts"/>

function McsInfoModalDirective ($branding) {
      return {
          restrict: "E",
          templateUrl: '/components/src/directives/mcs/mcs-system-errors/info-modal/info-modal.html'
        }
};

export default angular.module("directives.infoModal", [])
    .directive('infoModal', ['$branding', McsInfoModalDirective]);
