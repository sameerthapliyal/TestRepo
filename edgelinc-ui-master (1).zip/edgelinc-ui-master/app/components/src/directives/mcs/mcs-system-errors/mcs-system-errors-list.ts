///<reference path="../../../../../../typings/browser.d.ts"/>

import McsGeneralServiceModule, {McsGeneralService} from "../../../services/mcs/McsGeneralService";
import McsSystemErrorsServiceModule, {McsSystemErrorsService, IMcsSystemErrorsResponse} from "../../../services/mcs/McsSystemErrorsService";
import McsSystemErrorsDetailsModule from "./mcs-system-error-details/mcs-system-error-details";
import * as _ from "lodash";


export interface ISystemErrorsListFilter {
    daysToView?: number;
    sourceIP?: string;
    errorCategory?: string;
    customerName?: string;
    roadInitial?: string;
    roadNumber?: number;
    device?: string;
    outboundMessageID?: number
    limit?: number;
    offset?: number;
}

interface IMcsSystemErrorsListScope extends ng.IScope {
    seListFilter: ISystemErrorsListFilter;
    onFilterChange(): void;
    canListErrors: boolean;
    listErrors(): void;
    listErrorClicked: boolean;
}

interface IMcsSystemErrorsTableScope extends ng.IScope {
    seListFilter: ISystemErrorsListFilter;
    listErrorClicked: boolean;
    pipe(tableState: any, tableCtrl: any): void;
    pageSize: number;
    visibleErrors: any;
    toggleDetails(row: any, $index:number);
    filteredCount: number;
    from: number;
    to: number;
    isLoading: boolean;
    msgTxt: string;
    error: any;
}

interface IMcsSystemErrorsFiltersScope extends ng.IScope {
    seListFilter: ISystemErrorsListFilter;
    filterChanged(): void;
    onFilterChange(): void;
    lookupData: {
      errorCategoryDpd?: any;
      daysToViewDpd?: any;
      deviceDpd?: any;
      customerNameDpd?: any;
      roadNameDpd?: any;
    }
    allCustomerNames?: any;
    waitingForDropdown: boolean;
    initError: any;
    refresh(): void;
}

var requiredFilters = ["customerName", "roadInitial", "roadNumber"];
var mappedCustomer = {
    "Illinois Central Railroad": "IC",
    "IC": "IC",
    "Canadian National": "CN",
    "CN": "CN"
}

var mappedErrors = {
    "Invalid Parameter : Please specify Road Initial to uniquely identify one asset.": "Please specify Customer, Customer ID and Loco. ID to uniquely identify one asset",
    "Invalid Parameter : Please specify Customer Name and Road Initial to uniquely identify one asset.": "Please specify Customer, Customer ID and Loco. ID to uniquely identify one asset",
    "Invalid Parameter : Please specify Road Number to uniquely identify one asset.": "Please specify Customer, Customer ID and Loco. ID to uniquely identify one asset",
    "Invalid Parameter : sourceIP": "The Source IP Address is not valid"
}

class McsSystemErrorsListController {
    private static $inject = ['$scope', '$timeout', 'McsGeneralService'];

    constructor(private $scope: IMcsSystemErrorsListScope,
                private $timeout: ng.ITimeoutService,
                private McsGeneralService: McsGeneralService
    ) {
        this.$scope.seListFilter = {};
        this.$scope.canListErrors = false;

        this.$scope.onFilterChange = () => this.onFilterChanged();

        this.$scope.listErrors = () => {
            this.$scope.listErrorClicked = this.$scope.listErrorClicked ? !this.$scope.listErrorClicked : true;
        }
    }

    private onFilterChanged() {
        this.removeEmptyfilters();
    }

    private removeEmptyfilters() {
        this.$scope.seListFilter = this.mapSeFilters();
        this.$scope.seListFilter = _.omitBy(this.$scope.seListFilter, _.isNil);  //remove all undefined and null value from filters
        if(_.isEmpty(this.$scope.seListFilter) || !this.$scope.seListFilter.daysToView) {
            this.$scope.canListErrors = false;
        } else {
            this.$scope.canListErrors = true;
        }
    }

    private mapSeFilters() {
        let filters = {
            daysToView: this.$scope.seListFilter.daysToView ? this.$scope.seListFilter.daysToView : null,
            sourceIP: this.$scope.seListFilter.sourceIP ? this.$scope.seListFilter.sourceIP : null,
            errorCategory: this.$scope.seListFilter.errorCategory ? this.$scope.seListFilter.errorCategory : null,
            customerName: this.$scope.seListFilter.customerName ? this.$scope.seListFilter.customerName : null,
            roadInitial: this.$scope.seListFilter.roadInitial ? this.$scope.seListFilter.roadInitial : null,
            roadNumber: this.$scope.seListFilter.roadNumber ? this.$scope.seListFilter.roadNumber : null,
            device: this.$scope.seListFilter.device ? this.$scope.seListFilter.device : null,
            outboundMessageID: this.$scope.seListFilter.outboundMessageID ? this.$scope.seListFilter.outboundMessageID : null
          }
        return filters;
    }
}

class McsSystemErrorsFiltersController {
  private static $inject = ['$scope', 'McsGeneralService', ];
  constructor(private $scope: IMcsSystemErrorsFiltersScope,
              private McsGeneralService: McsGeneralService
  ) {

      this.$scope.onFilterChange = () => this.$scope.filterChanged();
      this.$scope.waitingForDropdown = true;
      this.getDropdown();

      $scope.$watch('seListFilter.customerName', (newCustomerName:any) => {
          this.mapDropdownValues(newCustomerName)
      });
      this.$scope.refresh = () => this.getDropdown();
  }

  private getLookupData(dataSetNames: string[]): ng.IPromise<any> {
       return this.McsGeneralService.getLookupData(dataSetNames);
  }

  private getDropdown () {
      return this.getLookupData(['DAYS_TO_VIEW', 'ASSET_DEVICES', 'ERROR_PROCESSOR_CATEGORIES', 'MCS_LOCO_SERVICE_OWNERS', 'MCS_LOCO_SERVICE_ROAD_INITIALS'])
          .then(lookups => {
              this.$scope.lookupData = {};
              this.$scope.lookupData.daysToViewDpd = lookups.DAYS_TO_VIEW;
              this.$scope.lookupData.deviceDpd = lookups.ASSET_DEVICES;
              this.$scope.lookupData.errorCategoryDpd = lookups.ERROR_PROCESSOR_CATEGORIES;
              this.$scope.lookupData.customerNameDpd = lookups.MCS_LOCO_SERVICE_OWNERS;
              this.$scope.allCustomerNames = lookups.MCS_LOCO_SERVICE_ROAD_INITIALS;
              this.$scope.waitingForDropdown = false;
              this.$scope.initError = null;
          }).catch(err => {
              console.log(err);
              this.$scope.waitingForDropdown = false;
              this.$scope.initError = err;
          });
  }

  private mapDropdownValues(choosenCustName: any) {
      if(typeof this.$scope.lookupData == "undefined") {
          this.$scope.lookupData = {};
      }
      this.$scope.lookupData.roadNameDpd = [];
      _.each(this.$scope.allCustomerNames, (custNameObj) => {
          if(custNameObj.lookupName == mappedCustomer[choosenCustName]) {
              this.$scope.lookupData.roadNameDpd.push(custNameObj);
          }
      });
  }

}

class McsSystemErrorsTableController {
  private static $inject = ['$scope', '$uibModal', 'McsGeneralService', 'McsSystemErrorsService'];

  private tableState: any;

  constructor(private $scope: IMcsSystemErrorsTableScope,
              private $uibModal,
              private McsGeneralService: McsGeneralService,
              private McsSystemErrorsService: McsSystemErrorsService
  ) {

      $scope.pipe = (_tableState: any) => {
          this.tableState = _tableState;
          if(this.checkRequiredFiltersIfAtLeastOneSelected(this.$scope.seListFilter)) {
              this.doRequest();
          }
      };

      $scope.$watch('listErrorClicked', (newValue:any) => {
          if(typeof newValue != "undefined") {
              this.$scope.isLoading = true;
              this.doRequest();
          }
      });

      this.$scope.toggleDetails = (row: any, $index:number)=>{
          row.isDetailsShow = !row.isDetailsShow;
      };
  }

  private doRequest() {
      if(_.isEmpty(this.$scope.seListFilter)) {
          return;
      }
      if(!this.tableState) {
          return;
      }
      let filters = angular.extend(
          this.$scope.seListFilter,
          {
              offset: this.tableState.pagination.start,
              limit: this.tableState.pagination.number

          }
      );
      let parameters = {
          params: filters
      }


      return this.McsSystemErrorsService.getSystemErrors(parameters)
          .then((result: IMcsSystemErrorsResponse) => {
              this.$scope.visibleErrors = result.data;
              this.$scope.filteredCount = result.totalCount;
              this.$scope.from = this.tableState.pagination.start + 1;
              const maxRange = this.tableState.pagination.start + this.tableState.pagination.number;
              this.$scope.to = maxRange < this.$scope.filteredCount ? maxRange : this.$scope.filteredCount;
              this.tableState.pagination.numberOfPages = Math.ceil(this.$scope.filteredCount / this.tableState.pagination.number);
              this.tableState.pagination.totalItemCount = result.totalCount;
              this.$scope.isLoading = false;
              this.$scope.error = null;
          })
          .catch(err => {
              console.error(err);
              if(err.statusCode == 422 && this.displayErrorMessage(err.data.errorMessage)) {
                  let message = this.$scope.msgTxt;
                  this.$uibModal.open({
                      animation: true,
                      template: '<info-modal></info-modal>',
                      controller: function ($scope, $uibModalInstance) {
                          $scope.title = 'Warning';
                          $scope.modalBody = message;
                          $scope.ok = function () {
                              $uibModalInstance.close();
                          };
                      },
                      size: 'md',
                      backdrop: 'static',
                      windowClass: 'info-modal-custom'
                  });
              } else {
                  this.$scope.error = err;
              }
              this.$scope.visibleErrors = [];
              this.$scope.from = 0;
              this.$scope.to = 0;
              this.$scope.filteredCount = 0;
              this.tableState.pagination.totalItemCoun = 0;
              this.$scope.isLoading = false;
          });
  }

  private checkRequiredFiltersIfAtLeastOneSelected(seFilters: ISystemErrorsListFilter) {
      let hasAllRequiredFilters = true;
      if(seFilters.customerName || seFilters.roadInitial || seFilters.roadNumber) {
        _.each(requiredFilters, (filter: any) => {
            if(!this.$scope.seListFilter.hasOwnProperty(filter)) {
                hasAllRequiredFilters = false;
            }
        });
      }
      return hasAllRequiredFilters;
  }

  private displayErrorMessage(errorMessage) {
      this.$scope.msgTxt = this.mapErrorMessage(errorMessage);
      if(this.$scope.msgTxt != "") {
          return true;
      } else {
          return false;
      }
  }

  private mapErrorMessage(errorMessage) {
      let errorToDisplay = mappedErrors[errorMessage];
      if(!errorToDisplay) {
          errorToDisplay = "";
          let parsedError = errorMessage.split(":");
          parsedError.shift();
          _.each(parsedError, (err) => {
              errorToDisplay += err;
          });
      }

      return errorToDisplay;

  }
}

function McsSystemErrorsFiltersDirective($branding: app.branding.IBrandingService) {
  return {
    templateUrl: $branding.getTemplateUrl('McsSystemErrorsFiltersDirective'),
    restrict: "E",
    scope: {
      seListFilter: '=',
      filterChanged: '&'
    },
    controller: McsSystemErrorsFiltersController
  }
}

function McsSystemErrorsListDirective($branding: app.branding.IBrandingService) {
  return {
    templateUrl: $branding.getTemplateUrl('McsSystemErrorsListDirective'),
    restrict: "E",
    controller: McsSystemErrorsListController
  }
}

function McsSystemErrorsTableDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('McsSystemErrorsTableDirective'),
        controller: McsSystemErrorsTableController,
        scope: {
            enableSelection: '=?',
            selectedId: '=?',
            showCheckboxes: '=?',
            seListFilter: '=?',
            listErrorClicked: '=?',
            filteredCount: '=?',
            from: '=?',
            to: '=?'
        }
    }
}

export default angular.module('directives.mcsSystemErrorsList', [McsGeneralServiceModule.name, McsSystemErrorsServiceModule.name, McsSystemErrorsDetailsModule.name])
  .directive('mcsSystemErrorsList', ['$branding', McsSystemErrorsListDirective])
  .directive('mcsSystemErrorsFilters', ['$branding', McsSystemErrorsFiltersDirective])
  .directive('mcsSystemErrorsTable', ['$branding', McsSystemErrorsTableDirective]);
