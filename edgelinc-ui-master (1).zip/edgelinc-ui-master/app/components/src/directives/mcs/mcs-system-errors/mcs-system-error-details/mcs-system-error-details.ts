import McsSystemErrorsServiceModule, {McsSystemErrorsService, IMcsSystemErrorDetails} from "../../../../services/mcs/McsSystemErrorsService";

interface IMcsSystemErrorDetailsScope extends ng.IScope{
    errorId: number;
    errorDetails: IMcsSystemErrorDetails;
    isLoading: boolean;
    error: any;
    refresh(): any;
}

class McsSystemErrorDetailsController {

    private static $inject = ['$scope', 'McsSystemErrorsService'];

    constructor(private $scope: IMcsSystemErrorDetailsScope,
                private McsSystemErrorsService: McsSystemErrorsService
    ) {
        this.$scope.isLoading = false;
        if(this.$scope.errorId) {
            this.$scope.isLoading = true;
            this.getDetails();
        }
        this.$scope.refresh = () => {
            if(this.$scope.errorId) {
                this.$scope.isLoading = true;
                this.getDetails();
            }
        }
    }

    private getDetails() {
        this.McsSystemErrorsService.getSystemErrorDetails(this.$scope.errorId).then((response: any)=>{
            this.$scope.errorDetails = response;
            this.$scope.isLoading = false;
            this.$scope.error = null;
        }).catch((err)=>{
            this.$scope.isLoading = false;
            this.$scope.error = err;
            console.log(err);
        });
    }


}

export default angular.module("directives.mcsSystemErrorsDetails", [McsSystemErrorsServiceModule.name])
.directive('systemErrorDetails', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            errorId: '=?'
        },
        controller: McsSystemErrorDetailsController,
        templateUrl: $branding.getTemplateUrl("McsSystemErrorsDetailsDirective"),
    }
}]);
