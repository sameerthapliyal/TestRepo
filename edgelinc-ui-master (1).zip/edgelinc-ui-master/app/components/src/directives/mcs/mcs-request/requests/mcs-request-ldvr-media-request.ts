import {McsRequestsService, IMcsRequestSubmitResponse} from "../../../../services/mcs/McsRequestsService";
import {IMcsSpecificRequestScope, McsSpecificRequestControllerBase} from "./McsSpecificRequestControllerBase";

interface IMcsRequestLdvrMediaRequestScopeData {
    selectAll: boolean;
    cameras: {[name: string]: {checked: boolean}}
}

class McsRequestLdvrMediaRequestController extends McsSpecificRequestControllerBase<IMcsSpecificRequestScope> {
    public data: IMcsRequestLdvrMediaRequestScopeData;

    public static $inject = ["$scope", "$q", "McsRequestsService"];
    constructor($scope: any, $q: ng.IQService, private McsRequestsService: McsRequestsService) {
        super($scope, $q);
        this.data = {
            selectAll: false,
            cameras: {}
        };

        $scope.$watch(() => this.data.selectAll, selectAll => {
            if(selectAll === true) {
                _.each(this.data.cameras, camera => camera.checked = true);
            } else if (selectAll === false) {
                _.each(this.data.cameras, camera => camera.checked = false);
            }
        });

        $scope.$watch(() => {
            let result = {all: true, any: false};
            _.each(this.data.cameras, camera => {
                result.all = result.all && camera.checked;
                result.any = result.any || camera.checked;
            });
            return result;
        }, (result: {all: boolean, any:boolean}) => {
            this.data.selectAll = result.all ? true : !result.any ? false : null;
        }, true);
    }

    protected submitAction(): ng.IPromise<IMcsRequestSubmitResponse> {
        let checkedCameras = [];
        _.each(this.data.cameras, (camera, cameraName) => {
            if(camera.checked) {
                checkedCameras.push(cameraName);
            }
        });
        return this.McsRequestsService.submitLdvrMediaRequest(this.$scope.asdid, {
            comments: this.comments,
            camera: checkedCameras,
            userName: null
        });
    }

    protected resetAction(): void {
        super.resetAction();
        _.each(this.data.cameras, camera => {
            camera.checked = false;
        });
    }

    protected reinitAction(): ng.IPromise<any> {
        return this.McsRequestsService.getCameras(this.$scope.asdid)
            .then(response => {
                let toRemove = _.clone(this.data.cameras);
                _.each(response.camera, camera => {
                    if(_.has(this.data.cameras, camera)) {
                        delete toRemove[camera];
                    } else {
                        this.data.cameras[camera] = {
                            checked: false
                        };
                    }
                });
                _.each(_.keys(toRemove), camera => {
                    delete this.data.cameras[camera];
                });
            })
    }
}


export function McsRequestLdvrMediaRequest($branding: app.branding.IBrandingService) {
    return {
        restrict: "E",
        templateUrl: $branding.getTemplateUrl('/components/src/directives/mcs/mcs-request/requests/mcs-request-ldvr-media-request'),
        scope: {
            asdid: '=',
            initError: '&',
            beforeSubmit: '&',
            submitSuccess: '&',
            submitError: '&'
        },
        controller: McsRequestLdvrMediaRequestController,
        controllerAs: "ctrl"
    }
}
McsRequestLdvrMediaRequest.$inject = ['$branding'];