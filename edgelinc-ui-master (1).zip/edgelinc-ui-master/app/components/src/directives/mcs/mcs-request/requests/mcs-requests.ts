import McsRequestsServiceModule from "../../../../services/mcs/McsRequestsService";
import {McsRequestGeneric} from "./mcs-request-generic";
import {McsRequestForceRegistration} from "./mcs-request-force-registration";
import {McsRequestLdvrRemoteStartStop} from "./mcs-request-ldvr-remote-start-stop";
import {McsRequestLdvrMediaRequest} from "./mcs-request-ldvr-media-request";
import {McsRequestReboot} from "./mcs-request-reboot";
import {McsRequestLdvrPreservationDownload} from "./mcs-request-ldvr-preservation-download";


export default angular.module('directives.mcs.mcsRequests.requests', [McsRequestsServiceModule.name])
    .directive('mcsRequestGeneric', McsRequestGeneric)
    .directive('mcsRequestForceRegistration', McsRequestForceRegistration)
    .directive('mcsRequestLdvrRemoteStartStop', McsRequestLdvrRemoteStartStop)
    .directive('mcsRequestLdvrMediaRequest', McsRequestLdvrMediaRequest)
    .directive('mcsRequestLdvrPreservationDownload', McsRequestLdvrPreservationDownload)
    .directive('mcsRequestReboot', McsRequestReboot)
