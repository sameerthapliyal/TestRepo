import {IMcsRequestSubmitResponse} from "../../../../services/mcs/McsRequestsService";

export interface IMcsSpecificRequestScope extends ng.IScope {
    asdid: string;
    beforeSubmit(): boolean;
    initError(args: {error: any}): void;
    submitSuccess(args: {result: IMcsRequestSubmitResponse});
    submitError(args: {error: any}): void;
    mcsSpecificRequestForm: ng.IFormController;
}

export abstract class McsSpecificRequestControllerBase<TScope extends IMcsSpecificRequestScope> {
    public ready: boolean;
    public comments: string;

    constructor(protected $scope: TScope, protected $q: ng.IQService) {
        this.$scope.$on('mcs-request:reset', this.reset.bind(this));
        this.$scope.$on('mcs-request:reinit', this.reinit.bind(this));
        setTimeout(() => {
            $scope.$apply(() => {
                this.reset();
            })
        })
    }

    public submit() {
        if(this.$scope.beforeSubmit()) {
            if(this.$scope.mcsSpecificRequestForm) {
                this.$scope.mcsSpecificRequestForm.$setSubmitted();
            }
            this.submitAction()
                .then(result => this.$scope.submitSuccess({result}))
                .catch(error => this.$scope.submitError({error}));
        }
    }

    protected reset() {
        this.resetAction();
        this.reinit();
    }

    protected reinit() {
        this.ready = false;
        this.reinitAction()
            .then(() => this.ready = true)
            .catch(error => this.$scope.initError({error}));
    }

    protected abstract submitAction(): ng.IPromise<IMcsRequestSubmitResponse>;
    protected resetAction() {
        this.comments = null;
        if(this.$scope.mcsSpecificRequestForm) {
            this.$scope.mcsSpecificRequestForm.$setPristine();
        }
    }
    protected reinitAction(): ng.IPromise<any> {
        return this.$q.resolve();
    }
}