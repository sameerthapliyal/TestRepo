import McsRequestsServiceModule, {
    IRequestHistoryFilter, IRequestHistoryItem,
    McsRequestsService
} from "../../../services/mcs/McsRequestsService";
import McsGeneralServiceModule, {McsGeneralService} from "../../../services/mcs/McsGeneralService";
import {DataSet, DataSetEntry, IMessageType} from "../../../services/mcs/McsServiceBase";
import * as _ from "lodash";
import {HttpError} from "../../../utilities/RestHelper";

interface IMcsRequestHistoryControllerScope extends ng.IScope {
    asdid: string;
    refresh();
    filterChanged();
    clear();
    pipe(tableState: any): void;
}

interface IListItem {
    key: string;
    value: string;
}

const MESSAGE_DIRECTION = "MESSAGE_DIRECTION";
const DAYS_TO_VIEW = "DAYS_TO_VIEW";
const MESSAGE_DELIVERY_STATUSES = "MESSAGE_DELIVERY_STATUSES";

class McsRequestHistoryController {
    public messageDirectionsDataSet: DataSet;
    public daysToViewDataSet: DataSet;
    public messageDeliveryStatusesDataSet: DataSet;
    public messageTypes: IMessageType[];
    public filter: IRequestHistoryFilter;
    public initializationPromise: ng.IPromise<any>;
    public isLoading: boolean = true;
    public lastTableState = null;
    public initError: HttpError = null;
    public error: HttpError = null;
    public items: IRequestHistoryItem[];
    public actions = {
        exportTable: _.noop
    };
    public retrieveDataThrottled: () => ng.IPromise<App.Models.SearchResult<IRequestHistoryItem>>;
    private _lastFilter: IRequestHistoryFilter;

    public static $inject = ['$scope', '$q', 'McsRequestsService', 'McsGeneralService'];
    constructor(private $scope: IMcsRequestHistoryControllerScope,
                private $q: ng.IQService,
                private McsRequestsService: McsRequestsService,
                private McsGeneralService: McsGeneralService
    ) {
        this.init();

        $scope.refresh = this.refresh.bind(this);
        $scope.filterChanged = this.filterChanged.bind(this);
        $scope.clear = this.clear.bind(this);
        $scope.pipe = this.getItems.bind(this);

        this.retrieveDataThrottled = this.$q.throttle(this.retrieveData.bind(this));
    }

    public init() {
        this.initError = null;
        this.filter = this.getEmptyFilter();
        let lookupDataPromise = this.McsGeneralService.getLookupData([MESSAGE_DIRECTION, DAYS_TO_VIEW, MESSAGE_DELIVERY_STATUSES])
            .then(dataSets => {
                this.messageDirectionsDataSet = dataSets[MESSAGE_DIRECTION];
                this.daysToViewDataSet = dataSets[DAYS_TO_VIEW];
                this.messageDeliveryStatusesDataSet = dataSets[MESSAGE_DELIVERY_STATUSES];

                if(this.filter.daysToView == null) {
                    let daysToViewEntry = this.daysToViewDataSet ? _.minBy(this.daysToViewDataSet, entry => entry.lookupOrder) : null;
                    if(daysToViewEntry) {
                        this.filter.daysToView = daysToViewEntry.lookupValue;
                    }
                }
            });
        let messageTypesPromise = this.McsGeneralService.getMessageTypes()
            .then(messageTypes => this.messageTypes = messageTypes);

        this.initializationPromise = this.$q.all([lookupDataPromise, messageTypesPromise])
            .catch(error => {

                this.initError = error
            });

    }

    public getItems(tableState: any): ng.IPromise<App.Models.SearchResult<IRequestHistoryItem>> {
        this.lastTableState = tableState;
        return this.retrieveDataThrottled();
    }

    public retrieveData(): ng.IPromise<App.Models.SearchResult<IRequestHistoryItem>> {
        let lastFilter = this._lastFilter;
        this._lastFilter = _.cloneDeep(this.filter);
        let limit =  this.lastTableState ? this.lastTableState.pagination.number : 10;
        let offset = this.lastTableState ? this.lastTableState.pagination.start : 0;
        return this.initializationPromise
            .then(() => this.McsRequestsService.getRequestsHistory(this.$scope.asdid, this.filter, limit, offset))
            .then(result => {
                this.error = null;
                this.isLoading = false;
                this.items = result.items;
                this.lastTableState.pagination.totalItemCount = result.totalCount;
                return result;
            })
            .catch(error => {
                this.error = error;
                this.isLoading = false;
                this._lastFilter = lastFilter;
                this.items = [];
                this.lastTableState.pagination.totalItemCount = 0;
                return this.$q.reject(error);
            })
    }

    public refresh() {
        this.$scope.$broadcast('smartTable:refreshRequired');
    }

    public filterChanged() {

    }

    public clear() {
        this.filter = this.getEmptyFilter();
        this.applyFilters();
    }

    public applyFilters() {
        if(!_.isEqual(this.filter, this._lastFilter)) {
            this.refresh();
        }
    }

    private getEmptyFilter() {
        let daysToViewEntry = this.daysToViewDataSet ? _.minBy(this.daysToViewDataSet, entry => entry.lookupOrder) : null;
        return {
            daysToView: daysToViewEntry ? daysToViewEntry.lookupValue : null
        }
    }

    public getMessageType(objId: string) {
        return objId; // TODO: use dataset
    }

    public getDirection(objId: string) {
        return objId; // TODO: use dataset
    }

    public getStatus(objId: string) {
        return objId; // TODO: use dataset
    }
}

function McsRequestHistory($branding: app.branding.IBrandingService) {
    return {
        require: "E",
        scope: {
            asdid: '=devAsdid',
        },
        controller: McsRequestHistoryController,
        controllerAs: "ctrl",
        templateUrl: $branding.getTemplateUrl("/components/src/directives/mcs/mcs-request/mcs-request-history")
    }
}
McsRequestHistory.$inject = ['$branding'];

export default angular.module("directives.mcs.mcsRequestHistory", [McsRequestsServiceModule.name, McsGeneralServiceModule.name])
    .directive('mcsRequestHistory', McsRequestHistory);