import {
    McsRequestsService, IMcsRequestSubmitResponse,
    IMcsActivePreservationRequestStatus, IMcsActivePreservationRequestsResponseWithTotal
} from "../../../../services/mcs/McsRequestsService";
import {IMcsSpecificRequestScope, McsSpecificRequestControllerBase} from "./McsSpecificRequestControllerBase";


interface IMcsRequestLdvrPreservationDownloadScopeData {
    selectAll: boolean;
    cameras: {[name: string]: {checked: boolean}};
    importance: "High"|"Low";
    deletionType: "Manual"|"AfterOffload";
    requestTitle: string;
    requestedStartTime: Date;
    requestedEndTime: Date;
}

class McsRequestLdvrPreservationDownloadController extends McsSpecificRequestControllerBase<IMcsSpecificRequestScope> {
    public data: IMcsRequestLdvrPreservationDownloadScopeData;
    public summary: IMcsActivePreservationRequestsResponseWithTotal;
    public table: {
        from: number;
        to: number;
        total: number;
        getRequests(table: any): ng.IPromise<App.Models.SearchResult<IMcsActivePreservationRequestStatus>>;
        pipe(tableState: any): void;
        refresh(): void;
        startExport(): void;
        items: IMcsActivePreservationRequestStatus[];
    };

    public static $inject = ["$scope", "$q", "McsRequestsService", "$filter"];
    constructor($scope: any, $q: ng.IQService, private McsRequestsService: McsRequestsService, private $filter) {
        super($scope, $q);

        this.data = {
            selectAll: false,
            cameras: {},
            importance: null,
            deletionType: null,
            requestTitle: null,
            requestedStartTime: null,
            requestedEndTime: null
        };

        this.table = {
            from: 0,
            to: 0,
            total: 0,
            getRequests: this.getRequests.bind(this),
            pipe: (tableState: any) => {
                this.getRequests(tableState)
                    .then(result => {
                        this.table.items = result.items;
                        tableState.pagination.totalItemCount = result.totalCount;
                    })
                    .catch(error => this.$scope.initError({error}));
            },
            refresh: () => {
                this.$scope.$broadcast('smartTable:refreshRequired')
            },
            startExport: null, // setting by st-custom-export-form directive
            items: []
        };

        $scope.$watch(() => this.data.selectAll, selectAll => {
            if(selectAll === true) {
                _.each(this.data.cameras, camera => camera.checked = true);
            } else if (selectAll === false) {
                _.each(this.data.cameras, camera => camera.checked = false);
            }
        });

        $scope.$watch(() => {
            let result = {all: true, any: false};
            _.each(this.data.cameras, camera => {
                result.all = result.all && camera.checked;
                result.any = result.any || camera.checked;
            });
            return result;
        }, (result: {all: boolean, any:boolean}) => {
            this.data.selectAll = result.all ? true : !result.any ? false : null;
        }, true);
    }

    public getRequests(table: any): ng.IPromise<App.Models.SearchResult<IMcsActivePreservationRequestStatus>> {
        let limit =  table ? table.pagination.number : 10;
        let offset = table ? table.pagination.start : 0;
        return this.McsRequestsService.getActivePreservationRequests(this.$scope.asdid, limit, offset)
            .then(result => {
                this.summary = result;
                this.table.from = Math.min(offset + 1, result.totalCount);
                this.table.to = Math.min(offset + limit, result.totalCount);
                this.table.total = result.totalCount;

                return {
                    items: result.status,
                    totalCount: result.totalCount
                }
            });
    }

    protected submitAction(): ng.IPromise<IMcsRequestSubmitResponse> {
        let dateFilter: ng.IFilterDate = this.$filter('date');
        let checkedCameras = [];
        _.each(this.data.cameras, (camera, cameraName) => {
            if(camera.checked) {
                checkedCameras.push(cameraName);
            }
        });
        return this.McsRequestsService.submitLDVRPreservationDownloadRequest(this.$scope.asdid, {
            comments: this.comments,
            camera: checkedCameras,
            importance: this.data.importance,
            deletionType: this.data.deletionType,
            requestTitle: this.data.requestTitle,
            requestedStartTime: dateFilter(this.data.requestedStartTime, "MM/dd/yyyy HH:mm:ss.sss"),
            requestedEndTime: dateFilter(this.data.requestedEndTime, "MM/dd/yyyy HH:mm:ss.sss"),
        }).then(response => {
            this.table.refresh();
            return response;
        });
    }

    protected resetAction(): void {
        super.resetAction();
        _.each(this.data.cameras, camera => {
            camera.checked = false;
        });
        this.data.importance = null;
        this.data.deletionType = null;
        this.data.requestTitle = null;
        this.data.requestedStartTime = null;
        this.data.requestedEndTime = null;
    }

    protected reinitAction(): ng.IPromise<any> {
        return this.McsRequestsService.getCameras(this.$scope.asdid)
            .then(response => {
                let toRemove = _.clone(this.data.cameras);
                _.each(response.camera, camera => {
                    if(_.has(this.data.cameras, camera)) {
                        delete toRemove[camera];
                    } else {
                        this.data.cameras[camera] = {
                            checked: false
                        };
                    }
                });
                _.each(_.keys(toRemove), camera => {
                    delete this.data.cameras[camera];
                });
            });
    }
}


export function McsRequestLdvrPreservationDownload($branding: app.branding.IBrandingService) {
    return {
        restrict: "E",
        templateUrl: $branding.getTemplateUrl('/components/src/directives/mcs/mcs-request/requests/mcs-request-ldvr-preservation-download'),
        scope: {
            asdid: '=',
            initError: '&',
            beforeSubmit: '&',
            submitSuccess: '&',
            submitError: '&'
        },
        controller: McsRequestLdvrPreservationDownloadController,
        controllerAs: "ctrl"
    }
}
McsRequestLdvrPreservationDownload.$inject = ['$branding'];