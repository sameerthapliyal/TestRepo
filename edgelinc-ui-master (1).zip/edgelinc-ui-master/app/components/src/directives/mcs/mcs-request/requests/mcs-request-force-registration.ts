import {McsRequestsService, IMcsRequestSubmitResponse, IMcsServerEnvironment, IForceRegistrationRequestData} from "../../../../services/mcs/McsRequestsService";
import {McsGeneralService} from "../../../../services/mcs/McsGeneralService";
import * as _ from "lodash";
import {IMcsSpecificRequestScope, McsSpecificRequestControllerBase} from "./McsSpecificRequestControllerBase";


interface IMcsRequestForceRegistrationData {
    requestorInitials: string;
    requestorLocation: string;
    commPath: "SAR"|"ITCM";
    cmuIpAddress: string;
    confirmCmuIpAddress: string;
    antennaMfg: string;
    antennaModel: string;
    antennaModelDisplay: string;
    antennaModelUnknown: boolean;
    mcsEnvironment: IMcsServerEnvironment;
}

class McsRequestForceRegistrationController extends McsSpecificRequestControllerBase<IMcsSpecificRequestScope> {
    public data: IMcsRequestForceRegistrationData;
    public mcsEnvironments: IMcsServerEnvironment[];

    public static $inject = ["$scope", "$q", "McsRequestsService", "McsGeneralService"];
    constructor($scope: any, $q: ng.IQService, private McsRequestsService: McsRequestsService, private McsGeneralService: McsGeneralService) {
        super($scope, $q);
    }

    protected submitAction(): ng.IPromise<IMcsRequestSubmitResponse> {
        let requestData: IForceRegistrationRequestData = {
            comments: this.comments,
            requestorInitials: this.data.requestorInitials,
            requestorLocation: this.data.requestorLocation,
            commPath: this.data.commPath,
            cmuIpAddress: this.data.cmuIpAddress,
            antennaMfg: this.data.antennaMfg,
            antennaModel: this.data.antennaModel,
            mcsEnvironment: this.data.mcsEnvironment.id
        };
        return this.McsRequestsService.submitForceRegistrationRequest(this.$scope.asdid, requestData);
    }

    protected resetAction(): void {
        super.resetAction();
        this.data = <any>{};
    }

    protected reinitAction(): ng.IPromise<any> {
        this.mcsEnvironments = [];
        let environmentsPromise = this.McsRequestsService.getMCSServerEnvironments(this.$scope.asdid)
            .then(environments => this.mcsEnvironments = environments);

        let deviceDataPromise = this.McsRequestsService.getDeviceDetails(this.$scope.asdid)
            .then(deviceDetails => {
                this.data.antennaMfg = this.data.antennaMfg || _.get<string>(deviceDetails, 'antennaInfo.antennaMfg');
                this.data.antennaModel = this.data.antennaModel || _.get<string>(deviceDetails, 'antennaInfo.antennaModel');
                this.data.cmuIpAddress = this.data.confirmCmuIpAddress = _.get<string>(deviceDetails, 'deviceInfo.deviceIPAddress');
                return this.McsGeneralService.getSingleLookupData("ANTENNA_MODELS").then(dataSet => {
                    let entry = _.find(dataSet, e => e.lookupName === this.data.antennaModel);
                    if(entry) {
                        this.data.antennaModelDisplay = entry.lookupValue;
                        this.data.antennaModelUnknown = false;
                    } else {
                        this.data.antennaModelDisplay = this.data.antennaModel;
                        this.data.antennaModelUnknown = true;
                    }
                });
            });

        return this.$q.all([environmentsPromise, deviceDataPromise])
    }
}

export function McsRequestForceRegistration($branding: app.branding.IBrandingService) {
    return {
        restrict: "E",
        templateUrl: $branding.getTemplateUrl('/components/src/directives/mcs/mcs-request/requests/mcs-request-force-registration'),
        scope: {
            asdid: '=',
            initError: '&',
            beforeSubmit: '&',
            submitSuccess: '&',
            submitError: '&'
        },
        controller: McsRequestForceRegistrationController,
        controllerAs: 'ctrl'
    }
}
McsRequestForceRegistration.$inject = ['$branding'];