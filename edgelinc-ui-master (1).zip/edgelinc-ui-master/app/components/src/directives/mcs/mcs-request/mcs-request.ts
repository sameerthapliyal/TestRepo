import McsRequestsServiceModule, {
    IMcsRequestSubmitResponse, IMcsRequestType,
    McsRequestsService
} from "../../../services/mcs/McsRequestsService";
import McsRequestsModule from "./requests/mcs-requests";

export interface IRequestData {
    requestType: string;
}

interface IMcsRequestControllerScope extends ng.IScope {
    asdid: string;
    mcsRequestForm: ng.IFormController;
    data: IRequestData;
}

class McsRequestController {
    public static $inject = ['$scope', 'McsRequestsService'];

    public requestTypes: IMcsRequestType[];
    public result: IMcsRequestSubmitResponse;
    public submitError: any;
    public initError: any;

    constructor(private $scope: IMcsRequestControllerScope, private McsRequestsService: McsRequestsService) {
        this.$scope.data = {
            requestType: null
        };
        this.init();

        $scope.$watch(() => $scope.data.requestType, () => {
            $scope.mcsRequestForm.$setPristine();
        })
    }

    public beforeSubmit(): boolean {
        this.$scope.mcsRequestForm.$setSubmitted();
        return this.$scope.mcsRequestForm.$valid;
    }

    public handleSubmitSuccess(result: IMcsRequestSubmitResponse) {
        this.result = result;
        this.submitError = null;
        this.resetForm();
    }

    public handleInitError(err: any) {
        console.error(err);
        this.initError = err;
    }

    public handleSubmitError(err: any) {
        console.error(err);
        this.submitError = err;
    }

    public init() {
        this.initError = null;
        this.McsRequestsService.getRequestTypes(this.$scope.asdid)
            .then(requestTypes => this.requestTypes = requestTypes)
            .catch(this.handleInitError.bind(this));
        this.$scope.$broadcast('mcs-request:reinit');
    }

    public resetForm() {
        this.$scope.mcsRequestForm.$setPristine();
        this.$scope.$broadcast('mcs-request:reset');
    }
}

function McsRequest($branding: app.branding.IBrandingService) {
    return {
        require: "E",
        scope: {
            asdid: '=devAsdid',
        },
        controller: McsRequestController,
        controllerAs: "ctrl",
        templateUrl: $branding.getTemplateUrl("/components/src/directives/mcs/mcs-request/mcs-request")
    }
}
McsRequest.$inject = ['$branding'];

export default angular.module("directives.mcs.mcsRequests", [McsRequestsServiceModule.name, McsRequestsModule.name])
    .directive('mcsRequest', McsRequest);