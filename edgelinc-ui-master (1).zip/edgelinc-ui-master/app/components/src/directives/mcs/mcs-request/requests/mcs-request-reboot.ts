import {
    McsRequestsService, IMcsRequestSubmitResponse, IRemoteStartStopRequestData,
    IMCSApplication
} from "../../../../services/mcs/McsRequestsService";
import {IMcsSpecificRequestScope, McsSpecificRequestControllerBase} from "./McsSpecificRequestControllerBase";
import {HttpError} from "../../../../utilities/RestHelper";
import {McsGeneralService} from "../../../../services/mcs/McsGeneralService";
import {DataSet} from "../../../../services/mcs/McsServiceBase";

interface IMcsRequestRebootScopeData {
    fullRestart: boolean;
    applicationsToRestart: {[appId: string]: {appName: string, checked: boolean}};
    applicationsToRestartError?: HttpError;
    portsToRestart: {[port: string]: {portName: string, checked: boolean}};
    portsToRestartError?: HttpError;
}

class McsRequestRebootController extends McsSpecificRequestControllerBase<IMcsSpecificRequestScope> {
    public data: IMcsRequestRebootScopeData;

    public static $inject = ["$scope", "$q", "McsGeneralService", "McsRequestsService"];
    constructor($scope: any, $q: ng.IQService, private McsGeneralService: McsGeneralService, private McsRequestsService: McsRequestsService) {
        super($scope, $q);
        this.data = {
            fullRestart: false,
            applicationsToRestart: null,
            portsToRestart: null
        };
    }

    protected submitAction(): ng.IPromise<IMcsRequestSubmitResponse> {
        let applicationsToRestart = [];
        _.each(this.data.applicationsToRestart, (app, appId) => {
            if(app.checked) {
                applicationsToRestart.push(appId);
            }
        });
        let portsToRestart = [];
        _.each(this.data.portsToRestart, (port, portId) => {
            if(port.checked) {
                portsToRestart.push(portId);
            }
        });
        return this.McsRequestsService.submitRebootRequest(this.$scope.asdid, {
            comments: this.comments,
            fullRestart: this.data.fullRestart ? "Y" : "N",
            applicationsToRestart,
            portsToRestart
        });
    }

    protected resetAction(): void {
        super.resetAction();
        _.each(this.data.applicationsToRestart, app => {
            app.checked = false;
        });
        _.each(this.data.portsToRestart, port => {
            port.checked = false;
        });
        this.data.fullRestart = false;
    }

    protected reinitAction(): ng.IPromise<any> {
        this.data.applicationsToRestartError = null;
        this.data.portsToRestartError = null;

        let applicationsPromise = this.McsRequestsService.getActiveServicesForDevice(this.$scope.asdid)
            .then(applicationsToRestart => {
                this.mergeApplicationsToRestart(applicationsToRestart);
            })
            .catch((err: HttpError) => {
                this.data.applicationsToRestartError = err;
                if(err.isNotFoundError) {
                    this.mergeApplicationsToRestart([]);
                }
            });

        let portsPromise = this.McsGeneralService.getSingleLookupData("CMU_IGNITION_PORTS")
            .then(portsToRestart => {
                this.mergePortsToRestart(portsToRestart);
            })
            .catch((err: HttpError) => {
                this.data.portsToRestartError = err;
            });



        return this.$q.all([applicationsPromise, portsPromise]);
    }

    private mergeApplicationsToRestart(applicationsToRestart: IMCSApplication[]) {
        this.data.applicationsToRestart = this.data.applicationsToRestart || {};
        let applicationsToRemove = _.clone(this.data.applicationsToRestart);
        _.each(applicationsToRestart, app => {
            let appId = app.applicationName;
            let appName = app.applicationDescription;
            if(_.has(this.data.applicationsToRestart, appId)) {
                delete applicationsToRemove[appId];
            } else {
                this.data.applicationsToRestart[appId] = {
                    appName: appName,
                    checked: false
                };
            }
        });
        _.each(_.keys(applicationsToRemove), appId => {
            delete this.data.applicationsToRestart[appId];
        });
    }

    private mergePortsToRestart(portsToRestart: DataSet) {
        this.data.portsToRestart = this.data.portsToRestart || {};
        let portsToRemove = _.clone(this.data.portsToRestart);
        _.each(portsToRestart, value  => {
            let port = value.lookupName;
            let portName = value.lookupValue;
            if(_.has(this.data.portsToRestart, port)) {
                delete portsToRemove[port];
            } else {
                this.data.portsToRestart[port] = {
                    portName: portName,
                    checked: false
                };
            }
        });
        _.each(_.keys(portsToRemove), portId => {
            delete this.data.portsToRestart[portId];
        });
    }
}

export function McsRequestReboot($branding: app.branding.IBrandingService) {
    return {
        restrict: "E",
        templateUrl: $branding.getTemplateUrl('/components/src/directives/mcs/mcs-request/requests/mcs-request-reboot'),
        scope: {
            asdid: '=',
            initError: '&',
            beforeSubmit: '&',
            submitSuccess: '&',
            submitError: '&'
        },
        controller: McsRequestRebootController,
        controllerAs: "ctrl"
    }
}
McsRequestReboot.$inject = ['$branding'];