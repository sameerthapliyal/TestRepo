import {McsRequestsService, IMcsRequestSubmitResponse, IRemoteStartStopRequestData} from "../../../../services/mcs/McsRequestsService";
import {McsSpecificRequestControllerBase, IMcsSpecificRequestScope} from "./McsSpecificRequestControllerBase";



class McsRequestLdvrRemoteStartStopController extends McsSpecificRequestControllerBase<IMcsSpecificRequestScope> {
    public data: IRemoteStartStopRequestData;

    public static $inject = ["$scope", "$q", "McsRequestsService"];
    constructor($scope: any, $q: ng.IQService, private McsRequestsService: McsRequestsService) {
        super($scope, $q);
        this.data = <any>{};
    }

    protected submitAction(): ng.IPromise<IMcsRequestSubmitResponse> {
        return this.McsRequestsService.submitRemoteStartStopRequest(this.$scope.asdid, {
            comments: this.comments,
            internalMemory: this.data.internalMemory,
            networkMemory: this.data.networkMemory,
        });
    }

    protected resetAction(): void {
        super.resetAction();
        this.data = <any>{};
    }
}

export function McsRequestLdvrRemoteStartStop($branding: app.branding.IBrandingService) {
    return {
        restrict: "E",
        templateUrl: $branding.getTemplateUrl('/components/src/directives/mcs/mcs-request/requests/mcs-request-ldvr-remote-start-stop'),
        scope: {
            asdid: '=',
            initError: '&',
            beforeSubmit: '&',
            submitSuccess: '&',
            submitError: '&'
        },
        controller: McsRequestLdvrRemoteStartStopController,
        controllerAs: "ctrl"
    }
}
McsRequestLdvrRemoteStartStop.$inject = ['$branding'];