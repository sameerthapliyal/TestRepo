import {McsRequestsService, IMcsRequestSubmitResponse} from "../../../../services/mcs/McsRequestsService";
import {
    IMcsSpecificRequestScope,
    McsSpecificRequestControllerBase
} from "./McsSpecificRequestControllerBase";


interface IMcsRequestGenericScope extends  IMcsSpecificRequestScope {
    requestType: string;
}



class McsRequestGenericController extends McsSpecificRequestControllerBase<IMcsRequestGenericScope> {

    public static $inject = ["$scope", "$q", "McsRequestsService"];
    constructor($scope: any, $q: ng.IQService, private McsRequestsService: McsRequestsService) {
        super($scope, $q);
    }

    protected submitAction(): ng.IPromise<IMcsRequestSubmitResponse> {
        return this.McsRequestsService.submitGenericRequest(this.$scope.asdid, this.$scope.requestType, this.comments);
    }
}


export function McsRequestGeneric($branding: app.branding.IBrandingService) {
    return {
        restrict: "E",
        templateUrl: $branding.getTemplateUrl('/components/src/directives/mcs/mcs-request/requests/mcs-request-generic'),
        scope: {
            asdid: '=',
            requestType: '=',
            initError: '&',
            beforeSubmit: '&',
            submitSuccess: '&',
            submitError: '&'
        },
        controller: McsRequestGenericController,
        controllerAs: 'ctrl'
    }
}
McsRequestGeneric.$inject = ['$branding'];