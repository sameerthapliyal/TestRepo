import McsGeneralServiceModule, { McsGeneralService } from "../../../services/mcs/McsGeneralService";
import McsGeozonesServiceModule, { McsGeozonesService, IMcsGeozonesResponse } from "../../../services/mcs/McsGeozonesService";
import ParameterStorageServiceModule, { IParameterStorageService, STORAGE_TYPE } from "../../../services/ParameterStorageService";
import {KnownError} from "../../../utilities/RestHelper";

interface IGeozonesListDirectiveScope extends ng.IScope {
  isLoading: boolean,
  filteredItems: number,
  error: any,
  message: string,
  customerNames: string[],
  geozonesData: any,
  refreshEvent: string,
  customerSelected: boolean,
  from: number,
  to: number,
  deactivateGeozones(items: any): void,
  listGeozones(): void,
  addGeozones(): void,
  deactivating: boolean,
  listFilter: {
    active: boolean,
    cn: any
  }
}

interface IGeozonesFiltersDirectiveScope extends ng.IScope {
  customerNames: string[],
  listFilter: {
    active: boolean,
    cn: any
  }
  customerSelected: boolean,
  pending: boolean,
  error: any
  refresh(): void;
}

interface IGeozonesTableDirectiveScope extends ng.IScope {
  visibleItems: any[],
  isLoading: boolean,
  pipe(tableState: any): void;
  offset: number,
  limit: number,
  refreshEvent: string,
  listFilter: {
    active: boolean,
    cn: any
  },
  filteredItems: number,
  from: number,
  to: number
  listError: any;
}

class GeozonesListController {
  private static $inject = ['$scope', '$routeParams', '$location', '$timeout', 'McsGeneralService', 'McsGeozonesService'];
  constructor(private $scope: IGeozonesListDirectiveScope,
    private $routeParams: any,
    private $location: ng.ILocationService,
    private $timeout: ng.ITimeoutService,
    private McsGeneralService: McsGeneralService,
    private McsGeozonesService: McsGeozonesService
  ) {
    this.$scope.listFilter = {
      active: $routeParams.active || true,
      cn: $routeParams.cn || null
    }
    this.$scope.message = ''
    this.$scope.error = null;
    this.$scope.customerSelected = this.$scope.listFilter.cn ? true : false;
    if ($routeParams.success && $routeParams.success.toString() === 'true') this.$scope.message = "Success: the GeoZones were added to the system";
    if ($routeParams.success && $routeParams.success.toString() === 'false') this.$scope.error = new KnownError($routeParams.errorMessage || "Error occured while adding GeoZones.");
    $location.replace();
    $location.search('success', null);
    $location.search('errorMessage', null);
    this.$scope.listGeozones = () => this.listGeozones();
    this.$scope.deactivateGeozones = items => this.deactivateGeozones(items);
  }

  private deactivateGeozones(items) {
    this.$scope.deactivating = true;
    const payload = items.map(o => ({
      geozoneObjid: o.geozoneObjid,
      active: 'N'
    }))
    this.McsGeozonesService.deactivateGeozones(payload)
      .then(response => {
        this.$scope.message = "Success: the GeoZones were deactivated from the system.";
        this.$scope.error = null;
      })
      .catch(err => {
        this.$scope.error = err;
      })
      .finally(() => {
        this.$scope.$broadcast(this.$scope.refreshEvent || 'smartTable:refreshRequired');
        this.$scope.deactivating = false;
      });
  }

  private listGeozones() {
    this.$scope.customerSelected = true;
    this.$scope.message = null;
    this.$scope.$broadcast(this.$scope.refreshEvent || 'smartTable:refreshRequired');
  }
}

class GeozonesTableController {
  private static $inject = ['$scope', 'McsGeozonesService',];
  private tableState: any;
  constructor(private $scope: IGeozonesTableDirectiveScope,
    private McsGeozonesService: McsGeozonesService) {
    $scope.visibleItems = [];
    $scope.filteredItems = 0;
    $scope.pipe = (_tableState: any) => {
      _tableState.customSelection.selectionState = {};
      this.tableState = _tableState;
      this.listGeozones();
    };
  }

  private getGeozones(query: any): ng.IPromise<IMcsGeozonesResponse> {
    return this.McsGeozonesService.getGeozones(query);
  }

  private listGeozones() {
    if (!this.$scope.listFilter.cn) return;
    if (this.tableState.pagination) {
      this.$scope.offset = this.tableState.pagination.start;
      this.$scope.limit = this.tableState.pagination.number;
    }
    const params = this.mapGeozonesFilter();
    this.$scope.isLoading = true;
    this.getGeozones({ params }).then(result => {
      this.$scope.visibleItems = result.data;
      this.$scope.filteredItems = result.totalCount;
      this.tableState.pagination.totalItemCount = result.totalCount;
      const maxRange = this.tableState.pagination.start + this.$scope.limit
      this.$scope.from = this.$scope.offset + 1;
      this.$scope.to = maxRange < result.totalCount ? maxRange : result.totalCount
      this.$scope.listError = null
    }).catch(err => {
      this.$scope.listError = err;
        this.$scope.visibleItems = [];
      console.error(err)
    }).finally(() => {
      this.$scope.isLoading = false;
    })
  }

  private mapGeozonesFilter() {
    return {
      customerName: this.$scope.listFilter.cn,
      active: this.$scope.listFilter.active ? 'Y' : 'N',
      limit: this.tableState.pagination.number,
      offset: this.tableState.pagination.start
    }
  }
}

class GeozonesFiltersController {
  private static $inject = ['$scope', 'McsGeneralService'];
  constructor(private $scope: IGeozonesFiltersDirectiveScope,
    private McsGeneralService: McsGeneralService) {
    this.getCustomersNames();
    this.$scope.refresh = () => this.getCustomersNames();
  }

  private getLookupData(dataSetNames: string[]): ng.IPromise<any> {
    return this.McsGeneralService.getLookupData(dataSetNames);
  }

  private getCustomersNames() {
    this.$scope.pending = true;
    this.getLookupData(['MCS_LOCO_SERVICE_OWNERS'])
      .then(result => {
        this.$scope.customerNames = result.MCS_LOCO_SERVICE_OWNERS;
        this.$scope.pending = false;
        this.$scope.error = null;
      })
      .catch(err => {
        console.error(err);
        this.$scope.error = err;
      });
  }
}

function GeozonesTableDirective($branding: app.branding.IBrandingService) {
  return {
    templateUrl: $branding.getTemplateUrl('GeozonesTableDirective'),
    restrict: "E",
    scope: {
      isLoading: '=',
      checkedItems: '=?',
      listFilter: '=?',
      showPageSizeSelector: '=?',
      visibleItems: '=?',
      filteredItems: '=?',
      offset: '=?',
      refreshEvent: '@',
      from: '=',
      to: '='
    },
    controller: GeozonesTableController
  }
}

function GeozonesFiltersDirective($branding: app.branding.IBrandingService) {
  return {
    templateUrl: $branding.getTemplateUrl('GeozonesFiltersDirective'),
    restrict: "E",
    scope: {
      listFilter: '=',
      filterChanged: '&'
    },
    controller: GeozonesFiltersController
  }
}

function GeozonesListDirective($branding: app.branding.IBrandingService) {
  return {
    templateUrl: $branding.getTemplateUrl('GeozonesListDirective'),
    restrict: "E",
    scope: {
      createGeozones: '&'
    },
    controller: GeozonesListController
  }
}

export default angular.module('directives.GeozonesList', [McsGeneralServiceModule.name, McsGeozonesServiceModule.name])
  .directive('geozonesList', ['$branding', GeozonesListDirective])
  .directive('geozonesTable', ['$branding', GeozonesTableDirective])
  .directive('geozonesFilters', ['$branding', GeozonesFiltersDirective]);
