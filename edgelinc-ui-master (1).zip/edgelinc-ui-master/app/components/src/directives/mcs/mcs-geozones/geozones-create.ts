import McsGeneralServiceModule, {McsGeneralService} from "../../../services/mcs/McsGeneralService";
import McsGeozonesServiceModule, {McsGeozonesService, IMcsGeozonesResponse} from "../../../services/mcs/McsGeozonesService";
import _ from 'lodash';

interface IGeozonesCreateDirectiveScope extends ng.IScope {
  toAdd: IGeozonesToAdd,
  geozonesToAdd: IGeozonesToAdd[],
  success: boolean,
  inProgress: boolean,
  customerName: string,
  addGeozone(): void,
  deleteGeozone(row: IGeozonesToAdd): void,
  saveGeozones(): void,
  clear(): void,
  backToList(success): void
  params: any
}

interface IGeozonesToAdd {
  customerName: string,
  geozoneName: string,
  lattitude1: number,
  longitude1: number,
  lattitude3: number,
  longitude3: number
}

class GeozonesCreateController {
  private static $inject = ['$scope', '$routeParams', 'McsGeneralService', 'McsGeozonesService'];
  public defaultValues: IGeozonesToAdd;
  constructor(private $scope: IGeozonesCreateDirectiveScope,
    private $routeParams: any,
    private McsGeneralService: McsGeneralService,
    private McsGeozonesService: McsGeozonesService
  ) {
    this.defaultValues = {
      customerName: $routeParams.cn,
      geozoneName: '',
      lattitude1: null,
      longitude1: null,
      lattitude3: null,
      longitude3: null
    };
    this.$scope.params = $routeParams;
    this.$scope.toAdd = _.clone(this.defaultValues);
    this.$scope.success = true;
    this.$scope.geozonesToAdd = [];
    this.$scope.addGeozone = () => this.addGeozone();
    this.$scope.deleteGeozone = row => this.deleteGeozone(row);
    this.$scope.saveGeozones = () => this.saveGeozones();
    this.$scope.clear = () => this.clear();
  }

  private createGeozones(payload: any): ng.IPromise<IMcsGeozonesResponse> {
    return this.McsGeozonesService.createGeozones(payload);
  }

  private addGeozone() {
    console.log(this.$scope)
    this.$scope.geozonesToAdd.push(this.$scope.toAdd);
    this.$scope.toAdd = _.clone(this.defaultValues);
  }

  private deleteGeozone(row) {
    let temp = this.$scope.geozonesToAdd;
    this.$scope.geozonesToAdd = _.reject(temp, row)
  }

  private clear() {
    this.$scope.toAdd = _.clone(this.defaultValues);;
    this.$scope.geozonesToAdd = [];
  }

  private saveGeozones() {
    const payload = this.$scope.geozonesToAdd;
    this.$scope.inProgress = true;
    this.createGeozones(payload)
      .then(response => {
        this.$scope.backToList({ success: true, cn: this.$scope.params.cn, active: this.$scope.params.active });
      })
      .catch(err => {
        this.$scope.backToList({ success: false, cn: this.$scope.params.cn, active: this.$scope.params.active, errorMessage: err.message })
      })
  }
}

function GeozonesCreateDirective($branding: app.branding.IBrandingService) {
  return {
    templateUrl: $branding.getTemplateUrl('GeozonesCreateDirective'),
    restrict: "E",
    scope: {
      backToList: '&'
    },
    controller: GeozonesCreateController
  }
}

function coordinatesValidator() {
  return {
    require: 'ngModel',
    link: function(scope, el, attr, ctrl) {
      ctrl.$validators.range = function(modelValue, viewValue) {
        return modelValue <= 180 && modelValue >= -180
      }
      ctrl.$validators.decimal = function(modelValue, viewValue) {
        if (modelValue === null) return true;
        else {
          const re: RegExp = /^-?\d*(\.\d{1,6})?$/
          return re.test(modelValue.toString())
        }
      }
    }
  }
}

function uniqueNameValidator() {
  return {
    require: 'ngModel',
    link: function(scope, el, attr, ctrl) {
      ctrl.$validators.unique = function(modelValue, viewValue) {
        return !_.some(scope.geozonesToAdd, ['geozoneName', modelValue])
      }
    }
  }
}


export default angular.module('directives.GeozonesCreate', [McsGeneralServiceModule.name, McsGeozonesServiceModule.name])
  .directive('geozonesCreate', ['$branding', GeozonesCreateDirective])
  .directive('coordinatesValidator', [coordinatesValidator])
  .directive('uniqueNameValidator', [uniqueNameValidator])
