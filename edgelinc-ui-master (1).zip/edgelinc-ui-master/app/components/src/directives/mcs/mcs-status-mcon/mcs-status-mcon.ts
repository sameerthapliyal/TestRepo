import _ from 'lodash'
import McsStatusServiceModule, { McsStatusService, iMCONStatusList, iMcsStatusService, iMCONSingleStatus, iMCONDetails } from "../../../services/McsStatusService";

interface iMCONPreparedStatus extends iMCONSingleStatus {
    isDetailsShow: Boolean;
    hasCachedDetails: Boolean;
    isDetailsLoaded: Boolean;
    details: iMCONDetails;
    hasError?: Boolean;
    notFound?: Boolean;
    error?: any;
}

export interface iMCONStatusScope extends ng.IScope {
    asdid: string;
    isLoading: Boolean;
    searchString: String;
    onFilterChange: Function;
    daysToView: Number;
    totalCount: Number;
    countDisplayed: Function;
    from: Function;
    to: Function;
    getStatus: Function;
    limit: Number;
    lastTableState: any;
    hasError: Boolean;
    notFound: Boolean;
    internalServerError: Boolean;
    data: Array<iMCONPreparedStatus>;
    toggleDetails: Function;
    wasListMconErrors: boolean;
    listMconErrors: any;
}

class McsStatusMCONController {

    private static $inject = ['$scope', '$timeout', 'McsStatusService'];
    private isLoading;
    constructor(
        private _scope: iMCONStatusScope,
        private _timeout,
        private _mcsStatusService: iMcsStatusService
    ) {
        this.initSmartTable();
        // this.getInitialState();
        this.initToggle();
        this.initSearchString();
        this.initFilters();

    }

    private showLoader(): void {
        this._scope.isLoading = true;
    }

    private hideLoader(): void {
        this._timeout(() => {
            this._scope.isLoading = false;
        }, 500)

    }

    private initSearchString() {
        this._scope.searchString = ''
        this._scope.onFilterChange = _.debounce(() => {
            const query = _.extend(
                this._scope.lastTableState,
                {
                    searchString: this._scope.searchString,
                    daysToView: this._scope.daysToView
                }
            )
            this.getStatus(query)
        }, 400)
    }

    private initFilters() {
        this._scope.daysToView = 1
        this._scope.totalCount = 0;
        this._scope.countDisplayed = () => {
            return this._scope.data.length
        }

        this._scope.from = () => {
            if (this._scope.lastTableState) {
                return this._scope.hasError ?
                    0 :
                    this._scope.lastTableState.pagination.start + 1
            }

        }
        this._scope.to = () => {
            if (this._scope.lastTableState) {
                const maxRange = this._scope.lastTableState.pagination.start + this._scope.limit
                const dataLength = this._scope.totalCount
                return maxRange < dataLength ? maxRange : dataLength

            }
        }
    }



    private initSmartTable() {
        this._scope.limit = 10;
        this._scope.getStatus = (tableState:any, tableCtrl:any) => {

            this._scope.limit = tableState.pagination.number;
            tableState.pagination.totalItemCount = this._scope.totalCount;
            this._scope.lastTableState = tableState;
            const query = _.extend(
                tableState,
                {
                    searchString: this._scope.searchString,
                    daysToView: this._scope.daysToView
                }
            )
            this.getStatus(query)

        };
    }

    private getStatus(query) {
        const currentQuery = this.addAsdidToQuery.call(this, query)
        this.resetErrorStatuses.apply(this);

        this.showLoader();
        this._mcsStatusService.getMconStatus(currentQuery)
            .then(this.updatePagination.bind(this))
            .then(this.prepareRawData.bind(this))
            .then(this.assignDataToScope.bind(this))
            .then(this.finalizeRequest.bind(this))
            .catch(this.handleErrors.bind(this));

    }

    private finalizeRequest () {
        this.hideLoader();
        this._scope.hasError = false;
        this._scope.wasListMconErrors = false;
    }


    private resetErrorStatuses () {
        this._scope.wasListMconErrors = !!this._scope.listMconErrors
        this._scope.listMconErrors = null;
        this._scope.hasError = false;
        this._scope.internalServerError = false;
        this._scope.notFound = false;
    }

    private handleErrors (e) {
        if(e.statusCode != 404) {
            this._scope.listMconErrors = e;
        } else {
          this._scope.data = [];
        }
        this._scope.isLoading = false;

    }

    private updatePagination (response: iMCONStatusList): iMCONStatusList {
        this._scope.lastTableState.pagination.totalItemCount = response.totalCount;
        return response;
    }

    private assignDataToScope(data: Array<iMCONPreparedStatus>) {
        this._scope.data = data;
    }

    private extendRawMCONStatus(item): iMCONPreparedStatus {
        return <iMCONPreparedStatus>_.extend(
            <any>{},
            <iMCONSingleStatus>item,
            <any>{ isDetailsShow: false, hasCachedDetails: false }
        );

    }

    private prepareRawData(data: iMCONStatusList )
        : Array<iMCONPreparedStatus> {
        this._scope.totalCount = data.totalCount;
        return data.items.map(this.extendRawMCONStatus);
    }

    private assignDetailToRow(row: iMCONPreparedStatus) {
        return details => {
            row.hasCachedDetails = true;
            row.details = details
            row.isDetailsLoaded = true;
        }
    }

    private assignErrorsToRow(row: iMCONPreparedStatus) {
        return error => {

            angular.extend(row, {
                isDetailsLoaded: true,
                error
            });
            if (error.status === 404) {
               angular.extend(row, {
                   notFound: true
               });
            }
            this.hideLoader.bind(this);
        }
    }
    private openRow(row: iMCONPreparedStatus) {
        row.isDetailsShow = true;
        row.isDetailsLoaded = false;
    }

    private getDetails(row: iMCONPreparedStatus) {
        row.error = null;
        this.openRow(row);
        this._mcsStatusService.getMconStatusDetails(row.objid)

            .then(this.assignDetailToRow(row))
            .then(this.hideLoader.bind(this))
            .catch(this.assignErrorsToRow(row))
    }

    public toggleDetails(row: iMCONPreparedStatus) {
        if (row.hasCachedDetails) {
            return row.isDetailsShow = !row.isDetailsShow;
        }
        this.getDetails(row)

    }


    private initToggle() {
        this._scope.toggleDetails = this.toggleDetails.bind(this);
    }


    private addAsdidToQuery (query) {
        return _.extend(
            {},
            query,
            { asdid: this._scope.asdid }
        )
    }


}



function McsStatusMCONDirective($branding) {
    return {
        restrict: "E",
        scope: {
            asdid: '=',
        },
        controller: McsStatusMCONController,
        templateUrl: $branding.getTemplateUrl("directives.mcsStatusMCON"),

    }
};

export default angular.module("directives.mcsStatusMcon", [McsStatusServiceModule.name])
    .directive('mcsStatusMcon', ['$branding', McsStatusMCONDirective]);
