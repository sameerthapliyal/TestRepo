/// <reference path="./../../../definitions/eapi/1.8/Package.d.ts" />

import McsStatusServiceModule, {McsStatusService} from "../../../services/McsStatusService";
import McsStatusMCONModule from "../mcs-status-mcon/mcs-status-mcon";

class McsConfigurationController {

    private static $inject = ['$scope', 'McsStatusService']
    constructor (
        private _scope,
        private _mcsStatusService
    ) {
        this.initErrorsHandlers();
        this.initConfiguration();
        this.initTemplateInfo();
    }

    private initConfiguration () {
        this._scope.getConfiguration = this.getConfiguration.bind(this);
        this.getConfiguration();
    }

    private assignConfigurationToScope (data) {
        this._scope.isLoading = false;
        this._scope.configuration = data;
        this.concatenateTempNumberVersion();
    }

    private handleResponse(response) {
        return response.data;
    }

    getConfiguration () {
        this._scope.isLoading = true;
        this.initErrorsHandlers.apply(this);
        this._mcsStatusService.getConfiguration(this._scope.asdid)
            .then(this.handleResponse.bind(this))
            .then(this.assignConfigurationToScope.bind(this))
            .catch(this.handleErrors.bind(this));

    }
    initErrorsHandlers() {
        this._scope.error = null;
        this._scope.hasError = false;
        this._scope.internalServerError = false;
        this._scope.notFound = false;
    }

    initTemplateInfo() {
        this._scope.templateInfoLimit = 10;
        this._scope.changeRangeTempInfo = (a, b) => {
            console.log(a, b)
        }

        this._scope.setLimit = function (limit) {
            this._scope.templateInfoLimit = limit

        }

        this._scope.$watch('templateInfoLimit', this._scope.setLimit.bind(this))
    }

    handleErrors (response) {
        this._scope.isLoading = false;
        if(response.statusCode != 404) {
          this._scope.error = response;
          this._scope.hasError = true;
        } else {
          this._scope.error = null;
          this._scope.hasError = false;
        }

    }

    private concatenateTempNumberVersion() {
        if(this._scope.configuration && this._scope.configuration.hasOwnProperty("templateInfo")) {
            _.each(this._scope.configuration.templateInfo, (conf: any, key: number) => {
                this._scope.configuration.templateInfo[key]["tempNumVer"] = `${conf.templateNumber}.${conf.templateVersion}`
            });
        }
    }

}



function McsConfiguration ($branding) {
    return {
        restrict: "E",
        scope: {
        asdid: '=devAsdid',
        },
        controller: McsConfigurationController,
        templateUrl: $branding.getTemplateUrl("directives.mcsConfiguration"),

    }
};

export default angular.module("directives.mcsConfiguration", [McsStatusServiceModule.name, McsStatusMCONModule.name])
    .directive('mcsConfiguration', ['$branding', McsConfiguration]);
