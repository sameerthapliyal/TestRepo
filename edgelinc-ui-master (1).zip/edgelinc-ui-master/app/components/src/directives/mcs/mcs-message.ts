import * as _ from "lodash";

/* For syntax see https://lodash.com/docs/4.17.4#template */
const MESSAGES = {
    // Messages form LDARS MCS ICD
    "MSG_1": "The field ${fieldName} is required.", // fieldName: string
    "MSG_2": "The field ${fieldName} only accepts integers between ${range.start} and ${range.end}.", // fieldName: string, range: {start: number, end: number}
    "MSG_3": "Loco ID From and To don't specify a valid range.",
    "MSG_4": "The locomotive was successfully created.",
    "MSG_5": "The locomotives were successfully created in the system. <% if (containsSkipped) { %> However, the following road numbers are skipped because they exist already. <% } %>.", // containsSkipped: boolean
    "MSG_6": "Transaction was not successful, error returned ${errorMessage}.", // errorMessage: string
    "MSG_7": "The locomotive was successfully updated.",
    "MSG_8": "There was an error processing your request. Please try again.",
    "MSG_9": "Special characters were found in your input, please be aware that single quote (') and brackets (< or >) are not allowed.",
    "MSG_10": "One or more templates selected already exist in the list.",
    "MSG_11": "The field ${fieldName} only accepts string in format *.*:*.*.", // fieldName: string
    "MSG_12": "${fieldName}: the maximum number of characters is ${maxLength}.", // fieldName: string, maxLength: number
    "MSG_13": "Start time must be earlier than end time.",
    "MSG_14": "${fieldName}: duplicate value is found.", // fieldName: string
    "MSG_15": "${fieldName}: only letters (A-Z, a-z), numbers (0-9), dash (-), underscore (_) and dot (.) are allowed.", // fieldName: string
    "MSG_15_LettersNumbers": "${fieldName}: only letters (A-Z, a-z) and numbers (0-9) are allowed.", // fieldName: string
    "MSG_16": "${fieldName}: only numbers between ${min} and ${max} are allowed.", // fieldName: string, min: number, max: number
    "MSG_17": "${fieldName}: no more than ${maxDigits} digits are allowed post the decimal point.", // fieldName: string, maxDigits: number
    "MSG_18": "Road number from and to do not specify a valid range, or having a total beyond the maximum (${maxValue}) allowed.", // maxValue: number
    "MSG_19": "software bundle file shall match the pattern RMD_APP_xxxx_yyyy, where the valid value for each x or y is 0-9, a-f or A-F.",
    // Custom Messages
    "Custom_MSG_DeviceSerialNumberFormat": "Invalid format. Expected format: YYMMXXXXX where YY is year, MM is month and XXXXX is the 5 digit serial number of the device.",
    "Custom_MSG_IP": "The field ${fieldName} should be a valid IP address.",
    "Custom_MSG_Match": "The field ${fieldName} should be the same as ${otherFieldName}."
};

const templates: {[key: string]: _.TemplateExecutor} = {};
_.each(MESSAGES, (templateStr, key) => {
    templates[key] = _.template(templateStr);
});


function McsMessageDirective($parse: ng.IParseService) {
    return {
        restrict: "A",
        link: (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: IMcsMessageDirectiveArgs) => {
            function update(args) {
                let key = attrs.mcsMessage;
                if(key in templates) {
                    elem.text(templates[key](args));
                } else {
                    elem.text("");
                }
            }

            if(attrs.mcsMessageArgs) {
                let argsGetter = $parse(attrs.mcsMessageArgs).bind(this, scope);
                scope.$watch(argsGetter, update, true)
            } else {
                update(null);
            }
        }
    }
}
McsMessageDirective.$inject = ['$parse'];

function McsMessageTooltipDirective($parse: ng.IParseService) {
    return {
        restrict: "A",
        require: '?ngModel',
        link: (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: IMcsMessageTooltipDirectiveArgs, ngModel: ng.INgModelController) => {
            let messagesGetter: ()=>string;
            let argsGetter: ()=>string;
            function update() {
                let messagesExpression = messagesGetter();
                let args = argsGetter();

                let messages = [];
                _.each(messagesExpression, (condition: boolean, message: string) => {
                    if(condition && message in templates) {
                        messages.push(templates[message](args))
                    }
                });

                if(messages.length) {
                    attrs.$set('title',  messages.join(' '));
                } else {
                    attrs.$set('title',  null);
                }
            }

            let $error: any = ngModel ? ngModel.$error : {};
            messagesGetter = $parse(attrs.mcsMessageTooltip).bind(this, scope, {$error, attrs});
            argsGetter = $parse(attrs.mcsMessageArgs || "{}").bind(this, scope, {$error, attrs});
            scope.$watch(messagesGetter, update, true);
            scope.$watch(argsGetter, update, true);
        }
    }
}
McsMessageDirective.$inject = ['$parse'];

function McsMessageArgsDirective(){
    return {
        restrict: "A"
    }
}

interface IMcsMessageDirectiveArgs extends ng.IAttributes {
    mcsMessage: string;
    mcsMessageArgs: string;
}

interface IMcsMessageTooltipDirectiveArgs extends ng.IAttributes {
    mcsMessageTooltip: string;
    mcsMessageArgs: string;
}

export default angular.module('directives.mcs.mcsMessage', [])
    .directive('mcsMessage', McsMessageDirective)
    .directive('mcsMessageTooltip', McsMessageTooltipDirective)
    .directive('mcsMessageArgs', McsMessageArgsDirective);