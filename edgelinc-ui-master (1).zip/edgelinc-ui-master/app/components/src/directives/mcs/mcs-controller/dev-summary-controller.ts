import McsStatusServiceModule, { McsStatusService, IControllerDetails} from "../../../services/McsStatusService";
import McsControllerOptionTableModule from "../mcs-controller/controller-option-table";

interface IMcsStatusControllerScope extends ng.IScope{
    asdid:string;
    objId: string;
    summaryControllerDetails: IControllerDetails;
    getData:()=> void;
    onFilterChange:()=>void;
    toggleDetails(row: any, $index:number);
    numberOfDays:number;
    from: number;
    to: number;
    total:number;
    isLoading: boolean;
    hasError: boolean;
    error: any;
}

class McsStatusControllerCtrl {

    private static $inject = ['$scope', 'McsStatusService'];


    constructor(private $scope: IMcsStatusControllerScope,
                private $mcsStatusService: McsStatusService
    ) {
        this.$scope.getData = this.getData.bind(this);
        this.$scope.onFilterChange = _.debounce(this.getData.bind(this),500);
        this.resetState.apply(this);
        this.getData.apply(this);
    }

    private getData(){
        this.resetState.apply(this);
        this.$mcsStatusService.getControllerStatus(this.$scope.asdid)
        .then(this.assignResponse.bind(this))
        .catch(this.handleErrors.bind(this));
    }

    private resetState () {
        this.$scope.isLoading = true;
        this.$scope.hasError = false;
        this.$scope.error = null;
    }

    private handleErrors(response) {
        if(response.statusCode != 404) {
          this.$scope.error = response;
          this.$scope.hasError = true;
        } else {
          this.$scope.error = null;
          this.$scope.hasError = false;
        }
        this.$scope.isLoading = false;
    }

    private assignResponse (result) {
        this.$scope.summaryControllerDetails = result;
        this.$scope.isLoading = false;
    }
}

export default angular.module("directives.mcsController", [McsStatusServiceModule.name, McsControllerOptionTableModule.name])
.directive('devSummaryController', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            asdid: '=devAsdid',
        },
        controller: McsStatusControllerCtrl,
        templateUrl: $branding.getTemplateUrl("directives.mcsController"),
    }
}]);
