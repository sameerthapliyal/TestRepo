import McsStatusServiceModule, { McsStatusService, IControllerOptions } from "../../../services/McsStatusService";


interface ICtrlOpt extends IControllerOptions {
    id?: number;
}

interface IMcsControllerOptionScope extends ng.IScope{
    ctrlOptions: ICtrlOpt[];
    updateData:(tableState:any, tableCtrl:any)=> void;
    onFilterChange:()=>void;
    showingOptions: {
      from?: number;
      to?: number;
      total?: number;
    }
    visibleItem: any;
    lastTableState: any;
    lastTableCtrl: any;
}

class McsControllerOptionCtrl {

    private static $inject = ['$scope', 'McsStatusService'];


    constructor(private $scope: IMcsControllerOptionScope,
                private $mcsStatusService: McsStatusService
    ) {
        this.$scope.showingOptions = {};

        this.$scope.updateData = (tableState:any, tableCtrl:any) => {
            this.$scope.lastTableState = tableState;
            this.$scope.lastTableCtrl = tableCtrl;
            this.updateData();
        };

        this.$scope.onFilterChange = _.debounce( ()=>{
            if(this.$scope.lastTableState && this.$scope.lastTableCtrl ){
                this.updateData();
            }
        },500);

    }

    private updateData(){
        if(this.$scope.lastTableState == null || this.$scope.lastTableCtrl == null){
            return;
        }

        if(this.$scope.ctrlOptions) {
          _.each(this.$scope.ctrlOptions, (opt:any, key: number) => {
              this.$scope.ctrlOptions[key].id = key;
          });
          this.$scope.lastTableState.pagination.totalItemCount = this.$scope.ctrlOptions.length;
          this.$scope.lastTableState.pagination.numberOfPages = Math.ceil(this.$scope.ctrlOptions.length / this.$scope.lastTableState.pagination.number);
          this.$scope.showingOptions.total = this.$scope.lastTableState.pagination.totalItemCount;
          var end = this.$mcsStatusService.calculateEndOfVisibleItems(this.$scope.lastTableState);
          this.$scope.visibleItem = this.$scope.ctrlOptions.slice(this.$scope.lastTableState.pagination.start, end);
        } else {
          this.$scope.visibleItem = [];
        }

    }

}

export default angular.module("directives.mcsControllerOption", [McsStatusServiceModule.name])
.directive('controllerOptionTable', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            ctrlOptions: "=ctrlOptions",
        },
        controller: McsControllerOptionCtrl,
        templateUrl: $branding.getTemplateUrl("directives.mcsControllerOption"),
    }
}]);
