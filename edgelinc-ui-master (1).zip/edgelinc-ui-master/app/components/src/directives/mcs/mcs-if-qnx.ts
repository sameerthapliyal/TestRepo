
import McsGeneralServiceModule, {McsGeneralService} from "../../services/mcs/McsGeneralService";

function getBlockNodes(nodes) {
    // TODO(perf): update `nodes` instead of creating a new object?
    var node = nodes[0];
    var endNode = nodes[nodes.length - 1];
    var blockNodes;

    for (var i = 1; node !== endNode && (node = node.nextSibling); i++) {
        if (blockNodes || nodes[i] !== node) {
            if (!blockNodes) {
                blockNodes = angular.element(Array.prototype.slice.call(nodes, 0, i));
            }
            blockNodes.push(node);
        }
    }

    return blockNodes || nodes;
}



function McsIfQnx($q: ng.IQService, $animate, $compile, McsGeneralService: McsGeneralService) {
    const DIRECTIVE_NAME = 'mcsIfQnx';
    return {
        multiElement: true,
        transclude: 'element',
        priority: 600,
        terminal: true,
        restrict: 'A',
        $$tlb: true, // HACK: angular's private implementation !!
        link: ($scope: ng.IScope, $element: ng.IAugmentedJQuery, $attr: ng.IAttributes, ctrl: any, $transclude: ng.ITranscludeFunction) => {
            let binding = $attr[DIRECTIVE_NAME];
            let asdid = null;
            let checkAsdidThrottled = $q.throttle(checkAsdid);
            var block, childScope, previousElements;

            $scope.$watch(binding, newAsdid => {
                asdid = newAsdid;
                checkAsdidThrottled();
            });


            function checkAsdid() {
                return McsGeneralService.getObjectId(asdid).then(objId => {
                    if (objId) {
                        show();
                    } else {
                        hide();
                    }
                }).catch(err => {
                    console.error(err);
                    hide();
                })
            }

            function show() {
                if (!childScope) {
                    $transclude(function(clone, newScope) {
                        childScope = newScope;
                        clone[clone.length++] = $compile.$$createComment(`end ${DIRECTIVE_NAME}`, binding);
                        // Note: We only need the first/last node of the cloned nodes.
                        // However, we need to keep the reference to the jqlite wrapper as it might be changed later
                        // by a directive with templateUrl when its template arrives.
                        block = {
                            clone: clone
                        };
                        $animate.enter(clone, $element.parent(), $element);
                    });
                }
            }

            function hide() {
                if (previousElements) {
                    previousElements.remove();
                    previousElements = null;
                }
                if (childScope) {
                    childScope.$destroy();
                    childScope = null;
                }
                if (block) {
                    previousElements = getBlockNodes(block.clone);
                    $animate.leave(previousElements).then(function() {
                        previousElements = null;
                    });
                    block = null;
                }
            }
        }
    }
}
McsIfQnx.$inject = ['$q', '$animate', '$compile', 'McsGeneralService'];

export default angular.module('services.mcs.mcsIfQnx', [McsGeneralServiceModule.name])
    .directive('mcsIfQnx', McsIfQnx);