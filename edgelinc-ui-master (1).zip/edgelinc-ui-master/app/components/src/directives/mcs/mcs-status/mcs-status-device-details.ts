import McsStatusServiceModule, {McsStatusService} from "../../../services/McsStatusService";
import McsStatusMCONModule from "../mcs-status-mcon/mcs-status-mcon";
import McsStatusLDVRModule from "../mcs-status-ldvr/dev-summary-ldvr";
import McsStatusDiskDriveModule from "../mcs-status-disk-drive/dev-summary-disk-drive";
import McsStatusControllerModule from "../mcs-controller/dev-summary-controller";


class McsStatusController {

    private static $inject = ['$scope', 'McsStatusService']
    constructor (
        private _scope,
        private _mcsStatusService
    ) {


        console.log(this._mcsStatusService, 'em stat')

    }

}



function McsStatusDirective ($branding) {
    return {
        restrict: "E",
        scope: {
        asdid: '=devAsdid',
        },
        controller: McsStatusController,
        templateUrl: $branding.getTemplateUrl("directives.mcsStatus"),

    }
};

export default angular.module("directives.mcsStatus", [McsStatusServiceModule.name, McsStatusMCONModule.name, McsStatusLDVRModule.name, McsStatusDiskDriveModule.name, McsStatusControllerModule.name])
    .directive('mcsStatus', ['$branding', McsStatusDirective]);
