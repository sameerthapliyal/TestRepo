import McsLookupMgmtServiceModule, {McsLookupMgmtService, ILookupSet, ILookupDataToSave} from "../../../services/mcs/McsLookupMgmtService";
import {DataSet, DataSetEntry} from "../../../services/mcs/McsServiceBase";
import {McsGeneralService} from "../../../services/mcs/McsGeneralService";
import * as _ from "lodash";

class McsLookupMgmtController {

    public lookupSets: ILookupSetViewModel[];
    public isLoading: boolean;
    private lookupSetsPromise: ng.IPromise<ILookupSetViewModel[]>;
    public tableState: any;
    public error: any;
    public listFilter: IListFilter = {};

    constructor(private $scope: ng.IScope,
                private $q: ng.IQService,
                private McsLookupMgmtService: McsLookupMgmtService,
                private McsGeneralService: McsGeneralService
    ) {
    }

    public getLookupSets(tableState: any): ng.IPromise<App.Models.SearchResult<ILookupSetViewModel>> {
        this.tableState = tableState;
        return this.getLookupSetsPromise()
            .then(lookupSets => {
                this.error = null;

                let filteredLookupSets = this.filterList(lookupSets);
                let limit = this.tableState ? this.tableState.pagination.number : 10;
                let offset = this.tableState ? this.tableState.pagination.start : 0;
                let pagedLookupSets = filteredLookupSets.slice(offset, offset + limit);
                this.lookupSets = filteredLookupSets;
                return {
                    items: pagedLookupSets,
                    totalCount: filteredLookupSets.length
                };
            })
            .catch(err => {
                this.error = err;
                return this.$q.reject(err);
            });
    }

    private getLookupSetsPromise() {
        if(!this.lookupSetsPromise) {
            return this.lookupSetsPromise = this.McsLookupMgmtService.getLookupSets()
                .then(lookupSets => {
                    let lookupSetViewModels = _.map(lookupSets, lookupSet => {
                        return {
                            lookupSet,
                            expanded: false
                        }
                    });
                    return lookupSetViewModels;
                })
                .catch(err => {
                    this.lookupSetsPromise = null;
                    return this.$q.reject(err);
                });
        }
        return this.lookupSetsPromise;
    }

    public search() {
        this.$scope.$broadcast('smartTable:refreshRequired');
    }

    public clear() {
        this.listFilter = {};
        this.$scope.$broadcast('smartTable:refreshRequired');
    }

    public toggle(row: ILookupSetViewModel) {
        row.isDetailsShow = !row.isDetailsShow;
        if(row.isDetailsShow && !row.lookupData) {
            row.loading = true;
            this.McsGeneralService.getLookupData([row.lookupSet.lookupSetName, row.lookupSet.parentLookupSetName])
                .then(dataSets => {
                    let orderedEntries = _.sortBy(dataSets[row.lookupSet.lookupSetName], dataSetEntry => dataSetEntry.lookupOrder);
                    row.lookupData = _.map(orderedEntries, dataSetEntry => {
                        return {
                            lookupData: dataSetEntry,
                            lookupDataToEdit: this.getLookupDataToSave(dataSetEntry, row),
                            editMode: false
                        }
                    });
                    row.parentLookupData = dataSets[row.lookupSet.parentLookupSetName];
                    row.loading = false;
                })
                .catch(err => {
                    row.error = err;
                    row.loading = false;
                })
        }
    }

    public getLookupValue(dataSet: DataSet, lookupObjid: string) {
        let entry = _.find(dataSet, e => e.lookupObjid === lookupObjid);
        if(entry) {
            return entry.lookupValue;
        } else {
            return null;
        }
    }

    public edit(row: ILookupSetViewModel, entry: ILookupDataViewModel) {
        entry.editMode = true;
        if(row.editingEntry) {
            row.editingEntry.editMode = false;
        }
        row.editingEntry = entry;
    }

    public save(row: ILookupSetViewModel) {
        if(row.editingEntry && row.editingEntry.form && row.editingEntry.form.$invalid) {
            row.editingEntry.form.$setSubmitted();
            return;
        }
        row.inProgress = true;
        let savePromise = this.saveEntry(row, row.editingEntry);
        _.each(row.lookupData, entry => {
            savePromise = savePromise.then(() => {
                if(entry.lookupDataToEdit && (!entry.lookupData || entry.lookupData.lookupOrder !== entry.lookupDataToEdit.lookupOrder)) {
                    return this.saveEntry(row, entry)
                } else {
                    return this.$q.resolve();
                }
            });
        });
        savePromise.then(() => {
            row.inProgress = false;
            row.saveError = null;
            if(row.editingEntry) {
                row.editingEntry.editMode = false;
                row.editingEntry = null;
            }
        }).catch(err => {
            row.inProgress = false;
            row.saveError = err;
        });
    }

    private saveEntry(row: ILookupSetViewModel, entry: ILookupDataViewModel) {
        if(!entry) {
            return this.$q.resolve();
        }
        if(entry.lookupDataToEdit.lookupObjid) {
            return this.McsLookupMgmtService.updateLookupData(entry.lookupDataToEdit)
                .then(lookupData => {
                    entry.lookupData = lookupData;
                    entry.lookupDataToEdit = this.getLookupDataToSave(entry.lookupData, row);
                });
        } else {
            return this.McsLookupMgmtService.addLookupData(entry.lookupDataToEdit)
                .then(lookupData => {
                    entry.lookupData = lookupData;
                    entry.lookupDataToEdit = this.getLookupDataToSave(entry.lookupData, row);
                });
        }
    }

    public cancel(row: ILookupSetViewModel) {
        if(row.editingEntry) {
            if(row.editingEntry.lookupData) {
                row.editingEntry.lookupDataToEdit = this.getLookupDataToSave(row.editingEntry.lookupData, row);
                row.editingEntry.editMode = false;
            } else {
                row.lookupData.splice(row.lookupData.indexOf(row.editingEntry), 1);
            }
            row.editingEntry = null;
        }
    }

    public newLookupValue(row: ILookupSetViewModel) {
        this.cancel(row);
        row.editingEntry = {
            lookupData: null,
            lookupDataToEdit: {
                lookupObjid: null,
                lookupName: "",
                lookupValue: "",
                description: "",
                lookupOrder: _.max(_.map(row.lookupData, entry => entry.lookupDataToEdit.lookupOrder)) + 1,
                lookupSetObjid: row.lookupSet.lookupSetObjid,
                lookupSetName: row.lookupSet.lookupSetName,
                parentLookupObjid: null,
                active: true
            },
            editMode: true
        };
        row.lookupData.push(row.editingEntry);
    }

    public sortAlphabetically(row: ILookupSetViewModel) {
        row.lookupData = _.orderBy(row.lookupData, entry => entry.lookupDataToEdit.lookupValue);
        _.each(row.lookupData, (entry, index) => {
            entry.lookupDataToEdit.lookupOrder = index + 1;
        });
        this.save(row);
    }

    public up(row: ILookupSetViewModel, entry: ILookupDataViewModel, index: number) {
        let lookupOrder = entry.lookupDataToEdit.lookupOrder;
        let previousEntry = row.lookupData[index - 1];
        if(previousEntry) {
            entry.lookupDataToEdit.lookupOrder = previousEntry.lookupDataToEdit.lookupOrder;
            previousEntry.lookupDataToEdit.lookupOrder = lookupOrder;

            row.lookupData[index - 1] = entry;
            row.lookupData[index] = previousEntry;
        }
    }

    public down(row: ILookupSetViewModel, entry: ILookupDataViewModel, index: number) {
        let lookupOrder = entry.lookupDataToEdit.lookupOrder;
        let nextEntry = row.lookupData[index + 1];
        if(nextEntry) {
            entry.lookupDataToEdit.lookupOrder = nextEntry.lookupDataToEdit.lookupOrder;
            nextEntry.lookupDataToEdit.lookupOrder = lookupOrder;

            row.lookupData[index + 1] = entry;
            row.lookupData[index] = nextEntry;
        }
    }

    private filterList(list: ILookupSetViewModel[]): ILookupSetViewModel[] {
        let nameRegexp: RegExp = null;
        if(this.listFilter.name) {
            nameRegexp = new RegExp(this.listFilter.name, "i");
        }
        let descriptionRegexp: RegExp = null;
        if(this.listFilter.description) {
            descriptionRegexp = new RegExp(this.listFilter.description, "i");
        }
        return _.filter(list, (e: ILookupSetViewModel) => {
            if(!e.lookupSet) {
                return false;
            }
            if(nameRegexp && !nameRegexp.test(e.lookupSet.lookupSetName)) {
                return false;
            }
            if(descriptionRegexp && !descriptionRegexp.test(e.lookupSet.lookupSetDescription)) {
                return false;
            }
            return true;
        })
    }

    private getLookupDataToSave(dataSetEntry: DataSetEntry, lookupSetViewModel: ILookupSetViewModel): ILookupDataToSave {
        return {
            lookupObjid: dataSetEntry.lookupObjid,
            lookupName: dataSetEntry.lookupName,
            lookupValue: dataSetEntry.lookupValue,
            description: dataSetEntry.description,
            lookupOrder: dataSetEntry.lookupOrder,
            lookupSetObjid: lookupSetViewModel.lookupSet.lookupSetObjid,
            lookupSetName: lookupSetViewModel.lookupSet.lookupSetName,
            parentLookupObjid: dataSetEntry.parentLookupObjid,
            active: dataSetEntry.active != "N"
        };
    }
}

function McsLookupMgmtDirective() {
    return {
        restrict: "E",
        templateUrl: "/components/src/directives/mcs/mcs-lookup-mgmt/mcs-lookup-mgmt.html",
        controller: McsLookupMgmtController,
        controllerAs: 'ctrl'
    }
}

interface ILookupSetViewModel {
    lookupSet: ILookupSet;
    lookupData?: ILookupDataViewModel[];
    parentLookupData?: DataSetEntry[];
    isDetailsShow?: boolean;
    loading?: boolean;
    error?: any;
    saveError?: any;
    inProgress?: boolean;
    editingEntry: ILookupDataViewModel;
}

interface ILookupDataViewModel {
    lookupData?: DataSetEntry;
    lookupDataToEdit?: ILookupDataToSave;
    form?: ng.IFormController;
    editMode?: boolean;
}

interface IListFilter {
    name?: string;
    description?: string;
}


export default angular.module("directives.mcs.mcsLookupMgmt", [McsLookupMgmtServiceModule.name])
    .directive('mcsLookupMgmt', McsLookupMgmtDirective);