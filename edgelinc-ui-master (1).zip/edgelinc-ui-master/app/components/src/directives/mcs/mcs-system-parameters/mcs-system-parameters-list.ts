///<reference path="../../../../../../typings/browser.d.ts"/>

import McsSystemParametersServiceModule, {McsSystemParametersService} from "../../../services/mcs/McsSystemParametersService";
import stCustomExportContextWrapperModule from "../../../directives/smart-table/st-custom-export-context-wrapper";
import * as _ from "lodash";

interface IMcsSystemParametersListScope extends ng.IScope {
  searchString: string,
  refreshEvent: string,
  visibleParameters: any,
  close(): void,
  fn: {
    onClearFilterClick(): void,
    onFilterChange(): void,
    exportParameters(): void,
  }
}

interface IMcsSystemParametersTableScope extends ng.IScope {
  systemParameters: any,
  visibleParameters: any,
  pipe(tableState: any): void,
  exportParameters(): void,
  isSaving: boolean,
  isEditing: boolean,
  isLoading: boolean,
  saveEnable: boolean,
  refreshEvent: string,
  searchString: string,
  totalCount: number,
  offset: number,
  limit: number,
  from: number,
  to: number,
  error: {
    general: string,
    saveParam: string,
    saving: boolean,
    parametersGet: boolean,
  },
  fn: {
    saveParameter(): void,
    checkValue(row): void,
    enterEditMode(param): void,
    exitEditMode(): void,
  }
}

class McsSystemParametersListController {
  private static $inject = ['$scope'];
  constructor(private $scope: IMcsSystemParametersListScope) {
    $scope.fn = {
      onClearFilterClick: () => this.clearFilter(),
      onFilterChange: () => this.changeFilter(),
      exportParameters: () => this.export()
    }
  }

  clearFilter() {
    this.$scope.searchString = '';
    this.$scope.$broadcast(this.$scope.refreshEvent || 'smartTable:refreshRequired');
  }

  changeFilter() {
    this.$scope.$broadcast(this.$scope.refreshEvent || 'smartTable:refreshRequired');
  }

  export() {
    this.$scope.$broadcast("smartTable:exportToCsv");
  }
}

class McsSystemParametersTableController {
  private static $inject = ['$scope', 'McsSystemParametersService'];
  private editedRow = null;
  private tableState: any;
  private systemParameters: any[] = [];
  constructor(private $scope: IMcsSystemParametersTableScope,
    private McsSystemParametersService: McsSystemParametersService) {
    $scope.error = {
      general: '',
      parametersGet: false,
      saveParam: '',
      saving: false
    }
    $scope.exportParameters = () => console.log('export');
    $scope.fn = {
      enterEditMode: row => this.enterEditMode(row),
      saveParameter: () => this.saveParameter(),
      checkValue: row => this.checkValue(row),
      exitEditMode: () => this.exitEditMode(),

    }
    $scope.pipe = (_tableState: any) => {
      this.tableState = _tableState;
      this.doRequest();
    };
  }

  filterParameters() {
    let limit = this.tableState ? this.tableState.pagination.number : 10;
    let offset = this.tableState ? this.tableState.pagination.start : 0;
    const maxRange = offset + limit;
    const re = this.$scope.searchString ? new RegExp(this.$scope.searchString, 'i') : /(.*?)/;
    const filteredParameters = this.systemParameters.filter(i => re.test(i.parameterName) || re.test(i.parameterDesc) || re.test(i.parameterValue));
    const totalCount = filteredParameters.length;
    this.tableState.pagination.totalItemCount = totalCount;
    this.$scope.totalCount = totalCount;
    this.$scope.from = offset + 1;
    this.$scope.to = maxRange < totalCount ? maxRange : totalCount
    this.$scope.visibleParameters = filteredParameters.slice(this.$scope.from - 1, this.$scope.to)
  }

  doRequest() {
    this.$scope.isLoading = true;
    this.McsSystemParametersService.getSystemParameters()
      .then(result => result.map(i => { (<any>i).edit = false; return i; }))
      .then(params => {
        this.$scope.error.parametersGet = false;
        this.$scope.isLoading = false;
        this.systemParameters = params;
        this.filterParameters();
      })
      .catch(err => {
        this.$scope.isLoading = false;
        this.$scope.error.general = err;
        this.$scope.error.parametersGet = true;
      })
  }

  saveParameter() {
    this.$scope.isSaving = true;
    this.McsSystemParametersService.saveParameter(this.editedRow)
      .then(response => {
        this.$scope.isSaving = false;
        this.$scope.error.saving = false;
      })
      .catch(err => {
        this.$scope.error.saving = true;
        this.$scope.isSaving = false;
        this.$scope.error.saveParam = err;
      })
      .finally(() => {
        this.exitEditMode();
      })
  }

  checkValue(row) {
    if (row.newValue.length > 0 && row.newValue !== row.parameterValue) {
      this.$scope.saveEnable = true;
    }
    else this.$scope.saveEnable = false;
  }

  enterEditMode(row) {
    this.editedRow = row;
    this.$scope.isEditing = true;
    row.edit = true;
  }

  exitEditMode() {
    this.$scope.isEditing = false;
    this.editedRow.edit = false;
  }
}

function McsSystemParametersListDirective($branding: app.branding.IBrandingService) {
  return {
    templateUrl: $branding.getTemplateUrl('McsSystemParametersListDirective'),
    restrict: "E",
    controller: McsSystemParametersListController
  }
}

function McsSystemParametersTableDirective($branding: app.branding.IBrandingService) {
  return {
    templateUrl: $branding.getTemplateUrl('McsSystemParametersTableDirective'),
    controller: McsSystemParametersTableController,
    scope: {
      refreshEvent: '@',
      visibleParameters: '=',
      searchString: '=',
      totalCount: '=',
      isLoading: '=',
      offset: '=',
      error: '=',
      from: '=',
      to: '='
    }
  }
}


export default angular.module('directives.mcsSystemParametersList', [McsSystemParametersServiceModule.name, stCustomExportContextWrapperModule.name])
  .directive('mcsSystemParametersList', ['$branding', McsSystemParametersListDirective])
  .directive('mcsSystemParametersTable', ['$branding', McsSystemParametersTableDirective])
