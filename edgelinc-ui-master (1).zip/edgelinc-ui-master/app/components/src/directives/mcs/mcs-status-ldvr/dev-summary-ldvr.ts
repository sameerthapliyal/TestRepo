
/**
 * Created by rosadnik on 08-Jun-17.
 */
import McsStatusServiceModule, { McsStatusService, iLdvrStatus, iLdvrDetailsQuery, iLdvrQuery, iLdvrStatusResponse } from "../../../services/McsStatusService";
import DeviceServiceModule, { DeviceService } from "../../../services/DeviceService";
import CommonServicesModule, { CommonServices } from "../../../services/CommonServices";
import McsStatusServiceDetailsModule from "./dev-summary-ldvr-details";
import devActivePreservationSummaryLdvrModule from "./dev-active-preservation-summary-ldvr";
import _ from "lodash";

interface iLdvrStatusExtended extends iLdvrStatus {
    hasCachedDetails: Boolean;
    details?: iLdvrStatus;
    isDetailsShow: Boolean;
    isDetailsLoaded: Boolean;
}

interface McsStatusLDVRScope extends ng.IScope{
    asdid:string;
    summaryLdvrList:iLdvrStatusExtended[];
    isLoading:boolean;
    numberOfDays:number;
    messageView:"Camera"|"Message";
    lastMessageView: "Camera"|"Message";
    messageViewRaw: string;
    cameraNo: string;
    devClass:string;
    isLCV:boolean;
    tableState: any;
    totalCount: number;
    hasErrors: boolean;
    internalServerError: boolean;
    notFound: boolean;
    camerasList:string[];
    listLdvrError: any;
    getData:(tableState:any, tableCtrl:any)=> void;
    onFilterChange:()=>void;
    toggleDetails(row: any, $index:number);
    hideLoader: ()=>void;
    showLoader: ()=>void;
    errors: any;
    wasListLdvrError: boolean;
    refreshClick: boolean;
}

class McsStatusLDVRController {

    private static $inject = ['$scope', '$q', 'McsStatusService', 'DeviceService','CommonServices'];
    private _lastTableState:any = null;
    private _lastTableCtrl:any = null;
    private _devData: eapi18.DeviceFromDSC;
    private loadingPromise: ng.IDeferred<{}>;

    constructor(
                private _scope:McsStatusLDVRScope,
                private _q: ng.IQService,
                private _mcsStatusService: McsStatusService,
                private _deviceService:DeviceService,
                private _commonServices: CommonServices
        )
    {
        this._scope.isLoading = true;
        this._scope.messageView = 'Message';
        this._scope.cameraNo;
        this._scope.numberOfDays = 3;
        this._scope.refreshClick = false;

        this._scope.errors = {};

        this._scope.getData = (tableState:any, tableCtrl:any) => {
            this._lastTableState = tableState;
            this._lastTableCtrl = tableCtrl;
            this._scope.tableState = this._lastTableState;
            this.getData();
        };


        this._scope.onFilterChange = _.debounce( ()=>{
            this._scope.refreshClick = !this._scope.refreshClick;
            if(this._lastTableState && this._lastTableCtrl ){
                this.getData();
            }
        },500);


        this._scope.toggleDetails = (row: any, $index: number)=>{
            if (row.hasCachedDetails) {
                return row.isDetailsShow = !row.isDetailsShow;
            }
            if (!row.isDetailsShow || row.error) {
                this.getDetails(row);
            }
        };

        this._scope.$watch("asdid", (asdidNew: string, asdidOld: string)=>{
            this._devData = null;
            this._scope.devClass = null;
            if(asdidNew) {
                // to do: implement recognize LCV devices in better way.
                _deviceService.getDeviceCacheData(asdidNew).then((devData: eapi18.DeviceFromDSC) => {
                    if(devData) {
                        this._devData = devData;
                        this._scope.devClass = this._commonServices.getDeviceModelVersionAttribute(devData.device_model, devData.model_version, "cnrClass");
                        this._scope.isLCV =  devData.assertions['$attributes/device_type'] == 'LCV' || this._scope.devClass == 'LCV' ;

                    }
                });
            }
        });
    }

    private getData() {
        if(this.hasTableState(this)){
            return;
        }
        this.showLoader.apply(this);
        this.resetErrorHandler.apply(this);
        var queryData:iLdvrQuery = {
            asdid:this._scope.asdid,
            limit: this._lastTableState.pagination.number,
            offset: this._lastTableState.pagination.start || 0,
            numberOfDays: this._scope.numberOfDays,
            messageView: this._scope.messageView
        };
        this._mcsStatusService.getLdvrStatus(queryData)
            .then(this.addTotalCountToScope.bind(this))
            .then(this.extendRawItems.bind(this))
            .then(this.assignResponseToScope.bind(this))
            .then(this.hideLoader.bind(this))
            .catch(this.handlePromiseError.bind(this));

    }

    private hasTableState(context) {
        return context._lastTableState == null || context._lastTableCtrl == null
    }

    private addTotalCountToScope (response: iLdvrStatusResponse): iLdvrStatusResponse {
        this._scope.totalCount = response.totalCount;

        return response;
    }

    private assignResponseToScope(
        response:App.Models.SearchResult<iLdvrStatusExtended>
    ) {

            this._scope.wasListLdvrError = false;
            this._scope.summaryLdvrList = response.items;
            this._lastTableState.pagination.totalItemCount = this._scope.totalCount = response.totalCount;
    }

    private extendRawItems(response)
        : App.Models.SearchResult<iLdvrStatusExtended> {
        return <App.Models.SearchResult<iLdvrStatusExtended>>_.extend(
            response,
            {
                items: response.items.map(this.extendRawItem)
            }
        )
    }

    private extendRawItem (item: iLdvrStatus) {
        return _.extend(
            item,
            {
                isDetailsShow: false,
                hasCachedDetails: false,
                details: null
            }

        )
    }

    private showLoader() {
        this._scope.isLoading = true;

    }

    private hideLoader () {
        // Resolve promise for viewMessage change
        // this.loadingPromise.resolve();
        this._scope.isLoading = false;
    }

    private handlePromiseError (response) {
        this._scope.isLoading = false;
        if(response.statusCode != 404) {
            this._scope.listLdvrError = response;
        } else {
            this._scope.summaryLdvrList = []
        }

    }

    private resetErrorHandler() {
        this._scope.wasListLdvrError = !!this._scope.listLdvrError;
        this._scope.listLdvrError = null;
        this._scope.hasErrors = false;
        this._scope.internalServerError = false;
        this._scope.notFound = false;
    }

    private getDetails (row) {
        row.error = null;
        row.isDetailsShow = true;
        row.isDetailsLoaded = false;
        let query:iLdvrDetailsQuery = {
            ldvrStatusObjid: row.objid,
            cameraNo: row.cameraNumber
        }
        query = <iLdvrDetailsQuery>_.omitBy(query, _.isUndefined)
        return this._mcsStatusService.getLdvrStatusDetails(query)
            .then(this.assignDetailsToRow(row))
            .catch(this.assignErrorToRow(row))

    }

    private assignDetailsToRow (row) {
        return response => {
            row.isDetailsShow = true;
            row.isDetailsLoaded = true;
            row.hasCachedDetails = true;
            row.details = response;
        }

    }
    private assignErrorToRow (row) {
        return response => {
            row.isDetailsShow = true;
            row.isDetailsLoaded = true;
            row.error = response;

        }
    }



}

export default angular.module("directives.mcs.StatusLDVR", [McsStatusServiceModule.name, McsStatusServiceDetailsModule.name, DeviceServiceModule.name, CommonServicesModule.name,
    devActivePreservationSummaryLdvrModule.name])
.directive('devSummaryLdvr', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            asdid: '=asdid',
        },
        controller: McsStatusLDVRController,
        templateUrl: $branding.getTemplateUrl("directives.mcsStatusLDVR"),
    }
}]);