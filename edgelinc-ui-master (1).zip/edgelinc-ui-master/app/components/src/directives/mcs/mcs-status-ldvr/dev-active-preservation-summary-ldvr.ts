/**
 * Created by rosadnik on 12-Jun-17.
 */
import McsStatusServiceModule, {
    McsStatusService,
    ILdvrActivePreservationRequests,
    ILdvrActivePreservationRequestStatus,
    ILdvrActivePreservationRequestsQuery,
    ILdvrActivePreservationRequestDetails
} from "../../../services/McsStatusService";

import DeviceServiceModule, { DeviceService } from "../../../services/DeviceService";
import CommonServicesModule, { CommonServices } from "../../../services/CommonServices"

interface devActivePreservationSummaryLdvrScope extends ng.IScope{
    asdid: string;
    isLcv: boolean;
    showActiveRequests: boolean;
    getData:(tableState: any, tableCtrl: any)=> void;
    onFilterChange: ()=>void;
    activeRequestsList: ILdvrActivePreservationRequestStatus[];
    toggleActiveRequests: ()=>void;
    ldvrDetails: ILdvrActivePreservationRequests;
    errors: any;
    refresh: boolean;
}

export class devActivePreservationSummaryLdvrControler {
    private _lastTableState:any = null;
    private _lastTableCtrl:any = null;

    private static $inject = ['$scope', 'McsStatusService', 'DeviceService','CommonServices'];

    constructor(private _scope:devActivePreservationSummaryLdvrScope, private _mcsStatusService: McsStatusService, private _deviceService:DeviceService,
                private _commonServices: CommonServices)
    {
        this._scope.showActiveRequests = false;
        this._scope.getData = (tableState:any, tableCtrl:any) => {
            this._lastTableState = tableState;
            this._lastTableCtrl = tableCtrl;
            this.getData.apply(this);
        };


        this._scope.onFilterChange = _.debounce( ()=>{
            if(this._lastTableState && this._lastTableCtrl ){
                this.getData.apply(this);
            }
        },500);

        this._scope.toggleActiveRequests = () => {
            this._scope.showActiveRequests = !this._scope.showActiveRequests
        }

        this.getInitialData();

        this._scope.$watch("refresh", (newRefresh:boolean, oldRefresh:boolean)=>{
            this.getData();
        });
    }

    private getData(){
        let query:ILdvrActivePreservationRequestsQuery = {}
        if (this._lastTableState && this._lastTableCtrl) {
            query={
                asdid: this._scope.asdid,
                limit: this._lastTableState.pagination.number || 10,
                offset: this._lastTableState.pagination.start || 0
            };
        } else {
          query={
              asdid: this._scope.asdid,
              limit: 10,
              offset: 0
          };
        }

            this._mcsStatusService
                .getLdvrActivePreservationRequests(query)
                .then(this.addRequestToScope.bind(this))
                .catch(error => {
                    this._scope.errors.activePrError = error;
                });
    }

    private getInitialData() {
        let query:ILdvrActivePreservationRequestsQuery= {
            asdid: this._scope.asdid,
            limit: 10,
            offset: 0
        }

        this._mcsStatusService
            .getLdvrActivePreservationRequests(query)
            .then(this.addRequestToScope.bind(this)).catch(error => {
                this._scope.errors.activePrError = error;
            });

    }

    private addRequestToScope (data:ILdvrActivePreservationRequests) {
        this._scope.activeRequestsList =  data.status
        this._scope.ldvrDetails = data
    }
}

export default angular.module("directives.mcs.devActivePreservationSummaryLdvr", [McsStatusServiceModule.name, DeviceServiceModule.name, CommonServicesModule.name])
.directive('devActivePreservationSummaryLdvr', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            asdid: '=asdid',
            isLcv: '=isLcv',
            errors: '=',
            refresh: '=?'
        },
        controller: devActivePreservationSummaryLdvrControler,
        templateUrl: $branding.getTemplateUrl("directives.mcsDevActivePreservationSummaryLdvr"),
    }
}]);