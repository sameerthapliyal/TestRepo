/**
 * Created by rosadnik on 09-Jun-17.
 */
import {iLdvrStatus} from "../../../services/McsStatusService";



interface McsStatusLdvrDetailsScope extends ng.IScope{
    summaryLdvr:iLdvrStatus;
    cameras: Array<any>;
}

class McsStatusLdvrDetailsController {
    
    
    private static $inject = ['$scope'];
    constructor(private _scope:McsStatusLdvrDetailsScope){
        this._scope.$watch('details', (details: Array<any>) => {
            const { cameraNo } = this._scope;
            if (details) {
                this._scope.cameras = details.slice(1, details.length)
            }
            if (cameraNo) {
                this._scope.cameras = this._scope
                    .cameras
                    .filter(item => item.camera == cameraNo)
            }
            
            
        })
    }
}

export default angular.module("directives.mcsStatusLdvrDetails", [])
.directive('devSummaryLdvrDetails', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            summaryLdvr: '=summaryLdvr',
            viewMode: '=',
            details: '=',
            cameraNo: '='
        },
        controller: McsStatusLdvrDetailsController,
        templateUrl: $branding.getTemplateUrl("directives.mcsStatusLDVRDetails")
    }
}]);