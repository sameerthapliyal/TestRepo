export class McsStatusMconDetailController {
    private static $inject = ['$scope']
    constructor (
        private _scope
        ) {
           

    }
}
function McsStatusMCONDetailsDirective ($branding) {
    return {
        restrict: "E",
        scope: {
            details: '=details',
        },
        controller: McsStatusMconDetailController,
        templateUrl: $branding.getTemplateUrl("directives.mcsStatusMCONDetails"),

    }
};

export default angular.module("directives.mcsStatusMconDetails", [])
    .directive('mcsStatusMconDetails', ['$branding', McsStatusMCONDetailsDirective]);
