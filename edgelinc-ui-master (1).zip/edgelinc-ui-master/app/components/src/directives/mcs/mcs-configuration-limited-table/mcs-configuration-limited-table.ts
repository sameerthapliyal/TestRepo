
class McsConfigurationLimitedTableController {

    private static $inject = ['$scope', 'McsStatusService']
    constructor (
        private _scope
    )
    {
        this._scope.limit = 10;
        this._scope.filtered = this._scope.data;

        this._scope.changeRange = (tableState:any, tableCtrl:any) => {
            if (!tableState) return;
            const { start, number } = tableState.pagination;
            const { data , limit } = this._scope;

            this._scope.tableState = tableState;

            if (!data || data.length === 0) {
                tableState.pagination.start = 0;
                tableState.pagination.totalItemCount = 0;
                this._scope.tableFrom = 0;
                this._scope.tableTo = 0;
                this._scope.filtered = [];
                tableState.pagination.numberOfPages = 0;
                return;
            }

            this._scope.tableFrom = tableState.pagination.start + 1;
            this._scope.tableTo = Math.min(tableState.pagination.start+tableState.pagination.number , data.length);
            tableState.pagination.totalItemCount = data.length;
            tableState.pagination.numberOfPages = Math.ceil(data.length / tableState.pagination.number);
            this._scope.filtered = data.slice(start, start + number);
        }


        
        this._scope.$watch('data', this._scope.changeRange.bind(this, this._scope.tableState));
    }
}



function McsConfigurationLimitedTable ($branding) {
    return {
        restrict: "E",
        scope: {
            data: '=',
            labels: '=',
            tableTitle: '@',
            additionalHeadingClass: "@?",
            missingTitle: '@?',
            subtitle: '@?'
        },
        controller: McsConfigurationLimitedTableController,
        templateUrl: $branding.getTemplateUrl("directives.mcsConfigurationLimitedTable"),

    }
};

export default angular.module("directives.mcsConfigurationLimitedTable", [])
    .directive('mcsConfigurationLimitedTable', ['$branding', McsConfigurationLimitedTable]);
