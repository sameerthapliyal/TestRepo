import {HttpError} from "../../../utilities/RestHelper";


function McsErrorMessageDirective() {
    return {
        restrict: "E",
        templateUrl: "/components/src/directives/mcs/mcs-error-message/mcs-error-message.html",
        scope: {
            error: '=',
            visible: '=?',
            retry: '&?',
            close: '&?'
        },
        link: (scope: IMcsErrorMessageDirectiveScope, elem: ng.IAugmentedJQuery, attrs: IMcsErrorMessageDirectiveAttrs) => {
            if(attrs.visible == null) {
                scope.visible = true;
            }
            if(attrs.retry) {
                scope.showRetry = true;
            }
            if(attrs.close) {
                scope.showClose = true;
            }
        }
    }
}
function McsTableMessageDirective() {
    return {
        restrict: "A",
        templateUrl: "/components/src/directives/mcs/mcs-error-message/mcs-table-message.html",
        scope: {
            options: '=mcsTableMessage'
        },
        link: () => {}
    }
}

export default angular.module('directives.mcs.mcsErrorMessage', [])
    .directive('mcsErrorMessage', McsErrorMessageDirective)
    .directive('mcsTableMessage', McsTableMessageDirective);

interface IMcsErrorMessageDirectiveScope extends ng.IScope {
    error: HttpError,
    visible?: boolean;
    retry(): void;
    close(): void;
    showRetry: boolean;
    showClose: boolean;
}

interface IMcsErrorMessageDirectiveAttrs extends ng.IAttributes {
    error: string;
    visible?: string;
    retry?: string;
    close?: string;
}