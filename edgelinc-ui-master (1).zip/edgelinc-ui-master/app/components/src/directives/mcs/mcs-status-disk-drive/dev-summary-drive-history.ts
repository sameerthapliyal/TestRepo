import McsStatusServiceModule, { McsStatusService, IDiskDriveStatus, IDriveHistoryStatus } from "../../../services/McsStatusService";


interface IDriveHist extends IDriveHistoryStatus {
    id?: number;
}

interface IMcsStatusDriveHistoryScope extends ng.IScope{
    asdid:string;
    objId: string;
    summaryDriveHistoryList: IDriveHist[];
    getData:(tableState:any, tableCtrl:any)=> void;
    onFilterChange:()=>void;
    isLoading: boolean;
    showingOptions: {
      from?: number;
      to?: number;
      total?: number;
    }
    visibleItem: any;
    lastTableState: any;
    lastTableCtrl: any;
    diskDriveHistoryError: any;
}

class McsStatusDriveHistoryController {

    private static $inject = ['$scope', 'McsStatusService'];

    constructor(private $scope: IMcsStatusDriveHistoryScope,
                private $mcsStatusService: McsStatusService
    ) {
        
        this.$scope.isLoading = true;
        this.$scope.summaryDriveHistoryList = [];
        this.$scope.showingOptions = {};

        this.$scope.getData = (tableState:any, tableCtrl:any) => {
            this.$scope.lastTableState = tableState;
            this.$scope.lastTableCtrl = tableCtrl;
            this.getData();
        };

        this.$scope.onFilterChange = _.debounce( ()=>{
            if(this.$scope.lastTableState && this.$scope.lastTableCtrl ){
                this.getData();
            }
        },500);

    }

    private getData(){
        if(this.$scope.lastTableState == null || this.$scope.lastTableCtrl == null){
            return;
        }
      this.$mcsStatusService.getDriveHistory(this.$scope.asdid).then((response: any)=>{
            this.$scope.summaryDriveHistoryList = response;

            _.each(this.$scope.summaryDriveHistoryList, (driveHistoryObj: any, key: number) => {
                this.$scope.summaryDriveHistoryList[key].id = key;
            });

            this.$scope.lastTableState.pagination.totalItemCount = response.length;
            this.$scope.lastTableState.pagination.numberOfPages = Math.ceil(response.length / this.$scope.lastTableState.pagination.number);
            this.$scope.showingOptions.total = this.$scope.lastTableState.pagination.totalItemCount;
            var end = this.$mcsStatusService.calculateEndOfVisibleItems(this.$scope.lastTableState);
            this.$scope.visibleItem = this.$scope.summaryDriveHistoryList.slice(this.$scope.lastTableState.pagination.start, end);
            this.$scope.isLoading = false;
        }).catch((err)=>{
            this.$scope.isLoading = false;
            if (err.statusCode === 404) {
                return this.$scope.visibleItem = [];

            }
            
            this.$scope.diskDriveHistoryError = err;
        });
    }

}

export default angular.module("directives.mcsDriveHistory", [McsStatusServiceModule.name])
.directive('devSummaryDriveHistory', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            asdid: '=devAsdid',
        },
        controller: McsStatusDriveHistoryController,
        templateUrl: $branding.getTemplateUrl("directives.mcsDriveHistory"),
    }
}]);
