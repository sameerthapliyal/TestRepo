import McsStatusServiceModule, { McsStatusService, IDiskDriveStatus } from "../../../services/McsStatusService";
import McsStatusDriveHistoryModule from "../mcs-status-disk-drive/dev-summary-drive-history";
import McsStatusDriveDetailsModule from "../mcs-status-disk-drive/dev-summary-drive-details";

interface IDiskDrive extends IDiskDriveStatus {
    id?: number;
}

interface IMcsStatusDiskDriveScope extends ng.IScope{
    asdid:string;
    objId: string;
    summaryDiskDriveList: IDiskDrive[];
    getData:(tableState:any, tableCtrl:any)=> void;
    onFilterChange:()=>void;
    toggleDetails(row: any, $index:number);
    showDriveHistory: boolean;
    daysToView: number;
    isLoading: boolean;
    lastTableState: any;
    lastTableCtrl: any;
    showingOptions: {
        from?: number;
        to?: number;
        total?: number;
    };
    wasDiskDriveError: boolean;
    diskDriveError: any;
}

class McsStatusDiskDriveController {

    private static $inject = ['$scope', 'McsStatusService'];

    constructor(private $scope: IMcsStatusDiskDriveScope,
                private $mcsStatusService: McsStatusService
    ) {

        this.$scope.daysToView = 1;
        this.$scope.showDriveHistory = false;
        this.$scope.isLoading = true;
        this.$scope.summaryDiskDriveList = [];
        this.$scope.showingOptions = {};

        this.$scope.getData = (tableState:any, tableCtrl:any) => {
            this.$scope.lastTableState = tableState;
            this.$scope.lastTableCtrl = tableCtrl;

            this.getData();
        };

        this.$scope.onFilterChange = _.debounce( ()=>{
            if(this.$scope.lastTableState && this.$scope.lastTableCtrl ){
                this.getData();
            }
        },500);

        this.$scope.toggleDetails = (row: any, $index:number)=>{
            row.isDetailsShow = !row.isDetailsShow;
        };

    }

    private resetErrorsHandlers () {
        this.$scope.wasDiskDriveError = !! this.$scope.diskDriveError;
        this.$scope.diskDriveError = null;
        this.$scope.isLoading = true;
    }

    private assignDataToScope (response) {
        this.$scope.summaryDiskDriveList = response.items;
        this.$scope.wasDiskDriveError = false;
        this.$scope.diskDriveError = null;

        _.each(this.$scope.summaryDiskDriveList, (diskDriveObj: any, key: number) => {
            this.$scope.summaryDiskDriveList[key].id = key;
        });

        if(response.totalCount) {
            this.$scope.lastTableState.pagination.totalItemCount = response.totalCount;
        } else {
            this.$scope.lastTableState.pagination.totalItemCount = response.items.length;
        }
        this.$scope.lastTableState.pagination.numberOfPages = Math.ceil(response.items.length / this.$scope.lastTableState.pagination.number);
        this.$scope.isLoading = false;

    }

    private handleErrors (err) {
        this.$scope.isLoading = false;
        if(err.statusCode != 404) {
            this.$scope.diskDriveError = err;
        } else {
            this.$scope.diskDriveError = null;
        }

    }

    private getData(){
        if(this.$scope.lastTableState == null || this.$scope.lastTableCtrl == null)
            return;

        var parameters  = {
            params:
            {
                offset: this.$scope.lastTableState.pagination.start,
                limit: this.$scope.lastTableState.pagination.number,
                daysToView: this.$scope.daysToView
            }
        }

        this.resetErrorsHandlers.apply(this)
        this.$mcsStatusService.getDiskDriveStatus(this.$scope.asdid, parameters)
            .then(this.assignDataToScope.bind(this))
            .catch(this.handleErrors.bind(this));
    }
}

export default angular.module("directives.mcsStatusDiskDrive", [McsStatusServiceModule.name, McsStatusDriveHistoryModule.name, McsStatusDriveDetailsModule.name])
.directive('devSummaryDiskDrive', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            asdid: '=devAsdid',
        },
        controller: McsStatusDiskDriveController,
        templateUrl: $branding.getTemplateUrl("directives.mcsStatusDiskDrive"),
    }
}]);
