import McsStatusServiceModule, { McsStatusService, IDiskDriveStatus, IDriveHistoryStatus } from "../../../services/McsStatusService";


interface IMcsStatusDriveDetailsScope extends ng.IScope{
    diskDriveDetails: IDiskDriveStatus;
}

class McsStatusDriveDetailsController {
    private static $inject = ['$scope'];

    constructor(private $scope: IMcsStatusDriveDetailsScope) {
        console.log("McsStatusDriveDetailsController constructor");
    }
}

export default angular.module("directives.mcsDriveDetails", [McsStatusServiceModule.name])
.directive('devSummaryDriveDetails', ['$branding', function ($branding) {
    return {
        restrict: "E",
        scope: {
            diskDriveDetails: '=diskDriveDetails',
        },
        controller: McsStatusDriveDetailsController,
        templateUrl: $branding.getTemplateUrl("directives.mcsDriveDetails"),
    }
}]);
