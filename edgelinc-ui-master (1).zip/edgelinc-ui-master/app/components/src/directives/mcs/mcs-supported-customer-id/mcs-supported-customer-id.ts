import McsGeneralServiceModule  from './../../../services/mcs/McsGeneralService';

function McsSupportedCustomerIdDirective ($branding, _mcsGeneralService) {
    return {
        restrict: "E",
        replace: true,
        scope: {
            customerId: '=',
        },
        controllerAs: 'ctrl',
        controller: ['$scope', function (scope) {


            console.log(scope);


            
            

          

            const checkCustomerId = () => {
                        if(this.supportedIdCustomer == null || this.supportedIdCustomer.length == 0 || scope.customerId == null){
                            this.notsupportedCustormerId = false;
                        }else{
                            let matchCustomerId = _.find( this.supportedIdCustomer, (ci)=>{ return ci == scope.customerId})
                            this.notsupportedCustormerId = matchCustomerId == null;
                        }
                    }

            this.supportedIdCustomer = null;


            const checkIfSupported = () =>  {
                _mcsGeneralService.getLookupData(["ROAD_INITIALS"]).then((lookupData)=>{
                    console.log(lookupData);
                    if(lookupData && lookupData["ROAD_INITIALS"]){
                        this.supportedIdCustomer =_.map(lookupData["ROAD_INITIALS"], (ri:any) => ri.lookupValue);
                        
                    }
                    checkCustomerId();
                }).catch((err)=>{
                    console.error(err);
                });

            }
            

            scope.$watch('customerId', checkIfSupported)

            
           

        }],
        templateUrl: '/components/src/directives/mcs/mcs-supported-customer-id/mcs-supported-customer-id.html',
    }
}


export default angular.module('directives.mcs.mcsSupportedCustomerIdModule', [McsGeneralServiceModule.name])
.directive('mcsSupportedCustomerId', ['$branding', 'McsGeneralService', McsSupportedCustomerIdDirective])