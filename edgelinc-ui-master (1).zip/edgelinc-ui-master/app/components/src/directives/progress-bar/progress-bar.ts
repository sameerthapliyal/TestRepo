/**
 * Created by rosadnik on 20-Dec-16.
 */
var angularModule = angular.module('directives.progressBar', []);
export default angularModule;

interface IProgressBarControllerScope{
    progress:number;
    text:string;
    progress_dipslay:()=>number;
    progress_style:()=> any;
    ctrl_class:Attr;
    ctrl_style:Attr;
    tooltip?: string;
}

class  MainMenuController {
    inject = ['$scope', '$element'];
    constructor(private $scope: IProgressBarControllerScope, private $element: HTMLElement) {
        $scope.progress_dipslay = ()=>{
            return Math.min(100, Math.max(0, Math.floor(this.$scope.progress || 0)));
        };
        $scope.progress_style = ()=>{
            return {
                'width':$scope.progress_dipslay()+'%'
            };
        };
        
        $scope.ctrl_class = $element[0].attributes.getNamedItem("class");
        $scope.ctrl_style = $element[0].attributes.getNamedItem("style");
    }
}

angularModule.directive("progressBar", function() {
    return {
        templateUrl: "/components/src/directives/progress-bar/progress-bar.html",
        restrict: "E",
        controller: MainMenuController,
        scope: {
            progress: "=",
            text:"@?",
            tooltip: "@?"
        },
        link: (scope:IProgressBarControllerScope, element: ng.IAugmentedJQuery) => {
        }
    }
});

