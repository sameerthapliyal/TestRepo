

function AppHeaderDirective($branding: app.branding.IBrandingService) {
    return {
        restrict: "E",
        templateUrl: $branding.getTemplateUrl("directives.appHeader")
    }
}
AppHeaderDirective.$inject = ["$branding"];

export default angular.module("directives.appHeader", [])
    .directive("appHeader", AppHeaderDirective);