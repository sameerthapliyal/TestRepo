///<reference path="../../../../typings/browser.d.ts"/>


class LoginPageCtrl {
	private authInterceptor: any;
	private authService: any;
	private rootScope: any;
	private scope: any;

	constructor ($rootScope, scope, AS, AI)	{
		this.authInterceptor = AI;
		this.authService =  AS;
		this.rootScope = $rootScope;
		this.scope = scope;
		this.scope.showLogoutOverlay = false;
		this.scope.confirmLoginWithoutUserCredentials = false;
		
		this.scope.$on('event:auth-showLoginPrompt',(event, data)=>{
			this.showLoginPrompt();
		});

		this.scope.$on('event:auth-showLogoutOverlay',(event, data)=>{
			console.log('showLogoutOverlay', performance.now());
			this.scope.hidden = false;
			this.scope.showLogoutOverlay = true;
			this.scope.showRedirectOverlay = false;
			this.scope.confirmLoginWithoutUserCredentials = false;
		});

		this.scope.$on('event:auth-credentialsUserInvalid',(event, data)=>{;
			this.scope.credError = {};
			this.scope.credError[event.name] = true;
			this.scope.submitted = false;
		});
		this.scope.$on('event:auth-fail',(event, data)=>{
			this.scope.credError = {};
			this.scope.credError[event.name] = true;
			this.scope.submitted = false;
		});
		this.scope.$on('event:auth-missingAuthEndpoint',(event, data)=>{
			this.scope.credError = {};
			this.scope.credError[event.name] = true;
			this.scope.submitted = false;
		});
		this.scope.$on('event:auth-authorizationFail',(event, data)=>{
			this.scope.credError = {};
			this.scope.credError[event.name] = true;
			this.scope.submitted = false;
		});
		this.scope.$on('event:auth-missingUserData',(event, data)=>{
			this.scope.credError = {};
			this.scope.credError[event.name] = true;
			this.scope.submitted = false;
		});

		this.scope.$on('event:auth-credentialsOK',(event, data)=>{
			this.scope.credError = null;
			this.scope.submitted = false;
			this.scope.hidden = true;
			this.scope.showLogoutOverlay = false;
			this.scope.showRedirectOverlay = false;
			this.scope.username = "";
			this.scope.password = "";
			this.scope.confirmLoginWithoutUserCredentials = false;
			this.rootScope.$broadcast('event:showContent');
		});
		
		this.scope.$on('event:authOK-failToGetUserCredentials',(event, data)=>{
			this.scope.confirmLoginWithoutUserCredentials = true
		});

		scope.sendcredentials = ()=>{
			this.scope.submitted = true;
			this.sendCredentials();
		};
		
		scope.retrylogin = () =>{
			this.showLoginPrompt();
		};
		
		scope.loginWitoutUserCredentials = () =>{
			this.authService.loginWitoutUserCredentials();
		};
	}
	
	private showLoginPrompt(){
		console.log('showLoginPrompt', performance.now());
		this.scope.hidden = false;
		this.scope.showLogoutOverlay = false;
		this.scope.showRedirectOverlay = false;
		this.scope.confirmLoginWithoutUserCredentials = false;
		this.scope.submitted = false;
	}

	private sendCredentials() {
		var user = this.scope.username;
		var pass = this.scope.password;
		this.authService.initGetUserToken_CS(user,pass);
	}
}

export default angular.module('directives.LoginPage',[])
	.directive('loginOverlay', ['$rootScope','AuthorizationService','authService', '$branding',function ($rootScope, AuthService, authService, $branding: app.branding.IBrandingService) {
		return {
			scope: {
				showOnStart: '@showOnStart',
				hidden: '=promptHidden'
			},
			templateUrl: $branding.getTemplateUrl("views.logiin"), //'/lpt.html',
			link: function(scope:any, ele, attrs) {
				scope.hidden = true;
				if(!AuthService.isAuthorized()){
					scope.hidden = false;
				}
				if(AuthService.isRedirecting()){
					scope.hidden = false;
					scope.showRedirectOverlay = true;
				}
				//scope.username = (<any>window).CONFIG.AUTH_CLIENT_ID;
				//scope.password = (<any>window).CONFIG.AUTH_CLIENT_SECRET;
				scope.username = (<any>window).CONFIG.LOGIN_USER_ID;
				scope.password = (<any>window).CONFIG.LOGIN_USER_SECRET;
				scope.controller = new LoginPageCtrl($rootScope, scope, AuthService, authService);
			}
		}
	}]);
