///<reference path="../../../../typings/browser.d.ts"/>

var angularModule = angular.module('directives.proxSpinner', []);
export default angularModule;

angularModule.controller('proxSpinnerController', ['$scope', function ($scope) { } ]);
angularModule.directive('proxSpinner', function () {
    return {
        template:'<i class="fa fa-spin fa-spinner fa-pulse"></i>',
        restrict: "E",
        controller: "proxSpinnerController",
        scope: { },
        link: (scope, element, attributes) => { }
    }
});