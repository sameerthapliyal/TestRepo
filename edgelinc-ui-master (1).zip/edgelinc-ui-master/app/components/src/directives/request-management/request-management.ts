import {ISystemFilter} from "../../services/DeviceService";
import {IRowItem as IGroupDevicesConfigurationRowItem} from "../smart-table/st-custom-group-devices-configuration";
import {IRowItem as IUnregistrationDevicesRowItem} from "../smart-table/st-custom-unregistration-devices";
import ParameterStorageServiceModule, {IParameterStorageService, STORAGE_TYPE} from "../../services/ParameterStorageService";
import RequestManagementServiceModule, {RequestManagementService} from "../../services/RequestManagementService";
import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";
import StatisticsSimpleServiceModule, {StatisticsSimpleService} from "../../services/StatisticsSimpleService";
import AlertListServiceModule, {AlertListService, AlertFilter} from "../../services/AlertListService";
import AddRequestModule from "../../../../views/requestmanagement/add-request";
import CommonServicesModule, {CommonServices} from "../../../../components/src/services/CommonServices"
import RequestManagementModule from "../../../../views/requestmanagement/requestmanagement";

 
var angularModule = angular.module('directives.requestManagement',[RequestManagementServiceModule.name]);
export default angularModule;



interface RequestMgmtFiltersDirectiveScope extends ng.IScope {

    listFilter: ISystemFilter;
    onFilterChange(): void;
    filterChanged(): void;
    clearFilter(): void;
    filterQueryBinding: string;
}

interface IMCSParameterDisplay {
    assetType?: eapi19.mcsParameter,
    fleet?: eapi19.mcsParameter,
    manufacturer?: eapi19.mcsParameter,
    model?: eapi19.mcsParameter,
    controllerConfig?: eapi19.mcsParameter
}

class RequestMgmtFiltersController {
    public static $inject = ["$scope", "$timeout"];
    public constructor(private $scope: RequestMgmtFiltersDirectiveScope,
                       private $timeout: ng.ITimeoutService) {
        $scope.onFilterChange = () => {
            $scope.filterChanged();
            this.$scope.$broadcast("ScopeBinder:update");
        };
        $scope.clearFilter = () => {
            this.$scope.listFilter = {
                searchFields: this.$scope.listFilter.searchFields
            }
        }
    }
}

export interface ISystemDisplay extends IGroupDevicesConfigurationRowItem, IUnregistrationDevicesRowItem
{
    isSelected: boolean;
    isChecked: boolean;
    asdid: string;
    did: string;
    name: string;
    status: App.Models.IStatusDescription;
    location: {
        latitude: number;
        longitude: number
    };
    totalAlerts: number;
    activeDevices: number;
    inactiveDevices: number;
    registrationDate: number,
    lastCommunication: number;
    additionalData: {[key: string]: any};
    mcsParameters?: IMCSParameterDisplay;
    numericDID?:number;
    numericLocoId?:number;
    deviceModel?: App.Models.IDeviceModelDefinition;
    attributes?:{[key: string]: any};
    aggregates?:any;
    parameters_object?: any;
}



function RequestMgmtFiltersDirective($branding: app.branding.IBrandingService) {
    return{
        templateUrl:$branding.getTemplateUrl("directives.RequestMgmt.filters"),
           
      
        controller:'RequestMgmtFiltersController',

        scope: {
            listFilter: '=?',
            filterChanged: '&',
            filterQueryBinding: '@?',
            hideAlarmSeverityFilter: '=?',
            template: '=?'
        }
    }
}

angularModule.directive('requestMgmtFilters', ['$branding', RequestMgmtFiltersDirective]);
angularModule.controller('RequestMgmtFiltersController', RequestMgmtFiltersController);


export interface RequestManagementControllerScope extends ng.IScope {
  addRequest(): void; 
   requests;
   listFilter: any;
   onFilterChange(): void;
   doRequest(): void;
   clear(): void;
   // listFilter: IRepositoryPackageFilter;
   
    visibleCount:number;
    filteredCount: number;
    offset: number;
    isLoading: boolean;
    inProgress: boolean;
    error: Error;
    route: string;
    // getRestrictions(query: string): ng.IPromise<Restrictions>;
    // visibleItems: IRepositoryPackageDisplay[];
    pipe(tableState: any, tableCtrl: any): void;
    pageSize: number;
    deviceModels: eapi19.IDeviceModel[];
   
}
class RequestManagementController{
    private doRequestThrottled:()=>void;

    public static $inject = ['$scope','$q','$location','RouteHelpers','$timeout','ParameterStorageService','RequestManagementService','CommonServices','DeviceModelsService'];
     
    private tableState: any;
    private scopePropertiesToSave:string[] = ["pageSize"];
    private storageKey:string = "packages-table-storage";
    private storageType:STORAGE_TYPE;

    constructor(private $scope: RequestManagementControllerScope,
                   private $q: ng.IQService,
                   private $location: ng.ILocationService,
                   private RouteHelpers: app.IRouteHelpers,
                   private $timeout: ng.ITimeoutService,
                   private ParameterStorageService: IParameterStorageService,
                   private requestManagementService: RequestManagementService,
                   private $commonServices: CommonServices,
                   private DeviceModelsService: DeviceModelsService)
                // private AlertListService: AlertListService,
                // private StatisticsSimpleService: StatisticsSimpleService)
 {
     this.getDeviceModels();
     $scope.listFilter = {};
      $scope.addRequest = () => this.addRequest(); 
      $scope.onFilterChange = () => this.onFilterChange();
       $scope.visibleCount = 0;
        $scope.filteredCount = null;
      // this.doRequest('');
      $scope.doRequest = () => this.doRequest();
      $scope.clear = () => this.clearFilter();
     $scope.offset = 0;
        $scope.requests = [];
        $scope.inProgress = true;
        $scope.isLoading = true;
        

        var doRequestThrottled = $q.throttle(() => this.doRequest());

        this.initTableParameterStorageService();

        $scope.pipe = (_tableState: any) => {
            this.customSaveState();
            this.tableState = _tableState;
            doRequestThrottled();
        };
 }

     private getDeviceModels(){
         this.DeviceModelsService.getDeviceModelsFromEAPI(false).then(data => {
          this.$scope.deviceModels = data;
          console.log(data);
        })
        .catch(err => {
            console.error(err);
        })
    }
  private clearFilter(){
      this.$scope.listFilter = {}; 
         this.tableState.pagination.start = 0;
         this.doRequest();
         }
         private initTableParameterStorageService(){
         this.storageType = STORAGE_TYPE.SESSION_STORAGE;
         this.ParameterStorageService.restoreState(this.storageKey,this.storageType,this.$scope);
         if(this.$scope.pageSize == null || typeof this.$scope.pageSize == "undefined")
            this.$scope.pageSize = 10;
         }
          private customSaveState() {
            this.ParameterStorageService.saveState(this.$scope,this.storageKey,this.storageType, this.scopePropertiesToSave);
         }

 private doRequest() {
   
    var sortColumn = null;
        var sortDir: any = null;
        if (this.tableState.sort && this.tableState.sort.predicate) {
            sortColumn = this.tableState.sort.predicate;
            sortDir = this.tableState.sort.reverse ? "desc" : "asc";
        } else {
            sortColumn = "lastModifiedDate";
            sortDir = "desc";
           this.tableState.sort.predicate = "lastModifiedDate";
           this.tableState.sort.reverse = true;
        }
        var limit = this.tableState.pagination.number;
        var offset = this.tableState.pagination.start;
        var listFilter = this.$scope.listFilter;
        var reqObj = {
            locoRange:listFilter.locoId?{"start":listFilter.locoId.from,"end":listFilter.locoId.to} : null,
            requestRange:listFilter.taskId?{"start":listFilter.taskId.from,"end":listFilter.taskId.to} : null,
            customerId: listFilter.customer_id,//? listFilter.customer_id.toString:null,
            deviceName: listFilter.deviceType,
            typeName: listFilter.requestType,
            status:listFilter.status,
            onboardRequestId:listFilter.onboardRequestId,
            requestDescription:listFilter.requestDescription,
            sortDirection: sortDir,
            sortColumns: sortColumn,
            limit: limit,
            offset: offset
        };
        return this.requestManagementService.getRequestManagementData(reqObj)
            .then((result: any) => {
                if(result.status == 200 || result.status == 206){
                this.$scope.requests = result.data? result.data.contents : [];
                this.$scope.offset = offset;
                this.$scope.visibleCount = this.$scope.requests.length;
                this.$scope.filteredCount = result.data.totalEle;
                this.tableState.pagination.numberOfPages =  result.data.totalPages;//Math.ceil(result.totalCount / this.tableState.pagination.number);
                this.tableState.pagination.totalItemCount = result.data.totalEle;
                this.$scope.error = null;
                this.$timeout(()=>{
                   // this.$scope.$emit("stCustomSelection:selectedItemsChanged", result.items);
                },100);
            } else{
                //console.error(err);
                this.$scope.requests = [];
                this.$scope.visibleCount = 0;
                this.$scope.filteredCount = 0;
                this.$scope.inProgress = false;
                //this.tableState.pagination.numberOfPages = 0;
                this.tableState.pagination.totalItemCoun = 0;
                // this.$scope.error = err;
            }

            })
            .catch(err => {
                console.error(err);
                this.$scope.requests = [];
                this.$scope.visibleCount = 0;
                this.$scope.filteredCount = 0;
                this.$scope.inProgress = false;
                //this.tableState.pagination.numberOfPages = 0;
                this.tableState.pagination.totalItemCoun = 0;
                this.$scope.error = err;
            })
            .finally(() => {
                this.$scope.inProgress = false;
                this.$scope.isLoading = false;
            })
      
 }
 private addRequest() {
        var addRequestModuleName = AddRequestModule.name;
        var route = (<any>window).BRANDING.menu.config[addRequestModuleName].route;
        this.$location.url(this.RouteHelpers.routeToLocation(route, {}));
    }
    private onFilterChange() {
        this.doRequest();
    }
   

}

       


angularModule.controller('RequestManagementController', RequestManagementController);


angularModule.directive('requestManagement', ['$branding', function($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl("RequestManagementDirective"),
        controller: RequestManagementController
    }
}]);

// templateUrl: $branding.getTemplateUrl("/components/src/requestmanagement/requestmanagement"),

interface RequestManagementTableControllerScope extends ng.IScope {
    enableSelection: boolean;
    selectedAsdid: string;
    listFilter: ISystemFilter;
    requests: any[];
    checkedItems: ISystemDisplay[];
    disableCheckboxes: boolean;
    hideCheckboxes:boolean
    offset: number;
    visibleCount: number;
    filteredCount: number;
    inProgress: boolean;
    onSystemClick(args: {asdid: string}): void;
    pageSize: number;
    pipe(tableState:any, tableCtrl:any): void;
    refreshTable(): void;
    selectRow(row: ISystemDisplay): void;
}
angularModule.directive('requestManagementTable', ['$branding', function($branding: app.branding.IBrandingService) {
    return {
        templateUrl:$branding.getTemplateUrl('RequestManagementTableDirective'),
        scope: {
            pipe: '=',
            requests: '=',
            enableSelection: '=?',
            selectedAsdid: '=?',
            onSystemClick: '&',
            checkedItems: '=?',
            disableCheckboxes: '=?',
            columnsGetter: '&columns',
            refreshEvent: '@?',
            wizard: '=?',
            paginationLimit: '=?',
            hideView: '=?',
            inProgress: '=?'
        },
        controller:RequestManagementTableController
    }
}]);

class RequestManagementTableController{
    private tableState;
    private doRequestThrottled:()=>void;

    public static $inject = ['$scope', '$q', '$timeout', 'ParameterStorageService', 'RequestManagementService', 'DeviceModelsService', 'AlertListService', 'StatisticsSimpleService'];

    private scopePropertiesToSave:string[] = ["pageSize"];
    private storageKey:string = "systems-table-storage";
    private storageType:STORAGE_TYPE;

    constructor(private $scope: RequestManagementTableControllerScope)
    //             private $q: ng.IQService,
    //             private $timeout: ng.ITimeoutService,
    //             private ParameterStorageService: IParameterStorageService,
    //             private DeviceService: DeviceService,
    //             private DeviceModelsService: DeviceModelsService,
    //             private AlertListService: AlertListService,
    //             private StatisticsSimpleService: StatisticsSimpleService)
    {
        // $scope.requests = null;
        console.log($scope.requests)
        // $scope.filteredCount = 1;
        // $scope.inProgress = true;
        $scope.hideCheckboxes = $scope.hideCheckboxes || false;

        $scope.$watch('requests', (value:any) => {
           $scope.requests = value;
            console.log($scope.requests)
        });
        // $scope.$watch('listFilter', () => {
        //     //$timeout(customSaveState);
        //     $scope.inProgress = true;
        //     $scope.$broadcast('smartTable:refreshRequired');
        // }, true);

        // this.tableState = null;

        // // this.doRequestThrottled = $q.throttle(() => this.doRequest());

        // this.initTableParameterStorageService();

        // $scope.pipe = (_tableState:any) => {
        //     this.customSaveState();
        //     this.tableState = _tableState;
        //     this.doRequestThrottled();
        // };

        // $scope.refreshTable = () => {
        //    DeviceService.refreshCache().then(() => {
        //         this.refresh();
        //     });
        // };

        // $scope.selectRow = (row: ISystemDisplay) =>{ this.selectRow(row) };

        // this.DeviceService.onSystemsRefreshed(()=>{
        //   this.refresh();
        // }, $scope);
    }


    private refresh() {
        this.$scope.$broadcast('smartTable:refreshRequired');
    }

    private selectRow(row: ISystemDisplay) {
        this.$scope.selectedAsdid = row.asdid;
        this.$scope.onSystemClick({asdid: row.asdid});
    }

   
}
angularModule.controller('RequestManagementTableController', RequestManagementTableController);
interface IAddRequestDirectiveScope extends ng.IScope  {
    onBackToList(): void;
    listFilter:any;
    //errMsg: string;
    //successMsg:boolean;
    onFilterChange(newObj: any):void;
    onDateFilterChange(from: any, to: any): void;
    changeDesc(): void;
    onEdit(args: {packageId: string, packageVersion: string, templateType: string;}): void;
}
class AddRequestController{
    private tableState;
    private doRequestThrottled:()=>void;

    public static $inject = ['$scope','$q','$location','RouteHelpers','$timeout','$config','RequestManagementService', '$rootScope'];


    constructor(private $scope: IAddRequestDirectiveScope,
                   private $q: ng.IQService,
                   private $location: ng.ILocationService,
                   private RouteHelpers: app.IRouteHelpers,
                   private $timeout: ng.ITimeoutService,
                   private $config: app.config.IConfigService,
                // private ParameterStorageService: IParameterStorageService,
                   private requestManagementService: RequestManagementService,
                   private $rootScope: any)
                // private DeviceModelsService: DeviceModelsService,
                // private AlertListService: AlertListService,
                // private StatisticsSimpleService: StatisticsSimpleService)
 {
     console.log('testing');

       this.resetListFilter();
       $scope.onFilterChange = (data: any) => {
            $scope.listFilter = (<any>Object).assign({}, $scope.listFilter, data);
        $rootScope.$broadcast('changeDesc', {data: $scope.listFilter}); 
       };
       $scope.onDateFilterChange = (from: any, to: any) => {
            $scope.listFilter = (<any>Object).assign({}, $scope.listFilter, {associationDateRange:{from: from, to: to}});
        $rootScope.$broadcast('changeDesc', {data: $scope.listFilter}); 
       };
      //this.requestManagementService._getRequestManagementData("").then((response)=>{console.log(response.data.content);$scope.requests = response.data.content;});
      $scope.changeDesc = () => {

          $rootScope.$broadcast('changeDesc', {data: $scope.listFilter}); 
       };
      $scope.$on("selectedLocomotives:addRequest", (event, params)=>{
         console.log(params.selectedLocomotives);   
         var locomotives = params.selectedLocomotives.map( (item) => {
             return {"customerId": item.attributes.customer_id,"locoId":item.attributes.loco_id};
         });
         console.log($scope.listFilter.associationDateRange);
         var reqObj = {
            "locomotives":locomotives,
            "deviceName": "GEER",
            "requestDescription": $scope.listFilter.description,
            "typeName": $scope.listFilter.requestType,
            "message": JSON.stringify({
            "tasks": [
                   {
                  "taskName":"geer-download",
                  "taskDetails":{
                     "logPartition":$scope.listFilter.dataType,
                     "startTime": $scope.listFilter.associationDateRange?$scope.listFilter.associationDateRange.from : null,
                     "endTime":$scope.listFilter.associationDateRange?$scope.listFilter.associationDateRange.to: null,
                     "downloadPercentage": this.$config.GeerDownloadPercentage,
                     "username": this.$config.GeerUsername,
                     "userComments": this.$config.GeerUserComments,
                     "milePost": this.$config.GeerMilePost,
                      "wheelDiameter": this.$config.GeerWheelDiameter,
                      "offsetTime": this.$config.GeerOffsetTime,
                    // "fileServerDomainName":$scope.listFilter.downloadServer,
            //          "protocol":"sftp",
                      // "Priority":$scope.listFilter.priority,
            //          "fileServerPath":"/data/geer/download/"
                  }
              },
                   {
                      "taskName":"ftp-push",
                         "taskDetails":{
                          "fileServerDomainName":$scope.listFilter.downloadServer,
                          "protocol":"sftp",
                          "Priority":$scope.listFilter.priority,
                          "fileServerPath":"GET/"
      }
   

               }]  } )   
           }; 

       this.requestManagementService.addRequest(reqObj)
            .then((result: any) => {
               console.log(result);
               if(result.status == 200 ){
                   this.resetListFilter();
                   $rootScope.$broadcast('showMsg', {data:  result.data});                   
               }
            })
            .catch(err => {
                console.error(err);
                
            })     
        });

 }
 private resetListFilter() {
      this.$scope.listFilter = {
    requestType:"request-geer-data",
    deviceType:"GEER",
    dataType:"",
    description:"", 
    downloadServer:"",  
    associationDateRange:"",
    priority:""
};
 }
}

function AddRequestDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('AddRequestDirective'),
        controller: 'AddRequestController',
        scope: {
            onBackToList: '&',
            onEdit: '&'
        }
}
}
angularModule.directive("addRequest", ['$branding', AddRequestDirective]);
angularModule.controller('AddRequestController', AddRequestController);
