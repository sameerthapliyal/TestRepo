///<reference path="../../../../../typings/browser.d.ts"/>

import RequestManagementServiceModule, {RequestManagementService} from "../../services/RequestManagementService";
import UserManagementServiceModule, {UserManagementService} from "../../services/UserManagementService";
import AuthServiceModule, {AuthService} from "../../services/AuthService";
import {NotifyData} from "../../utilities/NotifyHelper";
import McsGeneralServiceModule, {McsGeneralService} from "../../services/mcs/McsGeneralService";
import AclServiceModule, {ACLService} from "../../services/ACLService";

export type RequestEditControllerMode = "CREATE" | "UPDATE" | "REVISE" | "VIEW" | "BULK" | "REVISE | VIEW";

interface IAdditionalLog {
    value:string;
    caption:string;
}

export interface IRequestEditControllerScope extends ng.IScope {
    packageId?: string;
    packageVersion?: string;
    templateType?: string;
    // originalPackage: IRequest;
    // otherPendingPackage?: IRequest;
    // packageToUpdate: IRequestToUpdate;
    // savedPackage: IRequest;
    // lastChoosenPackageFile: File;
    // lastChoosenSignatureFile: File;
    // templateTypes: RepositoryTemplateTypes;
    // restrictions: Restrictions;
    statuses: { [key: string]: string };
    isStatusesDisabled(status:string);
    softwareVersionDate: string;
    fileSize: number;
    initialized: boolean;
    templateNumber: number;
    inProgress: boolean;
    inProgressMessage:string;
    inProgressTemplateFileProgres:number;
    inProgressTemplateFileDetailedProgres: NotifyData;
    error?: Error;
    additional_logs?: IAdditionalLog[];
    // getRestrictions(query: string): ng.IPromise<Restrictions>;
    createPackage(form: ng.IFormController): void;
    updatePackage(form: ng.IFormController): void;
    revisePackage(form: ng.IFormController): void;
    reset(form: ng.IFormController): void;
    backToList(): void;
    // edit(repositoryPackage: IRequest): void;
    // revise(repositoryPackage: IRequest): void;
    // view(repositoryPackage: IRequest): void;
    templateInterfaces: { [key: string]: string };
    qnxRestrictions: {
        name: string;
    }[];
    uplincTemplateTypes: any;
    packageIsEdited: boolean;
    bulkTemplate: File;
    bulkUploadProcess(form: ng.IFormController): void;
    bulkResponse: {
        templateArray?: any,
        blobId?: string;
    };
    confirmTemplates(bulkArrayTemplates: any): void;
    canConfirmTemplates: boolean;
    uploadBulkError?: Error;
    confirmBulkError?: Error;
    confirmBulkSuccess?: boolean;
    confirmBulkWarning?: boolean;
    hasPermissionManageTemplate:boolean;
    resetUploadedPackage(blobId: string): void;
    showConfirmButton: boolean;
    confirmationInProgress: boolean;
}

export class RequestEditController {
    public static $inject = ["$scope", "$q", "RequestManagementService", "UserManagementService", "AuthorizationService", "McsGeneralService"];

    private mode: RequestEditControllerMode;

    // public emptyPackageFactory: (originalPackage: IRequest) => IRequestToUpdate;
    public onBackToList: () => void;
    // public onEdit: (repositoryPackage: IRequest) => void;
    // public onRevise: (repositoryPackage: IRequest) => void;
    // public onView: (repositoryPackage: IRequest) => void;


    constructor(private $scope: IRequestEditControllerScope,
        private $q: ng.IQService,
        private PackageRepositoryService: RequestManagementService,
        private UserManagementService: UserManagementService,
        private AuthorizationService: AuthService,
        private McsGeneralService: McsGeneralService) {
        console.log("editrequestcontroller")

       

        // this.PackageRepositoryService.getRestrictions().then(restrictions => this.$scope.restrictions = restrictions)
        // this.$scope.getRestrictions = (query: string) => {
        //   var regexp = new RegExp(query, "i");
        //   return $q.when(_.filter(this.$scope.restrictions, r => regexp.test(r.name)));
        // }
        // this.PackageRepositoryService.getTemplateTypes().then((tt) => {
        //     this.$scope.templateTypes = tt;
        //     this.$scope.uplincTemplateTypes = tt;
        // });
        // if (this.$scope.packageId != null && this.$scope.packageVersion != null && this.$scope.templateType) {
        //     this.PackageRepositoryService.getPackage(this.$scope.packageId, this.$scope.packageVersion, this.$scope.templateType)
        //         .then((repositoryPackage:IRequest) => {
        //             this.$scope.originalPackage = repositoryPackage;
        //             this.resetData();
        //             this.$scope.initialized = true;
        //         })
        // } else {
        //     this.resetData();
        //     this.$scope.initialized = true;
        // }
    }

}

var angularModule = angular.module('directives.requestManagement.requestEditController', [RequestManagementServiceModule.name, UserManagementServiceModule.name,
    AuthServiceModule.name, McsGeneralServiceModule.name, AclServiceModule.name])
    .controller("RequestEditController", RequestEditController);

angularModule.directive('fileValidate', function($branding: app.branding.IBrandingService) {
    return {
        require: 'ngModel',
        link: function(scope: IRequestEditControllerScope, el, attrs: any, ctrl: any) {
          
                
        }
    };
});

export default angularModule;
