/// <reference path="../../../../../typings/browser.d.ts" />
/// <reference path="../../definitions/Commands/Command.d.ts" />
/// <reference path="../../definitions/eapi/1.8/GroupOperationIdObject.d.ts" />

import GroupOperationsServiceModule, {GroupOperationsService} from "../../services/GroupOperationsService";
import DeviceServiceModule, {DeviceService} from "../../services/DeviceService";
import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";
import CommandsControlerParameterModule from "./command-parameter";
import json = d3.json;

interface commandsControlerScope extends ng.IScope {
    asdids: () => string[];
    deviceClass: () => string;
    showResult: boolean;
    commandList: models.Commands.ICommand[];
    commandListLength:number;
    selectedCommand: models.Commands.ICommand;
    result: CommandTaskResult;
    onClearClick: () => void;
    onSubmitClick: () => void;
    clearForm: () => void;
    submitDisabled: boolean;
    errorResult: string;
    getDeviceCommandInprogres: boolean;
    devicesModelsVersionMismatch:boolean;
    cmdsForm: any;
    onCancel:() => void;
}

interface CommandTaskResult {
    operationId: string;
    status: { css: string, text: string };
    details?: { text: string, label: string };
    dateTime?: number;
    asdid?: string;
    deviceName?: string;
    output?: string;
}

class commandsControler {
    private cmdListToRestore: models.Commands.ICommand[];
    private timer;

    constructor(private $scope: commandsControlerScope, private $q: ng.IQService, private $timeout: ng.ITimeoutService, private groupOperationsService: GroupOperationsService,
        private deviceModelsService: DeviceModelsService, private deviceService: DeviceService) {
        this.$scope.onClearClick = () => {
            this.clear();
        };

        this.$scope.onSubmitClick = () => {
            this.sendCommand();
        };

        this.$scope.clearForm = () => {
            this.clearForm();
        };

        this.$scope.$on("$destroy", (e) => {
            this.$timeout.cancel(this.timer);
            this.timer = undefined;
        });

        this.$scope.$watch("selectedCommand", () => {
            this.$scope.errorResult = null;
        });

        this.$scope.$watch(
            ()=>{
                if(this.$scope.asdids == null ||this.$scope.asdids() == null || this.$scope.asdids().length == 0){
                    return "";
                }else {
                    return this.$scope.asdids().join("_");
                }
            },
            (newAddids, oldAsdids)=>{
                if(this.$scope.asdids != null && this.$scope.asdids() != null && this.$scope.asdids().length > 0) {
                    this.$scope.getDeviceCommandInprogres = true;
                    deviceService.getManyDevices($scope.asdids()).then((devices: eapi18.DeviceFromDSC[]) => {
                        if (devices && devices.length > 0) {
                            var devModel = devices[0].device_model;
                            var devModelVer = devices[0].model_version;
                            //cheack other's devices model version
                            var allModelVersionMatch = true;
                            _.each(devices, (device: eapi18.DeviceFromDSC) => {
                                if (device.device_model != devModel || device.model_version != devModelVer) {
                                    allModelVersionMatch = false;
                                }
                            });
                            if (allModelVersionMatch) {
                                this.$scope.devicesModelsVersionMismatch = false;
                                this.groupOperationsService.getCommandListForCurrentDeviceClass(devModel, devModelVer).then(cmdList => {
                                    this.cmdListToRestore = cmdList;
                                    this.$scope.commandList = angular.copy(cmdList);
                                    this.$scope.getDeviceCommandInprogres = false;
                                    this.$scope.commandListLength = cmdList.length
                                }).catch((reason: any) => {
                                    console.error(reason);
                                    this.$scope.getDeviceCommandInprogres = false;
                                });
                            } else {
                                this.$scope.getDeviceCommandInprogres = false;
                                this.$scope.devicesModelsVersionMismatch = true;
                                this.cmdListToRestore = [];
                                this.$scope.commandList = [];
                            }
                        } else {
                            this.cmdListToRestore = [];
                            this.$scope.commandList = [];
                            this.$scope.getDeviceCommandInprogres = false;
                        }
                    });
                }
            });
    }

    private parseValue(type: string, special_format:string, value: any) {
        switch (type) {
            case "boolean":
                return Boolean(value);
            case "string":
                return value.toString();
            case "number":
            case "integer":
                if( ["DateTimeMS","DateMS"].indexOf(special_format) >=0 && typeof value == "object" && value.getTime){
                    return value.getTime();
                }else  if( ["DateTime","datetime","Date","date"].indexOf(special_format) >=0 && typeof value == "object" && value.getTime){
                    return value.getTime()/1000;
                }
                return parseFloat(value)
            case "json":
                try {
                    var myJSON = JSON.parse(value);
                }
                catch (e) {
                    return e;
                }
                return myJSON;
            default:
                console.warn("Type " + type + "is not defined. It was parsed to string.")
                return value.toString();
        }
    }

    private sendCommand() {
        this.$scope.submitDisabled = true;
        this.$scope.errorResult = null;
        //var dataObj = { type: this.$scope.selectedCommand.name };
        var dataObj = { command: this.$scope.selectedCommand.name };
        var value, type, special_format;
        if (this.$scope.selectedCommand.parameters && this.$scope.selectedCommand.parameters.length) {
            this.$scope.selectedCommand.parameters.forEach((p) => {
                value = p.value || p.default_value;
                type = p.type || "string";
                special_format = p.special_format || null;
                dataObj[p.api_name] = this.parseValue(type, special_format, value);
            });
        }
        this.groupOperationsService.executeCommand({ asdids: this.$scope.asdids(), command: { name: this.$scope.selectedCommand.api_name, data: JSON.stringify(dataObj) } }).then(data => {
            this.$scope.result = { operationId: data.operation_id, status: this.mapStatusToCssAndText("IN_PROGRESS", "") };
            if (this.$scope.showResult) {
                this.scheduleDetailsRequest(data.operation_id);
            } else {
                this.$scope.selectedCommand = null;
                this.$scope.commandList = angular.copy(this.cmdListToRestore);
            }
            this.$scope.submitDisabled = false;
        }).catch((reason: any) => {
            console.error("sendCommand", reason);
            this.$scope.submitDisabled = false;
            var message = reason.data.code || reason.status || "";
            if (reason != null && reason.data != null && (reason.data.description != null || reason.data.message)) {
                var message = reason.data.code || reason.status || "";
                message += ": ";
                message += reason.data.description || reason.data.message;
            } else if (reason != null && reason.statusText) {
                var message = reason.status || "";
                message += ": ";
                message += reason.statusText
            } else {
                message += JSON.stringify(reason);
            }
            this.$scope.errorResult = message;
        });
    }

    private clear() {
        this.$scope.selectedCommand = null;
        this.$scope.commandList = angular.copy(this.cmdListToRestore);
        this.$scope.result = null;
        this.$scope.errorResult = null;
            if( this.$scope.onCancel){
                this.$scope.onCancel();
            }
        }

    private clearForm() {
        if (this.$scope.selectedCommand && this.$scope.selectedCommand.parameters && this.$scope.selectedCommand.parameters.length) {
            this.$scope.selectedCommand.parameters.forEach((p) => {
              p.value = null;
            });
        }
        this.$scope.cmdsForm.$setPristine();
    }

    private scheduleDetailsRequest(operationId: string) {
        this.$timeout.cancel(this.timer);
        this.timer = this.$timeout(() => {
            this.groupOperationsService.getGroupOperationDetails(operationId, "commands").then((td) => {
                var r = this.$scope.result;
                r.status = this.mapStatusToCssAndText(td.status, td.result);
                r.dateTime = td.endTs || td.startTs || td.createTs;
                if (td.items && td.items.length) {
                    var ti = td.items[0];
                    r.details = this.mapItemStatusToDetailsText(ti.status, ti.result);
                    r.output = ti.commandDetailedStatus;
                    r.asdid = ti.asdid;
                    if (!r.deviceName) {
                        r.deviceName = ti.asdid;
                        if(td.devNamesMapping[ti.asdid]){
                            r.deviceName = td.devNamesMapping[ti.asdid].name;
                        }
                    }
                }
                this.$scope.$applyAsync();

                // TO DELETE \|/ POOLING
                if (this.timer && td.status != "FINISHED") {
                    this.scheduleDetailsRequest(operationId);
                }
                // /|\
            }).catch(reason => {
                this.$scope.result.status = this.mapStatusToCssAndText("", "");
                this.$scope.result.details = this.mapItemStatusToDetailsText("", "");
            });
        }, 5000, false);
    }

    private mapStatusToCssAndText(status: string, result: string): { css: string, text: string } {
        if (status == "PENDING") {
            return { css: "Pending", text: "Pending" };
        }
        if (status == "IN_PROGRESS") {
            return { css: "InProgress", text: "In Progress" };
        }
        if (status == "FINISHED") {
            if (result == "SUCCESS") {
                return { css: "Success", text: "Success" };
            }
            if (result == "FAILURE") {
                return { css: "Failed", text: "Failed" };
            }
            if (result == "ABORTED") {
                return { css: "Aborted", text: "Aborted" };
            }
        }
        return { css: "Unknown", text: "Unknown" };
    }

    private mapItemStatusToDetailsText(status: string, result): { text: string, label: string } {
        if (status == "PENDING") {
            return { text: "One operation is waiting to be executed.", label: "Pending" };
        }
        if (status == "IN_PROGRESS") {
            return { text: "One operation is in progress.", label: "In progress" };
        }
        if (status == "FINISHED") {
            if (result == "SUCCESS") {
                return { text: "One operation has finished successfully.", label: "Completed" };
            }
            if (result == "FAILURE") {
                return { text: "One operation has failed.", label: "Failed" };
            }
            if (result == "ABORTED") {
                return { text: "One operation has been aborted.", label: "Aborted" };
            }
        }
        return { text: "Unknown opertaion status.", label: "Unknown" };
    }
}

var angularModule = angular.module('directives.commands', [GroupOperationsServiceModule.name, DeviceModelsServiceModule.name, DeviceServiceModule.name,
    CommandsControlerParameterModule.name]);

angularModule.controller('commandsControler', ['$scope', '$q', '$timeout', 'GroupOperationsService', 'DeviceModelsService', 'DeviceService', commandsControler]);
angularModule.directive('commands', function() {
        return {
            templateUrl: '/components/src/directives/commands/commands.html',
            restrict: 'E',
            controller: 'commandsControler',
            scope: {
                asdids: '&asdids',
                //deviceClass: '&deviceClass',
                onCancel: '=?',
                commandListLength: "=?commandListLength"
            },
            link: function(scope: commandsControlerScope, elm, attrs, ctrl) {
                scope.showResult = !attrs.hasOwnProperty('doNotShowResult');
            }
        }
    });

angularModule.directive("cmdsValidate", function() {
    return {
        require: 'ngModel',
        scope: {
            cmdsValidate: '@'
        },
        link: function(scope, elm, attrs, ctrl: any) {
            if (scope.cmdsValidate == 'number') {
                ctrl.$validators.validate = function(modelValue, viewValue) {
                    var re = /^\d+([\.]\d+)?$/g
                    return re.test(modelValue)
                }
            }
            else if (scope.cmdsValidate == 'json') {
                ctrl.$validators.validate = function(modelValue, viewValue) {
                    try {
                        var myJSON = JSON.parse(modelValue);
                    }
                    catch (e) {
                        return false;
                    }
                    return true;
                };
            }
        }
    };
});

export default angularModule;
