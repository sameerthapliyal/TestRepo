/**
 * Created by rosadnik on 06-Dec-16.
 */

import DatepickereModule from "../../directives/datepicker-simple/datepicker-simple";

interface commandsControlerParameterScope extends ng.IScope{
    parameter: models.Commands.ICommandParameter;
    parameterEditor:()=>string;
}

class commandParameterControler{
    constructor(
        private $scope: commandsControlerParameterScope,
        private $q: ng.IQService,
        private $timeout: ng.ITimeoutService)
    {
        this.$scope.parameterEditor = ()=> this.parameterEditor();
    }
    
    private parameterEditor(){
        switch(this.$scope.parameter.type){
            case "number":
                if(this.$scope.parameter.special_format == "DateTime" || this.$scope.parameter.special_format == "DateTimeMS" || this.$scope.parameter.special_format == "datetime"){
                    return "Datetime"
                }else if(this.$scope.parameter.special_format == "Date" || this.$scope.parameter.special_format == "DateMS"  || this.$scope.parameter.special_format == "date"){
                    return "Datetime"
                }else if(this.$scope.parameter.special_format == "Dropdown"|| this.$scope.parameter.special_format == "enum"){
                    return "dropdown";
                }
                return "number";
            case "integer":
                if(this.$scope.parameter.special_format == "DateTime" || this.$scope.parameter.special_format == "DateTimeMS" || this.$scope.parameter.special_format == "datetime"){
                    return "Datetime"
                }else if(this.$scope.parameter.special_format == "Date" || this.$scope.parameter.special_format == "DateMS"  || this.$scope.parameter.special_format == "date"){
                    return "Datetime"
                }else if(this.$scope.parameter.special_format == "Dropdown" || this.$scope.parameter.special_format == "enum"){
                    return "dropdown";
                }
                return "number";
            case "string":
                if(this.$scope.parameter.special_format == "Dropdown" || this.$scope.parameter.special_format == "enum"){
                    return "dropdown";
                }else if(this.$scope.parameter.special_format =="Textarea"){
                    return "textarea";
                }
                return "string";
            case "boolean":
                if(this.$scope.parameter.special_format == "Dropdown"){
                    return "dropdown";
                }
                return "checkbox";
            case "object":
                return "textarea";
            case "array":
                return "textarea";
            default:
                if(this.$scope.parameter.special_format == "Dropdown"){
                    return "dropdown";
                }
                return "string";
        }
    }
}


var angularModule = angular.module('directives.commands.commandParameter', [DatepickereModule.name]);
angularModule.controller('commandParameterControler', ['$scope', '$q', '$timeout', commandParameterControler]);
angularModule.directive('commandParameter', function() {
    return {
        templateUrl: '/components/src/directives/commands/command-parameter.html',
        restrict: 'E',
        controller: 'commandParameterControler',
        scope: {
            parameter: '=',
        }
    }
});

export default angularModule;