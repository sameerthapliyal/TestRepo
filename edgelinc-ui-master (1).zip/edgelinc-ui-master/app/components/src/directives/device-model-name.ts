import CommonServicesModule, {CommonServices} from "../services/CommonServices";


/// <reference path="../../../typings/browser.d.ts" />



interface IAngularCompileControllerScope extends ng.IScope {

}


export class deviceModelController{

    
    constructor (
                private _scope,
                private _commonServices   
                )
    {
        if(!_scope.data.device_model_name) {

            _scope.details = _commonServices
                .getDeviceModelsDetailsInfo(
                    _scope.data.device_model,
                    _scope.data.model_version
                )
        }

    }
}

export default angular.module('directives.deviceModelName', [CommonServicesModule.name])

.directive("deviceModelName",()=>{
    return {
        controller: ['$scope', 'CommonServices', deviceModelController],
        template:`<span>
                        <span ng-show="!data.device_model_name">{{ details.name }}</span>
                        <span ng-show="data.device_model_name">{{data.device_model_name}}</span>
                        <span ng-show="data.model_version">
                             version. {{ data.model_version }} 
                        </span>
                        
                    </span>`,
        replace: true,
        scope: {
            deviceModel: '=',
            modelVersion: '=',
            data: '='
        },
        restrict: "E",
        }
    }

);
