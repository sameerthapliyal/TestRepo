///<reference path="../../../../typings/browser.d.ts"/>

var angularModule = angular.module('directives.proxAlarmIcon', []);
export default angularModule;

angularModule.controller('proxAlarmIconController', ['$scope', function ($scope) {} ]);
angularModule.directive('proxAlarmIcon', function () {
    return {
        template:'<i class="fa fa-exclamation-circle" style="color: red;"></i>',
        restrict: "E",
        controller: "proxAlarmIconController",
        scope: { },
        link: (scope, element, attributes) => { }
    }
});