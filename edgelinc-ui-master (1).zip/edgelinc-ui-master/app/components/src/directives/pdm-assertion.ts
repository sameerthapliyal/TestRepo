
import AttributesServiceModule, {AttributesService} from "../services/AttributesService";

interface IPdmAssertionDirectiveScope extends ng.IScope {
    subject: string,
    predicate: string,
    object: string,
    defaultValue: any
    assertion: eapi19.IAssertion
}

function PdmAssertionDirective($interpolate: ng.IInterpolateService, AttributesService: AttributesService) {
    return {
        restrict: "E",
        scope: {
            subject: "@",
            predicate: "@",
            object: "@",
            defaultValue: "=?",
            initialValue: "=?"
        },
        template: "{{assertion.object || initialValue}}",
        transclude: true,
        link: (scope: IPdmAssertionDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: any, transcludeFn: ng.ITranscludeFunction) => {
            function updateValue() {
                let filter = {
                    subject: scope.subject,
                    predicate: scope.predicate,
                    object: scope.object
                };
                filter = _.omit(filter, _.isNull);
                filter = _.omit(filter, _.isUndefined);
                AttributesService.getAssertion(filter).then((assertion: eapi19.IAssertion) => {
                    if(assertion) {
                        scope.assertion = assertion;
                    } else {
                        scope.assertion = {
                            subject: null,
                            predicate: null,
                            object: scope.defaultValue
                        }
                    }
                }).catch(err => {
                    console.error(`Cannot retrieve assertion ${JSON.stringify(filter)}.`, err)
                });
            }
            transcludeFn(scope, (clone) => {
                if(clone.length) {
                    elem.empty();
                    elem.append(clone);
                }
            });

            updateValue();
        }
    }
}

PdmAssertionDirective.$inject = ['$interpolate', 'AttributesService'];

export default angular.module('directives.pdmAssertion', [AttributesServiceModule.name])
    .directive('pdmAssertion', PdmAssertionDirective);