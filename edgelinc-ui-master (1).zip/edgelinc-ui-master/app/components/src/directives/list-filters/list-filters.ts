///<reference path="../../../../../typings/browser.d.ts"/>

import CommonServicesModule, {CommonServices} from "../../services/CommonServices";
import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";
import AllowedCharactersModule from "../../directives/validators/allowedCharacters";

var angularModule = angular.module('directives.listFilters', [CommonServicesModule.name, DeviceModelsServiceModule.name, AllowedCharactersModule.name]);
export default angularModule;

interface IAlertSeverity {
    key:string;
    caption:string;
    checked:boolean;
}
interface IListFilterAlarmSeverityScope extends ng.IScope {
    title:string,
    selectedSeverities:string[];
    severities:IAlertSeverity[];
    filterChanged:(model:string[]) => void;
    onFilterChanged:() => void;
    checkAllOnStart: string;
}

angularModule.directive('listFilterAlarmSeverity', ['$branding', function ($branding:app.branding.IBrandingService) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            title: '@',
            selectedSeverities: '=ngModel',
            filterChanged: "&",
            checkAllOnStart: '@'
        },
        templateUrl: "/components/src/directives/list-filters/list-filter-alarm-severity.html",
        link: (scope:IListFilterAlarmSeverityScope) => {
            var initialState = scope.checkAllOnStart != 'false';
            if (angular.isUndefined(scope.title)) {
                scope.title = 'Severity:';
            }
            scope.severities = [];
            var severities = $branding.getAlertSeverities();
            for (var i = 0; i < severities.length; i++) {
                scope.severities.push({
                    key: severities[i].key,
                    caption: severities[i].caption,
                    checked: initialState
                });
            }

            scope.onFilterChanged = () => {
                scope.selectedSeverities = _.chain(scope.severities)
                    .filter(s => s.checked)
                    .map(s => s.key)
                    .value();
                if(initialState && scope.selectedSeverities.length == scope.severities.length) {
                    scope.selectedSeverities = null;
                }
                if(!initialState && scope.selectedSeverities.length == 0) {
                    scope.selectedSeverities = null;
                }
                scope.filterChanged(scope.selectedSeverities);
            }

            scope.$watch('selectedSeverities', (severities:string[]) => {
                if (scope.selectedSeverities == null) {
                    if(initialState) {
                        _.each(scope.severities, s => s.checked = true);
                        //scope.selectedSeverities = _.map(scope.severities, s => s.key);
                    } else {
                        _.each(scope.severities, s => s.checked = false);
                        //scope.selectedSeverities = [];
                    }
                } else {
                    _.each(scope.severities, s => s.checked = (severities.indexOf(s.key) >= 0));
                }
            })
        }
    };
}]);

export interface IListItem {
    id:string;
    text:string;
}

interface IListFilterDeviceModelScope extends ng.IScope {
    title:string,
    placeholder?:string,
    deviceModelIds:string[];
    deviceModels:IListItem[];
    filterChanged:(model:string[]) => void;
    DeviceModelListFilter:(query:string) => ng.IPromise<IListItem[]>;
    onFilterChanged:() => void;
}
angularModule.directive('listFilterDeviceModel', ['DeviceModelsService', 'CommonServices', function (
    DeviceModelsService: DeviceModelsService,
    CommonServices: CommonServices
) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            title: '@',
            placeholder: '@',
            deviceModelIds: '=ngModel',
            filterChanged: "&",
        },
        templateUrl: "/components/src/directives/list-filters/list-filter-device-model.html",
        link: (scope:IListFilterDeviceModelScope) => {
            if (angular.isUndefined(scope.title)) {
                scope.title = 'Device Models:';
            }
            if(angular.isUndefined(scope.placeholder)) {
              scope.placeholder = 'Select Device Models';
            }

            var deviceModelsPromise:ng.IPromise<IListItem[]> = null;

            function updateDeviceModelList() {
                deviceModelsPromise = DeviceModelsService.getDeviceModels().then(result => {
                    return _.map(result, dm => {
                        return {
                            text: dm.name,
                            id: dm.id
                        }
                    }).sort((a, b) => {
                        return a.text.localeCompare(b.text);
                    });
                });
            }

            updateDeviceModelList();

            scope.DeviceModelListFilter = (query:string) => {
                return deviceModelsPromise.then(deviceModels => {
                    if (query != null && query.trim().length > 0) {
                        var pattern = new RegExp(query, "i");
                        return deviceModels.filter((m) => {
                            return pattern.test(m.text);
                        })
                    } else {
                        return deviceModels;
                    }
                })
            };

            scope.$on(CommonServices.onDeviceModelListUpdateCallback_EventName, ()=> {
                updateDeviceModelList();
            });

            scope.onFilterChanged = () => {
                scope.deviceModelIds = _.map(scope.deviceModels, dm => dm.id);
                if (scope.deviceModelIds.length == 0) {
                    scope.deviceModelIds = null;
                }
                scope.filterChanged(scope.deviceModelIds);
            };
            scope.$watch('deviceModelIds', (dmIds:string[]) => {
                if (dmIds == null || dmIds.length == 0) {
                    scope.deviceModels = [];
                } else {
                    deviceModelsPromise
                        .then(deviceModels => {
                            scope.deviceModels = _.filter(deviceModels, dm => dmIds.indexOf(dm.id) >= 0);
                        })
                }
            })

        }
    };
}]);

interface IListItemWithClass {
    id:string;
    text:string;
    cssClass: string;
}

interface IListFilterOperationalStateScope extends ng.IScope {
    title:string,
    systemStatuses: string;
    devicesFlag: string,
    selectedStates:string[];
    selectedItems:IListItemWithClass[];
    filterChanged:(model:string[]) => void;
    ListFilter:(query:string) => IListItemWithClass[];
    onFilterChanged:() => void;
}
angularModule.directive('listFilterOperationalState', ['$branding', function (
    $branding: app.branding.IBrandingService
) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            title: '@',
            systemStatuses: '@',
            devicesFlag: '@',
            selectedStates: '=ngModel',
            filterChanged: "&",
        },
        templateUrl: "/components/src/directives/list-filters/list-filter-operational-state.html",
        link: (scope:IListFilterOperationalStateScope) => {
            if (angular.isUndefined(scope.title)) {
                scope.title = 'Status:';
            }

            var statuses: app.branding.IDeviceStatus[];
            if(scope.systemStatuses == "true") {
                statuses = $branding.getSystemDeviceStatuses();
            } else {
                statuses = $branding.getDeviceStatuses(scope.devicesFlag)
            }

            var operationalStates: IListItemWithClass[] = _.map(statuses, status => {
                return {
                    text: status.text,
                    id: status.name,
                    cssClass: status.cssClass
                }
            });


            scope.ListFilter = (query:string) => {
                if (query != null && query.trim().length > 0) {
                    var pattern = new RegExp(query, "i");
                    return operationalStates.filter((m) => {
                        return pattern.test(m.text);
                    })
                } else {
                    return operationalStates;
                }
            };


            scope.onFilterChanged = () => {
                scope.selectedStates = _.map(scope.selectedItems, dm => dm.id);
                if (scope.selectedStates.length == 0) {
                    scope.selectedStates = null;
                }
                scope.filterChanged(scope.selectedStates);
            };
            scope.$watch('selectedStates', (states:string[]) => {
                if (states == null || states.length == 0) {
                    scope.selectedItems = [];
                } else {
                    scope.selectedItems = _.filter(operationalStates, state => states.indexOf(state.id) >= 0);
                }
            })

        }
    };
}]);

interface IListFilterRangeScope extends ng.IScope {
    title:string,
    model:{from?:number, to?:number};
    filterChanged:(model:{from?:number, to?:number}) => void;
    onFilterChanged:() => void;
    from: number;
    to: number;
    min: number,
    max: number,
    step: number
}
angularModule.directive('listFilterRange', function () {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            title: '@',
            model: '=ngModel',
            filterChanged: "&",
            from: '=?',
            to: '=?',
            min: '@',
            max: '@',
            step: '@',
            required: '=?ngRequired',
            disabled: '=?ngDisabled'
        },
        templateUrl: "/components/src/directives/list-filters/list-filter-range.html",
        link: (scope:IListFilterRangeScope) => {
            if (angular.isUndefined(scope.title)) {
                scope.title = 'Range:';
            }

            scope.onFilterChanged = () => {
                scope.filterChanged(scope.model);
            };
            //scope.max = scope.max || 999999999;
        }
    };
});

interface IListFilterDateRangeScope extends ng.IScope {
    title:string,
    dateFrom:Date;
    dateTo:Date;
    model:{from:number, to:number};
    filterChanged:(model:{from:number, to:number}) => void;
    onFilterChanged:() => void;
}
angularModule.directive('listFilterDateRange', function () {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            title: '@',
            model: '=ngModel',
            dateFrom: '=?',
            dateTo: '=?',
            filterChanged: "&",
            elemId: "@?id",
            disabled: '=?ngDisabled',
            required: '@',
            field: '@'
        },
        templateUrl: "/components/src/directives/list-filters/list-filter-date-range.html",
        link: (scope:IListFilterDateRangeScope) => {
            if (angular.isUndefined(scope.title)) {
                scope.title = 'Date Range';
            }
            scope.onFilterChanged = () => {
                scope.model = {
                    from: scope.dateFrom ? scope.dateFrom.getTime() : null,
                    to: scope.dateTo ? scope.dateTo.getTime() : null
                };
                if (scope.model.from == null && scope.model.to == null) {
                    scope.model = null;
                }
                scope.filterChanged(scope.model);
            }
            scope.$watch('model', (model:{from:number; to:number}) => {
                if (model && model.from != null) {
                    scope.dateFrom = new Date(model.from);
                } else {
                    scope.dateFrom = null;
                }
                if (model && model.to != null) {
                    scope.dateTo = new Date(model.to);
                } else {
                    scope.dateTo = null;
                }
            }, true)
        }
    };
});

interface IListFilterCheckboxScope extends ng.IScope {
    title:string,
    label:string,
    model:boolean;
    filterChanged:(model:boolean) => void;
    onFilterChanged:() => void;
}
angularModule.directive('listFilterCheckbox', function () {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            title: '@',
            label: '@',
            model: '=ngModel',
            filterChanged: "&",
        },
        templateUrl: "/components/src/directives/list-filters/list-filter-checkbox.html",
        link: (scope:IListFilterCheckboxScope) => {
            scope.onFilterChanged = () => {
                scope.filterChanged(scope.model);
            }
        }
    }
});

interface IListFilterDropdownScope extends ng.IScope {
    title:string,
    model:string;
    filterChanged:(args: any) => void;
    onFilterChanged:() => void;
    options: {id: string; text:string}[];
    placeholder?: string;
    field?: string;
}
interface IListFilterDropdownOptionScope extends ng.IScope {
    id: string;
    text: string;
}
interface IListFilterDropdownCtrl {
    addOption(id: string, text: string);
}
class ListFilterDropdownCtrl implements IListFilterDropdownCtrl{
    public static $inject = ['$scope'];
    constructor(private $scope: IListFilterDropdownScope) {}

    addOption(id: string, text: string) {
        this.$scope.options.push({id: id, text: text});
    }
}
angularModule.controller("ListFilterDropdownCtrl", ListFilterDropdownCtrl);
angularModule.directive('listFilterDropdown', function () {
    return {
        restrict: 'E',
        transclude: true,
        replace: true,
        scope: {
            title: '@',
            label: '@',
            model: '=ngModel',
            filterChanged: "&",
            placeholder: '@',
            disabled: '=?ngDisabled',
            required: '@',
            field: '@'
        },
        templateUrl: "/components/src/directives/list-filters/list-filter-dropdown.html",
        controller: "ListFilterDropdownCtrl",
        link: (scope:IListFilterDropdownScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: ListFilterDropdownCtrl, transcludeFn: ng.ITranscludeFunction) => {
            scope.options = [];
            scope.onFilterChanged = () => {
                let data = {};
                data[scope.field] = scope.model;
                scope.filterChanged({data: data});
            }
            transcludeFn(scope.$parent, (clone: ng.IAugmentedJQuery) => {
                elem.append(clone);
            });
        }
    }
});
angularModule.directive('listFilterDropdownItem', function () {
    return {
        restrict: 'E',
        require: '^listFilterDropdown',
        scope: {
            id: '@',
            text: '@'
        },
        link: (scope:IListFilterDropdownOptionScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: ListFilterDropdownCtrl) => {
            ctrl.addOption(scope.id, scope.text);
        }
    }
});

interface IListFilterTextScope extends ng.IScope {
    title:string,
    model:string,
    inputType: string;
    filterChanged:(args: {model:string}) => void;
    onFilterChanged:() => void;
    inputWidth: string;
}
angularModule.directive('listFilterText', function () {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            title: '@',
            model: '=ngModel',
            filterChanged: "&",
            inputType: '@',
            inputWidth: '@',
            maxlength: '@',
            max: '@',
            min: '@'
        },
        templateUrl: "/components/src/directives/list-filters/list-filter-text.html",
        link: (scope:IListFilterTextScope) => {
            if (angular.isUndefined(scope.inputType)) {
              scope.inputType = 'text';
            }
            scope.onFilterChanged = () => {
                scope.filterChanged({model: scope.model});
            }
        }
    }
});

angularModule.directive('listFilterCustom', function() {
    return {
        restrict: "E",
        transclude: true,
        replace: true,
        templateUrl: "/components/src/directives/list-filters/list-filter-custom.html",
        scope: {
            title: '@',
        }
    }
})
