///<reference path="../../../../../../typings/browser.d.ts"/>

import "./core/ClusterMarker";

export interface IClusteredNodeModel extends ng.leaflet.MapMarker {
    id: string;
    type: string;
    geoHash: string;
    cluster: {
        bounds: ng.leaflet.Bounds;
        hasChildren: boolean;
    },
    spiderfy: {
        getNodes: (capacity: number, options: L.ClusterMarkerSpiderfyOptions) => ng.IPromise<IClusteredNodeModel[]>;
    }
    properties?: any;
}

export class ClusteredMarkersHelpers {
    public static $inject = ['leafletHelpers', 'leafletMarkersHelpers', 'leafletMarkerEvents'];

    public static DefaultClusterMarkerFactory = L.ClusterMarker;
    public static DefaultNodeMarkerFactory = L.Marker;
    public static DefaultSpiderfyMarkerFactory = L.Marker;


    constructor(private leafletHelpers, private leafletMarkersHelpers, private leafletMarkerEvents) {

    }

    public createClusterMarker(markerData, factory?) {
        return this.createMarker(markerData, factory || ClusteredMarkersHelpers.DefaultClusterMarkerFactory);
    }

    public createNodeMarker(markerData, factory?) {
        return this.createMarker(markerData, factory || ClusteredMarkersHelpers.DefaultNodeMarkerFactory);
    }

    public createSpiderfyMarker(markerData, factory?) {
        return this.createMarker(markerData, factory || ClusteredMarkersHelpers.DefaultSpiderfyMarkerFactory);
    }

    private createMarker(markerData: IClusteredNodeModel, factory) {
        markerData = _.omit(markerData, ['layer']);

        // workaround: leafletMarkersHelpers.createMarker doesn't allow us to provide custom marker constructor/factory
        var originalMarkerFactory = L.marker;
        var marker;
        try {
            L.marker = factory;
            marker = this.leafletMarkersHelpers.createMarker(markerData);
        } finally {
            L.marker = originalMarkerFactory;
        }
        return marker;
    }

    public initMarker(marker: any, model: IClusteredNodeModel, markerName: string, mapId: string, map: any, leafletScope: ng.IScope, layerName: string) {
        var pathToMarker = this.leafletHelpers.getObjectDotPath(layerName ? [layerName, markerName] : [markerName]);

        if (this.leafletHelpers.isDefined(model.message)) {
            marker.bindPopup(model.message, model.popupOptions);
        }

        // Show label if defined
        if (this.leafletHelpers.LabelPlugin.isLoaded() && this.leafletHelpers.isDefined(model.label) && this.leafletHelpers.isDefined(model.label.message)) {
            marker.bindLabel(model.label.message, model.label.options);
        }

        this.leafletMarkersHelpers.listenMarkerEvents(marker, model, leafletScope, false, map);
        this.leafletMarkerEvents.bindEvents(mapId, marker, pathToMarker, model, leafletScope, layerName);

        if(model.cluster) {
            marker.options.cluster = {
                bounds: model.cluster.bounds ? L.latLngBounds(model.cluster.bounds.southWest, model.cluster.bounds.northEast) : null,
                hasChildren: model.cluster.hasChildren
            };
        }
        marker.options.properties = model.properties;
        if(marker instanceof L.ClusterMarker) {
            marker.on('spiderfy', args => {
                var spiderfyOptions: L.ClusterMarkerSpiderfyOptions = args.spiderfyOptions;
                var capacity = args.capacity;
                model.spiderfy.getNodes(capacity, spiderfyOptions)
                    .then(nodes => {
                        var markers = _.map(nodes, (node: IClusteredNodeModel) => {
                            var marker = this.createSpiderfyMarker(node);
                            this.initMarker(marker, node, node.id, mapId, map, leafletScope, layerName);
                            return marker;
                        });
                        args.done(markers);
                    })
                    .catch(args.error);
            });
        }
    }

    public updateMarker(model: IClusteredNodeModel, oldModel: IClusteredNodeModel, marker: any, name: string, leafletScope: ng.IScope, map: any) {
        model = _.omit(model, ['layer']);
        oldModel = _.omit(oldModel, ['layer']);
        this.leafletMarkersHelpers.updateMarker(model, oldModel, marker, name, leafletScope, null, map);

        if(model.cluster) {
            marker.options.cluster = {
                bounds: model.cluster.bounds ? L.latLngBounds(model.cluster.bounds.southWest, model.cluster.bounds.northEast) : null,
                hasChildren: model.cluster.hasChildren
            };
        }
        marker.options.properties = model.properties;
    };
}

export default angular.module('directives.leaflet.clusteredMarkersSource.helpers', [])
    .service('ClusteredMarkersHelpers', ClusteredMarkersHelpers);