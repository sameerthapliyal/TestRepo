///<reference path="extensions.d.ts"/>
///<reference path="ClusterMarker.d.ts"/>
///<reference path="RemoteClusteredMarkersGroup.d.ts"/>
