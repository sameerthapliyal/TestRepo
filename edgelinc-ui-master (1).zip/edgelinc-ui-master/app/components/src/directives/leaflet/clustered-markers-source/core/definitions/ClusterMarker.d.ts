///<reference path="../../../../../../../../typings/browser.d.ts"/>

declare namespace L {

    export interface ClusterMarkerSpiderfyOptions {
        levels?: number;
        markerSize?: [number,number];
        spiderLegPolylineOptions?: L.PolylineOptions;
    }

    export interface ClusterMarkerOptions extends MarkerOptions {
        cluster: {
            bounds: L.LatLngBounds;
            hasChildren: boolean;
        },
        spiderfy?: ClusterMarkerSpiderfyOptions;
    }

    export interface ClusterMarker extends Marker {
        options: ClusterMarkerOptions;
        toggleSpiderfy(): void;
        showSpiderfy(): void;
        hideSpiderfy(): void;
    }
    export var ClusterMarker: {
        new(latlng: LatLng, options: MarkerOptions): ClusterMarker
    };

    export function clusterMarker(latlng: LatLng, options: ClusterMarkerOptions): ClusterMarker;
}