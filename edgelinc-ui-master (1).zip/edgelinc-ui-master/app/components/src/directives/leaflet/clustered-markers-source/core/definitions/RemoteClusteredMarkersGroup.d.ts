///<reference path="../../../../../../../../typings/browser.d.ts"/>

declare namespace L {
    export interface RemoteClusteredMarkersGroupOptions {

    }

    export interface RemoteClusteredMarkersGroup extends FeatureGroup<Marker> {
        refresh(): void;
        addMarker(marker: L.Marker, parent: L.Marker): void;
        updateMarker(marker: L.Marker, updateFn: (marker: L.Marker) => void): void;
        removeMarker(marker: L.Marker, parent: L.Marker): void;
        applyChanges(): Promise<any>;
        enableRefreshing(enable?: boolean): void;
    }

    export var RemoteClusteredMarkersGroup: {
        new(options: RemoteClusteredMarkersGroupOptions): RemoteClusteredMarkersGroup;
    };

    export function remoteClusteredMarkersGroup(options: RemoteClusteredMarkersGroupOptions): RemoteClusteredMarkersGroup;
}