///<reference path="../../../../../../typings/browser.d.ts"/>
///<reference path="core/definitions/index.d.ts"/>

import * as _ from "lodash";

import ClusteredMarkersHelpersModule, {ClusteredMarkersHelpers, IClusteredNodeModel} from "./ClusteredMarkersHelpers";
import "./core/RemoteClusteredMarkersGroup";


export interface IClusteredMarkersSourceLayerOptions {
    layerOptions?: any;
    getNodes: (bounds: ng.leaflet.Bounds, zoomLevel: number) => ng.IPromise<{[nodeId: string]: IClusteredNodeModel}>;
    enableRefreshing?: boolean;
}

export type IClusteredMarkersSourceOptions = {[layerId: string]: IClusteredMarkersSourceLayerOptions};

interface IClusteredMarkersSourceAttributes extends ng.IAttributes {
    clusteredMarkersSource: string;
}



class ClusteredMarkersSourceController {
    static $inject = ['$scope', '$parse', '$attrs', 'ClusteredMarkersHelpers'];

    private _map: any;
    private _layers: any;
    private _trackedLayers: L.RemoteClusteredMarkersGroup[];
    private _leafletScope: ng.IScope;
    private options: IClusteredMarkersSourceOptions;
    private markers: {[layerId: string]: {
        [markerId: string]: {
            marker: L.Marker,
            model: IClusteredNodeModel
        }
    }} = {};

    constructor(private $scope: ng.IScope,
                private $parse: ng.IParseService,
                private $attrs: IClusteredMarkersSourceAttributes,
                private ClusteredMarkersHelpers: ClusteredMarkersHelpers
    ) {

    }

    init(scope: ng.IScope, mapId: string, map: L.Map, layers, leafletScope): void {
        this._map = map;
        this._layers = layers;
        this._leafletScope = leafletScope;

        this.options = this.$parse(this.$attrs.clusteredMarkersSource)(this.$scope);


        this._trackedLayers = [];

        _.each(this.options, (layerSourceOptions: IClusteredMarkersSourceLayerOptions, layerName: string) => {
            var layer = layers && layers.overlays ? layers.overlays[layerName] : null;
            if (!layer) {
                layer = L.remoteClusteredMarkersGroup(layerSourceOptions.layerOptions || {});
                layer.addTo(map);
            } else if (!(layer instanceof L.RemoteClusteredMarkersGroup)) {
                throw new Error("Cannot assign markers source to layer other than L.RemoteClusteredMarkersGroup");
            }
            this._trackedLayers.push(layer);

            scope.$watch(() => layerSourceOptions.enableRefreshing, enableRefreshing => layer.enableRefreshing(enableRefreshing));

            layer.on("refreshrequired", (args: any) => {
                try {
                    var bounds = {
                        northEast: {
                            lat: args.bounds.getNorth(),
                            lng: args.bounds.getEast()
                        },
                        southWest: {
                            lat: args.bounds.getSouth(),
                            lng: args.bounds.getWest()
                        }
                    };
                    var zoomLevel = args.zoom;
                    layerSourceOptions.getNodes(bounds, zoomLevel)
                        .then(nodes => {
                            this.updateLayer(layerName, layer, nodes, mapId, map, leafletScope)
                                .then(args.done)
                                .catch(args.error);
                        })
                        .catch(args.error);
                } catch(err) {
                    console.error(err);
                }
            });
        });


        this.$scope.$on("clusteredMarkersSource:refresh", () => {
            _.each(this._trackedLayers, (layer: L.RemoteClusteredMarkersGroup) => layer.refresh());
        })
    }

    updateLayer(layerName: string, layer: L.RemoteClusteredMarkersGroup, nodes: {[nodeId: string]: IClusteredNodeModel}, mapId: string, map: L.Map, leafletScope: ng.IScope): Promise<any> {
        var oldMarkers = this.markers[layerName] || {};

        var markersToRemove = _.mapValues(oldMarkers, (marker) => {
            return {
                marker: marker.marker,
                model: marker.model,
                parent: null
            };
        });
        var markersToAdd = {};
        var markersToUpdate = {};

        _.each(nodes, (model: IClusteredNodeModel, key: string) => {
            if (key in markersToRemove) {
                markersToUpdate[key] = {
                    marker: markersToRemove[key].marker,
                    model: model,
                    oldModel: markersToRemove[key].model
                };
                delete markersToRemove[key];
            } else {
                var marker;
                if(model.type == "CLUSTER") {
                    marker = this.ClusteredMarkersHelpers.createClusterMarker(model);
                } else {
                    marker = this.ClusteredMarkersHelpers.createNodeMarker(model)
                }
                this.ClusteredMarkersHelpers.initMarker(marker, model, key, mapId, map, leafletScope, layerName);
                markersToAdd[key] = {
                    marker: marker,
                    model: model,
                    parent: null
                };
            }
        });

        _.each(markersToAdd, (markerToAdd) => {
            _.each(markersToRemove, (markerToRemove) => {
                if (this.isChildOf(markerToRemove.model, markerToAdd.model)) {
                    markerToRemove.parent = markerToAdd.marker;
                }
                else if (this.isChildOf(markerToAdd.model, markerToRemove.model)) {
                    markerToAdd.parent = markerToRemove.marker;
                }
            });
        });

        _.each(markersToUpdate, (markerToUpdate) => {
            /*_.each(markersToRemove, (markerToRemove) => {
                if (this.isChildOf(markerToRemove.model, markerToUpdate.model)) {
                    markerToUpdate.children.push(markerToRemove.marker);
                }
            });*/
            _.each(markersToAdd, (markerToAdd) => {
                if (this.isChildOf(markerToAdd.model, markerToUpdate.model)) {
                    markerToAdd.parent = markerToUpdate.marker;
                }
            });
        });

        _.each(markersToRemove, (markerInfo, markerName) => {
            layer.removeMarker(markerInfo.marker, markerInfo.parent);
        });

        _.each(markersToUpdate, (markerInfo, markerName) => {
            layer.updateMarker(markerInfo.marker, marker => {
                this.ClusteredMarkersHelpers.updateMarker(markerInfo.model, markerInfo.oldModel, marker, markerName, leafletScope, map)
            });
            oldMarkers[markerName].model = markerInfo.model;
        });

        _.each(markersToAdd, (markerInfo, markerName) => {
            function markerAdded() {
                oldMarkers[markerName] = {
                    marker: markerInfo.marker,
                    model: markerInfo.model
                };
                markerInfo.marker.off('add', markerAdded);
            }
            function markerRemoved() {
                delete oldMarkers[markerName];
                markerInfo.marker.off('remove', markerRemoved);
            }

            markerInfo.marker.on('add', markerAdded);
            markerInfo.marker.on('remove', markerRemoved);
            layer.addMarker(markerInfo.marker, markerInfo.parent);

        });
        this.markers[layerName] = oldMarkers;
        return layer.applyChanges();
    }

    private isChildOf(node: IClusteredNodeModel, secondNode: IClusteredNodeModel) {
        return _.startsWith(node.geoHash, secondNode.geoHash)
    }
}


function ClusteredMarkersSourceDirective($q: ng.IQService) {
    return {
        restrict: "A",
        require: ["leaflet", "layers", "clusteredMarkersSource"],
        controller: ClusteredMarkersSourceController,
        link: function (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: IClusteredMarkersSourceAttributes, ctrls) {
            var leafletCtrl = ctrls[0];
            var layersCtrl = ctrls[1];
            var clusteredMarkersSourceCtrl: ClusteredMarkersSourceController = ctrls[2];

            var mapPromise = leafletCtrl.getMap();
            var layersPromise = layersCtrl.getLayers();
            var leafletScope = leafletCtrl.getLeafletScope();

            $q.all([$q.when(scope), $q.when(null), mapPromise, layersPromise, $q.when(leafletScope)])
                .then((args) => {
                    ClusteredMarkersSourceController.prototype.init.apply(clusteredMarkersSourceCtrl, args);
                });
        }
    }
}
ClusteredMarkersSourceDirective.$inject = ['$q'];


export default angular.module('directives.leaflet.clusteredMarkersSource', [ClusteredMarkersHelpersModule.name])
    .directive('clusteredMarkersSource', ClusteredMarkersSourceDirective);