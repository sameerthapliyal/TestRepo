///<reference path="../../../../../../../typings/browser.d.ts"/>
///<reference path="definitions/index.d.ts"/>

import "leaflet";
import "./MarkerExtensions";


type MarkersToAdd = {
    marker: L.Marker & MarkerExtension,
    parent: L.Marker & MarkerExtension
}[];

type MarkersToRemove = {
    marker: L.Marker & MarkerExtension,
    parent: L.Marker & MarkerExtension
}[];

type MarkersToUpdate = {
    marker: L.Marker & MarkerExtension;
    updateFn: (marker: L.Marker & MarkerExtension) => void;
}[]

interface MarkerExtension {
    _latlng?: L.LatLng;
    _icon?: HTMLElement;
    __removing?: boolean;
    __targetLatLng?: L.LatLng;
}

class RemoteClusteredMarkersGroupClass extends L.FeatureGroup<L.Marker> {
    options: L.RemoteClusteredMarkersGroupOptions;
    _map: L.Map;
    _animations: any[];
    viewResetCallback: () => void;
    zoomStartCallback: () => void;
    zoomEndCallback: () => void;
    moveStartCallback: () => void;
    moveEndCallback: () => void;
    nodeClickCallback: (e: {target: L.Marker}) => void;
    _debouncedLoadData: () => void;
    _markersToAdd: MarkersToAdd;
    _markersToRemove: MarkersToRemove;
    _markersToUpdate: MarkersToUpdate;
    _refreshingEnabled: any;


    initialize(options) {
        L.FeatureGroup.prototype.initialize.call(this, []);
        this.options = options;
        this._animations = [];



        this._markersToAdd = <MarkersToAdd>[];
        this._markersToRemove = <MarkersToRemove>[];
        this._markersToUpdate = <MarkersToUpdate>[];
    }

    onAdd(map: L.Map) {
        //L.FeatureGroup.prototype.onAdd.call(this, map);
        super.onAdd(map);

        this.viewResetCallback = this._onViewReset.bind(this);
        this.zoomStartCallback = this._onZoomStart.bind(this);
        this.moveStartCallback = this._onMoveStart.bind(this);
        this.zoomEndCallback = this._onZoomEnd.bind(this);
        this.moveEndCallback = this._onMoveEnd.bind(this);
        this.nodeClickCallback = this._onNodeClick.bind(this);

        map.on('viewreset', this.viewResetCallback);
        map.on('zoomstart', this.zoomStartCallback);
        map.on('movestart', this.moveStartCallback);
        map.on('zoomend', this.zoomEndCallback);
        map.on('moveend', this.moveEndCallback);
        this.refresh();
    }

    onRemove(map: L.Map) {
        //L.FeatureGroup.prototype.onRemove.call(this, map);
        super.onRemove(map);
        map.off('viewreset', this.viewResetCallback);
        map.off('zoomstart', this.zoomStartCallback);
        map.off('movestart', this.moveStartCallback);
        map.off('zoomend', this.zoomEndCallback);
        map.off('moveend', this.moveEndCallback);
    }

    addMarker(marker: L.Marker, parent: L.Marker) {
        this._markersToAdd.push({
            marker: marker,
            parent: parent
        });
    }

    updateMarker(marker: L.Marker, updateFn: (marker: L.Marker) => void) {
        this._markersToUpdate.push({
            marker: marker,
            updateFn: updateFn
        });
    }

    removeMarker(marker: L.Marker, parent: L.Marker) {
        this._markersToRemove.push({
            marker: marker,
            parent: parent
        });
    }

    applyChanges(): Promise<any> {
        this._map._mapPane.className = this._map._mapPane.className.replace(' leaflet-cluster-anim', '');
        this._map._mapPane.className += ' leaflet-cluster-anim';

        var transitionPromises: Promise<any>[] = [];

        var markersToRemove = this._markersToRemove;
        var markersToAdd = this._markersToAdd;
        var markersToUpdate = this._markersToUpdate;

        this._markersToRemove = [];
        this._markersToAdd = [];
        this._markersToUpdate = [];

        _.each(markersToRemove, (markerInfo: {marker: L.Marker & MarkerExtension, parent: L.Marker & MarkerExtension}) => {
            var marker = markerInfo.marker;
            var parent = markerInfo.parent;

            if(!marker._icon) {
                console.warn("Cannot remove marker. Marker is not on the map", marker);
                return;
            }
            marker.__removing = true;
            var parentLatLng = parent ? parent.getLatLng() : null;
            if(parentLatLng) {
                marker.__targetLatLng = parentLatLng;
            }
        });
        _.each(markersToAdd, (markerInfo: {marker: L.Marker & MarkerExtension, parent: L.Marker & MarkerExtension}) => {
            var marker = markerInfo.marker;
            var parent = markerInfo.parent;

            if(marker._icon) {
                console.warn("Cannot add marker. Marker is already on the map", marker);
                return;
            }

            var latlng = marker.getLatLng();
            var parentLatLng = parent ? parent.getLatLng() : null;
            if(parentLatLng) {
                marker.__targetLatLng = latlng;
                marker._latlng = parentLatLng;
            }
            this.addLayer(marker);
            marker.hide();
            this._onMarkerAdded(markerInfo.marker, markerInfo.parent);
        });
        _.each(markersToUpdate, (markerInfo: {marker: L.Marker & MarkerExtension, updateFn: (marker:L.Marker & MarkerExtension) => void}) => {
            var marker: L.Marker & MarkerExtension = markerInfo.marker;
            if(!markerInfo.marker._icon) {
                console.warn("Cannot update marker. Marker is not on the map", markerInfo.marker);
                return;
            }
            marker.__removing = false;
            marker.show();
        });

        return new Promise((resolve: () => void, reject: (err: any) => void) => {
            setTimeout(() => {
                try {
                    _.each(markersToRemove, (markerInfo: {marker: L.Marker & MarkerExtension, parent: L.Marker & MarkerExtension}) => {
                        var marker: L.Marker & MarkerExtension = markerInfo.marker;
                        if (!marker._icon) {
                            return;
                        }
                        if (marker.__targetLatLng) {
                            marker._latlng = marker.__targetLatLng;
                            marker.hide();
                            marker.update();
                        }
                        var duration = this.getTransitionDuration(marker._icon);
                        var transitionPromise = new Promise((done: () => void) => {
                            setTimeout(() => {
                                if (marker.__removing) {
                                    this.removeLayer(marker);
                                    this._onMarkerRemoved(markerInfo.marker, markerInfo.parent);
                                }
                                done();
                            }, duration);
                        });
                        transitionPromises.push(transitionPromise);
                    });

                    _.each(markersToAdd, (markerInfo: {marker: L.Marker & MarkerExtension, parent: L.Marker & MarkerExtension}) => {
                        var marker: L.Marker & MarkerExtension = markerInfo.marker;
                        if (marker.__targetLatLng) {
                            marker._latlng = marker.__targetLatLng;
                            marker.update();
                        }
                        marker.show();
                        var duration = this.getTransitionDuration(marker._icon);
                        var transitionPromise = new Promise((done: () => void) => {
                            setTimeout(done, duration);
                        });
                        transitionPromises.push(transitionPromise);
                    });
                    _.each(markersToUpdate, (markerInfo: {marker: L.Marker & MarkerExtension, updateFn: (marker: L.Marker & MarkerExtension) => void}) => {
                        var marker: L.Marker & MarkerExtension = markerInfo.marker;
                        if (!marker._icon) {
                            return;
                        }
                        markerInfo.updateFn((marker));
                        this._onMarkerUpdated(marker);
                        var duration = this.getTransitionDuration(marker._icon);
                        var transitionPromise = new Promise((done: () => void) => {
                            setTimeout(done, duration);
                        });
                        transitionPromises.push(transitionPromise);
                    });
                    Promise.all(transitionPromises)
                        .then(() => {
                            this._map._mapPane.className = this._map._mapPane.className.replace(' leaflet-cluster-anim', '');
                            resolve();
                        })
                } catch(err) {
                    reject(err);
                }
            }, 1);
        })
    }

    enableRefreshing(enable: boolean = true) {
        var old = this._refreshingEnabled;
        this._refreshingEnabled = enable;
        if(enable && !old) {
            //setTimeout(this._refresh.bind(this), 0);
        }
    }

    private _onMarkerAdded(marker: L.Marker, parent: L.Marker) {
        marker.on('click', this.nodeClickCallback);
    }

    private _onMarkerRemoved(marker: L.Marker, parent: L.Marker) {
        marker.off('click', this.nodeClickCallback);
    }

    private _onMarkerUpdated(marker: L.Marker) {

    }

    private _onViewReset() {
        this.refresh();
    }
    private _onZoomStart() {
        this._hideSpiderfy();
    }
    private _onMoveStart() {

    }
    private _onZoomEnd() {
        this.refresh();
    }
    private _onMoveEnd() {
        this.refresh();
    }




    /*addLayer: function(layer) {
     throw new Error("Adding layers is not implemented by L.RemoteClusteredMarkersGroup");
     },

     removeLayer: function(layer) {
     throw new Error("Removing layers is not implemented by L.RemoteClusteredMarkersGroup");
     },*/


    refresh() {
        if(!this._debouncedLoadData) {
            this._debouncedLoadData = _.debounce(this.throttlePromise(this._refresh.bind(this), 0), 100);
        }
        return this._debouncedLoadData();
    }

    _refresh() {
        if(!this._refreshingEnabled) {
            return Promise.resolve(null);
        }
        if(this._map) {
            var refreshFn = (resolve: () => void, reject: (err) => void) => {
                this.fire('refreshrequired', {
                    bounds: this._map.getBounds(),
                    zoom: this._map.getZoom(),
                    done: resolve,
                    error: reject
                })
            }
            return new Promise(refreshFn);
        } else {
            return Promise.resolve(null);
        }
    }

    private _onNodeClick(e: {target: L.Marker}) {
        var marker = e.target;

        if(marker instanceof L.ClusterMarker) {
            if(!marker.options.cluster) {
                return;
            }
            var bounds = marker.options.cluster.bounds;
            if (marker.options.cluster.hasChildren && bounds) {
                var zoom = this._map.getBoundsZoom(bounds);
                var currentZoom = this._map.getZoom();
                var maxZoom = this._map.getMaxZoom();
                if(zoom > currentZoom) {
                    this._map.fitBounds(bounds);
                } else if (currentZoom < maxZoom) {
                    this._map.zoomIn();
                } else {
                    this._hideSpiderfy(marker);
                    marker.toggleSpiderfy();
                }
            } else {
                this._hideSpiderfy(marker);
                marker.toggleSpiderfy();
            }
        }
    }

    private _hideSpiderfy(skipMarker?: L.Marker) {
        this.eachLayer((otherMarker: L.ClusterMarker) => {
            if(typeof otherMarker.hideSpiderfy === "function" && otherMarker != skipMarker) {
                otherMarker.hideSpiderfy();
            }
        });
    }

    private throttlePromise(callback, interval) {
        var currentPromise, pendingPromise;


        function timeout() {
            return new Promise(function(resolve) {
                if (interval != null) {
                    setTimeout(resolve, interval);
                } else {
                    resolve();
                }
            });
        }

        function onAfterCallback() {
            currentPromise = pendingPromise;
            pendingPromise = null;
        }

        function doCallback() {
            var timeoutPromise = timeout();
            var callbackPromise = callback().then(onAfterCallback).catch(onAfterCallback);
            return Promise.all([callbackPromise, timeoutPromise]);
        }

        return function() {
            if(!pendingPromise) {
                if(!currentPromise) {
                    currentPromise = doCallback();
                    return currentPromise;
                } else {
                    pendingPromise = currentPromise.then(doCallback).catch(doCallback);
                    return pendingPromise;
                }
            } else {
                return pendingPromise;
            }
        }
    }

    private getTransitionDuration(element: HTMLElement) {
        function parseTime(time) {
            var parsedTime = parseFloat(time);
            if(time.indexOf('ms') < 0 && time.indexOf('s') >= 0) {
                parsedTime *= 1000;
            }
            return parsedTime;
        }

        var transitionDurationsStr = (window.getComputedStyle(element)['transition-duration'] || '').split(',');
        var transitionDelaysStr = (window.getComputedStyle(element)['transition-delay'] || '').split(',');

        var durations = _.map(_.zip(transitionDurationsStr, transitionDelaysStr), (durationAndDelay: [string, string]) => {
            var duration = parseTime(durationAndDelay[0]);
            var delay = parseTime(durationAndDelay[1]);
            return duration + delay;
        });
        return _.max(durations);
    }
}

L.RemoteClusteredMarkersGroup = L.FeatureGroup.extend(RemoteClusteredMarkersGroupClass.prototype);

L.remoteClusteredMarkersGroup = function (options) {
    return new L.RemoteClusteredMarkersGroup(options);
};