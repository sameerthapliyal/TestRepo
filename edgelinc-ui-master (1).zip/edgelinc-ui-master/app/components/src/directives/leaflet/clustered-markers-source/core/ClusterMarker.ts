///<reference path="../../../../../../../typings/browser.d.ts"/>
///<reference path="definitions/index.d.ts"/>

import "leaflet";
import "./MarkerExtensions";

const DefaultSpiderLegPolylineOptions = {};

interface SpiderfyMarkerExtension {
    _latlng?: L.LatLng;
    _icon?: HTMLElement;
    __targetlatlng?: L.LatLng;
}
interface SpiderLegExtension {
    _latlngs?: L.LatLng[];
    _path?: SVGPathElement;
    __targetOpacity?: number;
}

class ClusterMarkerClass extends L.Marker {
    _icon: HTMLElement;
    _spiderfyLayer: L.LayerGroup<L.ILayer>;
    _map: L.Map;
    _latlng: L.LatLng;
    options: L.ClusterMarkerOptions;
    _spiderfyNodesPromise: Promise<L.Marker[]>;

    initialize(latlng: L.LatLng, options: L.ClusterMarkerOptions): void {
        L.Marker.prototype.initialize.call(this, latlng, options);
    }

    onRemove(map: L.Map): this {
        if(this._spiderfyLayer) {
            this._map.removeLayer(this._spiderfyLayer);
            this._spiderfyLayer = null;
        }
        L.Marker.prototype.onRemove.call(this, map);
        return this;
    }

    toggleSpiderfy(): void {
        if(this._spiderfyLayer) {
            this.hideSpiderfy();
        } else {
            this.showSpiderfy();
        }
    }

    showSpiderfy(): void {
        if (this._spiderfyLayer) {
            return;
        }

        this._spiderfyLayer = L.layerGroup([]).addTo(this._map);
        if (!this._spiderfyNodesPromise) {
            var levelsCount = this._getLevelsCount();
            var maxNodes = 6 * (levelsCount + 1) * levelsCount / 2; // 6 + 12 + 18 + 24 ...

            var spiderfyFn = (resolve: (nodes: L.Marker[]) => void, error: (err: any) => void) => {
                var args = {
                    capacity: maxNodes,
                    spiderfyOptions: this.options.spiderfy,
                    done: resolve,
                    error: error
                };
                this.fire("spiderfy", args);
            };

            this._spiderfyNodesPromise = new Promise(spiderfyFn);
        }

        this._spiderfyNodesPromise
            .then((nodes: (L.Marker & SpiderfyMarkerExtension)[]) => {
                this._spiderfyNodesPromise = null;
                this._renderSpiderfy(nodes);
            })
    }

    hideSpiderfy(): void {
        if (!this._spiderfyLayer) {
            return;
        }

        this._map.removeLayer(this._spiderfyLayer);
        this._spiderfyLayer = null;
        this.options.opacity = 1;
        this.show();
    }

    _renderSpiderfy(markers: (L.Marker & SpiderfyMarkerExtension)[]): void {
        var spiderfyLayer = this._spiderfyLayer;
        if (!spiderfyLayer) {
            return;
        }
        if (!markers || !markers.length) {
            return;
        }

        var markerSize = this._getMarkerSize();
        var clusterLatLng = this._latlng;
        var clusterPos = this._map.latLngToLayerPoint(clusterLatLng);
        spiderfyLayer.clearLayers();

        var startIndex = 0;

        var markersToDisplay: (L.Marker & SpiderfyMarkerExtension)[] = [];
        var spiderLegsToDisplay: (L.Polyline & SpiderLegExtension)[] = [];

        var levelsCount = this._getLevelsCount();
        for (var level = 1; level <= levelsCount; level++) {
            var levelCapacity = level * 6; // 6, 12, 18, ...
            var radius = markerSize.multiplyBy(level);

            var nodesCount = Math.min(levelCapacity, markers.length - startIndex);

            for (var i = 0; i < nodesCount; i++) {
                var spiderfyMarker: L.Marker & SpiderfyMarkerExtension = markers[i + startIndex];

                var angle = i * 2 * Math.PI / nodesCount;
                var offsetX = Math.cos(angle) * radius.x;
                var offsetY = Math.sin(angle) * radius.y;
                var offset = L.point(offsetX, offsetY);
                var pos = clusterPos.add(offset);
                var latlng = this._map.layerPointToLatLng(pos);

                var spiderLegPolylineOptions: L.PolylineOptions = _.extend({}, DefaultSpiderLegPolylineOptions, this._getSpiderLegPolylineOptions());
                spiderLegPolylineOptions.className = (spiderLegPolylineOptions.className || '') + ' leaflet-cluster-spider-leg';
                var spiderLeg: L.Polyline & SpiderLegExtension = L.polyline([clusterLatLng, latlng], spiderLegPolylineOptions);

                spiderfyLayer.addLayer(spiderLeg);

                if(L.Path.SVG) {
                    var spiderLegPath = spiderLeg._path;
                    var spiderLegLength = spiderLegPath.getTotalLength() + 0.1; // Need a small extra length to avoid remaining dot in Firefox.
                    spiderLegPath.style.strokeDasharray = spiderLegLength.toString(); // Just 1 length is enough, it will be duplicated.
                    spiderLegPath.style.strokeDashoffset = spiderLegLength.toString();
                    spiderLegPath.style.transition = 'none';
                    spiderLeg.__targetOpacity = spiderLegPolylineOptions.opacity;
                    spiderLeg.setStyle({opacity: 0});
                }


                spiderfyMarker._latlng = clusterLatLng;
                spiderfyMarker.__targetlatlng = latlng;
                spiderfyMarker.hide();
                spiderfyLayer.addLayer(spiderfyMarker);

                markersToDisplay.push(spiderfyMarker);
                spiderLegsToDisplay.push(spiderLeg);


            }
            startIndex += nodesCount;
            if (startIndex >= markers.length) {
                break;
            }
        }


        this._map._mapPane.className = this._map._mapPane.className.replace(' leaflet-cluster-anim', '');
        this._map._mapPane.className += ' leaflet-cluster-anim';
        this._forceLayout();
        //setTimeout(() => {
            var transitionPromises: Promise<any>[] = [
                this.getTransitionPromise(this._icon)
            ];

            _.each(markersToDisplay, (marker: L.Marker & SpiderfyMarkerExtension) => {
                marker._latlng = marker.__targetlatlng;
                marker.update();
                spiderfyMarker.show();
                transitionPromises.push(this.getTransitionPromise(marker._icon));
            });
            if(L.Path.SVG) {
                _.each(spiderLegsToDisplay, (spiderLeg: L.Polyline & SpiderLegExtension) => {
                    var spiderLegPath = spiderLeg._path;
                    spiderLegPath.style.transition = null;
                    spiderLegPath.style.strokeDashoffset = "0";
                    spiderLeg.setStyle({opacity: spiderLeg.__targetOpacity});

                    transitionPromises.push(this.getTransitionPromise(spiderLeg._path));
                });
            }
            this.hide(0.5);
            this.options.opacity = 0.5;

            Promise.all(transitionPromises)
                .then(() => {
                    this._map._mapPane.className = this._map._mapPane.className.replace(' leaflet-cluster-anim', '');
                })
        //},1);


    }

    _getLevelsCount(): number {
        var levels = this.options.spiderfy ? this.options.spiderfy.levels : null;
        if(levels == null) {
            levels = 2;
        }
        return levels;
    }

    _getMarkerSize(): L.Point {
        var result: [number, number] = this.options.spiderfy ? this.options.spiderfy.markerSize : null;
        if(result == null) {
            result = [40,40];
        }
        return L.point(result);
    }

    _getSpiderLegPolylineOptions(): L.PolylineOptions {
        return this.options.spiderfy ? this.options.spiderfy.spiderLegPolylineOptions : {};
    }


    private getTransitionPromise(element: Element) {
        var duration = this.getTransitionDuration(element);
        return new Promise((done: () => void) => {
            setTimeout(done, duration);
        });
    }

    private getTransitionDuration(element: Element) {
        function parseTime(time) {
            var parsedTime = parseFloat(time);
            if(time.indexOf('ms') < 0 && time.indexOf('s') >= 0) {
                parsedTime *= 1000;
            }
            return parsedTime;
        }

        if(element == null) {
            return 0;
        }

        var transitionDurationsStr = (window.getComputedStyle(element)['transition-duration'] || '').split(',');
        var transitionDelaysStr = (window.getComputedStyle(element)['transition-delay'] || '').split(',');

        var durations = _.map(_.zip(transitionDurationsStr, transitionDelaysStr), (durationAndDelay: [string, string]) => {
            var duration = parseTime(durationAndDelay[0]);
            var delay = parseTime(durationAndDelay[1]);
            return duration + delay;
        });
        return _.max(durations);
    }

    private _forceLayout () {
        //In my testing this works, infact offsetWidth of any element seems to work.
        //Could loop all this._layers and do this for each _icon if it stops working

        L.Util.falseFn(document.body.offsetWidth);
    }
}

L.ClusterMarker = (<any>L.Marker).extend(ClusterMarkerClass.prototype);

L.clusterMarker = function(latlng, options) {
    return new L.ClusterMarker(latlng, options);
};