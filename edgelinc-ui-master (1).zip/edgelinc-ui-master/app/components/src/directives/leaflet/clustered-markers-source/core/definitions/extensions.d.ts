
declare namespace L {
    namespace Util {
        export function falseFn(...args: any[]): boolean;
    }

    namespace DomUtil {
        export var TRANSITION_END: string;
    }

    namespace Browser {
        export var any3d: any;
    }

    function point(coords: [number, number]): Point;

    export interface Map {
        _mapPane: HTMLElement;
    }

    export interface Marker {
        options: MarkerOptions;
        bindLabel(message: string, options: any): void;
        cloneIcon(deep: boolean): HTMLElement;
        getIconPosition(map: L.Map): L.Point;
        hide(opacity?: number): void;
        show(): void;
    }
}