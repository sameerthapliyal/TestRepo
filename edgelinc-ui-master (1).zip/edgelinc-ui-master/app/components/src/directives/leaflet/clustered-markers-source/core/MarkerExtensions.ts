///<reference path="../../../../../../../typings/browser.d.ts"/>
///<reference path="definitions/index.d.ts"/>


import "leaflet";

(<any>L.Marker).include({
    cloneIcon: function (deep: boolean) {
        return this._icon ? this._icon.cloneNode(deep) : null;
    },
    getIconPosition: function (map: L.Map) {
        map = map || this._map;
        if(this._icon) {
            return L.DomUtil.getPosition(this._icon);
        } else if(map) {
            return map.latLngToLayerPoint(this._latlng);
        } else {
            return null;
        }
    },
    hide: function(opacity: number = 0){
        if(this._icon) {
            L.DomUtil.setOpacity(this._icon, opacity);
        }
    },
    show: function(){
        if(this._icon) {
            L.DomUtil.setOpacity(this._icon, this.options.opacity);
        }
    }

});