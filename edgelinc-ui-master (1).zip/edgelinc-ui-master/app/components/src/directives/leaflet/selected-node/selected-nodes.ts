///<reference path="../../../../../../typings/browser.d.ts"/>

interface ISelectedNodesExpressionDirectiveAttributes extends ng.IAttributes {
    selectedNode: string;
    selectedNodeKey: string;
    selectionOptions: string;
}

function SelectedNodeDirective($parse: ng.IParseService) {

    function init(scope: ng.IScope, map, selectedNodeGetter: () => any, selectedNodeKeyGetter: (args: {marker: L.Marker}) => any, options: any) {
        function onLayerAdded(args: {layer: L.ILayer}) {
            var layer = args.layer;
            if(layer instanceof L.Marker) {
                var marker = <any>layer;
                var markerKey = selectedNodeKeyGetter({marker: marker});
                var selectedKey = selectedNodeGetter();
                var icon = angular.element(marker._icon);
                var cssClass = options.cssClass || "selected";
                if(selectedKey && markerKey == selectedKey) {
                    icon.addClass(cssClass);
                }
            }
        }

        function changeSelection(layer, selectedNode) {
            if(layer instanceof L.LayerGroup) {
                layer.eachLayer(childLayer => {
                    changeSelection(childLayer, selectedNode);
                });
            }
            if(layer instanceof L.Marker) {
                var marker = <any>layer;
                var markerKey = selectedNodeKeyGetter({marker: marker});
                var selectedKey = selectedNodeGetter();
                var icon = angular.element(marker._icon);
                var cssClass = options.cssClass || "selected";
                if(selectedKey && markerKey == selectedKey) {
                    icon.addClass(cssClass);
                } else {
                    icon.removeClass(cssClass);
                }
            }
        }

        function onSelectedNodeChanged(selectedNode) {
            map.eachLayer(layer => {
                changeSelection(layer, selectedNode);
            });
        }

        map.on("layeradd", onLayerAdded);

        scope.$watch(selectedNodeGetter, onSelectedNodeChanged);
    }

    return {
        restrict: "A",
        require: ["leaflet"],
        link: (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: ISelectedNodesExpressionDirectiveAttributes, ctrls: any) => {
            var leafletCtrl = ctrls[0];
            var selectedNodeGetter = $parse(attrs.selectedNode).bind(this, scope);

            var selectedNodeKeyGetter = _.identity;
            if(attrs.selectedNodeKey) {
                selectedNodeKeyGetter = $parse(attrs.selectedNodeKey).bind(this, scope);
            }
            var options = {};
            if(attrs.selectionOptions) {
                options = $parse(attrs.selectionOptions)(scope) || {};
            }

            leafletCtrl.getMap()
                .then(map => {
                    init(scope, map, selectedNodeGetter, selectedNodeKeyGetter, options);
                })

        }
    }
}

function SelectedNodeKeyDirective() {
    return {
        restrict: "A",
        link: () => {}
    }
}

function SelectionOptionsDirective() {
    return {
        restrict: "A",
        link: () => {}
    }
}

export default angular.module("directives.leaflet.selectedNode", [])
    .directive("selectedNode", SelectedNodeDirective)
    .directive("selectedNodeKey", SelectedNodeKeyDirective)
    .directive("selectionOptions", SelectionOptionsDirective);