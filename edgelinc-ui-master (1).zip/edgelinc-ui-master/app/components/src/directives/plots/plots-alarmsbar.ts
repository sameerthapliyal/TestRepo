///<reference path="../../../../../typings/browser.d.ts"/>

import select = d3.select;
interface Dimmensions {
	width:number;
	height: number;
}
class AlarmsBarCtrl {
	private scope;
	private ele;
	private attrs;
	private oData: any;
	private dimensionsCache: { [elemKey:string]:Dimmensions; };


	constructor ($scope, ele, attrs)	{
		this.scope = $scope;
		this.ele = ele;
		this.attrs = attrs;
		this.oData = [
			{value: 0, name: 'Emergency'},
			{value: 0, name: 'Fatal'},
			{value: 0, name: 'Critical'},
			{value: 0, name: 'Error'},
			{value: 0, name: 'Warning'},
			{value: 0, name: 'Informational'},
		];
		this.dimensionsCache = this.dimensionsCache || {};
		this.feedData(null)
	}

	private mapColor(cls: string)
	{
		switch(cls) {
			case 'inactive':
				return '#757e82';
			case 'active':
				return '#478907';
		}
		return 'white';
	}

	public feedData(_data) {
		var data = this.oData;
		if(_data)
		{
			data = _data;
		}
		var t = this;
		var marginB = 60;
		var marginL = 30;
		this.ele.selectAll('g').remove();
		this.ele.attr('transform','translate('+marginL+',20)');
		var w = this.scope.maxW - 20 - marginL;
		var h = this.scope.maxH - 20 - marginB;
		var xValue = function(d) { return d.name; }, // data -> value
			xScale = d3.scale.ordinal().rangeRoundBands([0, w], .1), // value -> display
			xMap = function(d) { return xScale(xValue(d)); }, // data -> display
			xAxis = d3.svg.axis().scale(xScale).orient('bottom');

		var yValue = function(d) { return d.value; }, // data -> value
			yScale = d3.scale.linear().range([h, 0]) // value -> display
			yScale.ticks(4);
		var	yMap = function(d) { return yScale(yValue(d)); }, // data -> display
			yAxis = d3.svg.axis()
				.ticks(4)
				.scale(yScale)
				.orient('left')
				.tickSize(-w)

		xScale.domain(data.map(xValue));
		yScale.domain([0, d3.max(data, yValue)+10]);

		this.ele.append('g')
			.attr('class', 'y axis')
			.call(yAxis)

		this.ele.append('g')
			.attr('class', 'x axis')
			.attr('transform', 'translate(0,' + h + ')')
			.call(xAxis)
		.selectAll('text')
			.classed('smalltick', true)
			.attr("transform", function(d){
				var height = this.getBoundingClientRect().height;
				var width = this.getBoundingClientRect().width;
				//console.log(d + " : width = " + width + " height = " + height);
				if(height == 0) {
					if(t.dimensionsCache[d]) {
						height = t.dimensionsCache[d].height;
					}
				} else {
					if(!t.dimensionsCache[d])
						t.dimensionsCache[d] = {width:width, height:height};
					else {
						t.dimensionsCache[d].width = width;
						t.dimensionsCache[d].height = height;
					}
				}
				return "translate(" + height * -1 + "," + height + ")rotate(-30)";
			})



		var bars = this.ele.selectAll('.bar')
			.data(data);
		bars.enter().append('g')
			.append('rect')
				.attr('class','bar')
				.attr('x',xMap)
				.attr('width',xScale.rangeBand)
				.attr('y', yMap)
				.attr('height', function(d) { return h-yMap(d); })


	}
}

export default angular.module('directives.Plots.alarmsbar', [])
	.directive('plotBarAlarms', function () {
		return {
			scope: {
				data: '=plotData',
				maxW: '@maxWidth',
				maxH: '@maxHeight',
				spinnerIndicator: "=spinnerIndicator"
			},
			template: '<div style="position:relative"><div class="plotarea"></div><div ng-show="datawait || spinnerIndicator" class="plotoverlays"><i class="fa fa-spin fa-spinner fa-pulse"></i></div><div ng-show="datafail" class="plotoverlays"><i class="fa fa-exclamation-circle" style="color: red"></i></div></div>',
			link: function(scope:any, ele, attrs) {
				scope.datawait = true;
				var de = d3.select(ele[0]);
				var dd = de.select('div.plotarea')
					.style({
						display: 'flex',
						'align-items': 'center',
						'justify-content':'left'
						})
				var dd2 = dd.append('svg')
					.attr({
						'viewBox':'0 0 '+scope.maxW+' '+scope.maxH,
						'preserveAspectRatio':'none'
					})
					.style({
						'max-width':scope.maxW+'px',
						'max-height':scope.maxH+'px',
						'flex':'1 1 100%'
					})
				.append('g')
					.attr('transform','translate(20,20)');
				scope.alarmsBarCtrl = new AlarmsBarCtrl(scope, dd2, attrs);
				scope.$watch('data',function() {
					//console.time("alarmsBarCtrl.feedData");
					scope.datawait = true;
					scope.alarmsBarCtrl.feedData(scope.data);
					scope.datawait = false;
					//console.timeEnd("alarmsBarCtrl.feedData");
				});
			}
		}
	});
