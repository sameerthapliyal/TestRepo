///<reference path="../../../../../typings/browser.d.ts"/>
import DeviceServiceModule, { DeviceService } from "../../../../components/src/services/DeviceService";
import * as __ from "lodash";

class Statistics {
  private width = 350;
  private height = 350;
  private marginB = 80;
  private marginL = 100;

  private oData: any;
  private tempData: any;
  private tempEvd: any;
  private Data: any;
  private clip: any;
  private clip_context: any;
  private formatX: any = d3.time.format('%x %I:%M:%S %p');

  private xValue;
  private yValue;

  private x;
  private x2;
  private y;
  private y2;

  private xScaleValue;
  private yScaleValue;
  private xScaleValue2;
  private yScaleValue2;

  private lineGen;
  private lineGen2;
  private areaGen;
  private areaGen2;

  private xAxis;
  private xAxis2;
  private yAxis;
  private yAxis2;

  private xAxisG;
  private xAxisG2
  private yAxisG;
  private yAxisG2;

  private focus;
  private context;
  private plotClip;
  private contextClip;
  private brush;
  private gradient;
  private defs;

  private data_c;
  private data_f;
  private statInfo;
  private statEnums;
  private enumMapper;
  private pause = false;
  private mode = 'linear';
  private status: any = [];

  constructor(private $scope, private ele, private attrs) {

    this.oData = {
      data: [
        { value: 0, timestamp: '0' }
      ]
    };

    this.defs = ele.append('defs');

    this.clip = this.defs.append('svg:clipPath')
      .attr('id', 'clip_' + $scope.asdid + '_' + $scope.statId) //bypass chrome bug
      .append('svg:rect')
      .attr('id', 'clip-rect_' + $scope.asdid + '_' + $scope.statId)
      .attr('x', '0')
      .attr('y', '-6');

    this.clip_context = this.defs.append('svg:clipPath')
      .attr('id', 'clip_' + $scope.asdid + '_' + $scope.statId + '_c') //bypass chrome bug
      .append('svg:rect')
      .attr('id', 'clip-rect_' + $scope.asdid + '_' + $scope.statId + '_c')
      .attr('x', '0')
      .attr('y', '-6');

    this.gradient = this.defs.append('svg:linearGradient')
      .attr('id', 'gradient' + $scope.statId)
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');

    this.gradient.append('stop').attr({
      'class': 'begin',
      'offset': '0%',
      'stop-color': 'steelblue',
      'stop-opacity': .1
    })

    this.gradient.append('stop').attr({
      'class': 'end',
      'offset': '100%',
      'stop-color': 'steelblue',
      'stop-opacity': .1
    })

    this.xValue = (d) => { return d.timestamp; };
    this.yValue = (d) => { return d.value; };
    this.xScaleValue = (d) => { return this.x(d.timestamp); };
    this.yScaleValue = (d) => { return this.y(this.mode === 'enum' ? this.enumMapper[d.value] : d.value); };
    this.xScaleValue2 = (d) => { return this.x2(d.timestamp); };
    this.yScaleValue2 = (d) => { return this.y2(this.mode === 'enum' ? this.enumMapper[d.value] : d.value);};

    // line generators:
    this.lineGen = (<any>d3).svg.line()
      .interpolate('linear')
      .defined(d => { return d.value !== null; })
      .x(this.xScaleValue)
      .y(this.yScaleValue)


    //
    // this.i = this.pointInterval - d.timestamp;
    // this.pointInterval = d.timestamp;
    // console.log(this.i)
    // if(Math.abs(this.i) > 120000) {
    //   console.log('false')
    //   return false;
    // }
    // else {
    //   console.log('true')
    //   return d.value;
    // }


    this.lineGen2 = (<any>d3).svg.line()
      .interpolate('linear')
      .defined(d => { return d.value !== null; })
      .x(this.xScaleValue2)
      .y(this.yScaleValue2);

    // area generators:
    // this.areaGen = d3.svg.area()
    //     .interpolate('linear')
    //     .x(this.xScaleValue)
    //     .y1(this.yScaleValue);
    //
    // this.areaGen2 = d3.svg.area()
    //     .interpolate('linear')
    //     .x(this.xScaleValue2)
    //     .y1(this.yScaleValue2);

    // scales:
    this.x = d3.time.scale();
    this.x2 = d3.time.scale();

    // axes:
    this.xAxis = d3.svg.axis()
      .scale(this.x)
      .orient('bottom');

    this.xAxis2 = d3.svg.axis()
      .scale(this.x2)
      .orient('bottom');

    this.yAxis = (<any>d3).svg.axis()
      .orient('left');

    this.yAxis2 = (<any>d3).svg.axis()
      .orient('left');

    this.brush = d3.svg.brush()
      .x(this.x2)
      .on('brush', (d) => {
        if (!this.brush.empty()) this.$scope.datawait_brush = true;
        this.$scope.$applyAsync();
      })
      .on('brushend', (d) => {
        var extent = this.brush.extent();
        if (!this.brush.empty()) {
          this.pause = true;
          this.$scope.brushFrom = this.formatX(new Date(extent[0]));
          this.$scope.brushTo = this.formatX(new Date(extent[1]));
          this.$scope.$emit('event:brushRequest', { statId: this.$scope.statId, brushFrom: extent[0], brushTo: extent[1] });
        }
        else {
          this.brushReset();
        }
      })
    this.convertToCsv();
  }

  private prepareYEnumAxis(statInfo: any, height: number, height2: number) {
    const uniqEnumeration = _.reduce(statInfo.Enumeration, (acc, val: any, key) => {
      acc[val] = acc[val] > key ? key : acc[val] || key;
      return acc;
    }, <any>{});
    let domain = _.sortBy(uniqEnumeration, val => +val);
    this.y.domain(domain);
    this.y2.domain(domain);
    this.yAxis
      .tickFormat((d) => {
        return statInfo.Enumeration[d];
      })
      .tickValues(domain);
    this.lineGen.interpolate('step-after');
    this.lineGen2.interpolate('step-after');

    this.enumMapper = _.reduce(statInfo.Enumeration, (acc, val: any, key) => {
      acc[key] = uniqEnumeration[val]
      return acc
    }, {})
    // this.gradient.select('stop.begin').attr('stop-opacity', .4);
  };

  private prepareYAxis(data: any, data_f: any, height: number, height2: number) {
    var extent = data ? d3.extent(data, function(d: any) { return d.value; }) : 0;
    var extentBrush = data ? d3.extent(data_f, function(d: any) { return d.value; }) : 0;
    var minv = extent[0];
    var maxv = extent[1];
    var bminv = extentBrush[0];
    var bmaxv = extentBrush[1];

    this.y.domain(this.computeRange(bminv, bmaxv)).nice();
    this.y2.domain(this.computeRange(minv, maxv)).nice()
    if ((<any>Number).isInteger(minv) && (<any>Number).isInteger(maxv)) {
      this.yAxis.tickFormat(d3.format('d'));
    }
  };

  private computeRange(min, max) {
    if (min != max) {
      if (min >= 0) {
        min = 0;
      }
      else if (min < 0 && max > 0) {
        var range = (<any>d3).max([Math.abs(min), max]);
        min = -range;
        max = range;
      }
      else {
        max = 0;
      }
    }
    else { //stats have only 1, constant value
      if (min == 0) {
        max = 1;
      } else if (min > 0) {
        min = 0;
      } else {
        max = 0;
      }
    }
    return [min, max]
  }
  private formatY(d) {
    switch (this.mode) {
      case 'enum':
        return this.statEnums[d];
      default:
        return d;
    }
  };

  private convertToCsv() {
    this.$scope.$on('statistics:exportToCsv', (event: any, eventArgs: any) => {
      var array = this.data_f;
      var str = '';
      str += 'timestamp' + ',' + 'value' + '\r\n';
      for (var i = 0; i < array.length; i++) {
          if (!_.isNumber(array[i].value) || !array[i].timestamp) continue;
          var line = '';
          line += array[i].timestamp + ',' + array[i].value;
          str += line + '\r\n';
      }
      var blob = new Blob([str], {
          type: 'text/csv;charset=utf-8'
      });
      saveAs(blob, eventArgs || 'export.csv');
    });
  };

  private feedData(_data) {
    var mode = 'line';

    if (_data) {
      this.oData = _data;
      if (!_data.evd.hasOwnProperty('brush')) {
        this.tempData = this.oData.res.data;
        this.tempEvd = this.oData.evd
      }

      if (_data.evd.hasOwnProperty('brush')) {
        var temp = this.data_c;
        this.Data.res = _data.res;
        this.data_c = temp;
        this.data_f = this.Data.res.data;
        this.$scope.datawait_brush = false;
      }

      if (!this.pause) {
        this.Data = _data;
        if (!this.statInfo) this.statInfo = this.Data.res.statInfo;
        this.data_c = this.Data.res.data;
        this.data_f = this.Data.res.data;
        this.$scope.datawait_brush = false;
      }

      var statEnum = this.statInfo.details.Enumeration;
      for (var key in statEnum) {
        if (statEnum.hasOwnProperty(key) && !isNaN(parseInt(key))) {
          this.status.push(parseInt(key));
        }
      }

      if (this.statInfo.details.ValueType === 'Enum') {
        var filteredData_c = this.data_c.filter((cur, i, arr) => { return (this.status.indexOf(cur.value) >= 0) || _.isNull(cur.value) })
        var filteredData_f = this.data_f.filter((cur, i, arr) => { return (this.status.indexOf(cur.value) >= 0) || _.isNull(cur.value) })
        // var badData = this.data_c.filter((cur, i, arr) => { return (this.status.indexOf(cur.value) < 0) })
        var badData = this.data_f.filter((cur, i, arr) => { return (this.status.indexOf(cur.value) < 0) && !_.isNull(cur.value) })
        this.data_c = filteredData_c;
        this.data_f = filteredData_f;
        this.$scope.badData = badData;
      }
    }


    var width = this.$scope.maxWidth - this.marginL / 2;
    var height = this.$scope.maxHeight * 3 / 4 - this.marginB / 2 - 20;
    var height2 = this.$scope.maxHeight * 1 / 4 - this.marginB / 2;
    this.x.range([0, width]);
    this.x2.range([0, width]);

    var customTicks = d3.time.format.multi([
      [".%L", function(d) { return d.getMilliseconds(); }],
      [":%S", function(d) { return d.getSeconds(); }],
      ["%I:%M", function(d) { return d.getMinutes(); }],
      ["%I %p", function(d) { return d.getHours(); }],
      ["%a %d", function(d) { return d.getDay() && d.getDate() != 1; }],
      ["%a %d", function(d) { return d.getDate() != 1; }],
      ["%b %d", function(d) { return d.getMonth(); }],
      ["%Y", function() { return true; }]
    ]);

    this.xAxis.tickSize(-height).outerTickSize(-height).tickFormat(customTicks);
    this.xAxis2.tickSize(-4).outerTickSize(-height2).tickFormat(customTicks);
    this.yAxis.tickSize(-width).outerTickSize(-width);
    this.yAxis2.tickValues([]).tickSize(-width).outerTickSize(-width);

    this.clip
      .attr('width', width)
      .attr('height', height + 12);
    this.clip_context
      .attr('width', width)
      .attr('height', height2 + 12);

    var statInfoDetails;
    if (this.statInfo) {
      statInfoDetails = this.statInfo.details;
    }

    if (statInfoDetails && statInfoDetails.ValueType) {
      switch (statInfoDetails.ValueType) {
        case 'Enum':
          if (!statInfoDetails.Enumeration) {
            console.warn('Enum type statistics with no enumerator defined');
          }
          else {
            this.statEnums = statInfoDetails.Enumeration;
            this.mode = 'enum';
          }
          break;
      }
    }

    switch (this.mode) {
      case 'enum':
        if (!this.y) {
          this.y = (<any>d3).scale.ordinal().rangePoints([height, 0]);
          this.y2 = (<any>d3).scale.ordinal().rangePoints([height2, 0]);
          this.prepareYEnumAxis(statInfoDetails, height, height2);
        }
        break;

      default:
        this.y = (<any>d3).scale.linear().range([height, 0]);
        this.y2 = (<any>d3).scale.linear().range([height2, 0]);
        this.prepareYAxis(this.data_c, this.data_f, height, height2);
        break;
    }

    this.yAxis.scale(this.y)
    this.yAxis2.scale(this.y2)
    if (_data) {
      if (!this.brush.empty()) {
        this.x2.domain([this.Data.evd.tsFrom, this.Data.evd.tsTo]);// - context refresh
        this.x.domain(this.brush.empty() ? this.x2.domain() : this.brush.extent());
      }
      else {
        this.x2.domain([this.oData.evd.tsFrom, this.oData.evd.tsTo])
        this.x.domain(this.x2.domain())
      }
    }
    else {
      if (this.oData.evd) {
        this.x2.domain([this.oData.evd.tsFrom, this.oData.evd.tsTo])
        this.x.domain(this.x2.domain())
      }
    }

    // focus create:
    if (!this.focus) {
      this.focus = this.ele.append('g')
        .attr('class', 'focus')
        .attr('transform', 'translate(' + (this.marginL / 2 + 10) + ', 10)');

      this.plotClip = this.focus.append('g')
        .attr('class', 'clip-path')
        .attr('clip-path', 'url(#clip_' + this.$scope.asdid + '_' + this.$scope.statId + ')');

      // this.plotClip.append('path')
      //     .datum([])
      //     .attr('class', 'area fill')
      //     .attr('d', this.areaGen)
      //     // .style('fill', 'url("#gradient' + this.$scope.statId + '")');
      //     .style('fill', 'transparent');
      //
      this.plotClip.append('path')
        .datum([])
        .attr('class', 'area line')
        .attr('d', this.lineGen);
    }

    if (this.xAxisG) {
      this.xAxisG.call(this.xAxis);
      this.xAxisG.selectAll('text')
        .classed('smalltick', true)
        .style('text-anchor', 'end')
        .attr('transform', function(d) {
          return 'translate(0,' + this.getBBox().height / 2 + '), rotate(-30)';
        });
    }
    else {
      this.xAxisG = this.focus.insert('g', 'g.clip-path')
        .attr('class', 'x axis')
        .attr('transform', 'translate(0,' + height + ')')
        .call(this.xAxis);
      this.xAxisG.selectAll('text')
        .classed('smalltick', true)
        .style('text-anchor', 'end')
        .attr('transform', function(d) {
          return 'translate(0,' + this.getBBox().height / 2 + ')rotate(-30)';
        });
    }

    if (this.yAxisG) {
      this.yAxisG.call(this.yAxis);
      this.yAxisG.selectAll('text')
        .call(this.labelWrap)
    }
    else {
      this.yAxisG = this.focus.insert('g', 'g.clip-path')
        .attr('class', 'y axis')
        .call(this.yAxis);
      this.yAxisG.selectAll('text')
        .call(this.labelWrap)
    }

    // context create:
    if (!this.context) {
      this.context = this.ele.append('g')
        .attr('class', 'context')
        .attr('transform', 'translate(' + (this.marginL / 2 + 10) + ',' + (height + this.marginB / 2 + 30) + ')');

      this.contextClip = this.context.append('g')
        .attr('class', 'clip-path')
        .attr('clip-path', 'url(#clip_' + this.$scope.asdid + '_' + this.$scope.statId + '_c)');

      // this.contextClip.append('path')
      //     .datum([])
      //     .attr('class', 'area fill')
      //     .attr('d', this.areaGen2)
      //     // .style('fill', 'url("#gradient' + this.$scope.statId + '")');
      //     .style('fill', 'transparent');
      //
      this.contextClip.append('path')
        .datum([])
        .attr('class', 'area line')
        .attr('d', this.lineGen2)
        .attr('clip-path', 'url(#clip_' + this.$scope.asdid + '_' + this.$scope.statId + '_c)');

      var gBrush = this.context.append('g')
        .attr({
          'class': 'x brush'
        })
        .call(this.brush)

      gBrush.selectAll('rect')
        .attr({
          'y': -2,
          'height': height2 + 4
        })

      var handle = gBrush.selectAll("g.resize")
        .append('circle')
        .attr({
          'class': 'handle',
          'r': 6,
          'cx': (d, i) => { return i == 0 ? -1 : 1 },
          'cy': (height2 - 2) / 2,
        })
    }


    if (this.xAxisG2) {
      this.xAxisG2.call(this.xAxis2);
      this.xAxisG2.selectAll('text')
        .classed('smalltick', true)
        .style('text-anchor', 'end')
        .attr('transform', function(d) {
          return 'translate(0,' + this.getBBox().height / 2 + ')rotate(-30)';
        });
    }

    else {
      this.xAxisG2 = this.context.insert('g', '.clip-path')
        .attr('class', 'x axis')
        .attr('transform', 'translate(0,' + height2 + ')')
        .call(this.xAxis2)

      this.xAxisG2.selectAll('text')
        .classed('smalltick', true)
        .style('text-anchor', 'end')
        .attr('transform', function(d) {
          return 'translate(0,' + this.getBBox().height / 2 + ')rotate(-30)';
        });
    }

    if (this.yAxisG2) {
      this.yAxisG2.call(this.yAxis2);
    }
    else {
      this.yAxisG2 = this.context.insert('g', 'g.clip-path')
        .attr('class', 'y axis')
        .call(this.yAxis2);
    }

    // points create:
    var points = this.plotClip.selectAll('g.dataPoint');
    points = points.data(this.data_f.filter(v => { return !_.isNull(v.value) }), this.xValue);
    var newPoints = points.enter();
    var newGPoints = newPoints.append('g').attr('class', 'dataPoint');

    newGPoints.append('circle')
      // .attr('class', 'area line points')// FOR QA PURPOSE ONLY!
      .attr('stroke', 'steelblue') // FOR QA PURPOSE ONLY!
      .attr('stroke-width', 2) // FOR QA PURPOSE ONLY!
      .attr('cursor', 'default')
      .attr('cx', 0)
      .attr('cy', 0)
      .attr('r', 3);

    var _self = this;
    newGPoints.on('click', function(d) {
      _self.$scope.corX = _self.formatX(new Date(d.timestamp));
      _self.$scope.corY = _self.formatY(d.value);
      _self.$scope.$applyAsync();
      _self.plotClip.selectAll('.selected').classed('selected', false).select('circle').attr('r', 3);
      d3.select(this).classed('selected', true)
        .select('circle')
        .attr('r', 4);
    });

    // remove old points:
    points.exit().remove();

    // translate the points:
    points = this.plotClip.selectAll('g.dataPoint');
    points.attr({
      'transform': (d) => { return 'translate(' + this.xScaleValue(d) + ',' + this.yScaleValue(d) + ')'; },
    })
      .attr('fill', d => { return d.color || 'white' }); // FOR QA PURPOSE ONLY!


    // create the transition
    var transition = this.ele.transition().duration(10);

    // feed the current data:
    // transition.select('.focus .area').attr('d', this.areaGen(this.data_f));
    // transition.select('.context .area').attr('d', this.areaGen2(this.data_c));
    transition.select('.focus .line').attr('d', this.lineGen(this.data_f));
    transition.select('.context .line').attr('d', this.lineGen2(this.data_c));
  }

  private brushReset() {
    this.brush.clear();
    this.pause = false;
    this.ele.selectAll('.brush').call(this.brush);
    this.feedData({
      res: {
        data: this.tempData
      },
      evd: this.tempEvd
    });
    this.$scope.brushFrom = null;
    this.$scope.brushTo = null;
    this.$scope.$applyAsync();
  }

  private labelWrap(label) {
    label.each(function() {
      const text = d3.select(this);
      const words = text.text().split(/\s+/).reverse();
      const y = text.attr('y');
      const dy = parseFloat(text.attr('dy'));
      let line = [];
      let lineNumber = 0;
      let word;
      let tspan = text.text(null).append('tspan')
        .attr({
          'x': -5
        })
      while (word = words.pop()) {
        line.push(word)
        tspan.text(line.join(' '));
        if (words.length > 1 && (<any>tspan).node().getComputedTextLength() > 80) {
          line.pop();
          tspan.text(line.join(' '));
          line = [word];
          tspan = text.append('tspan')
            .attr('x', -5)
            .attr('dy', `${++lineNumber * 1.2}em`)
            .text(word);
        }
      }
    })
  }
}

export default angular.module('directives.StatPlot', [])
  .directive('statisticPlot', ['$branding', 'DeviceService', 'StatisticsSimpleService', function(branding: any, deviceService: DeviceService, sss) {
    return {
      scope: {
        corX: '=selectedX',
        corY: '=selectedY',
        brushFrom: '=',
        brushTo: '=',
        maxHeight: '@maxHeight',
        maxWidth: '=maxWidth',
        statId: '=statId',
        asdid: '=devAsdid',
        hasData: '=',
        badData: '=badData',
      },
      templateUrl: branding.getTemplateUrl("PlotsStatsDirective"),
      link: function(scope: any, ele, attrs) {
        scope.curQ = 0;
        var statArea = d3.select(ele[0]).select('div.plotarea');
        var stat = statArea.append('svg')
          .attr({
            'height': scope.maxHeight,
            'viewBox': '0 0 ' + scope.maxWidth + ' ' + scope.maxHeight,
            'preserveAspectRatio': 'xMinYMid meet'
          })
          .style({
            'flex': '1 1 100%',
            'overflow': 'visible'
          });

        scope.datawait = true;
        scope.datafail = false;
        scope.$statPlotCtrl = new Statistics(scope, stat, attrs);
        var eventNamePx = scope.asdid + '_' + scope.statId;
        var eventNameData = eventNamePx + '_stat_data_ready';
        var eventNameFail = eventNamePx + '_stat_data_fail';
        var eventNameReq = eventNamePx + '_stat_data_req';
        var eventNameBrush = eventNamePx + '_stat_data_brush';
        deviceService.startDeviceNotyfication(scope.asdid, scope);

        scope.$on(eventNameReq, (event, data, data2) => {
          if (data2) { }
          else {
            scope.datawait = true;
            scope.datafail = false;
          }
          scope.curQ = data;
        });

        scope.$on(eventNameData, (event, data) => {
          if (scope.curQ <= data.evd.dq) {
            scope.datawait = false;
            scope.datafail = false;
            scope.$statPlotCtrl.feedData(data);
            scope.curQ = data.evd.dq;
            scope.curData = data.res.data;
            if ((data.res.data && data.res.data.length > 0)) {
              scope.hasData = true;
            }
            else {
              scope.hasData = false;
            }
          }
        });

        scope.$on(eventNameBrush, (event, data) => {
          if (data.res.data) {
            scope.$statPlotCtrl.feedData(data);
          }
        });

        scope.$on(eventNameFail, (event, data) => {
          if (scope.curQ <= data) {
            scope.datawait = false;
            scope.datafail = true;
            scope.curQ = data;
          }
        });

        scope.$on('event:statsWidthChanged', function(event, data) {
          scope.maxWidth = data;
          stat.attr('viewBox', '0 0 ' + scope.maxWidth + ' ' + scope.maxHeight);
          if (scope.curQ != 0) scope.$statPlotCtrl.feedData(null);
        });

        scope.$on('event:brushReset', function(event, data) {
          scope.$statPlotCtrl.brushReset();
        });
      }
    }
  }]);
