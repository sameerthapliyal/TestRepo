import DeviceServiceModule, {DeviceService} from '../../../../components/src/services/DeviceService';

class PressureMat {
    private colorScale;
    private scale;
    private interspace = 4;
    private margin = 30;
    private Data;
    private tileG;
    private tileGroup;
    private tileSize;
    private tiles;
    private rows;
    private cols;
    private width;
    private height;
    private selS: string[];
    private selU: string;
    private legendGroup;
    private legend;
    private selected: boolean = false;
    protected scales: any = {};
    public colorSchemes = {
        RdYlBu: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee090", "#ffffbf", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4", "#313695"],
        Spectral: ["#9e0142", "#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#e6f598", "#abdda4", "#66c2a5", "#3288bd", "#5e4fa2"],
        GnBu: ["#084081", "#0868ac", "#2b8cbe", "#4eb3d3", "#7bccc4", "#a8ddb5", "#ccebc5", "#e0f3db", "#f7fcf0"],
        PuBu: ["#023858", "#045a8d", "#0570b0", "#3690c0", "#74a9cf", "#a6bddb", "#d0d1e6", "#ece7f2", "#fff7fb"],
        OrRd: ["#7f0000", "#b30000", "#d7301f", "#ef6548", "#fc8d59", "#fdbb84", "#fdd49e", "#fee8c8", "#fff7ec"]
    }
    public tempUnit = ['Celcius', 'Fahrenheit']

    constructor(private $scope, private parent, private ele) {
        this.$scope.update = () => this.update()
        this.$scope.colorSchemes = this.colorSchemes;
        this.$scope.selectedScheme = this.colorSchemes.RdYlBu;
        this.selS = this.$scope.selectedScheme;
        this.$scope.tempUnit = this.tempUnit;
        this.$scope.selectedUnit = this.tempUnit[0];
        this.selU = this.$scope.selectedUnit;

        this.colorScale = (<any>d3).scale.linear()
            .domain((<any>d3).range(150, -1, -(150 / (this.selS.length - 1))))
            .range(this.selS);

        this.scales.x = d3.scale.linear()
            .domain([0, 100])
            .range([0, 100])

        this.scales.y = d3.scale.linear()
            .domain([0, 100])
            .range([0, 100])


    }

    private feedData(_data) {
        this.width = this.$scope.maxW; // this.$scope.maxW;
        this.height = this.$scope.maxH; // this.$scope.maxH;
        this.Data = _data ? _data.res.data : this.Data;
        this.rows = _data ? _data.res.sizeX : this.rows;
        this.cols = _data ? _data.res.sizeY : this.cols;
        this.tileSize = d3.min([this.scales.x(this.height - this.margin), this.scales.y(this.width - this.margin)]) / this.rows - this.interspace;

        let t = this;
        if (!this.tileGroup) {
            this.tileGroup = this.ele.append('g')
                .attr({
                    'class': 'tileGroup',
                    'transform': `translate(0,${this.margin / 2})`
                })
        }
        if (!this.tiles) {
            this.tiles = this.tileGroup.selectAll('g.tile').data(this.Data).enter();
            this.tileG = this.tiles.append('g').attr('class', 'tile')
            var pos = (i) => this.calculateTilePosition(i)
            this.tileG.append('rect').attr({
                'height': this.scales.x(this.tileSize),
                'width': this.scales.x(this.tileSize),
                'transform': (d, i) => {
                    return 'translate(' + pos(i).x + ',' + pos(i).y + ')';
                },
                'fill': (d) => { return this.colorScale(d) },
                'stroke': '#444',
                'stroke-width': 1,
                'rx': this.scales.x(this.tileSize) / 20,
                'ry': this.scales.x(this.tileSize) / 20
            })
            this.tileG.append('text')
                .text((d) => {
                    return this.calculateTemp(d);
                })
                .attr({
                    'fill': '#fff',
                    'text-anchor': 'middle',
                    'transform': function(d, i) {
                        return 'translate(' + (pos(i).x + t.tileSize / 2) + ',' + (pos(i).y + t.tileSize / 2 + 5) + ')'
                    }
                });
        }
        else this.tileGroup.selectAll('g.tile').data(this.Data)

        this.tileG.select('rect')
            .transition().duration(250)
            .attr('fill', (d) => {
                return this.colorScale(d);
            });

        this.tileG.select('text')
            .transition().duration(100)
            .attr('fill', (d) => {
                return this.getTextColor(this.colorScale(d));
            })
            .text((d) => {
                return this.calculateTemp(d);
            });

        if (!this.legendGroup) this.drawLegend();

        this.tileG.on('mouseenter', function() {
            (<any>d3).select(this).select('text').classed('selected', true)
        });

        this.tileG.on('mouseleave', function() {
            if (t.selected == false) {
                (<any>d3).select(this).select('text').classed('selected', false)
            }
        });

        this.tileGroup.on('click', function(d, i) {
            (<any>d3).select(this).selectAll('text').classed('selected', !t.selected)
            t.selected = !t.selected;
        });

    }

    private calculateTilePosition(i) {
        let result = {
            x: this.scales.x((i % this.cols - this.cols / 2) * (this.tileSize + this.interspace) + this.width / 2),
            y: this.scales.y(Math.floor(i / this.cols) * (this.tileSize + this.interspace))
        }
        return result;
    }

    private update() {
        this.selS = this.$scope.selectedScheme;
        this.selU = this.$scope.selectedUnit;
        this.colorScale = (<any>d3).scale.linear()
            .domain((<any>d3).range(150, -1, -(150 / (this.selS.length - 1))))
            .range(this.selS);
        this.feedData(null)
        this.drawLegend();
    }

    private getTextColor(hexcolor) {
        hexcolor = hexcolor.slice(1, hexcolor.length)
        var r = parseInt(hexcolor.substr(0, 2), 16);
        var g = parseInt(hexcolor.substr(2, 2), 16);
        var b = parseInt(hexcolor.substr(4, 2), 16);
        var yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
        return (yiq >= 128) ? '#444' : '#eee';
    }

    private calculateTemp(d) {
        if (this.selU == 'Celcius') {
            return d3.round(((d - 32) / 1.8), 1);
        }
        else return d3.round((d), 1);
    }

    private drawLegend() {
        let legendH = 30, legendW = 60, len = this.selS.length, shiftY = (this.height - len * legendH) / 2;
        if (this.legendGroup) this.legendGroup.remove();

        this.legendGroup = this.ele.append('g')
            .attr({
                'class': 'legendGroup',
                'transform': `translate(30, ${shiftY})`
            });

        this.legend = this.legendGroup.selectAll('.legend')
            .data(this.colorScale.domain(), function(d) { return d; });

        this.legend.enter().append('g')
            .attr('class', 'legend');

        this.legend.append('rect')
            .attr({
                'x': 0,
                'y': (d, i) => {
                    return i * legendH;
                },
                'width': legendW,
                'height': legendH,
                'fill': (d, i) => {
                    return this.colorScale(d);
                }
            });

        this.legend.append('text')
            .text((d) => {
                return '≥ ' + this.calculateTemp(d);
            })
            .attr({
                'x': legendW / 2,
                'y': function(d, i) {
                    return i * legendH + this.getBBox().height;
                },
                'text-anchor': 'middle',
                'fill': (d) => {
                    return this.getTextColor(this.colorScale(d));
                }
            });
        this.legend.exit().remove();
    }
}

export default angular.module('directives.PressureMat', [])
    .directive('pressureMat', ['$branding', 'DeviceService', 'StatisticsSimpleService', function(branding: any, deviceService: DeviceService, sss) {
        return {
            scope: {
                maxH: '=maxHeight',
                asdid: '=devAsdid',
                statId: '=statId',
                colorSchemes: '=',
                selectedScheme: '=',
                tempUnit: '=',
                selectedUnit: '='
            },
            templateUrl: branding.getTemplateUrl('PressureMatDirective'),
            link: function(scope: any, ele, attrs) {
                scope.curQ = 0;
                scope.maxW = 600;
                var parent = d3.select(ele[0]);
                var area = parent.select('div.plotarea')
                var svg = area.append('svg')
                    .attr({
                        'height': scope.maxH,
                        'viewBox': '0 0 ' + scope.maxW + ' ' + scope.maxH,
                        'preserveAspectRatio': 'xMidYMid meet'

                    })
                    .style({
                        // 'max-height': scope.maxH + 'px',
                        'flex': '1 1 100%'
                    });
                scope.$PressureMatCtrl = new PressureMat(scope, parent, svg);
                scope.datawait = true;
                scope.datafail = false;
                var eventNamePx = scope.asdid + '_' + scope.statId;
                var eventNameData = eventNamePx + '_stat_data_ready';
                var eventNameFail = eventNamePx + '_stat_data_fail';
                var eventNameReq = eventNamePx + '_stat_data_req';
                deviceService.startDeviceNotyfication(scope.asdid, scope);
                scope.$on(eventNameReq, (event, data) => {
                    if (scope.curQ >= data) {
                        scope.datawait = true;
                        scope.datafail = false;
                    }
                    else { };
                    scope.curQ = data;
                });

                scope.$on(eventNameData, (event, data) => {
                    if (scope.curQ <= data.evd.dq) {
                        scope.datawait = false;
                        scope.datafail = false;
                        scope.$PressureMatCtrl.feedData(data);
                        scope.curQ = data.evd.dq;
                        scope.curData = data.res.data;
                    }
                });

                scope.$watchGroup(['selectedScheme', 'selectedUnit'], function(newValue, oldValue) {
                    if (newValue !== oldValue) {
                        scope.update()
                    }
                });
            }
        }
    }]);
