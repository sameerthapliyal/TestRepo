///<reference path="../../../../../typings/browser.d.ts"/>


class PerfDonutCtrl {
	private width = 300;
	private height = 300;
	private layout;

	private scope;
	private ele;
	private attrs;
	private pie:any;
	private arc:any;
	private arc2:any;


	constructor ($scope, ele, attrs)	{
		this.scope = $scope;
		this.ele = ele;
		this.attrs = attrs;
		this.arc = d3.svg.arc()
			.outerRadius( 103)
			.innerRadius( 57)
		this.arc2 = d3.svg.arc()
			.outerRadius( 120)
			.innerRadius( 130)
		this.pie = d3.layout.pie()
			.value(function(d:any){return d.value});
		var data = [ {value: 0, type: 'inactive'}, {value: 0, type: 'active'} ];
		this.feedData(data)
	}

	public feedData(values) {
		var c = 0;
		var values2=[];
		if(values)
		{
			for(var i =0 ;i < values.length; i++){
				c += values[i].value;
			}
		}
		if(c)
		{
			c=1.0*c;
			for(var i =0 ;i < values.length; i++){
				values2[i] = {};
				values2[i].value = Math.round(values[i].value/c*100);
				values2[i].type = values[i].type;
			}
		}
		else
		{
			values2 = [{value: 100, type: 'inactive'}];
		}

		var t = this;
		var g = this.ele.selectAll('.arc') //will change if we add animations
			g.remove();
		g = this.ele.selectAll('.arc')
			.data(this.pie(values2))
			.enter().append('g')
			.attr('class','arc')

		g.append('path')
			.attr('d',this.arc)
			.attr('class', function(d) { return d.data.type;})

		var tt = g.append('text')
			.attr('transform',function(d) { return 'translate(' + t.arc2.centroid(d) + ')' })
			.attr('dy', '.35em')
			.attr('text-anchor','middle')
			.attr('dominant-baseline','central')
			.attr('class', function(d) { return d.data.type;})
		tt.append('tspan')
			.text(function(d) { return d.data.value + '%'})
			.attr('x',0)
			.attr('y',7)
		tt.append('tspan')
			.attr('x',0)
			.attr('y',-7)
			.text(function(d) {
				switch(d.data.type)
				{
					case 'inactive':
						return 'Stale';
					case 'active':
						return 'Active';
					default:
						return 'unknown';
				}
			})
	}
}

export default angular.module('directives.Plots.perfdonut', [])
	.directive('plotDonutPerf', function () {
		return {
			scope: {
				data: '=plotData',
				maxW: '@maxWidth',
				maxH: '@maxHeight'
			},
			link: function(scope:any, ele, attrs) {
				var de = d3.select(ele[0]);
				var dd = de.append('div')
					.style({
						display: 'flex',
						'align-items': 'center',
						'justify-content':'left'
						})
				var dd2 = dd.append('svg')
					.attr({
						'viewBox':'0 0 '+scope.maxW+' '+scope.maxH,
						'preserveAspectRatio':'xMidYMid meet'
					})
					.style({
						'max-width':scope.maxW+'px',
						'max-height':scope.maxH+'px',
						'flex':'1 1 100%'
					})
				.append('g')
					.attr('transform','translate('+scope.maxW/2+','+scope.maxH/2+')');
				scope.perfDonutCtrl = new PerfDonutCtrl(scope, dd2, attrs);
				scope.$watch('data',function() {
					scope.perfDonutCtrl.feedData(scope.data);
				});


			}
		}
	});
