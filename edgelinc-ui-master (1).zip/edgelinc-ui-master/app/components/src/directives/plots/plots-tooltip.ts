
export default angular.module('directives.Plots.tooltip',[])
    .directive('plotsTooltip', ['$branding', function ($branding:any) {
      return {
        scope: {
          data: '=ttipData'
        },
        templateUrl: $branding.getTemplateUrl("PlotsTooltipDirective"),
        link: function(scope:any, ele, attrs) {
            scope.detaillink=(<any>window).BRANDING.ui.device_details_route.replace(":asdid","");
            scope.$container = ele[0];
        }
     }
    }]);
