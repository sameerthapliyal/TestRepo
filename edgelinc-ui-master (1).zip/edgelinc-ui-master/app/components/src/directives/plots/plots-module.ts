///<reference path="../../../../../typings/browser.d.ts"/>

import AlarmsBarModule from "./plots-alarmsbar";
import PerfDonutModule from "./plots-perfdonut";
import TooltipModule from "./plots-tooltip";

export default angular.module('directives.Plots',[
    AlarmsBarModule.name,
    PerfDonutModule.name,
    TooltipModule.name,
]);
