
import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";
import DeviceServiceModule, {DeviceService} from "../../services/DeviceService";

interface IDeviceImageDirectiveScope extends ng.IScope {
    asdid: string;
    imageDataUrl: string;
    ready: boolean;
}

function DeviceImageDirective(DeviceService: DeviceService, DeviceModelsService: DeviceModelsService) {
    return {
        restrict: "E",
        templateUrl: "/components/src/directives/device-image/device-image.html",
        scope: {
            asdid: '='
        },
        link: ($scope: IDeviceImageDirectiveScope, elem: ng.IAugmentedJQuery) => {
            $scope.ready = false;
            DeviceService.getDeviceCacheData($scope.asdid)
                .then(device => {
                    return DeviceModelsService.getDeviceModelImage(device.device_model);
                })
                .then(imageData => {
                    if(imageData) {
                        elem.find("img").attr("src", imageData.imageDataUrl);
                    }
                    $scope.ready = true;
                })
                .catch(err => {
                    console.error(err);
                    $scope.ready = true;
                })

        }
    }
}

DeviceImageDirective.$inject = ["DeviceService", "DeviceModelsService"];

export default angular.module('directives.deviceImage', [DeviceServiceModule.name, DeviceModelsServiceModule.name])
    .directive('deviceImage', DeviceImageDirective);