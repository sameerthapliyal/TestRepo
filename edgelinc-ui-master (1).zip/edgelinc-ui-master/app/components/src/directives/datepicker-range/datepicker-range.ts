/**
 * Created by rosadnik on 2015-12-01.
 */
///<reference path="../../../../../typings/browser.d.ts"/>


var angularModule = angular.module('directives.datepickerRange', []);
export default angularModule;
angularModule.controller('datepickerRangeController', ['$scope', '$element','$timeout','$branding','$filter',function($scope, $element,$timeout,$branding, $filter){
    return new datepickerRangeController($scope, $element, $timeout, $branding, $filter);
}]);
angularModule.directive("datepickerRange", function(){
    return{
        templateUrl: "/components/src/directives/datepicker-range/datepicker-range.html",
        restrict:"E",
        controller: "datepickerRangeController",
        scope:{
            dateRequired: "=",
            dateFrom: '=',
            dateTo: "=",
            dateFormatInControl: "@",
            onChange: "&",
            showSeconds:"=",
            secondsExclusive: "=?"
        }
    };
});

interface datepickerRangeControllerScope extends ng.IScope {
    dateToPickerOptions: angular.ui.bootstrap.IDatepickerConfig,
    dateFromPickerOptions: angular.ui.bootstrap.IDatepickerConfig,
    status:{opened: boolean};
    open:(event:any)=>void;
    onClearClick:()=> void;
    onCloseClick:()=> void;
    dateTo: number;
    dateFrom: number;
    dateTo_private: number;
    dateFrom_private: number;
    dateToDisplay: string;
    dateFromDisplay: string;
    onChange:()=> void;
    dateRequired:boolean;
    hasErrorDate:()=>boolean;
    showSeconds:boolean;
    secondsExclusive:boolean;
    showMeridian:boolean;
}

class datepickerRangeController{
    private _element:any;
    private _timeout:ng.ITimeoutService;
    private _scope:datepickerRangeControllerScope;
    private _orginal_dateFrom:number;
    private _orginal_dateTo:number;
    

    constructor ($scope:any,$element:any, $timeout:ng.ITimeoutService, private $branding, private $filter){
        this._element =$element;
        this._timeout = $timeout;
        this._scope = $scope;
        $scope.dateToPickerOptions = {
            showWeeks: false,
            minDate: $scope.dateFrom
        };
        $scope.dateFromPickerOptions = {
            showWeeks: false,
            maxDate: $scope.dateTo
        };
        $scope.status = {
            opened: false
        };
        $scope.open = ($event)=> {
            $scope.status.opened = true;
            this._orginal_dateFrom = this._scope.dateFrom;
            this._orginal_dateTo = this._scope.dateTo;
        };
        $scope.hasErrorDate = ()=>{
          if (this._scope.dateFrom_private != null && this._scope.dateTo_private != null){
            if (this._scope.dateTo_private < this._scope.dateFrom_private){
              return true;
            } else {
              return false;
            }
          }else {
            return false;
          }
        };

        $scope.onClearClick = ()=>{
            // update time pickers
            var timepickerElements = $element[0].querySelectorAll(".timepicker-range");
            for(var i in timepickerElements){
                if(timepickerElements.hasOwnProperty(i)){
                    var angularElement = angular.element(timepickerElements[i]);
                    if(angularElement.data()["$uibTimepickerController"] != null){

                        angularElement.data()['$ngModelController'].$setViewValue(new Date());
                        angularElement.data()['$ngModelController'].$setViewValue(null);
                        angularElement.data()["$uibTimepickerController"].render();
                    }
                }
            }

            $scope.dateFrom_private = null;
            $scope.dateTo_private = null;
            $scope.dateToDisplay = $scope.formatDate($scope.dateTo_private );
            $scope.dateFromDisplay = $scope.formatDate($scope.dateFrom_private);

        };
        $scope.onCloseClick = ()=>{
          if ($scope.validateDate()){
              $scope.status.opened = false;
              var dateRangeChange = $scope.dateFrom != $scope.dateFrom_private || $scope.dateTo != $scope.dateTo_private;
              $scope.dateFrom = $scope.dateFrom_private;
              $scope.dateTo = $scope.dateTo_private;
              if(dateRangeChange) {
                  this._scope.onChange();
              }
          }else if(this._scope.dateRequired == true){
              this._scope.dateTo = this._scope.dateTo_private = this._orginal_dateTo;
              this._scope.dateFrom = this._scope.dateFrom_private = this._orginal_dateFrom;
              if ($scope.validateDate()){
                  $scope.status.opened = false;
              }
          }
        };

        $scope.validateDate = ()=>{
          if(( _.isEmpty($scope.dateRequired) == false || $scope.dateRequired == true)){
            if($scope.dateFrom_private != null && $scope.dateTo_private != null){
              return true;
            }else{
              return false;
            }
          }else{
            return true;
          }
        };

        $scope.formatDate = (ts:number)=>{
            if(ts == null || ts == 0){
                return "not set";
            }else {
                //return  moment(ts).format($scope.dateFormatInControl);
                //return d3.time.format("%Y-%m-%d %H:%M")(new Date(ts));
                var dateTimeFormat = $branding.getUISettings().dateTimeFormat;
                return this.$filter('date')(new Date(ts), dateTimeFormat);
            }
        };

        $scope.showMeridian = $branding.getUISettings().dateTimeFormat.indexOf('a') >= 0;

        $scope.$watch("dateTo", (newValue: number, oldValue: number) => {
            if(!$scope.status.opened) {
                $scope.dateTo_private = newValue;
                $scope.dateToDisplay = $scope.formatDate($scope.dateTo);
                $scope.dateFromPickerOptions.maxDate = newValue;

                if (this._scope.onChange != null) {
                    this._scope.onChange();
                }
            }
        });
        $scope.$watch("dateFrom", (newValue: number, oldValue: number) => {
            if(!$scope.status.opened) {
                $scope.dateFrom_private = newValue;
                $scope.dateFromDisplay = $scope.formatDate($scope.dateFrom);


                $scope.dateToPickerOptions.minDate = newValue;

                if (this._scope.onChange != null) {
                    this._scope.onChange();
                }
            }
        });

        $scope.$watch("dateFrom_private", (newValue: number, oldValue: number) => {
            if($scope.status.opened){
                if($scope.dateFrom_private && !this._scope.showSeconds && new Date($scope.dateFrom_private).getSeconds() != 0){
                    if(typeof $scope.dateFrom_private == "number") {
                        $scope.dateFrom_private -= new Date($scope.dateFrom_private).getSeconds();
                    }else if(typeof $scope.dateFrom_private == "object" && $scope.dateFrom_private.setSeconds){
                        $scope.dateFrom_private.setSeconds(0,0);
                    }
                }
                $scope.dateFromDisplay = $scope.formatDate($scope.dateFrom_private);
                $scope.dateToPickerOptions.minDate = newValue;
            }
        });

        $scope.$watch("dateTo_private", (newValue: number, oldValue: number) => {
          if($scope.status.opened){
            if($scope.dateTo_private && !this._scope.showSeconds){
                if(typeof $scope.dateTo_private == "number") {
                    $scope.dateTo_private += $scope.secondsExclusive ? 0 : 59 - new Date($scope.dateTo_private).getSeconds();
                }else if(typeof $scope.dateTo_private == "object" && $scope.dateTo_private.setSeconds){
                    $scope.dateTo_private.setSeconds($scope.secondsExclusive ? 0 : 59, 0);
                }
            }
            $scope.dateToDisplay = $scope.formatDate($scope.dateTo_private);
            $scope.dateFromPickerOptions.maxDate = newValue;
            }
        });


        var clickOutOfControl:(ev: MouseEvent) => any = (ev: MouseEvent)=>{
            if(this._scope.status.opened === true) {
                if(this._element[0].contains(ev.srcElement || ev.target)== false){
                    this._scope.onCloseClick();
                }
            }
        };
        document.addEventListener("mousedown", clickOutOfControl);
        $scope.$on("$destroy",()=>{
            document.removeEventListener("mousedown", clickOutOfControl)
        });
    }

    private updateSelected(){
        //R.O. this function don't work as ai expected
        if(this._scope .dateFrom == null || this._scope .dateFrom == 0 || this._scope .dateTo == null || this._scope .dateTo == 0){
            return;
        }

        var datepickers = this._element.find("table");
        for(var i in datepickers ){
            if (datepickers.hasOwnProperty(i)){
                var datepickerElem:Element = datepickers[i];
                datepickers.data("$scope").$apply((datepickerScope:any)=>{
                    datepickerScope.rows.forEach((dpRow)=> {
                        dpRow.forEach((dpDate)=> {
                            if (dpDate.date > this._scope .dateFrom && dpDate.date < this._scope.dateTo) {
                                dpDate.selected = true
                            }
                        });
                    });
                });
            }
        }
    }

}
