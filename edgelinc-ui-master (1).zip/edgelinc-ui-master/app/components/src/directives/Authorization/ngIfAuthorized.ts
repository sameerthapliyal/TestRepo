/**
 * Created by rosadnik on 04-Apr-17.
 */
import AuthServiceModule, {AuthService} from "../../services/AuthService";

var module = angular.module('directives.ngIfAuthorized', [AuthServiceModule.name]);
export default module;

var ngIfAuthorizedDirective = ['$animate', 'AuthorizationService', function ($animate, authService:AuthService) {
    return {
        multiElement: true,
        transclude: 'element',
        priority: 600,
        terminal: true,
        restrict: 'A',
        $$tlb: true, // HACK: angular's private implementation !!
        link: function ($scope, $element, $attr, $ctrl, $transclude) {
            var loaded;
            var ngIfAuthorizedWatchAction = function (value:string | string[], isNegation:boolean) {
                var permissionsList:string[] = [];
                if(Array.isArray(value)){
                    permissionsList = value;
                }else if(typeof value == "string"){
                    permissionsList = value.split(",");
                }
                if(isNegation){
                    var canSee = !authService.hasLoginUserAnyOfPermissions(permissionsList);
                }else{
                    var canSee = authService.hasLoginUserAnyOfPermissions(permissionsList);
                }
                if (loaded) {
                    $animate[canSee ? 'removeClass' : 'addClass']($element, 'ng-hide');
                }
                else if (canSee) {
                    loaded = true;
                    $transclude(function (clone) {
                        clone[clone.length++] = document.createComment(' end ngIfAuthorized: ' + $attr.ngIfAuthorized + ' ');
                        $animate.enter(clone, $element.parent(), $element);
                        $element = clone;
                    });
                }
            };
            if($attr.ngIfAuthorized){
                ngIfAuthorizedWatchAction($attr.ngIfAuthorized, false);
            }else if($attr.ngIfNotAuthorized){
                ngIfAuthorizedWatchAction($attr.ngIfNotAuthorized, true);
            }
        }
    };
}];

module.directive('ngIfAuthorized', ngIfAuthorizedDirective);

module.directive('ngIfNotAuthorized', ngIfAuthorizedDirective);

module.directive("ngShowAuthorized",['AuthorizationService',function (authService:AuthService) {
    return {
        link:function ($scope, $element, $attr, $ctrl) {
            var permissionsList:string[] = [];
            if(Array.isArray($attr.ngShowAuthorized)){
                permissionsList = $attr.ngShowAuthorized;
            }else if(typeof $attr.ngShowAuthorized == "string"){
                permissionsList = $attr.ngShowAuthorized.split(",");
            }
            let hasPermissions = authService.hasLoginUserAnyOfPermissions(permissionsList);
            $element.css('display', hasPermissions? '' : 'none');
        }
    };
}]);
