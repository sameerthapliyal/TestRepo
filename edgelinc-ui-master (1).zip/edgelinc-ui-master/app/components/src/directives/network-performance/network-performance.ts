/**
 * Created by rosadnik on 2015-12-07.
 */
///<reference path="../../../../../typings/browser.d.ts"/>
/// <reference path="../../services/CommonServices.ts" />

import CommonServicesModule, {CommonServices} from "../../services/CommonServices";

var angularModule = angular.module('directives.networkPerformance', [CommonServicesModule.name]);
export default angularModule;

angularModule.controller('networkPerformanceController', ['$scope','CommonServices',function($scope, commonServices: CommonServices){
    return new networkPerformanceController($scope, commonServices);
}]);
angularModule.directive("networkPerformance", function(){
    return{
        templateUrl: "/components/src/directives/network-performance/network-performance.html",
        restrict:"E",
        controller: "networkPerformanceController"
    };
});

class networkPerformanceController{
    constructor ($scope:any, commonServices){
        $scope.networkPerformance = commonServices.NetworkPerformance;
        $scope.$on(commonServices.onNetworkPerformanceChange, (networkPerformance:number)=>{
            $scope.networkPerformance = commonServices.NetworkPerformance;
        });
    }
}