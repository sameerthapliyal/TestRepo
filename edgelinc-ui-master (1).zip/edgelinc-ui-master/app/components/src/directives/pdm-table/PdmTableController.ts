import { IPdmColumnBaseDirective } from './columns/column-definition';
import { TableColumn, TableDetails } from './PdmTableController';

export interface TableHeader {
    caption?: string;
    colspan?: number;
    isCheckbox?: boolean;
    sort?: string;
}

export interface TableColumnSettings {
    template?: string;
    transcludeFn?: ng.ITemplateLinkingFunction;
    wrap?: boolean;
}

export interface TableColumn {
    transcludeFn?: ng.ITemplateLinkingFunction;
    wrap: boolean;
}
export interface TableDetails {
    transcludeFn?: ng.ITemplateLinkingFunction;
    wrap: boolean;
    template?: string;
}
export interface IPdmTableScope extends ng.IScope {
    data: any[];
    headers: TableHeader[];
    columns: TableColumn[];
    pipe: (data: any) => Promise<App.Models.SearchResult<any>>;
    searchString: string;
    asyncDetails(date:any): Promise<any>;
    getData(tableState:any): void;
    toggle(row: IRow): IRow | void;
    getItems(tableState:any): Promise<App.Models.SearchResult<any>>;
    items: any[];
    pageSize: number;
    limit: number;
    isLoading: boolean;
    error: any;
    hasError: boolean;
    knownError: boolean;
    internalServerError: boolean;
    notFound: boolean;
    totalCount: number,
    details: any[];
    viewChanges: boolean;
}

export interface IRow extends ng.IScope{
    isDetailsShow: boolean;
    isDetailsCached: boolean;

}

export interface IPdmTableController {
    columns: TableColumn[];
    details: any[];
    detailsExpression: string;
    addHeader(header: TableHeader): void;
    addColumn(column: TableColumnSettings): void;
    addDetails(details: TableDetails): void;
    asyncDetails?(details:any): Promise<any>;
    
}

export class PdmTableController implements IPdmTableController {
    public static $inject = ['$scope', '$parse', '$compile'];

    public columns: TableColumn[];

    public details = [];

    public detailsExpression: string;
    
    public asyncDetails;

    private _lastTableState;

    constructor(public $scope: IPdmTableScope, private $parse: ng.IParseService, private $compile: ng.ICompileService) {
        $scope.headers = [];
        $scope.columns = this.columns = [];
        $scope.details = this.details;
        $scope.pageSize = 10;

        $scope.limit = 10;

        console.log($scope.searchString)

        
        if ($scope.asyncDetails) {
            this.registerAsyncDetails($scope.asyncDetails)
        }
        if ($scope.getData) {
            $scope.isLoading = true;
            this.initPipe();
        }

        $scope.getData = tableState => {
            if (this.$scope.data && !this.$scope.viewChanges) {
                return; // check if data is a plain object insted of promise
            }
            $scope.isLoading = true;
            this.initPipe(tableState);
        }

        $scope.$on("smartTable:pageSizeChange", (event, tableState) => {

            const number = this._lastTableState ? this._lastTableState.pagination.number : 10;
            tableState.pagination.number = number;
            $scope.getData(tableState);
        });

        $scope.$on("smartTable:refreshRequired", (event, tableState) => {

            this._lastTableState = tableState = tableState || this._lastTableState;
            if (!tableState) return;
            
            $scope.getData(tableState);
        });

        $scope.$watchCollection('data', this.assignPlainDataToScope.bind(this));

        $scope.$watch('searchString', searchString => {
            let tableState = this._lastTableState || { search: {}, pagination: {}};
            tableState.search.string = searchString;
            $scope.getData(tableState)
        })


        $scope.toggle = (row: IRow) : IRow | void => {
            if(this.isDetailsAsync() && !row.isDetailsCached) {
                return this.getDetails(row);
            }
            row.isDetailsShow = !row.isDetailsShow;

            return row;
        }
    }

    private initPipe (tableState = undefined) {
        
        this._lastTableState = tableState = tableState || this._lastTableState;
        this.$scope.pageSize = tableState.pagination.number;
        this.$scope.limit = tableState.pagination.number;

        
        return this.$scope
            .getItems({tableState})
            .then(result => {
                if (tableState) {
                    tableState.pagination.totalItemCount = result.totalCount;
                }
                this.$scope.hasError = this.$scope.knownError = this.$scope.internalServerError = false;
                this.$scope.error = null;
                return result;
            })
            .then(this.checkDetailsExpression.bind(this))
            .then(this.assignResponseToScope.bind(this))
            .catch(this.handleErrors.bind(this))
        }

    public addHeader(header: TableHeader) {
        this.$scope.headers.push(header);
    }

    public addColumn(column: TableColumnSettings) {
        if (typeof column.wrap !== "boolean") {
            column.wrap = !!column.transcludeFn;
        }
        let transcludeFn: ng.ITemplateLinkingFunction = column.transcludeFn;
        if (!transcludeFn && column.template) {
            transcludeFn = this.$compile(angular.element(column.template));
        }

        this.columns.push({
            transcludeFn: transcludeFn,
            wrap: column.wrap
        });
    }

    public addDetails(details: TableDetails) {
         if (typeof details.wrap !== "boolean") {
            details.wrap = !!details.transcludeFn;
        }
        let transcludeFn: ng.ITemplateLinkingFunction = details.transcludeFn;
        if (!transcludeFn && details.template) {
            transcludeFn = this.$compile(angular.element(details.template));
        }

        this.details.push({
            transcludeFn: transcludeFn,
            wrap: details.wrap
        });
    }
    public registerDetailsExpression(expression: string) : void {
        this.detailsExpression = expression;
    }

    private hasRegisteredDetails() {
        return !!this.details.length;
    }


    private getDetailsExpression () : string {
        return this.detailsExpression;
    }

    private hasDetails (row: any) {
        const detailExpression = this.getDetailsExpression();
        if (detailExpression) {
            row.hasDetails = this.$parse(detailExpression)({ row });
            row.isDetailsShow = false;

        }
        return row;

    }

    private checkDetailsExpression (result: App.Models.SearchResult<any>): App.Models.SearchResult<any> {
        return angular.extend(result, {items: result.items.map(this.hasDetails.bind(this))});
    }

    private assignResponseToScope (result: App.Models.SearchResult<any>): ng.IScope {
        return angular.extend(this.$scope, result, { isLoading: false });
    }

    private assignPlainDataToScope (data = []) {
        return angular.extend(
            this.$scope,
            {
                items: data,
                totalCount: data.length
            },
            { isLoading: false }
        );
    }

    private handleErrors (err): void {
        this.$scope.error = err;
        this.$scope.hasError = true;
        this.$scope.isLoading = false;
        if (err.status === 500) {
            this.$scope.knownError = true;
            this.$scope.internalServerError = true;
        }
        if (err.status === 404) {
            this.$scope.knownError = true;
            this.$scope.notFound = true;
        }
    }

    private registerAsyncDetails (getDetailsFunction: (any) => Promise<any>) {
        this.asyncDetails = getDetailsFunction;
    }

    private isDetailsAsync() : boolean {
        return !!this.asyncDetails;
    }
    private getDetails(row: any): void {
        row.isLoading = true;
        row.isDetailsShow = true;
        this.asyncDetails(row)
            .then(result => angular.extend(row, result, {isLoading: false, isDetailsCached: true}));
    }
}
