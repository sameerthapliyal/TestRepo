import {PdmTableController} from "./PdmTableController";

import PdmTableColumnDirective from './columns/pdm-table-column';
import PdmTableColumnCheckboxDirective from './columns/pdm-table-column-checkbox';
import PdmTableColumnDateDirective from './columns/pdm-table-column-date';
import PdmTableColumnDeviceLinkDirective from './columns/pdm-table-column-device-link';
import PdmTableColumnUserLinkDirective from './columns/pdm-table-column-user-link';
import PdmTableColumnTemplateDirective from './columns/pdm-table-column-template';
import PdmTableDetailsToggleDirective from './columns/pdm-table-column-details-toggle'



export default angular.module('directives.pdmTable.columns', [])
    .directive('pdmTableColumn', PdmTableColumnDirective)
    .directive('pdmTableColumnDate', PdmTableColumnDateDirective)
    .directive('pdmTableColumnDeviceLink', PdmTableColumnDeviceLinkDirective)
    .directive('pdmTableColumnUserLink', PdmTableColumnUserLinkDirective)
    .directive('pdmTableColumnDetailsToggle', PdmTableDetailsToggleDirective)
    .directive('pdmTableColumnTemplate', PdmTableColumnTemplateDirective)
    .directive('pdmTableColumnCheckbox', PdmTableColumnCheckboxDirective)