import * as _ from "lodash";
import {PdmTableController} from "./PdmTableController";
import PdmTableColumnsModule from "./pdm-table-columns";

function PdmTableDirective() {
    return <ng.IDirective>{
        restrict: "E",
        templateUrl: "/components/src/directives/pdm-table/pdm-table.html",
        controller: PdmTableController,
        transclude: {
            columns: 'pdmTableColumns',
            footer: '?pdmTableFooter'
            // details: 'pdmTableDetails'
        },
        scope: {
            data: '=?',
            pipe: '=',
            getItems: '&?',
            selection: '=?',
            asyncDetails: '=?',
            notFoundMessage: "@?",
            hidePagination: "=?",
            selectionKey: '@?',
            searchString: '=',
            viewChanges: '=?'

        }
    }
}


function PdmTableRowDirective($parse: ng.IParseService) {
    return {
        restrict: "A",
        require: "^pdmTable",
        link: (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: PdmTableController) => {
            elem.empty();
            let rowScope = ctrl.$scope.$parent.$new();
            let rowGetter = $parse(attrs['pdmTableRow']).bind(null, scope);
            scope.$watch(rowGetter, row => rowScope['row'] = row);

            _.each(ctrl.columns, column => {
                let container: ng.IAugmentedJQuery = elem;
                if(column.wrap || !column.transcludeFn) {
                    container = angular.element(document.createElement('td'));
                    elem.append(container);
                }
                if(column.transcludeFn) {
                    column.transcludeFn(rowScope, (contentElem: ng.IAugmentedJQuery) => {
                        container.append(contentElem);
                    })
                }
            });
        }
    }
}
PdmTableRowDirective.$inject = ['$parse'];


function PdmTableDetailsContainerDirective($compile, $parse) {
    return {
        restrict: "E",
        require: "^pdmTable",
        transclude: true,
        scope: {
            row: '=',
           
            hasDetails: '@',
            expanded: '@'
        },
        link: (scope, elem, attr, ctrl, transclude) => {  
            ctrl.registerDetailsExpression(scope.hasDetails);
            ctrl.addDetails({ transcludeFn: transclude })
        },
        template: '<div></div>'
        
    }
}

function PdmTableDetailsDirective($compile, $parse) {
    return {
        restrict: "E",
        require: "^pdmTable",
        transclude: true,
        scope: {
            row: '=',
            hasDetails: '@'
        },
        link: (scope, elem, attr, ctrl, transclude) => {
            elem.empty();

            let rowScope = ctrl.$scope.$parent.$new();
            scope.$watch("row", row => rowScope['row'] = row);

            scope.row.details = false

            _.each(ctrl.details, detail => {
                let container: ng.IAugmentedJQuery = elem;
                if(detail.wrap || !detail.transcludeFn) {
                    container = angular.element(document.createElement('div'));
                    elem.append(container);
                }
                if(detail.transcludeFn) {
                    detail.transcludeFn(rowScope, (contentElem: ng.IAugmentedJQuery) => {
                        container.append(contentElem);
                    })
                }
            });
            
        },
        template: '<div></div>'
        
    }
}





export default angular.module('directives.pdmTable', [PdmTableColumnsModule.name])
    .directive('pdmTable', PdmTableDirective)
    .directive('pdmTableRow', PdmTableRowDirective)
    .directive('pdmTableDetailsContainer', ['$compile', '$parse', PdmTableDetailsContainerDirective])
    .directive('pdmTableDetails', ['$compile', '$parse', PdmTableDetailsDirective])
