import { IPdmTableColumnBaseScope, IPdmColumnBaseDirective } from './column-definition'
import { IPdmTableController } from './../PdmTableController'


interface IPdmTableColumnTemplateScope extends IPdmTableColumnBaseScope {
    
}

interface IPdmTableColumnTemplateDirective extends IPdmColumnBaseDirective {
    transclude: boolean;
    scope: any; 
    link(scope: IPdmTableColumnTemplateScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController, transclude: ng.ITranscludeFunction): void;
}
export default function PdmTableColumnTemplateDirective(): IPdmTableColumnTemplateDirective {
    return {
        restrict: "E",
        require: "^pdmTable",
        transclude: true,
        scope: {
            caption: '@',
            sort: '@?'
        },
        link: (scope: IPdmTableColumnTemplateScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController, transclude: ng.ITranscludeFunction) => {
            ctrl.addHeader({
                caption: scope.caption,
                sort: scope.sort
            });
            ctrl.addColumn({
                transcludeFn: transclude
            });
        }
    }
}