import { IPdmTableColumnBaseScope, IPdmColumnBaseDirective } from './column-definition'
import { IPdmTableController } from './../PdmTableController'



interface IPdmTableColumnDeviceLinkDirectiveScope extends IPdmTableColumnBaseScope {
    text: string;
    asdid: string;
}

interface IPdmTableColumnDeviceLinkDirective extends IPdmColumnBaseDirective {
    scope: any;
    link: (scope: IPdmTableColumnDeviceLinkDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController) => void;
}

export default function PdmTableColumnDeviceLinkDirective(): IPdmTableColumnDeviceLinkDirective {
    return {
        restrict: "E",
        require: "^pdmTable",
        scope: {
            caption: '@',
            text: '@',
            asdid: '@'
        },
        link: (scope: IPdmTableColumnDeviceLinkDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController) => {
            ctrl.addHeader({
                caption: scope.caption
            });
            ctrl.addColumn({
                template: `<td><a device-details-href="${scope.asdid}">{{${scope.text} | dashForEmpty}}</a></td>`
            });
        }
    }
}