import { IPdmTableColumnBaseScope, IPdmColumnBaseDirective } from './column-definition'
import { IPdmTableController } from './../PdmTableController'


interface IPdmTableColumnUserLinkDirectiveScope extends IPdmTableColumnBaseScope {
    text: string;
    name: string;
}

interface IPdmTableColumnDeviceLinkDirective extends IPdmColumnBaseDirective {
    scope: any;
    link: (scope: IPdmTableColumnUserLinkDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController) => void;
}


export default function PdmTableColumnUserLinkDirective(): IPdmTableColumnDeviceLinkDirective {
    return {
        restrict: "E",
        require: "^pdmTable",
        scope: {
            caption: '@',
            text: '@',
            name: '@',
            sort: '@'
        },
        link: (scope: IPdmTableColumnUserLinkDirectiveScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController) => {
            console.log(scope)
            ctrl.addHeader({
                caption: scope.caption,
                sort: scope.sort
            });
            ctrl.addColumn({
                template: `<td><a href="#/views/user-management/user-display/{{${scope.name}}}"> {{ ${scope.name} }}</a></td>`
            });
        }
    }
}
