import { IPdmTableColumnBaseScope, IPdmColumnBaseDirective } from './column-definition'
import { IPdmTableController } from './../PdmTableController'

interface IPdmTableColumnDetailsScope extends IPdmTableColumnBaseScope {
    toggle: string;
}


interface iPdmTableDetailsToggleDirective extends IPdmColumnBaseDirective {
    link: (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController) => void;
}
export default function PdmTableDetailsToggleDirective () {
    return {
        restrict: "E",
        require: "^pdmTable",
        transclude: true,
        scope: {
            toggle: '@'
        },
        link: (scope: IPdmTableColumnDetailsScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController, transclude: ng.ITranscludeFunction) => {
            ctrl.addHeader({
                caption: ''
            });
            ctrl.addColumn({
                template: `
                <td>
                    <a ng-click="${scope.toggle}" ng-show="row.hasDetails">
                        <span class='fa-stack'>
                        <i class='fa fa-square fa-stack-2x'></i>
                            <i class='fa fa-stack-1x fa-inverse'
                                ng-class="{' fa-plus-circle':!row.isDetailsShow, 'fa-minus-circle':row.isDetailsShow}"></i>
                        </span>
                    </a>
                </td>`
            });
        }
    }

}