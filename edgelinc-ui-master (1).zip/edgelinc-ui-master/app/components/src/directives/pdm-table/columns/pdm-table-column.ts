import { IPdmTableColumnBaseScope, IPdmColumnBaseDirective } from './column-definition'
import { IPdmTableController } from './../PdmTableController'


interface IPdmTableColumnScope extends IPdmTableColumnBaseScope {
    text: string;


}

interface IPdmTableColumnDirective extends IPdmColumnBaseDirective {
    link: (scope: IPdmTableColumnScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController) => void;
}
export default function PdmTableColumnDirective() {
    return {
        restrict: "E",
        require: "^pdmTable",
        scope: {
            caption: '@',
            text: '@',
            sort: '@?'
        },
        link: (scope: IPdmTableColumnScope, elem: ng.IAugmentedJQuery, attr: ng.IAttributes, ctrl: IPdmTableController): void => {
            ctrl.addHeader({
                caption: scope.caption,
                sort: scope.sort
            });
            ctrl.addColumn({
                template: `<td>{{${scope.text} | dashForEmpty}}</td>`
            });
        }
    }
}