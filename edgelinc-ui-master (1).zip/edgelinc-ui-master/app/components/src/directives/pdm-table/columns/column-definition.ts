import { PdmTableController } from '../PdmTableController';

export interface IPdmTableColumnBaseScope extends ng.IScope {
    caption: string;
    sort?: string;
}

export interface IPdmColumnBaseDirective {
    restrict: "E";
    require: '^pdmTable';
    scope: IPdmTableColumnBaseScope;

}

