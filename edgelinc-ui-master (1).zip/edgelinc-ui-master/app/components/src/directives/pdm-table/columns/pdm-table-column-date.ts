import { IPdmTableColumnBaseScope, IPdmColumnBaseDirective } from './column-definition'
import { IPdmTableController } from './../PdmTableController'


interface IPdmTableColumnDateScope extends IPdmTableColumnBaseScope {
    date: string;
}

interface IPdmTableColumnDateDirective extends IPdmColumnBaseDirective {
    scope: any;
    link: (scope: IPdmTableColumnDateScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController) => void;
}

export default function PdmTableColumnDateDirective(): IPdmTableColumnDateDirective {
    return {
        restrict: "E",
        require: "^pdmTable",
        scope: {
            caption: '@',
            date: '@',
            sort: '@?'
        },
        link: (scope: IPdmTableColumnDateScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController) => {
            ctrl.addHeader({
                caption: scope.caption,
                sort: scope.sort
            });
            ctrl.addColumn({
                template: `<td>{{${scope.date} | dateFromTs | dashForEmpty}}</td>`
            });
        }
    }
}
