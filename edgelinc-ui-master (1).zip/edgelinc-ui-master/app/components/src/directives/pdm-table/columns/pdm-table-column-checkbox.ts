import { IPdmTableColumnBaseScope, IPdmColumnBaseDirective } from './column-definition'
import { IPdmTableController } from './../PdmTableController'


interface IPdmTableColumnCheckboxScope extends IPdmTableColumnBaseScope {
    text: string;

}

interface PdmTableColumnCheckboxDirective extends IPdmColumnBaseDirective {
    scope: any;
    link: (scope: IPdmTableColumnCheckboxScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: IPdmTableController) => void;
}
export default function PdmTableColumnCheckboxDirective(): PdmTableColumnCheckboxDirective {
    return {
        restrict: "E",
        require: "^pdmTable",
        scope: {
            caption: '@',
            text: '@'
        },
        link: (scope: IPdmTableColumnCheckboxScope, elem: ng.IAugmentedJQuery, attr: ng.IAttributes, ctrl: IPdmTableController) => {
            ctrl.addHeader({
                isCheckbox: true
            });
            ctrl.addColumn({
                template: `<td st-custom-row-checkbox="row"></td>`
            });
        }
    }
}

