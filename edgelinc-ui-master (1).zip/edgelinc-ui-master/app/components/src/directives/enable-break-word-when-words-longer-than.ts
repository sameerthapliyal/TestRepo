/**
 * Created by rosadnik on 20-Mar-17.
 */
var angularModule = angular.module('directives.enableBreakWord', []);
interface enableBreakWordWhenWordsLongerThanScope extends ng.IScope{
    enableBreakWordWhenWordsLongerThan?:number;
}

angularModule.directive("enableBreakWordWhenWordsLongerThan",function(){
    return {
        restrict:'A',
        link: (scope: enableBreakWordWhenWordsLongerThanScope, element: ng.IAugmentedJQuery, attrs: ng.IAttributes, tabset: any) => {
            scope.$watch(()=>{ return element[0].innerText; },
                (newVal:string, oldVal:string)=>{
                    if(newVal.findLongestWord()> (scope.enableBreakWordWhenWordsLongerThan || 50) ){
                        if(element.hasClass("break-word-ellipsis") == false){
                            element.addClass("break-word-ellipsis");
                        }
                    }else{
                        if(element.hasClass("break-word-ellipsis")){
                            element.removeClass("break-word-ellipsis");
                        }
                    }
                }
            );
        }
    };
});

export default angularModule;