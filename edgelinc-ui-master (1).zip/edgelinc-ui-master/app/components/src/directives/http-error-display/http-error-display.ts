import {HttpError} from "../../utilities/RestHelper";

var angularModule = angular.module('directives.http-error-display',[]);

interface httpErrorDisplayScope extends ng.IScope{
    httpError:HttpError;
}

class httpErrorDisplayController{
    public static $inject = [ "$scope" ];
    constructor(private $scope: httpErrorDisplayScope){
    
    }
}

export default angularModule.directive("httpErrorDisplay",["$branding", function(){
    return{
        //templateUrl: $branding.getTemplateUrl('directives.http-error-display'),
        templateUrl: "/components/src/directives/http-error-display/http-error-display.html",
        controller: httpErrorDisplayController,
        scope:{
            httpError:"="
        }
    };
}]);