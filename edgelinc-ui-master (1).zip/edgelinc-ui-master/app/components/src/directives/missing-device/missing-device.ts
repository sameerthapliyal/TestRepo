/**
 * Created by rosadnik on 04-Aug-16.
 */

var angularModule = angular.module('directives.missingDevice', []);

angularModule.directive('missingDevice', function () {
    return {
        templateUrl:'/components/src/directives/missing-device/missing-device.html',
        restrict: "E",
        scope: {
            asdid: "="
        },
        link: (scope, element, attributes) => { }
    }
});

export default angularModule;