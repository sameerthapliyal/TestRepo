

function PdmThreeStateCheckbox() {
    return {
        restrict: "A",
        require: 'ngModel',
        link: (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes, ctrl: ng.INgModelController) => {

            ctrl.$parsers.unshift(function(value) {
                return value;
            });
            ctrl.$formatters.unshift(function(value) {
                if(ctrl.$modelValue == null) {
                    return null;
                } else {
                    return value;
                }
            });
            ctrl.$render = function() {
                elem.prop('checked', !!ctrl.$viewValue);
                elem.prop('indeterminate', ctrl.$viewValue == null);
            };
            ctrl.$isEmpty = function(value) {
                return value == null;
            }
        }
    }
}

export default angular.module('directives.pdmThreeStateCheckbox', [])
    .directive('pdmThreeStateCheckbox', PdmThreeStateCheckbox);