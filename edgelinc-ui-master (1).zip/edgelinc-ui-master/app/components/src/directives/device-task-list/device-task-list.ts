import {stLoadingStatusService} from "../smart-table/st-loading-status";
import GroupOperationsServiceModule, {GroupOperationsService, IGetTaskFilter, IAbortRequestResult} from "../../services/GroupOperationsService";
import DeviceServiceModule, {DeviceService} from "../../services/DeviceService";
import DeviceModelsServiceModule, {DeviceModelsService} from "./../../services/DeviceModelsService";
import {BrandingService} from "../../services/BrandingService";
import ParameterStorageServiceModule, {ParameterStorageService, STORAGE_TYPE} from "../../services/ParameterStorageService";
import {GroupOperationsListViewMode, IGroupOperationDisplay, IGroupOperationChangeParameterDisplay, ITaskItemDisplay} from "../../../../views/tasks/definitions/group-operations-display-interfaces";



export interface ItableInfo {
    limit: number;
    offset: number;
    sortColumn: string;
    sortDir: string;
}



export class DeviceTaskListController {
    
    private _currentAsdid:string;
    private _filterChange:boolean = false;
    private _scopePropertiesToSave:string[] = ["listFilter.status_dt", "listFilter.create_dt", "listFilter.selectedTaskStatus", "listFilter.numericLocoId", "listFilter.searchString", "listFilter.taskType",
                                                "listFilter.customer_id", "listFilter.groupOperationId", "listFilter.groupOperationType", "listFilter.packages_filters", "pageSize"];
    private _storageKey:string = "tasks-list-filters-and-table-storage";
    private _storageType:STORAGE_TYPE;

    private _lastTableState:any;
    private _tableCtrl:any;
    private ReadJson;

  public static $inject = ['$scope', '$timeout', '$q', 'GroupOperationsService', 'DeviceService', 'DeviceModelsService', 'ParameterStorageService', '$translate', '$branding']

  constructor (
                private _scope,
                private _timeout: ng.ITimeoutService,
                private _q: ng.IQService,
                private _groupOperationsService: GroupOperationsService,
                private _deviceService: DeviceService,
                private _deviceModelsService: DeviceModelsService,
                private _storage: ParameterStorageService,
                private $translate:any,
                private $branding:BrandingService
  ) {

     
    
    this._currentAsdid = this._scope.asdid;
    this.initFilters();
    this.initParameterStorageService();
    this.initTable();
    this.initAbortFuncionality();
    
  }


    initTable () {
 
        this._scope.showGroupOperationsDetails = ( taskDisplay:ITaskItemDisplay)=> {
                taskDisplay.showDetails = !taskDisplay.showDetails;
        };

        this._scope.callServer = _.compose(
            this.customSaveState.bind(this),
            this.getGroupOperationList.bind(this)
        );

        this._scope.onClearFilterClick = () => {
            this._scope.listFilter = {
                selectedTaskStatus: [],
                searchString:"",
                status_dt:{from: null, to: null},
                create_dt:{from: null, to: null},
                numericLocoId:{from: null, to: null},
                groupOperationId:{from: null, to: null},
                groupOperationType:null,
                packages_filters:{
                    type: null,
                    number: null,
                    version: null
                },
                customer_id:null
            };
            this._scope.onFilterChange();
        };
        this._scope.onFilterChange();
    }

    customSaveState() {
        this._timeout(()=>{
            this._storage.saveState(this._scope,this._storageKey,this._storageType, this._scopePropertiesToSave);
        });
    }
    

    getGroupOperationList(tableState:any, tableCtrl:any) {
        
        const setLastTableState = (tableState:any, tableCtrl:any) => {
            this._lastTableState = tableState ;
            this._tableCtrl = tableCtrl;
            this._scope.isLoading = true;
        }

        const setLoadingInfo = (data, response) => {
            this._scope.isLoading = false;
            this._scope.limit = data.limit;
            this._scope.offset = data.offset;
            this._scope.filtered = response.totalCount;
            this._scope.lastItemIndex = Math.min(this._scope.offset+this._scope.limit , this._scope.filtered);
            tableState.pagination.numberOfPages = Math.ceil(response.totalCount/tableState.pagination.number);
        }
        const isSortOrPredicate = (tableState:any) => tableState.sort && tableState.sort.predicate

        const getLastTableInfo = () => (<ItableInfo>{
            limit: this._lastTableState.pagination.number,
            offset: this._lastTableState.pagination.start,
            sortColumn: isSortOrPredicate(tableState)
                ? this._lastTableState.sort.predicate
                : 'create_ts',
            sortDir: isSortOrPredicate(tableState)
                ?  this._lastTableState.sort.reverse ? "desc": "asc"
                :  'desc',
            
            
        });

        const iliterateTaskData = (data:any) => this.calculateTaskDispalyFields(data);

        const handlerResponse = data => response => {
            this._scope.tasksList = _.toArray(response.items)
                .map(iliterateTaskData);
                setLoadingInfo(data, response)
        };
        
        setLastTableState(tableState, tableCtrl);

        const tableInfo = getLastTableInfo();

        const handlerWithData = handlerResponse(tableInfo);

        let filters: IGetTaskFilter = _.extend(
            {},
            { asdid: this._currentAsdid },
            this.getGroupOperationList_prepareFilter()
        )
        
      
        this._groupOperationsService
        .getTasks(
            filters,
            tableInfo.sortColumn,
            tableInfo.sortDir,
            tableInfo.limit,
            tableInfo.offset
         )
        .then(handlerWithData)

    }





  private calculateTaskDispalyFields(taskData){

      if(taskData.systemAsdid){
          taskData.systemAsdid.then((systemAsdid)=>{
              taskData.systemAsdid_Display = systemAsdid;
          });
      }
      if(taskData.systemName){
          taskData.systemName.then((systemName)=>{
              taskData.systemName_Display = systemName;
          });
      }
      if(taskData.system){
          taskData.system.then((systemData)=>{
              taskData.systemDevice = systemData;
          });
      }

      if(taskData.device){
          taskData.device.then((deviceData)=>{
              taskData.deviceData = deviceData;
          });
      }

      if(taskData.description){
          taskData.description.then((description:string)=>{
              taskData.description_Display = description;
          });
      }
      if(taskData.groupOperation != null){
          (taskData.groupOperation).hasDetailsData = true;
      }

      if(taskData.type == "parameter_change") {
        if(taskData.groupOperation && taskData.groupOperation["parameters"]) {
          this._deviceService.getDeviceCacheData(taskData.asdid).then((dev: eapi18.DeviceFromDSC) => {
              if(dev!= null) {
                this._deviceModelsService.getVisCapfile(dev.device_model, dev.model_version).then((visCapfile)=> {
                    var newDiplayParam = [];
                    if(visCapfile == null) {
                        console.warn("Missing visual capability file for:", dev.device_model_name, dev.device_model, dev.model_version, taskData);
                    }
                    _.each(taskData.groupOperation.parameters, (parameter:any) => {
                        if(visCapfile != null && visCapfile.Parameters != null && visCapfile.Parameters.hasOwnProperty(parameter.api_name)) {
                            parameter.name_Display = visCapfile.Parameters[parameter.api_name].Caption;
                            if( visCapfile.Parameters[parameter.api_name].Enumeration != null &&
                                visCapfile.Parameters[parameter.api_name].Enumeration.hasOwnProperty(parameter.value)){
                                parameter.value_Display = visCapfile.Parameters[parameter.api_name].Enumeration[parameter.value];
                            }
                        }
                        newDiplayParam.push(parameter);
                    });
                    this._timeout(()=> {
                        taskData.groupOperation.parameters = newDiplayParam;
                    });
                })
              }
          })
        }
      }

      switch(taskData.status){
          case "PENDING":
              (<any>taskData).status_fields = {text:"Scheduled", cssClass:"Pending" };
              switch(taskData.cancel_status){
                  case "REQUESTED":
                      (<any>taskData).status_fields = {text:"Canceling", cssClass:"Canceling" };
                      break;
                  case "REQUEST_CONFIRMED":
                      (<any>taskData).status_fields = {text:"Canceled", cssClass:"Canceled" };
                      console.warn("Inconsistency in taks status. Task have cancel_status: 'REQUEST_CONFIRMED' and status: 'PENDING'. Inconsistency", taskData);
                      break;
                  case "ERROR":
                      (<any>taskData).status_fields = {text:"Canceled", cssClass:"Canceled" };
                      console.warn("Inconsistency in taks status. Task have cancel_status: 'ERROR' and status: 'PENDING'. Inconsistency", taskData);
                      break;
              }
              break;
          case "IN_PROGRESS":
              (<any>taskData).status_fields = {text:"In Progress", cssClass:"InProgress" };
              switch(taskData.installationStatus){
                  case "STAGING":
                      (<any>taskData).status_fields = {text:"Staged", cssClass:"Staged" };
                      break;
                  case "PENDING":
                      (<any>taskData).status_fields = {text:"Pending", cssClass:"Pending" };
                      break;
              }
              switch(taskData.commandStatus){
                  case "STAGING":
                      (<any>taskData).status_fields = {text:"Staged", cssClass:"Staged" };
                      break;
                  case "PENDING":
                      (<any>taskData).status_fields = {text:"Pending", cssClass:"Pending" };
                      break;
              }
              switch(taskData.cancel_status){
                  case "REQUESTED":
                      (<any>taskData).status_fields = {text:"Canceling", cssClass:"Canceling" };
                      break;
                  case "REQUEST_CONFIRMED":
                      (<any>taskData).status_fields = {text:"Canceled", cssClass:"Canceled" };
                      console.warn("Inconsistency in taks status. Task have cancel_status: 'REQUEST_CONFIRMED' and status: 'IN_PROGRESS'. Inconsistency", taskData);
                      break;
                  case "ERROR":
                      (<any>taskData).status_fields = {text:"Canceled", cssClass:"Canceled" };
                      console.warn("Inconsistency in taks status. Task have cancel_status: 'ERROR' and status: 'IN_PROGRESS'. Inconsistency", taskData);
                      break;
              }

              break;
          case "FINISHED":
              switch (taskData.result){
                  case "SUCCESS":
                      switch(taskData.installationStatus){
                          case "DELIVERED":
                              (<any>taskData).status_fields = {text:"Delivered", cssClass:"Delivered" };
                              break;
                          default:
                              (<any>taskData).status_fields = {text:"Success", cssClass:"Success" };
                              break;
                      }
                      break;
                  case "FAILURE":
                      (<any>taskData).status_fields = {text:"Failed", cssClass:"Failed" };
                      break;
                  case "ABORTED":
                      (<any>taskData).status_fields = {text:"Aborted", cssClass:"Aborted" };
                      break;
                  case "CANCELLED":
                      (<any>taskData).status_fields = {text:"Canceled", cssClass:"Canceled" };
                      break;
                  default:
                      (<any>taskData).status_fields = {text:"Finish", cssClass:"Finish" };
                      break;
              }
              break;
          case "UNKNOWN":
          default:
              (<any>taskData).status_fields = {text:"Unknown", cssClass:"Unknown" };
              break;
      }
      return taskData;
  }

  private initFilters(){

      this._scope.listFilter = {};
      this._scope.severity = [
          {caption:'Scheduled', value:"SCHEDULED"},
          {caption:'Pending', value:"PENDING"},
          {caption:'In Progress', value:"IN_PROGRESS"},
          {caption:'Staged', value:"STAGED"},
          {caption:'Success', value:"SUCCESS"},
          {caption:'Failed', value:"FAILURE"},
          {caption:'Delivered', value:"DELIVERED"},
          {caption:'Aborted', value:"ABORTED"},
          {caption:'Canceled', value:"CANCELLED"},
          {caption:'Cancelling', value:"CANCELLING"}
      ];

      this._scope.getStatuses = (query: string) => {
          if (query != null && query.trim().length > 0) {
              var pattern = new RegExp(query, "i");
              return this._scope.severity.filter((m) => {
                  return pattern.test(m.caption);
              })
          } else {
              return this._scope.severity;
          }
      }

      this._scope.listFilter.selectedTaskStatus = [];

      this._scope.taskType = [
          {id:"parameter_change", text: this.$translate.getTranslationTable()["tasks.types.parameter_change.one"] || "Device Configuration"},
          {id:"package_management", text: this.$translate.getTranslationTable()["tasks.types.package_management.one"] || "Template Management"},
          {id:"command", text: this.$translate.getTranslationTable()["tasks.types.command.one"] || "Execute command"},
          {id:"registration", text: this.$translate.getTranslationTable()["tasks.types.registration.one"] || "Device Registration"},
          {id:"unregistration", text: this.$translate.getTranslationTable()["tasks.types.unregistration.one"] || "Device Unregistration"},
          {id:"assertions", text: this.$translate.getTranslationTable()["tasks.types.assertion.one"] || "Change Devices Assertions"}
      ];

      this._scope.onFilterChange = _.debounce(()=>{
              if(this._lastTableState && this._tableCtrl) {
                  this.getGroupOperationList(this._lastTableState, this._tableCtrl);
              }
              if(this._scope.stateRestored) {
                this.customSaveState();
              }
          },100);
  }

  private getGroupOperationList_prepareFilter():IGetTaskFilter{
        var filterObj:IGetTaskFilter = {};

        filterObj.taskStatus = [];

        _.each(this._scope.listFilter.selectedTaskStatus,(s:any, i)=> {
            if (s) {
                filterObj.taskStatus.push(s.value);
            }
        });

        if(this._scope.listFilter.create_dt != null && (this._scope.listFilter.create_dt.from || this._scope.listFilter.create_dt.to)){
            filterObj.createDate = {};
            if(this._scope.listFilter.create_dt.from != null) {
                filterObj.createDate.from = <any>this._scope.listFilter.create_dt.from;
            }
            if(this._scope.listFilter.create_dt.to){
                filterObj.createDate.to = <any>this._scope.listFilter.create_dt.to;
            }
        }
        if(this._scope.listFilter.status_dt != null && (this._scope.listFilter.status_dt.from || this._scope.listFilter.status_dt.to)){
            filterObj.statusDate = {};
            if(this._scope.listFilter.status_dt.from != null) {
                filterObj.statusDate.from = <any>this._scope.listFilter.status_dt.from;
            }
            if(this._scope.listFilter.status_dt.to){
                filterObj.statusDate.to = <any>this._scope.listFilter.status_dt.to;
            }
        }

        if(this._scope.listFilter.customer_id){
            filterObj.customer_id = this._scope.listFilter.customer_id;
        }
        if(this._scope.listFilter.numericLocoId != null && (this._scope.listFilter.numericLocoId.from || this._scope.listFilter.numericLocoId.to)){
            filterObj.numericLocoId = {};
            if(this._scope.listFilter.numericLocoId.from != null) {
                filterObj.numericLocoId.from = this._scope.listFilter.numericLocoId.from;
            }
            if(this._scope.listFilter.numericLocoId.to){
                filterObj.numericLocoId.to = this._scope.listFilter.numericLocoId.to;
            }
        }
        if(this._scope.listFilter.groupOperationId != null && (this._scope.listFilter.groupOperationId.from || this._scope.listFilter.groupOperationId.to)){
            filterObj.groupOperationId = {};
            if(this._scope.listFilter.groupOperationId.from != null) {
                filterObj.groupOperationId.from = this._scope.listFilter.groupOperationId.from;
            }
            if(this._scope.listFilter.groupOperationId.to){
                filterObj.groupOperationId.to = this._scope.listFilter.groupOperationId.to;
            }
        }

        if(this._scope.taskType  != null && this._scope.listFilter.taskType != ""){
            filterObj.taskType = this._scope.listFilter.taskType;
        }else{
            filterObj.taskType = null;
        }
        filterObj.searchPattern = this._scope.listFilter.searchString;

        if( this._scope.listFilter.taskType == "package_management" && this._scope.listFilter && this._scope.listFilter.packages_filters){
            if(this._scope.listFilter.packages_filters.type){
                filterObj.packages_filters = filterObj.packages_filters || {};
                filterObj.packages_filters.type = this._scope.listFilter.packages_filters.type
            }
            if(this._scope.listFilter.packages_filters.number){
                filterObj.packages_filters = filterObj.packages_filters || {};
                filterObj.packages_filters.number = this._scope.listFilter.packages_filters.number
            }
            if(this._scope.listFilter.packages_filters.version){
                filterObj.packages_filters = filterObj.packages_filters || {};
                filterObj.packages_filters.version = this._scope.listFilter.packages_filters.version
            }
        }
        return filterObj;
    }


  private initParameterStorageService(){
        this._storageType = STORAGE_TYPE.SESSION_STORAGE;
        this._scope.stateRestored = false;
        this._filterChange = false;

        this._storage.restoreState(this._storageKey,this._storageType,this._scope);
        if(typeof this._scope.listFilter.create_dt != "undefined" && this._scope.listFilter.create_dt != null) {
          if(this._scope.listFilter.create_dt.from != null && typeof this._scope.listFilter.create_dt.from == "string"){
            this._scope.listFilter.create_dt.from = new Date((<any>this._scope.listFilter.create_dt.from).toString());
          }
          if(this._scope.listFilter.create_dt.to != null && typeof this._scope.listFilter.create_dt.to == "string"){
            this._scope.listFilter.create_dt.to = new Date((<any>this._scope.listFilter.create_dt.to).toString());
          }
        }

        if(typeof this._scope.listFilter.status_dt != "undefined" && this._scope.listFilter.status_dt != null) {
          if(this._scope.listFilter.status_dt.from != null && typeof this._scope.listFilter.status_dt.from == "string"){
            this._scope.listFilter.status_dt.from = new Date((<any>this._scope.listFilter.status_dt.from).toString());
          }
          if(this._scope.listFilter.status_dt.to != null && typeof this._scope.listFilter.status_dt.to == "string"){
            this._scope.listFilter.status_dt.to = new Date((<any>this._scope.listFilter.status_dt.to).toString());
          }
        }

        if(this._scope.pageSize == null || typeof this._scope.pageSize == "undefined")
          this._scope.pageSize = 10;

        this._scope.stateRestored = true;
    }

    

    private initAbortFuncionality(){

        this._scope.showAbortButton = (taskData: ITaskItemDisplay) =>{
            var ngShow = !taskData.showTaskAbortConfirmation && taskData.taskAbortPromise == null && this.taskAbortAvaliabls(taskData);
            return ngShow;
        };

        this._scope.showTaskAbortConfirmation = (taskData: ITaskItemDisplay, setValue?:boolean)=>{
            if(typeof setValue == "boolean"){
                taskData.showTaskAbortConfirmation = setValue;
            }

            return  taskData.showTaskAbortConfirmation && taskData.taskAbortPromise == null && this.taskAbortAvaliabls(taskData);
        };

        

        this._scope.taskAbort = (taskData: ITaskItemDisplay)=>{
            taskData.taskAbortPromise = this._groupOperationsService.abortTaskItem(taskData.id, taskData.asdid).then((responce:IAbortRequestResult)=>{
                taskData.taskAbortPromise = null;
                taskData.taskItemAbortedOk = true;
                taskData.showTaskAbortConfirmation = false;
                this._timeout(3000).then(()=> {
                    if(this._lastTableState && this._tableCtrl) {
                        this.getGroupOperationList(this._lastTableState, this._tableCtrl);
                    }
                });
                taskData.AbortedOperation  = responce.operation;
                taskData.taskAbortedFail = null;
            }).catch((reason:any)=>{
                taskData.taskAbortPromise = null;
                taskData.taskAbortedFail = reason.data;
                taskData.showTaskAbortConfirmation = false;
            });
        };

        this._scope.canCancleSelectedTask = ()=>{
            var _canCancleSelectedTask = false;
            if(this._scope.selection && this._scope.selection.length > 0){
                _canCancleSelectedTask = true;
                this._scope.selection.forEach((task)=>{
                    if(task.status == "FINISHED" || task.status == "UNKNOWN"){
                        _canCancleSelectedTask = false;
                    }
                });
            }
            return _canCancleSelectedTask;
        };

        this._scope.cancelSelectedTask = (confirmation?:boolean)=>{
            
            if(confirmation) {
                this._scope.showAbordConfirmation = false;
                this.cancelSelectedTask();
            }else{
                var hasTaskToAbort = false;
                this._scope.selection.forEach((taskData:ITaskItemDisplay) =>{
                   if(this._groupOperationsService.getAbortOperationTypeForTask(taskData) == 'abort'){
                       hasTaskToAbort = true;
                   }
                });
                if(hasTaskToAbort) {
                    this._scope.showAbordConfirmation = true;
                    this.hideTaskAbortNotyfication();
                }else {
                    this.cancelSelectedTask();
                    this._scope.showAbordConfirmation = false;
                }
            }
        };

        this._scope.hideTaskAbortNotyfication = ()=>{
            this.hideTaskAbortNotyfication();
        };
    }
    private taskAbortAvaliabls(taskData: ITaskItemDisplay):boolean{
        if(taskData.type == "parameter_change" || taskData.type == "command" ||  taskData.type == "package_management")
        {
            return taskData.status == "PENDING" || taskData.status == "IN_PROGRESS";
        }else{
            return false;
        }
    }

    private hideTaskAbortNotyfication(){
        this._scope.updateLastAbortSummary = null;
        this._scope.tasksList.forEach((taskData)=>{
            delete taskData.AbortedOperation;
            delete taskData.taskAbortedFail;
            delete taskData.taskItemAbortedOk;
            delete taskData.taskAbortPromise;
            taskData.showTaskAbortConfirmation = false
        });
    }

    private updateTaskData(taskData:ITaskItemDisplay){
        this._groupOperationsService.getTask(taskData.id).then((newTaskData:ITaskItemDisplay)=> {
            var indexToReplace = null;
            this._scope.tasksList.forEach((t, i) => {
                if (t.id == taskData.id) {
                    indexToReplace = i
                }
            });
            if (indexToReplace != null) {
                newTaskData.hasDetailsData = false;
                this.calculateTaskDispalyFields(newTaskData);
                var oldTaskData = this._scope.tasksList.splice(indexToReplace, 1, newTaskData)[0];
                newTaskData.taskItemAbortedOk = oldTaskData.taskItemAbortedOk;
                newTaskData.showTaskAbortConfirmation = oldTaskData.showTaskAbortConfirmation;
                newTaskData.AbortedOperation = oldTaskData.AbortedOperation;
                newTaskData.taskAbortedFail = oldTaskData.taskAbortedFail;
                newTaskData.showRawData = oldTaskData.showRawData;
                newTaskData.showDetails = oldTaskData.showDetails;
            }
        });
    }

    private updateLastAbortSummary() {
        var WaitingForResponce: number = 0;
        var TaskCorrectlyAborted: number = 0;
        var TaskCorrectlyCanceled: number = 0;
        var FailToAbortTask: number = 0;
        var FailToCancelTask: number = 0;

        _.each(this._scope.tasksList, (taskItem: ITaskItemDisplay) => {
            if (taskItem.taskAbortPromise != null) {
                WaitingForResponce++;
            } else if (taskItem.taskAbortedFail != null) {
                if (taskItem.AbortedOperation == 'cancel') {
                    FailToCancelTask++;
                } else if (taskItem.AbortedOperation == 'abort') {
                    FailToAbortTask++;
                }
            } else if (taskItem.taskItemAbortedOk) {
                if (taskItem.AbortedOperation == 'cancel') {
                    TaskCorrectlyCanceled++;
                } else if (taskItem.AbortedOperation == 'abort') {
                    TaskCorrectlyAborted++;
                }
            }
        });
        if (WaitingForResponce + TaskCorrectlyAborted + TaskCorrectlyCanceled + FailToAbortTask + FailToCancelTask > 0) {
            this._scope.updateLastAbortSummary = {
                WaitingForResponce: WaitingForResponce,
                TaskCorrectlyAborted: TaskCorrectlyAborted,
                TaskCorrectlyCanceled: TaskCorrectlyCanceled,
                FailToAbortTask: FailToAbortTask,
                FailToCancelTask: FailToCancelTask,
                AllTask: WaitingForResponce + TaskCorrectlyAborted + TaskCorrectlyCanceled + FailToAbortTask + FailToCancelTask
            }
        }
        console.log(this._scope.updateLastAbortSummary)
    }

    private cancelSelectedTask(){
        if(this._scope.selection && this._scope.selection.length > 0) {
            this.hideTaskAbortNotyfication();

            this._scope.updateLastAbortSummary = null
            this._scope.tasksList.forEach((taskData)=>{
                delete taskData.AbortedOperation;
                delete taskData.taskAbortedFail;
                delete taskData.taskItemAbortedOk;
                delete taskData.taskAbortPromise;
                taskData.showTaskAbortConfirmation = false;

            });

            var taskAbortPromises:ng.IPromise<IAbortRequestResult>[] = [];

            this._scope.selection.forEach((taskData:ITaskItemDisplay) => {
                taskData.taskAbortPromise = this._groupOperationsService.abortTaskItem(taskData.id, taskData.asdid).then((responce:IAbortRequestResult)=>{
                    taskData.taskAbortPromise = null;
                    taskData.taskItemAbortedOk = true;
                    taskData.showTaskAbortConfirmation = false;
                    taskData.AbortedOperation  = responce.operation;
                    taskData.taskAbortedFail = null;
                    this._timeout(3000).then(()=> {
                        this.updateTaskData(taskData);
                    });
                    this.updateLastAbortSummary();
                }).catch((reason:any)=>{
                    taskData.taskAbortPromise = null;
                    taskData.taskAbortedFail = reason.data;
                    taskData.AbortedOperation = reason.data.operation;
                    taskData.showTaskAbortConfirmation = false;
                    this._timeout(3000).then(()=> {
                        this.updateTaskData(taskData);
                    });
                    this.updateLastAbortSummary();
                });
                taskAbortPromises.push(taskData.taskAbortPromise);
            });
            this._q.all(taskAbortPromises).finally(()=>{
                this.updateLastAbortSummary();
            });
            this.updateLastAbortSummary();
        }
    }

    
}
function deviceTaskListDirective ($branding) {
    return {
        restrict: "E",
        scope: {
        asdid: '=devAsdid',
        },
        controller: DeviceTaskListController,
        templateUrl: $branding.getTemplateUrl("directives.deviceTaskList"),

    }
};

export default angular.module('directives.deviceTaskList', [GroupOperationsServiceModule.name, DeviceServiceModule.name, DeviceModelsServiceModule.name])
  .directive('deviceTaskList', ['$branding', deviceTaskListDirective])
