/**
 * Created by rosadnik on 19-Jul-16.
 */

interface displayJsonObject_controller_scope extends ng.IScope{
    json:any;
    checkType:(value:any)=>string;
    objectDescription:(value:any)=>string;
    arrayDescription:(value:any)=>string;
}

class displayJsonObject_controller{
    constructor(private _scope:displayJsonObject_controller_scope, private _rootScope:any){
        this._scope.checkType = (value)=>{
            if(value === null) {
                return "null";
            }
            if(Array.isArray(value)) {
                return "array";
            }
            return typeof value;
        };
        this._scope.objectDescription = (value)=>{
            var propertyCounter = 0;
            for(var i in value){
                if(value.hasOwnProperty(i) && i.startsWith("$") == false) propertyCounter++;
            }
    
            if(propertyCounter == 0){
                return "Empty Object";
            }else if(propertyCounter == 1){
                return "Object with 1 propertie";
            }else{
                return  "Object with "+propertyCounter+" properties";
            }
        };
    
        this._scope.arrayDescription = (value)=>{
            if(value.length == 0){
                return "Empty Array";
            }else if(value.length == 1){
                return "Array with 1 item";
            }else{
                return  "Array with "+value.length+" items";
            }
        };
        
    };
}

var angularModule = angular.module('views.DeviceHistory.directives.displayJsonObject',[]);
angularModule.directive('displayJsonObject',['$branding', function($branding: app.branding.IBrandingService){
    return {
        templateUrl: '/components/src/directives/jsonDisplay/displayJsonObject.html',
        controller: ["$scope", "$rootScope", displayJsonObject_controller],
        scope: {
            "json": "<"
        }
    };
}]);

export default angularModule;