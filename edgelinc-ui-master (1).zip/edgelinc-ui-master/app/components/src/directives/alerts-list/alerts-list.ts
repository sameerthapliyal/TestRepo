///<reference path="../../../../../typings/browser.d.ts"/>
/// <reference path="../../definitions/eapi/Alarm.d.ts" />
/// <reference path="../../services/DeviceService.ts" />
/// <reference path="../../services/CommonServices.ts" />
/// <reference path="../../services/AlertListService.ts" />
/// <reference path="../../services/BrandingService.ts" />
///<reference path="../../utilities/decorators.ts"/>


import ParameterStorageServiceModule, {IParameterStorageService, STORAGE_TYPE} from "../../services/ParameterStorageService";
import AlertListServiceModule, {AlertListService, AlertFilter} from "../../services/AlertListService";
import CommonServicesModule, {CommonServices} from "../../services/CommonServices";
import QueryParserModule, {IScopeBinderService, IScopeBinder} from "../../utilities/ScopeBinder";
import stCustomExportContextWrapperModule from "../../directives/smart-table/st-custom-export-context-wrapper";


interface IAlertDisplay {
    uniqueId: string;
    id: string;
    description: string;
    timestamp: number;
    state: string;

    severity: string;
    severityCss: string;
    severityLabel: string;

    system: {
        asdid: string;
        name: string;
        did: string;
        numericDID: string;
    };
    device: {
        asdid: string;
        name: string;
        modelId: string;
        modelVersion: string;
        modelName: string;
        type: string;
    },
    raw: any

    hasDetails: boolean;
    toggleDetails(): void;
    detailsPromise?: ng.IPromise<App.Models.IParsedDescription>;
    details?: App.Models.IParsedDescription;
    detailsVisible: boolean;
}
interface AlertsTableControllerScope extends ng.IScope {
    systemId: string;
    asdid: string;
    listFilter: AlertFilter;
    showCheckboxes: boolean;
    alerts: IAlertDisplay[];
    visibleAlertCount: number;
    filteredAlertCount: number;
    inProgress: boolean;
    isLoading: boolean;
    pipe(tableState:any, tableCtrl:any): void;
    pageSize: number;
    toggleAlarmDetails(alarm: App.Models.IAlert): void;
    offset: number;
}

interface AlertsListControllerScope extends ng.IScope {
    systemId: string;
    enableQueryBinding: boolean;
    listFilter: AlertFilter;
    visibleAlertCount: number;
    filteredAlertCount: number;
    isLoading: boolean;
    onFilterChange(): void;
    onFilterClick(): void;
    onClearFilterClick(): void;
    refreshTable(): void;
    stateRestored:boolean;
    offset: number;

}

class AlertsTableController {
    public static $inject = ['$scope', '$q', '$timeout', 'ParameterStorageService', 'CommonServices', 'AlertListService'];

    private tableState: any;

    private scopePropertiesToSave:string[] = ["pageSize"];
    private storageKey:string = "alert-table-storage";
    private storageType:STORAGE_TYPE;

    constructor(private $scope: AlertsTableControllerScope,
                private $q: ng.IQService,
                private $timeout: ng.ITimeoutService,
                private ParameterStorageService: IParameterStorageService,
                private CommonServices: CommonServices,
                private AlertListService: AlertListService
    ) {
        $scope.alerts = [];
        $scope.filteredAlertCount = 1;
        $scope.inProgress = true;
        $scope.isLoading = true;
        var doRequestThrottled = $q.throttle(() => this.doRequest(), 1000);

        this.initTableParameterStorageService();

        $scope.pipe = (_tableState:any) => {
            this.customSaveState();
            this.tableState = _tableState;
            doRequestThrottled();
        };

        $scope.$on(this.getChangeNotificationEventName(), ()=>{
            if(this.tableState) {
                doRequestThrottled();
          }
        });
    }

    private initTableParameterStorageService(){
         this.storageType = STORAGE_TYPE.SESSION_STORAGE;
         this.ParameterStorageService.restoreState(this.storageKey,this.storageType,this.$scope);
         if(this.$scope.pageSize == null || typeof this.$scope.pageSize == "undefined")
            this.$scope.pageSize = 10;
     }

     private customSaveState() {
        this.ParameterStorageService.saveState(this.$scope,this.storageKey,this.storageType, this.scopePropertiesToSave);
     }

    private doRequest() {
      var sortColumn = null;
      var sortDir: any = null;
      if (this.tableState.sort && this.tableState.sort.predicate) {
          sortColumn = this.tableState.sort.predicate;
          sortDir = this.tableState.sort.reverse ? "desc" : "asc";
      } else {
          sortColumn = "timestamp";
          sortDir = "desc";
          this.tableState.sort.predicate = "timestamp";
          this.tableState.sort.reverse = true;
      }
      var limit = this.tableState.pagination.number;
      this.$scope.offset = this.tableState.pagination.start;
      var listFilter = this.$scope.listFilter;
      /*var listFilter = JSON.parse(JSON.stringify(this.$scope.listFilter));
        if(typeof listFilter.systemId != "undefined") {
          listFilter.deviceModels = null;
        }
      */
        return this.getAlerts(listFilter, sortColumn, sortDir, limit, this.$scope.offset)
            .then((result:App.Models.SearchResult<App.Models.IAlert>) => {
                this.$scope.inProgress = false;
                this.$scope.isLoading = false;
                var oldAlerts = _.indexBy(this.$scope.alerts, (alert: IAlertDisplay) => alert.uniqueId);
                this.$scope.alerts = _.map(result.items, (alarm: App.Models.IAlert) => {
                    var system = null;
                    if(alarm.system) {
                        system = {
                            asdid: alarm.system.asdid,
                            name: alarm.system.name || alarm.systemName,
                            //did: alarm.system.did,
                            //numericDID: alarm.system.numericDID,
                            //attributes: alarm.system.attributes
                        }
                    }else{
                        system = {
                            asdid: alarm.systemId,
                            name: alarm.systemName
                        }
                    }
                    var device = null;
                    if(alarm.device){
                        device = {
                            asdid: alarm.device.asdid,
                            name: alarm.device.name,
                            modelId: alarm.device.model.id,
                            modelVersion: alarm.device.model.version,
                            modelName: alarm.device.model.name,
                            //type: alarm.device.type
                        }
                    } else {
                        device = {
                            asdid: alarm.asdid,
                            name: (<any>alarm).device_name,
                            modelId: alarm.device_model_id,
                            modelVersion: alarm.device_model_version,
                            modelName: (<any>alarm).device_model_name,
                            type: (<any>alarm).device_type
                        }
                    }

                    var newAlert: IAlertDisplay = {
                        uniqueId: alarm.uniqueId,
                        id: alarm.id,
                        description: alarm.description,
                        timestamp: alarm.timestamp,
                        state: alarm.state,

                        severity: alarm.severity,
                        severityCss: alarm.severityCss,
                        severityLabel: alarm.severityLabel,
                        system: system,
                        device: device,
                        raw: alarm.raw,

                        hasDetails: alarm.hasDescription,
                        toggleDetails: function(){
                            var _thisAlert: IAlertDisplay = this;
                            if(_thisAlert.detailsVisible) {
                                _thisAlert.detailsVisible = false;
                            } else {
                                _thisAlert.detailsVisible = true;
                                _thisAlert.detailsPromise = alarm.getDescription();
                                _thisAlert.detailsPromise.then(description => {
                                    _thisAlert.details = description;
                                });
                            }
                        },
                        details: oldAlerts[alarm.uniqueId] ? oldAlerts[alarm.uniqueId].details : undefined,
                        detailsPromise: oldAlerts[alarm.uniqueId] ? oldAlerts[alarm.uniqueId].detailsPromise : undefined,
                        detailsVisible: oldAlerts[alarm.uniqueId] ? oldAlerts[alarm.uniqueId].detailsVisible : false
                    };
                    if(newAlert.detailsPromise) {
                        newAlert.detailsPromise.then(description => {
                            newAlert.details = description;
                        });
                    }
                    return newAlert;
                });
                this.$scope.visibleAlertCount = this.$scope.alerts.length;
                this.$scope.filteredAlertCount = result.totalCount;
                //this.tableState.pagination.numberOfPages = Math.ceil(result.totalCount / this.tableState.pagination.number);
                this.tableState.pagination.totalItemCount = result.totalCount;
            })
    }

    private getAlerts(filters?: AlertFilter, sortBy?: string, sortOrder?: eapi18.SortOrder, limit?: number, offset?: number) {
        filters = _.clone(filters);
        filters.asdid = this.$scope.asdid;
        filters.systemId = this.$scope.systemId;
        return this.AlertListService.getAllAlerts(filters, sortBy, sortOrder, limit, offset);
    }

    private getChangeNotificationEventName(): string {
        if(this.$scope.asdid != null) {
            return `event:${this.$scope.asdid}:AlarmNotification`;
        } else {
            return this.AlertListService.onAlarmNotification_EventName;
        }

    }

}


class AlertsListController {

    public static $inject = ['$scope', '$timeout', 'ParameterStorageService'];
    private filterChange:boolean = false;
    private scopePropertiesToSave:string[];

    private storageKey:string;
    private storageType:STORAGE_TYPE;


    constructor(private $scope: AlertsListControllerScope,
                private $timeout: ng.ITimeoutService,
                private ParameterStorageService: IParameterStorageService
    ) {

        $scope.filteredAlertCount = null;
        $scope.isLoading = null;
        $scope.listFilter = {};
        $scope.listFilter["systemId"] = $scope.systemId;
        if(typeof $scope.systemId != "undefined") {
          this.storageKey = "alarm-list-filters-with-systemId";
          this.scopePropertiesToSave = ["listFilter.severities", "listFilter.setDateRange.from", "listFilter.setDateRange.to", "listFilter.searchPattern"];
        } else {
          this.storageKey = "alarm-list-filters";
          this.scopePropertiesToSave = ["listFilter.deviceModels", "listFilter.searchPattern", "listFilter.setDateRange.from", "listFilter.setDateRange.to", "listFilter.severities"];
        }
        this.initParameterStorageService();


        $scope.onFilterChange = _.throttle(() => this.onFilterChanged(), 1000);
        $scope.onFilterClick = () => this.onFilterChanged();
        $scope.onClearFilterClick = () => this.clearFilters();
        $scope.refreshTable = () => this.onRefreshTable();
    }


    private clearFilters() {
        this.$scope.listFilter = {
            systemId: this.$scope.systemId,
            searchFields: this.$scope.listFilter.searchFields
        };
        this.customSaveState();
        this.onFilterChanged();
    }

    private onFilterChanged() {
        this.$scope.$broadcast('smartTable:refreshRequired');
        if(this.$scope.stateRestored ){
          this.customSaveState();
        }
    }

    private onRefreshTable(){
        this.$scope.$broadcast('smartTable:refreshRequired');
    };

    private initParameterStorageService(){
        this.storageType = STORAGE_TYPE.SESSION_STORAGE;
        this.$scope.stateRestored = false;
        this.filterChange = false;
        //this.scopePropertiesToSave = ["listFilter.deviceModels", "listFilter.searchPattern", "listFilter.setDateRange.from", "listFilter.setDateRange.to",
        //                              "listFilter.severities"];
        this.ParameterStorageService.restoreState(this.storageKey,this.storageType,this.$scope);
        this.$scope.stateRestored = true;
    }

    private customSaveState() {
        this.$timeout(()=>{
            this.ParameterStorageService.saveState(this.$scope,this.storageKey,this.storageType, this.scopePropertiesToSave);
        });
    }
}

var angularModule = angular.module('directives.alerts.list', [ParameterStorageServiceModule.name, QueryParserModule.name, CommonServicesModule.name, AlertListServiceModule.name,
    stCustomExportContextWrapperModule.name]);

export default angularModule;


interface AlertsFiltersDirectiveScope extends ng.IScope {
    listFilter: AlertFilter;
    filterChanged(): void;
    filterQueryBinding: string;
    onFilterChange(): void;
}

function DeviceAlertsListDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('DeviceAlertsListDirective'),
        controller:'AlertsListController',
        scope: {
            asdid: '=',
            enableQueryBinding: '=?'
        },
    }
}
function DeviceAlertsTableDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl(['DeviceAlertsTableDirectives', 'AlertsTableDirectives']),
        controller:'AlertsTableController',
        scope: {
            asdid: '=',
            listFilter: '=',
            visibleAlertCount: '=',
            filteredAlertCount: '=',
            offset: '=?',
            isLoading: '=',
            showCheckboxes: '=',
            tableType: '@?'
        }
    }
}
function DeviceAlertsFiltersDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('DeviceAlertsFiltersDirective'),
        scope: {
            listFilter: '=',
            filterChanged: '&',
            enableQueryBinding: '=?'
        },
        link: (scope: AlertsFiltersDirectiveScope) => {
            scope.onFilterChange = () => scope.filterChanged();
        }
    }
}
function SystemAlertsListDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('SystemAlertsListDirective'),
        controller:'AlertsListController',
        scope: {
            systemId: '=',
            enableQueryBinding: '=?'
        },
    }
}
function SystemAlertsTableDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl(['SystemAlertsTableDirective', 'DeviceAlertsTableDirectives']),
        controller:'AlertsTableController',
        scope: {
            systemId: '=',
            listFilter: '=',
            visibleAlertCount: '=',
            filteredAlertCount: '=',
            offset: '=?',
            isLoading: '=',
            showCheckboxes: '=',
            tableType: '@?'
        }
    }
}
function SystemAlertsFiltersDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('SystemAlertsFiltersDirective'),
        scope: {
            listFilter: '=',
            filterChanged: '&',
            enableQueryBinding: '=?'
        },
        link: (scope: AlertsFiltersDirectiveScope) => {
            scope.onFilterChange = () => scope.filterChanged();
        }
    }
}

function GlobalAlertsListDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('GlobalAlertsListDirective'),
        controller:'AlertsListController',
        scope: {
            enableQueryBinding: '=?'
        }
    }
}
function GlobalAlertsTableDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl(['GlobalAlertsTableDirective', 'GlobalAlertsTableDirectives']),
        controller:'AlertsTableController',
        scope: {
            listFilter: '=',
            visibleAlertCount: '=',
            filteredAlertCount: '=',
            offset: '=?',
            isLoading: '=',
            showCheckboxes: '=',
            tableType: '@?'
        }
    }
}
function GlobalAlertsFiltersDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('GlobalAlertsFiltersDirective'),
        scope: {
            listFilter: '=',
            filterChanged: '&',
            enableQueryBinding: '=?'
        },
        link: (scope: AlertsFiltersDirectiveScope) => {
            scope.onFilterChange = () => scope.filterChanged();
        }
    }
}




angularModule
    .controller('AlertsTableController', AlertsTableController)
    .controller('AlertsListController', AlertsListController)
    .directive('deviceAlertsList', ['$branding', DeviceAlertsListDirective])
    .directive('deviceAlertsTable', ['$branding', DeviceAlertsTableDirective])
    .directive('deviceAlertsFilters', ['$branding', DeviceAlertsFiltersDirective])
    .directive('systemAlertsList', ['$branding', SystemAlertsListDirective])
    .directive('systemAlertsTable', ['$branding', SystemAlertsTableDirective])
    .directive('systemAlertsFilters', ['$branding', SystemAlertsFiltersDirective])
    .directive('globalAlertsList', ['$branding', GlobalAlertsListDirective])
    .directive('globalAlertsTable', ['$branding', GlobalAlertsTableDirective])
    .directive('globalAlertsFilters', ['$branding', GlobalAlertsFiltersDirective])
;
