///<reference path="../../../../typings/browser.d.ts"/>

var angularModule = angular.module('directives.guiVersion', []);
export default angularModule;

interface IGuiVersionScope extends ng.IScope{
    guiVersion:string;
}

class guiVersionController {
    private static $inject = ['$scope'];
    constructor($scope) {
    }
}

angularModule.directive('guiVersion', () => {
    return {
        template: `
            <li>
                <a>
                    <i class="fa fa-info"></i> <b>GUI</b> ver. {{ guiVersion }}
                </a>
            </li>
        `,
        restrict: "E",
        replace: true,
        transclude: true,
        controller: guiVersionController,
        scope: {
            guiVersion: "@"
        },
        link: (scope:IGuiVersionScope, element, attributes) => {
            scope.guiVersion = window.CONFIG.VERSION;
        }
    }
});
