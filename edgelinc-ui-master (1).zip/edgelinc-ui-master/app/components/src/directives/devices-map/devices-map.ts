///<reference path="../../../../../typings/browser.d.ts"/>

import SelectedNodeModule from "../leaflet/selected-node/selected-nodes";
import ClusteredMarkersSourceDirectiveModule, {IClusteredMarkersSourceOptions} from "../leaflet/clustered-markers-source/clustered-markers-source";
import MapsServiceModule, {MapsService} from "../../services/MapsService";
import {ISystemFilter} from "../../services/DeviceService";

interface IDevicesMapDirectiveScope extends ng.IScope {
    zoomControlPosition: ng.leaflet.ControlPosition;
    filter: ISystemFilter;
    classes: string;
    enableSelection: boolean;
    selectedAsdid: string;
    onNodeClick(args: {asdid: string}): void;
    isActive: boolean;
    bounds: ng.leaflet.Bounds;
    maxBounds: ng.leaflet.Bounds;
    defaults: ng.leaflet.Defaults;
    events: ng.leaflet.EventBroadcast;
    layers: ng.leaflet.Layers;
    markersSource: IClusteredMarkersSourceOptions;
}

export class DevicesMapDirectiveController {

    static $inject = ['$scope','$timeout','$element','leafletData', 'MapsService'];

    constructor(private $scope: IDevicesMapDirectiveScope,
                private $timeout:ng.ITimeoutService,
                private $element:JQuery,
                private leafletData,
                private MapsService: MapsService
    ) {
        $scope.isActive = false;
        $scope.defaults = {
            scrollWheelZoom: $scope.isActive,
            zoomControlPosition: $scope.zoomControlPosition
        };

        $scope.layers = {
            baselayers: {
                osm: {
                    name: 'OpenStreetMap',
                    type: 'xyz',
                    url: '//{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                    layerOptions: {
                        showOnSelector: false,
                        subdomains: ['a', 'b', 'c'],
                        attribution: '© <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
                        noWrap: true
                    }
                }
            }
        };

        $scope.markersSource = {
            "devices": {
                enableRefreshing: true,
                getNodes: this.getNodes.bind(this)
            }
        };

        function resetBounds() {
            $scope.bounds = {
                northEast: {
                    lat: 49.38,
                    lng: -66.94
                },
                southWest: {
                    lat: 25.82,
                    lng: -124.39
                }
            };
        }

        resetBounds();
        $scope.maxBounds = {
            northEast: {
                lat: 90,
                lng: 180
            },
            southWest: {
                lat: -90,
                lng: -180
            }
        };

        // to listen for specific event, you must enumerate it here.
        // every event is logged to console and it's not possible to turning it off
        // (https://github.com/tombatossals/angular-leaflet-directive/issues/1033),
        // so avoid enumerating not used events (especially mouse events), to not flooding console
        $scope.events = {
            map: {
                enable: ['focus', 'blur'],
                logic: 'broadcast'
            },
            markers: {
                enable: ['click'],
                logic: 'broadcast'
            }
        };

        MapsService.onNodesRefreshed(() => this.refreshMap(), $scope);

        $scope.$watch('filter', () => this.refreshMap(), true);

        setTimeout(() => {
            var link: any = document.querySelectorAll(".map-container > .angular-leaflet-map > .leaflet-control-container .leaflet-control-attribution > a");
            for (var i in link) {
                if (link.hasOwnProperty(i)) {
                    link[i].setAttribute("target", "_blank");
                }
            }
        }, 100);

        $scope.$watch('isActive', (value: boolean) => {
            leafletData.getMap().then(function (map) {
                if (value) {
                    map.scrollWheelZoom.enable();
                } else {
                    map.scrollWheelZoom.disable();
                }
            });
        });

        $scope.$on('leafletDirectiveMap.focus', () => {
            $scope.isActive = true;
        });
        $scope.$on('leafletDirectiveMap.blur', () => {
            $scope.isActive = false;
        });
        $scope.$on('leafletDirectiveMarker.click', (ev, data) => {
            if(data.model && data.model.properties && data.model.properties.asdid) {
                //$scope.onNodeClick(data.model.asdid);
                $scope.onNodeClick({asdid: data.model.properties.asdid});
                if($scope.enableSelection) {
                    $scope.selectedAsdid = data.model.properties.asdid;
                }
            }
        });

        var first_showContent_Event = true;
        $scope.$on('event:showContent', () => {
            $scope.$broadcast('invalidateSize');
            var isHidden = $element[0].isHidden();
            if (first_showContent_Event && isHidden == false) {
                _.each(this.$scope.markersSource, layerOptions => layerOptions.enableRefreshing = false);
                first_showContent_Event = false
                $timeout(() => {
                    $scope.bounds = {};
                    $scope.$broadcast('invalidateSize');
                    $timeout(() => {
                        resetBounds();
                        _.each(this.$scope.markersSource, layerOptions => layerOptions.enableRefreshing = true);
                    }, 200);
                }, 10);
            }
        });
    }

    public getNodes(bounds: ng.leaflet.Bounds, zoomLevel: number): ng.IPromise<any> {
        var classes = undefined;
        if(this.$scope.classes) {
            classes = this.$scope.classes.split(',');
        }
        return this.MapsService.getClusteredDeviceNodes(bounds, zoomLevel, this.$scope.filter, classes, 60)
            .then(nodes => {
                return _.indexBy(nodes, "id");
            });
    }

    public refreshMap() {
        this.$scope.$broadcast("clusteredMarkersSource:refresh");
    }
}

function DevicesMapDirective() {
    return {
        restrict: "E",
        templateUrl: "/components/src/directives/devices-map/devices-map.html",
        controller: DevicesMapDirectiveController,
        scope: {
            zoomControlPosition: '@',
            enableSelection: '=?',
            selectedAsdid: '=?',
            filter: '=',
            classes: '@?',
            onNodeClick: '&'
        }
    }
}

export default angular.module("directives.devicesMap", ["leaflet-directive", SelectedNodeModule.name, ClusteredMarkersSourceDirectiveModule.name, MapsServiceModule.name])
    .directive('devicesMap', DevicesMapDirective);
