///<reference path="../../../../../typings/browser.d.ts"/>

import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";

interface ProxModelVersionSelectorScope extends ng.IScope {
    deviceModelId: string,
    modelVersion: string;
    modelVersions: string[];
}
function ProxModelVersionSelectorDirective($q: ng.IQService, DeviceModelsService: DeviceModelsService) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            deviceModelId: "<",
            modelVersion: '=ngModel'
        },
        templateUrl: "/components/src/directives/form-controls/prox-model-version-selector.html",
        link: (scope: ProxModelVersionSelectorScope) => {
            function loadModelVersions() {
                if(scope.deviceModelId == null) {
                    scope.modelVersions = [];
                    return $q.when();
                }
                scope.modelVersions = null;
                return DeviceModelsService.getDeviceModel(scope.deviceModelId).then(deviceModel => {
                    scope.modelVersions = deviceModel.versions;
                })
            }

            var loadModelVersionsThrottled = $q.throttle(loadModelVersions);
            scope.modelVersions = [];
            scope.$watch("deviceModelId", loadModelVersionsThrottled);
        }
    }
}

export default angular.module('formControls.proxModelVersionSelector', [DeviceModelsServiceModule.name])
    .directive('proxModelVersionSelector', ["$q", "DeviceModelsService", ProxModelVersionSelectorDirective]);