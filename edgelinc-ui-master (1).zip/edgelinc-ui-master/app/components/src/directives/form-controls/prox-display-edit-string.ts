/**
 * Created by rosadnik on 06-Apr-16.
 */
///<reference path="../../../../../typings/browser.d.ts"/>


interface proxDisplayEditStringController extends ng.IScope{
    displayName:string;
    value:string;
    edit:boolean;
    password?:boolean;
    number?:boolean;
    inputType:string;
    email?:boolean;
    numberMin:number;
    numberMax:number;
    pattern:string;
    blackList:string[];
}

class proxDisplayEditStringController{
    constructor(private _element:any, private _scope:proxDisplayEditStringController, private transclude: any){
        this._scope.inputType = "text";
        if( this._scope.password){
            this._scope.inputType = "password";
        }else if( this._scope.email){
            this._scope.inputType = "email";
        }else if( this._scope.number){
            this._scope.inputType = "number";
        }

        this.applyTransclude(".additionalDescription","additionalDescription")
    }

    private applyTransclude(targetSelector, TranscludeName){
        var TranscludeLocations = this._element[0].querySelectorAll(targetSelector);
        _.each(TranscludeLocations, (TranscludeLocation)=>{
            this.transclude(this._scope.$parent, (transEl, transScope)=> {
                angular.element(TranscludeLocation).append(transEl);
            }, this._scope.$parent.$parent, TranscludeName );
        });
    }
}

var angularModule = angular.module('directives.formControls', []);
export default angularModule;

angularModule.controller('proxDisplayEditStringController', ['$element', '$scope', '$transclude',proxDisplayEditStringController]);
angularModule.directive('proxDisplayEditString', function () {
    return {

        templateUrl: "/components/src/directives/form-controls/prox-display-edit-string.html",
        restrict: "E",
        controller: "proxDisplayEditStringController",
        scope: {
            displayName:"@",
            value: "=",
            edit: "=",
            password: "=?",
            number: "=?",
            numberMin: "=?",
            numberMax: "=?",
            maxlength: "=?",
            email: "=?",
            name:"@",
            ngRequired:"<?required",
            pattern:"@",
            blackListValues:"<?",
            blackListMessage:"@"
        },
        transclude: {
            'additionalDescription':'?additionalDescription'
        },
        link: (scope, element, attributes) => { }
    }
});