///<reference path="../../../../../typings/browser.d.ts"/>

import DeviceModelsServiceModule, {DeviceModelsService} from "../../services/DeviceModelsService";

interface IDeviceModel {
    id: string;
    name: string;
}

interface ProxModelSelectorScope extends ng.IScope {
    deviceModelId: string,
    deviceModels: IDeviceModel[];
}
function ProxModelSelectorDirective(DeviceModelsService: DeviceModelsService) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            deviceModelId: '=ngModel'
        },
        templateUrl: "/components/src/directives/form-controls/prox-model-selector.html",
        link: (scope: ProxModelSelectorScope) => {
            DeviceModelsService.getDeviceModels().then(deviceModels => {
                scope.deviceModels = deviceModels;
            })
        }
    }
}

export default angular.module('formControls.proxModelSelector', [DeviceModelsServiceModule.name])
    .directive('proxModelSelector', ["DeviceModelsService", ProxModelSelectorDirective]);