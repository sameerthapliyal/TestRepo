///<reference path="../../../../../typings/browser.d.ts"/>

import RuleBundleRepositoryServiceModule, {RuleBundleRepositoryService, IRepositoryPackage} from "../../services/RuleBundleRepositoryService";
import {ISystemDisplay} from "../systems-list/systems-list";
import {HttpError} from "../../components/src/utilities/RestHelper";


//TODO Redirect to Request Management screen
var requestManagementModule = "views.requestManagement";

enum Step {
    deviceSelection,
    finalize,
    applyRuleBundle,
    sent
}

interface IApplyRuleBundleDirectiveScope extends ng.IScope {
    wizard: {
        step: Step,
        steps: any;
        back(): void;
        cancel(): void;
        finalize(): void;
        send(): void;
    }
    ruleBundleId: string,
    ruleBundleVersion: string,
    ruleBundleName: string,
    selectedPackage: IRepositoryPackage,
    inProgress: boolean,
    operation_id: string,
    selectedLocomotives: ISystemDisplay[];
    checkedLocomotives: {
        selectionAdd: ISystemDisplay[];
        selectionRemove: ISystemDisplay[];
        visibleLocomotives: ISystemDisplay[];
        pipe(tableState: any, tableCtrl: any): void;
        removeLocomotives(): void;
        addLocomotives(): void
        hasLocomotives: boolean;
    }
    onBackToList(): void;
    goToRequestManagement(): void;
    send(): void;
    minDate:Date;
    scheduleDate:Date;
    clearFilter(): void;
    listFilter: any;
    deployRuleBundleError:HttpError;
    requestIds: any;
}

class ApplyRuleBundleController {
    public static $inject = ['$scope', 'RuleBundleRepositoryService', '$routeParams', '$location', 'RouteHelpers'];
    private selectedLocomotives: ISystemDisplay[] = [];
    constructor(
      private $scope: IApplyRuleBundleDirectiveScope,
      private prs: RuleBundleRepositoryService,
      private $routeParams: any,
      private $location: ng.ILocationService,
      private RouteHelpers: app.IRouteHelpers) {
        $scope.wizard = {
            step: Step.deviceSelection,
            steps: Step,
            back: () => this.back(),
            cancel: () => this.cancel(),
            finalize: () => this.finalize(),
            send: () => this.send()
        };
        $scope.ruleBundleId = $routeParams.ruleBundleId;
        $scope.ruleBundleVersion = $routeParams.ruleBundleVersion;
        $scope.ruleBundleName = $routeParams.ruleBundleName;
        var ruleBundle: IRepositoryPackage = <any> {
                    ruleBundleId: $routeParams.ruleBundleId,
                    ruleBundleVersion: $routeParams.ruleBundleVersion,
                    ruleBundleName: $routeParams.ruleBundleName,
                    description:$routeParams.description,
                    lastUpdatedDate:$routeParams.lastUpdatedDate
                };
        $scope.selectedPackage = ruleBundle;

        /*prs.getPackage($scope.ruleBundleId, $scope.ruleBundleVersion, $scope.ruleBundleName).then((result:IRepositoryPackage) => {
            $scope.selectedPackage = result;

        })*/

        $scope.checkedLocomotives = {
            selectionAdd: [],
            selectionRemove: [],
            visibleLocomotives: [],
            pipe: (tableState: any, tableCtrl: any) => this.selectedLocomotivesPipe(tableState, tableCtrl),
            addLocomotives: () => this.addLocomotives(),
            removeLocomotives: () => this.removeLocomotives(),
            hasLocomotives: false
        }
        $scope.goToRequestManagement = () => this.goToRequestManagement();
        $scope.minDate = new Date();

        $scope.clearFilter = () => this.clearFilters();

    }

    private addLocomotives(): void {
        var currentSelectedLocomotives = _.indexBy(this.selectedLocomotives, p => p.asdid);
        _.each(this.$scope.checkedLocomotives.selectionAdd, p => {
            if (!_.has(currentSelectedLocomotives, p.asdid)) {
                var clone = _.clone(p);
                clone.isChecked = false;
                this.selectedLocomotives.push(clone);
            }
        });
        this.$scope.checkedLocomotives.hasLocomotives = this.selectedLocomotives.length > 0;
        this.$scope.checkedLocomotives.selectionAdd = null;
        this.$scope.selectedLocomotives = this.selectedLocomotives;
        this.$scope.$broadcast("selectedLocomotives:refresh");
    }

    private removeLocomotives(): void {
        this.selectedLocomotives = _.difference(this.selectedLocomotives, this.$scope.checkedLocomotives.selectionRemove);
        this.$scope.checkedLocomotives.hasLocomotives = this.selectedLocomotives.length > 0;
        this.$scope.checkedLocomotives.selectionRemove = null;
        this.$scope.selectedLocomotives = this.selectedLocomotives;
        this.$scope.$broadcast("selectedLocomotives:refresh");
    }

    private selectedLocomotivesPipe(tableState: any,tableCtrl:any): void {
        var limit = tableState.pagination.number;
        var offset = tableState.pagination.start;
        this.$scope.checkedLocomotives.visibleLocomotives = this.selectedLocomotives.slice(offset, offset + limit);
        //tableState.pagination.numberOfPages = Math.ceil(this.selectedLocomotives.length / tableState.pagination.number);
        tableState.pagination.totalItemCount = this.selectedLocomotives.length;
    }

    private finalize() {
        this.$scope.wizard.step = Step.finalize;
        this.$scope.$broadcast("selectedLocomotives:refresh");
    }

    private back() {
        this.$scope.wizard.step--;

    }

    private cancel() {
        this.selectedLocomotives = [];
        this.$scope.$destroy()
        this.$scope.onBackToList();
    }

    private send(){
      this.$scope.wizard.step = Step.applyRuleBundle;
      this.$scope.inProgress = true;
      this.$scope.requestIds = [];
      var asdids = [];
      var ruleBundleId = this.$scope.selectedPackage.ruleBundleId;
      var ruleBundleVersion = this.$scope.selectedPackage.version;
      var ruleBundleName = this.$scope.selectedPackage.ruleBundleName;
      var scheduleDate = this.$scope.scheduleDate;
      asdids = _.map(this.$scope.selectedLocomotives, (val) => {
        return val.did;
      });
      this.prs.applyRuleBundleNew(ruleBundleId, ruleBundleVersion, ruleBundleName, asdids, scheduleDate).then((response: any) => {
      //  this.$scope.operation_id = response[0].requestId;
      response.forEach( item => 
                      {
                          if(item.created)  
                              this.$scope.requestIds.push(item.requestId);
                      });
        this.$scope.inProgress = false;
        this.$scope.wizard.step = Step.sent;
        this.$scope.deployRuleBundleError = null;
      }).catch((httpError:HttpError)=>{
        //  this.back();
          this.$scope.inProgress = false;
          this.$scope.wizard.step = Step.sent;
          this.$scope.deployRuleBundleError = httpError;
      });
    }

    private goToRequestManagement() {
      //TODO Redirect to Request Management screen
   var route = (<any>window).BRANDING.menu.config[requestManagementModule].route;
    //var route = (<any>window).BRANDING.menu.config["views.rulebundlecreation"].route;
    this.$location.url(this.RouteHelpers.routeToLocation(route, {}));
    }

    private clearFilters() {
        this.$scope.listFilter = {
            searchFields: this.$scope.listFilter.searchFields
        }
    }
}

function ApplyRuleBundleDirective($branding: app.branding.IBrandingService) {
    return {
        templateUrl: $branding.getTemplateUrl('ApplyRuleBundleDirective'),
        link: function (scope: any, element: any, attr: any, ctrl: any) {
            scope.paginationLimit = 9007199254740991
        },
        controller: 'ApplyRuleBundleController',
        scope: {
            onBackToList: '&'
        }
    }
}


export default angular.module("directives.rulemanagement.applyRuleBundle", [RuleBundleRepositoryServiceModule.name])
    .controller("ApplyRuleBundleController", ApplyRuleBundleController)
    .directive("applyRuleBundle", ['$branding', ApplyRuleBundleDirective]);
