/**
 * Created by pradziej on 2015-12-09.
 */
/// <reference path="../../../../app.d.ts" />

import ParameterStorageServiceModule, {IParameterStorageService, STORAGE_TYPE} from "../../services/ParameterStorageService";

var headerController;
var angularModule = angular.module('directives.pageHeader',['ngRoute', 'ui.bootstrap',ParameterStorageServiceModule.name, 'utilities.routeHelpers', 'directives.breadcrumb']);
export default angularModule;

angularModule.controller('pageHeaderController',['$scope','$location','$rootScope', '$route', 'ParameterStorageService',
    function($scope, $location, $rootScope, $route, ParameterStorageService) {
        if(!headerController)
            headerController = new pageHeaderController($scope, $location, $route, ParameterStorageService);
        $rootScope.$on('$routeChangeStart', function(){
            headerController.routeChangeStart();
        });
        return headerController;
    }
]);

angularModule.directive('pageHeader',function(){
    return {
       templateUrl: "/components/src/directives/page-header/page-header.html",
       restrict: "E",
       controller: "pageHeaderController",
       scope:{
           breadcrumbData: '=',
           breadcrumbVisible: '='
       },
       link: (scope, element, attributes) => {
           if(headerController) {
               headerController.link(scope,attributes);
           }
       }
    };
});

class pageHeaderController{
    private _storage;
    private _location;
    private _route;
    private _storageKey;
    private _storageType: STORAGE_TYPE;

    constructor($scope:any, $location: any, $route: any, ParameterStorageService: IParameterStorageService){
        $scope.title = "";
        this._location = $location;
        this._route = $route;
        this._storage = ParameterStorageService;
        this._storageType = STORAGE_TYPE.SESSION_STORAGE;
        this._storageKey = "_ph" + this._route.current.loadedTemplateUrl;
    }

    public link(scope:any, attributes: any) {
        scope.title = attributes["title"];
        /*
        //read here everything from service
        var _state: any = this._storage.ReadJson(this._storageKey, this._storageType);
        if(_state) {
            for(var storedProperty in _state) {
                this._route.scope = _state[storedProperty];
            }
        }
        */
    }

    public routeChangeStart(){
        /*
        console.log("Writing to storage %s:%s", this._storageKey, JSON.stringify(this._route.scope));
        this._storage.SaveJson(this._storageKey, this._route.scope, this._storageType);
        */
    }
}
