///<reference path="../../../../../typings/browser.d.ts"/>
///<reference path="../../../../../app/components/src/utilities/stringBooleanParser.ts"/>


var angularModule = angular.module('directives.listHeader',[]);
export default angularModule;

interface IListHeaderScope {
    showAdvanceFilter: boolean;
    disableSearchString: boolean;
    onClearFilterClick: () => void;
    onFilterClick: () => void;
    onFilterChange: () => void;
    searchString: () => string;
    searchStringValidation: ()=> string;
}

angularModule.directive('listHeader', function(){
        return {
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
                onClearFilterClick: "=",
                onFilterClick: "=",
                onFilterChange: "=",
                searchString: "=",
                disableSearchString: "=",
                searchStringValidation: "="
            },
            controller: ['$scope', function($scope: IListHeaderScope) {
                $scope.showAdvanceFilter = true;
                if($scope.disableSearchString == null){
                    $scope.disableSearchString = false;
                } else if(typeof $scope.disableSearchString == "string"){
                    $scope.disableSearchString  = (<any>($scope.disableSearchString)).parseBoolean();
                }
            }],
            link: function(scope:any, element, attrs, controller, transclude) {

                function process(header, transcludedBlock) {
                    var titleBlock = header.querySelector('.list-title');
                    var filtersBlocks = header.querySelector('.list-filters');
                    var titleElement = transcludedBlock.querySelector('list-title');
                    var filtersElement = transcludedBlock.querySelector('list-filters');
                    titleBlock.appendChild(titleElement);

                    if(filtersElement != null && filtersElement.hasChildNodes()) {
                        filtersBlocks.appendChild(filtersElement);
                        scope.missingAdvanceFilter = false;
                    }else{
                        scope.missingAdvanceFilter = true;
                    }
                }

                var headers = element[0].querySelectorAll('header');
                for(var i=0; i<headers.length;i++) {
                    transclude(scope.$parent, function(clone, scope) {
                        var transcludedBlock = angular.element('<div/>').append(clone);
                        process(headers[i], transcludedBlock[0]);
                    });
                }
            },
            templateUrl: "/components/src/directives/list-header/list-header.html",
        };
    });