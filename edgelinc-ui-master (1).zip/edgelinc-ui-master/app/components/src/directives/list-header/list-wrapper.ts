///<reference path="../../../../../typings/browser.d.ts"/>
///<reference path="../../../../../app/components/src/utilities/stringBooleanParser.ts"/>

import CommonServicesModule, {CommonServices} from "../../../../components/src/services/CommonServices";

var angularModule = angular.module('directives.listWrapper',["services.branding", CommonServicesModule.name]);
export default angularModule;

interface IListWrapperScope extends ng.IScope{
    showAdvanceFilter: boolean;
    disableSearchString: boolean;
    showSearchString: () => boolean;
    showClearButton: boolean;
    missingAdvanceFilter: boolean;
    missingListTable: boolean;
    missingTitleIconBox: boolean;
    missingTabViews:boolean;
    missingIconBoxLeft:boolean
    missingTitle:boolean;
    missingSubTitle:boolean;
    missingSubTitleIconBox: boolean;
    iconBox_hasIconButtons:boolean;
    iconBox_hasTextButtons:boolean;
    iconBox_hasIconButtonsLeft:boolean;
    iconBox_hasTextButtonsLeft:boolean;
    onClearFilterClick: () => void;
    onClearFilterClick_internal: () => void;
    onFilterClick: () => void;
    onFilterChange: () => void;
    onRefreshClick: () => void;
    clearSearchQuery: () => void;
    refreshVisible: boolean;
    searchString: string;

    searchStringValidation: ()=> string;
    searchStringMinLenght:number
    currentTabView:string;
    tabViews:{ [id: string] : {name:string, iconClass:string, elem:JQuery}} ;
    enableQueryBinding: boolean;
    hideAdvanceFilterIcon: boolean;
    showMainBox: boolean;
    refreshInSubtitle: boolean;

    filter:{
        searchStringRaw: string;
    }
}

class listWrapperController{
    private _skipOne_searchStringRaw_update:boolean;

    constructor(private $element, private $scope: IListWrapperScope, private transclude: any, $compile:ng.ICompileService, private CommonService: CommonServices, private $timeout:ng.ITimeoutService){
        this._skipOne_searchStringRaw_update = false;
        this.$scope.missingTabViews = true;
        this.$scope.missingIconBoxLeft = true;
        this.$scope.missingTitle = this.$scope.missingTitle === undefined ? true : this.$scope.missingTitle;
        this.$scope.refreshInSubtitle = this.$scope.refreshInSubtitle === undefined ? false : this.$scope.refreshInSubtitle;
        this.$scope.missingSubTitle = true;
        this.$scope.missingTitleIconBox = true;
        this.$scope.missingSubTitleIconBox = true;
        this.applyTransclude(".group-operation-controls-transclude", "groupOperationControls");
        this.applyTransclude(".icon_box-transclude", "iconBox");
        this.applyTransclude(".icon_box-left-transclude", "iconBoxLeft");
        this.applyTransclude(".list-table-transclude", "listTable");
        this.applyTransclude(".title-transclude", "listTitle");
        this.applyTransclude(".sub-title-transclude", "listSubTitle");
        this.applyTransclude(".title-icon-Box-transclude", "listTitleIconBox");
        this.applyTransclude(".sub-title-icon-Box-transclude", "listSubTitleIconBox");
        this.$scope.missingAdvanceFilter = true;
        this.$scope.missingListTable = true;
        this.applyTransclude(".filters-transclude", "filters");

        this.applyMultiTransclude(".tab-views-transclude", "tabViews");

        $scope.showAdvanceFilter = true;

        if($scope.disableSearchString == null){
            $scope.disableSearchString = false;
        } else if(typeof $scope.disableSearchString == "string"){
            $scope.disableSearchString  = (<any>($scope.disableSearchString)).parseBoolean();
        }

        if($scope.showSearchString == null){
            $scope.showSearchString = ()=>{ return true; }
        }
        if($scope.showClearButton == null) {
            $scope.showClearButton = !!$scope.showSearchString;
        }

        $scope.filter = {searchStringRaw:this.$scope.searchString || ""};
        if($scope.searchStringValidation == null){
            this.$scope.searchStringValidation = ()=>{
                return this.CommonService.searchStringValidateErrorMessage(this.$scope.filter.searchStringRaw, this.$scope.searchStringMinLenght);
            };
        }

        this.$scope.$watch("filter.searchStringRaw",(newValue:string, oldValue:string)=>{
            if(newValue != this.$scope.searchString ){
                if(this.$scope.searchStringValidation() == null) {
                    this.$scope.searchString = newValue;
                }else{
                    this._skipOne_searchStringRaw_update = this.$scope.searchString != null;
                    this.$scope.searchString = null;
                }
            }
        });
        this.$scope.$watch("searchString",(newValue:string, oldValue:string)=>{
            if(newValue != this.$scope.filter.searchStringRaw && this._skipOne_searchStringRaw_update == false){
                this.$scope.filter.searchStringRaw = newValue;
            }
            this._skipOne_searchStringRaw_update = false;
        });

        this.$scope.onClearFilterClick_internal = ()=>{
            this.$scope.$parent.$emit("smartTable:clearRowCheckbox");
            if(typeof this.$scope.onClearFilterClick == "function") {
                this.$scope.onClearFilterClick();
            }
        };

        this.$scope.clearSearchQuery = ()=>{
            this.$timeout(()=>{
                this.$scope.searchString = "";
            },10);
        }
        
        if(this.$scope.showMainBox = this.$scope.showMainBox === undefined)
         this.$scope.showMainBox =true;
        else
         this.$scope.showMainBox =this.$scope.showMainBox;
    }

    private applyTransclude(targetSelector, TranscludeName){
        var TranscludeLocations = this.$element[0].querySelectorAll(targetSelector);
        _.each(TranscludeLocations, (TranscludeLocation)=>{
            this.transclude(this.$scope.$parent, (transEl, transScope)=> {
                angular.element(TranscludeLocation).append(transEl);
                if(TranscludeName == "filters"){
                    if(transEl.attr("ng-show")){
                        transScope.$watch(()=>{ return transEl.attr('class'); },(newValue)=>{
                            if (newValue.match(/ng-hide/) !== null) {
                                this.$scope.missingAdvanceFilter = true;
                            }else{
                                this.$scope.missingAdvanceFilter = false;
                            }
                        });
                    }else {
                        this.$scope.missingAdvanceFilter = false;
                    }
                }else if(TranscludeName == "listTable"){
                    this.$scope.missingListTable = false;
                }else if(TranscludeName == "listTitleIconBox"){
                    this.$scope.missingTitleIconBox = false;
                }else if(TranscludeName == "iconBoxLeft"){
                    this.$scope.missingIconBoxLeft = false;
                    this.$scope.iconBox_hasIconButtonsLeft = transEl[0].querySelectorAll("a .fa").length > 0;
                    this.$scope.iconBox_hasTextButtonsLeft = transEl[0].querySelectorAll("button.btn").length > 0;
                }else if(TranscludeName == "listTitle"){
                    this.$scope.missingTitle = false;
                }else if(TranscludeName == "listSubTitle"){
                    this.$scope.missingSubTitle = false;
                }else if(TranscludeName == "listSubTitleIconBox") {
                    this.$scope.missingSubTitleIconBox = false;
                }else if(TranscludeName == "iconBox"){
                    this.$scope.iconBox_hasIconButtons = transEl[0].querySelectorAll("a .fa").length > 0;
                    this.$scope.iconBox_hasTextButtons = transEl[0].querySelectorAll("button.btn").length > 0;
                    if(this.$scope.iconBox_hasIconButtons && this.$scope.iconBox_hasTextButtons){
                        console.error("Using text buttons and icon buttons in transclude 'icon-box' in control 'list-wrapper' buttons will be display with  incorrect styles.")
                    }
                }
            }, this.$scope.$parent.$parent, TranscludeName );
        });
    }

    private applyMultiTransclude(targetSelector, TranscludeName){
        var TranscludeLocations = this.$element[0].querySelectorAll(targetSelector);
        var defaultTabView = null;
        _.each(TranscludeLocations, (TranscludeLocation)=>{
            this.transclude(this.$scope.$parent, (transEl, transScope)=> {
                var tabViews = transEl.children();
                _.each(tabViews,(tabViewElem)=>{
                    this.$scope.missingTabViews = false;
                    var tabView = angular.element(tabViewElem);
                    var viewName = tabView.attr("name");
                    var iconClass = tabView.attr("icon");
                    defaultTabView = this.$scope.currentTabView || viewName;
                    this.$scope.tabViews = this.$scope.tabViews || {};
                    tabView.addClass("ng-hide");
                    if(viewName != null && viewName.length > 0 && iconClass != null && iconClass.length > 0) {
                        this.$scope.tabViews[viewName] = {name: viewName, iconClass: iconClass, elem: tabView};
                    }else if(viewName == null || viewName.length == 0){
                        console.error(`In directive 'list-wrapper' in transclude '${TranscludeName}' missing attributes 'name' in `, transEl)
                    }else if(iconClass == null || iconClass.length == 0){
                        console.error(`In directive 'list-wrapper' in transclude '${TranscludeName}' missing attributes 'icon' in `, transEl)
                    }
                });
                angular.element(TranscludeLocation).append(transEl);

            }, this.$scope.$parent.$parent, TranscludeName );
        });

        this.$scope.currentTabView = defaultTabView;

        this.$scope.$watch("currentTabView",(newValue:string, oldvalue:string)=> {
            if(newValue == null) {
                newValue = this.$scope.currentTabView = defaultTabView;
            }
            if (this.$scope.tabViews != null && this.$scope.tabViews[oldvalue] != null && this.$scope.tabViews[oldvalue].elem != null) {
                this.$scope.tabViews[oldvalue].elem.addClass("ng-hide");
            }

            if (this.$scope.tabViews != null && this.$scope.tabViews[newValue] != null && this.$scope.tabViews[newValue].elem != null) {
                this.$scope.tabViews[newValue].elem.removeClass("ng-hide");

            }
        });
    }
}



angularModule.directive('listWrapper', ['$branding',function($branding: app.branding.IBrandingService){
    return {
        restrict: 'E',
        replace: true,
        transclude: {
            'listTitle':'?listTitle',
            'filters':'?filters',
            'iconBox':'?iconBox',
            'iconBoxLeft':'?iconBoxLeft',
            'groupOperationControls':'?groupOperationControls',
            'listTable':'?listTable',
            'listSubTitle':'?listSubTitle',
            'tabViews':'?tabViews',
            'listTitleIconBox':'?listTitleIconBox',
            'listSubTitleIconBox':'?listSubTitleIconBox'
        },
        scope: {
            onClearFilterClick: "=",
            onFilterClick: "=",
            onFilterChange: "=",
            onRefreshClick: "=?",
            refreshVisible: "=?",
            searchString: "=?",
            showSearchString: "=?",
            showClearButton: "=?",
            disableSearchString: "=?",
            searchStringValidation: "=?",
            searchStringMinLenght:"=?",
            currentTabView: "=?",
            enableQueryBinding: "=?",
            hideAdvanceFilterIcon: "=?",
            showMainBox: "=?",
            missingTitle: "@?",
            refreshInSubtitle: "=?"
        },
        controller: ['$element','$scope','$transclude', '$compile','CommonServices','$timeout', listWrapperController],
        link: function(scope:IListWrapperScope, element, attrs, controller, transclude) {

        },
        //templateUrl: "/components/src/directives/list-header/list-wrapper.html",
        templateUrl: $branding.getTemplateUrl("directives.list-header.list-wrapper"),
    };
}]);
