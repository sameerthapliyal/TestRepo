///<reference path="../../../../../typings/browser.d.ts"/>

interface IProxListAttributes extends ng.IAttributes {
    
}

export class ProxListController {
    public static $inject = ["$scope"];

    constructor(private $scope: ng.IScope) {}
    
    refresh(refreshEventName: string = 'smartTable:refreshRequired') {
        this.$scope.$broadcast(refreshEventName);
    }
}

function ProxListDirective() {
    return {
        restrict: "A",
        controller: ProxListController
    }
}

export default angular.module('directives.proxList', [])
    .directive('proxList', ProxListDirective);