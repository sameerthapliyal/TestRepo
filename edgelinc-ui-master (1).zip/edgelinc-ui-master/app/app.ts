///<reference path="app.d.ts"/>

import "underscore";

import "angular";
import "angular-bootstrap";
import "angular-route";
import "angular-sanitize";
import "angular-translate";
import "angular-translate-loader-url";
import "angular-translate-handler-log";
import "oclazyload";
import "angular-http-auth";

import decoratorsModule from "components/src/utilities/decorators";
import proxSpinnerModule from "components/src/directives/prox-spinner";
import proxBoxModule from "components/src/directives/prox-box";
import proxAlarmIconModule from "components/src/directives/prox-alarm-icon";
import enableWordBreakModule from "components/src/directives/enable-break-word-when-words-longer-than";

import BrandingModule from "components/src/services/BrandingService";
import ConfigModule from "components/src/services/ConfigService";
import AuthorizationServiceModule, {AuthService}  from "components/src/services/AuthService";

import IndexModule from "views/Index";
import LoginModule from "components/src/modules/login";

interface ISystemWithSettings extends System {
    app: {
        useTemplateCache: boolean;
    }
}

var appModule = angular.module('myApp', [
    'ui.bootstrap',
    'ngRoute',
    'ngSanitize',
    'pascalprecht.translate',
    'oc.lazyLoad',
    'http-auth-interceptor',

    decoratorsModule.name,
    proxSpinnerModule.name,
    proxBoxModule.name,
    proxAlarmIconModule.name,
    enableWordBreakModule.name,
    
    BrandingModule.name,
    ConfigModule.name,
    
    IndexModule.name,
    LoginModule.name,
]).
    config(['$routeProvider','$httpProvider','$ocLazyLoadProvider', function($routeProvider, $httpProvider: ng.IHttpProvider, $ocLLP) {
        //$routeProvider.otherwise({redirectTo: '/views/dashboard'});
        $ocLLP.config({debug: window.CONFIG.DEBUG_LAZYLOAD});
        if(window.CONFIG.ENABLE_EAPI_COOKIE) {
            $httpProvider.defaults.withCredentials = true;
        }
        
        var originalWhen = $routeProvider.when;
        $routeProvider.when = (path, route)=>{
            route = route || {};
            var originalTemplateUrl = route.templateUrl;
            
            route.templateUrl = ()=>{
                var authorizationService:AuthService = angular.element(document.body).injector().get("AuthorizationService");
                let currentRestrictions:string[] =  authorizationService.getRestrictionsForPath(path);
                let hasAccess = true;
                if(currentRestrictions && currentRestrictions.length>0) {
                    hasAccess = authorizationService.hasLoginUserAnyOfPermissions(currentRestrictions);
                }
                if(hasAccess === false){
                    console.log("Access deny", path);
                    return "/views/CM/access_denied.html"
                }else if( typeof originalTemplateUrl == "function"){
                    return originalTemplateUrl()
                }else if(typeof originalTemplateUrl == "string"){
                    return originalTemplateUrl;
                }else{
                    return originalTemplateUrl;
                }
            };
            if(route.hasOwnProperty("reloadOnSearch") == false){
                route.reloadOnSearch = false;
            }
            originalWhen.call($routeProvider, path, route);
        };
    }])
    .config(['$configProvider', function($configProvider) {
        $configProvider.init(window.CONFIG);
    }])
    .config(['$brandingProvider', function(bp) {
        bp.init(window.BRANDING);
    }])
    .config(['$translateProvider', function($translateProvider: ng.translate.ITranslateProvider) {
        $translateProvider
            .useUrlLoader('locale.json')
            .preferredLanguage('en')
            .fallbackLanguage('en')
            .useSanitizeValueStrategy('escapeParameters')
            .useMissingTranslationHandlerLog();
    }])
    .run(['$rootScope', '$config','$ocLazyLoad', '$route', '$branding', '$q', 'AuthorizationService', function($rootScope, $config, $ocLazyLoad, $route, $branding, $q: ng.IQService, authService:AuthService){
        $rootScope.logout = function(){
            sessionStorage.clear();
            $rootScope.$broadcast('event:auth-logout');
        };
        $rootScope.refreshToken = ()=> {authService.refreshToken()};
        $rootScope.scheduleTokenRefresh = () => {authService.tokenRefreshing = !authService.tokenRefreshing; };
        $rootScope.tokenIsScheduleToRefresh = () => {return authService.tokenRefreshing;};
        $rootScope.baseApiUrl = $config.EAPI_URL + "/";
        $rootScope.baseApiURLWithVersion = $config.EapiRoot19;
        //$rootScope.baseDdsUrlWithVersion = $config.EAPI_URL + "/rest/1.7/device_models/";
        $rootScope.baseDdsUrlWithVersion = $config.EAPI_URL + "/rest/legacy/dds/";
        $rootScope.brandConstants = window.BRANDING.ui.constants;
        
        $rootScope.branding = {
            appTitle: $branding.getUISettings().appTitle,
            appFooter: $branding.getUISettings().appFooter
        };
    
        var tokenRefreshingIntervalHandler = null;
        $rootScope.$watch(()=>{return window.CONFIG.PRODUCTION || $config.PRODUCTION;},(newValue)=>{
            $rootScope.showRefreshTokem =  !(newValue);
            if(tokenRefreshingIntervalHandler){
                clearInterval(tokenRefreshingIntervalHandler);
            }
            if($rootScope.showRefreshTokem ){
                $rootScope.tokenExpireIn_Display = authService.tokenExpireIn_Display();
                $rootScope.tokenRefreshIn_Display = authService.tokenRefreshIn_Display();
                tokenRefreshingIntervalHandler = setInterval(() => {
                    $rootScope.tokenExpireIn_Display = authService.tokenExpireIn_Display();
                    $rootScope.tokenRefreshIn_Display = authService.tokenRefreshIn_Display();
                }, 250);
            }
        });
        

        $branding.config = window.BRANDING;

        var views = window.BRANDING.paths;
        var modules = window.BRANDING.modules;

        var loadedViews = 0;
        var loadedModules = 0;

        $rootScope.lazyLoaded = 0;
        $rootScope.lazyToLoad = modules.length + views.length + 1;

        function loadTemplates() {
            var settings = (<ISystemWithSettings>System).app;
            if(settings && settings.useTemplateCache) {
                return $ocLazyLoad.load("dist/templates.js");
            } else {
                return $q.when(null);
            }
        }

        function loadView(path): ng.IPromise<string[]> {
            return System.import(path)
                .then(function(m) {
                    var module = m.default;
                    if(module) {
                        return $ocLazyLoad.load(module);
                    } else {
                        console.warn("View '" + path + "' is not compatible with SystemJS.");
                        return $ocLazyLoad.load(path);
                    }
                })
                .then(function(module){
                    loadedViews++;
                    $rootScope.lazyLoaded = loadedViews + loadedModules;
                    return module;
                });
        }

        function loadModule(path): ng.IPromise<string> {
            return System.import(path)
                .then(function(m) {
                    var module = m.default;
                    if(module) {
                        return module.name;
                    } else {
                        console.warn("Module '" + path + "' is not compatible with SystemJS.");
                        return null;
                    }
                })
                .then(function(module){
                    loadedModules++;
                    $rootScope.lazyLoaded = loadedViews + loadedModules;
                    return module;
                });
        }

        function loadModules() {
            var modulePromises: ng.IPromise<string>[] = [];
            for (var i = 0; i < modules.length; i++) {
                var module = loadModule(modules[i]);
                modulePromises.push(module);
            }
            return $q.all(modulePromises)
                .then((loadedModules: string[]) => {
                    var angularModule = angular.module('lazyLoaded.modules', loadedModules);
                    return $ocLazyLoad.load(angularModule);
                })
        }

        function loadViews() {
            var viewsPromises: ng.IPromise<string[]>[] = [];
            for (var i = 0; i < views.length; i++) {
                var module = loadView(views[i]);
                viewsPromises.push(module);
            }
            return $q.all(viewsPromises)
                .then((modules: string[][]) => {
                    var moduleNames = [];
                    for (var i = 0; i < modules.length; i++) {
                        if(modules[i]) {
                            moduleNames.concat(modules[i]);
                        }
                    }
                    var angularModule = angular.module('lazyLoaded.views', moduleNames);
                    return $ocLazyLoad.load(angularModule);
                })
        }

        // loading scripts in proper order
        $q.when(null)
            .then(loadTemplates)
            .then(loadModules)
            .then(loadViews)
            .then(() => {
                $ocLazyLoad.load('/views/lastView/lastView.js').then(function(){
                    $rootScope.lazyLoaded = $rootScope.lazyToLoad;
                    if(!authService.isRedirecting()) {
                        $route.reload();
                    }
                });
            })
            .catch(console.error.bind(console));
        


        $rootScope.$watch( function() {
            var windowWidth=document.body.clientWidth;
            if($rootScope.maxWold != windowWidth)
            {
                $rootScope.$broadcast("event:browserWindowChanged", windowWidth);
                $rootScope.maxWold = windowWidth;
            }
        });
    }]);

angular.element(document).ready(function() {
    angular.bootstrap(document, [ appModule.name ], {
        strictDi: false
    });
});

export default appModule;