/// <reference path="../typings/browser.d.ts" />
/// <reference path="components/src/definitions/ConfigConstant.d.ts"/>

declare module App {
    interface IRootScope extends ng.IScope {
        baseApiUrl: string;
        baseApiURLWithVersion:string;
        baseDdsUrlWithVersion:string;
        AuthorizationUrl:string;
        selectedDevices: string[];
        branding: {
            appTitle: string;
            appFooter: string;
        }
        brandConstants: any;
    }
}

interface Window {
    CONFIG: app.config.IConfigConstant;
    BRANDING: any;
}

declare module angular.route {
    interface ICurrentRoute {
        originalPath: string;
    }
}